# VP — Codex live-work instructions

## Latest firmware and feature audit — 2026-10-05

- Later authorized 35 C trial, 18:00–18:16 local: only H28 was written (2→1→2); fixed target was already 3500. Fifteen minutes observed, then curve mode H28=2 and curve target H32=2650 were verified restored. See `docs/heating35-test-2026-10-05.md`.
- During that trial compressor frequency rose to 48 Hz and flow reached 35.5 C. I227/I228 became dynamic (raw consumed=1, produced=4–6). Whole-kW interpretation is plausible, not calibrated; asynchronous updates and integer resolution prevent precise instantaneous COP. Brine candidates remained zero while running. The audit-only no-write statement below does not cover this later explicitly authorized trial.

- Live I3/H10 = 30101, interpreted as A1M firmware 3.1.1; I8/I9 = 8000/1.
- All 467 FTC6-applicable entries in the FTC register table were successfully read, including I193–270 and H342–429. Counts include mirrors and signed/unsigned variants, not independent features. These are not proven maximum addresses.
- See `docs/features-3.1.1-2026-10-05.md` and `docs/register-inventory-3.1.1.json` for the complete audit and raw-log provenance.
- Historical energy records dated 2026-10-04 permit calculated ratios: heating 7.77/3.68 = 2.11, DHW 3.53/1.48 = 2.39. They are not live COP. Total energy registers return zero despite nonzero components; use matching dated components. Power fields I227/I228 are readable but unit/timebase remains unvalidated.
- No validated TH32/TH34, brine flow, or brine pump RPM mapping through A1M. Generic CRHV brine fields remain zero; Flow Rate 2 now responds with zero but is not identified as brine flow.
- Current H28=2 and H32=2700; do not restore September's temporary test settings over this newer externally changed state. No device writes were performed during this audit.

This repository is a focused workspace for Mitsubishi Geodan / FTC6 investigation and control.

## Live device

Shelly Pro 2 with Shelly Pro Modbus Add-On:

- IP: `DEVICE_HOST`
- Modbus client component: `mbrtuclient:100`
- Serial component: `serial:100`
- Mode: `mb_client`
- Serial: `9600 8N1`
- Procon A1M slave ID: `1`
- Heat pump: Mitsubishi Geodan `EHGT17D-YM9ED`
- Controller: FTC6
- A1M connected via CN105

Known-good read example:

```text
http://DEVICE_HOST/rpc/MbRtuClient.ReadInputRegisters?id=100&sid=1&addr=9&qty=1
```

Expected result:

```json
{"values":[1]}
```

`1` means ATW detected.

## Safety / working rules

- Prefer read-only discovery first.
- Before any write, read the target register and record the original value.
- For writes, change only one documented control at a time and immediately read it back.
- Do not write undocumented registers by brute force.
- Do not change service/DIP/function-setting registers.
- Do not reset faults, counters, configuration, or function settings unless explicitly requested.
- Do not disable native Mitsubishi safeties.
- For DHW testing, use the documented A1M/FTC control path and restore the prior state after the test if the command is intended as temporary.
- Record all live commands and observations in the repository.

## Confirmed live observations

A1M status:

- Input raw addr 8 = `8000` => no fault
- Input raw addr 9 = `1` => ATW

Confirmed register extents by live probing:

- Input registers: valid through raw addr `152`; `153` times out.
- Holding registers: valid through raw addr `271`; `272` times out.

Important observed Holding values from one live snapshot:

```text
25 = 1
26 = 0
27 = 0
28 = 2
29 = 2
30 = 5200
31 = 5200
32 = 2650
33 = 2650
34 = 3500
35 = 3500
36 = 0
37 = 0
38 = 0
```

Working interpretation from Mitsubishi A1M/FTC documentation:

- 25: system on/off
- 26: operating mode/status control field
- 27: DHW mode
- 28/29: Zone 1/2 heating/cooling control mode; observed `2` = heating heat curve
- 30/31: DHW target; observed `5200` = 52.00 C
- 32/33: Zone 1 heating/cooling target; observed 26.50 C
- 34/35: Zone 2 heating/cooling target; observed 35.00 C
- 37: force DHW / DHW boost candidate; verify exact semantics before write

Observed telemetry snapshot included:

- compressor frequency 0 Hz
- outdoor approximately 16 C
- flow approximately 35 C
- return approximately 29 C
- DHW tank approximately 50.5 C
- no active A1M fault

## Missing values of special interest

Find whether any documented or inferable A1M-accessible values exist for:

- brine pump ON/OFF
- brine pump command / output step
- brine pump RPM
- brine inlet temperature TH32
- brine outlet temperature TH34
- brine flow / source-side flow, if exposed
- primary circuit flow rate
- FTC output-signal bitfields that may reveal pump state
- FTC Running Information values that may be available indirectly through A1M

Do not assume that service-menu request codes are directly mapped to Modbus addresses; prove mappings from documentation and live correlation.

## Documentation clues

The Mitsubishi Geodan service manual confirms that FTC/Geodan internally knows more than the currently identified A1M registers, including:

- brine pump rotational-speed supervision
- TH32 / TH34 thermistors
- primary-circuit flow rate (Running Information request code 540)
- FTC output/input signal information
- FTC software version request codes 190/191

The goal is to determine whether A1M exposes any of these through the valid register map or bitfields.

## Replacement interface — 2026-09-15

- Firmware raw I3/H10 is now 30015 (interpreted 3.0.15), replacing raw 20004.
- The register extents above describe the OLD interface. The replacement also successfully reads I153–173 and H272–299; these are not established maximum addresses.
- Historical energy records and I173/H299 water flow are now readable. Energy dates were 2026-09-09; flow was zero and has not been validated during operation.
- Initially status was 6999/255; it changed to 8000/1 without our intervention. Gate telemetry validity on device communication, not just Modbus transport success.
- Connected readings showed H25=0 and H26=0. No writes were made in this replacement-interface investigation.
- See `docs/replacement-interface-2026-09-15.md` for values, scaling errata and remaining uncertainties. Historical reports remain dated observations.
