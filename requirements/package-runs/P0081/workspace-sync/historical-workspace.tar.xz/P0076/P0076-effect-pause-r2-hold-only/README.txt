P0076 r2 EFFECT native-pause handling + DIP addressing; hardware validation pending.
One compact BIN for both units. Address comes from DIP at startup.
Program only compact BIN after separate full98304-byte application erase.
Never erase/write the resident bootloader. Physical provisioning needs operator handoff.
RAM-only restore is not safe for unattended control after reset.
