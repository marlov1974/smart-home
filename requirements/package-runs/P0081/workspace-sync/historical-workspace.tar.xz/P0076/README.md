# P0076 — lokal leverans

Byggd och verifierad offline 2026-10-08. Inte flashad eller publicerad till GitHub.

- `firmware/procon-p76.bin`: kompakt firmware, 16 476 byte. Kräver separat full
  radering av det 98 304 byte stora applikationsområdet enligt FLASH_PLAN.json.
  Bootloadern ska bevaras. Filen innehåller ingen utfyllnad med FF.
- Samma binär för båda enheterna. DIP i fysisk ordning SW1–SW8:
  `10000110` = adress 1, `01000110` = adress 2; avläsning vid uppstart.
  Stöd för adress 1–30. Fysisk korrelation måste verifieras med en enhet åt gången.
- `procon-melcobems-mini-a1m/`: komplett källkod, tester och dokumentation.
- `smart-home/`: paketdesign, funktionskatalog och verifiering för P0076.
- `evidence/`: faktiska testloggar och kontroll av publik källkod.
- `P0076-effect-dip-r1.zip`: firmwareartefakter och motsvarande GPL-källkod.

37 ARM-fall, sju C-testsamlingar med sanitizer och host-/flashmocktester passerar.
En tvingad ombyggnad ger identisk BIN. Hårdvarutest av DIP, gemensam RS485-buss
och EFFECT återstår. Återställning efter processorreset är fortfarande inte
beständig; använd inte EFFECT oövervakat. Inga P0077-försök har körts.

Arbetskopiorna innehåller förberedda, staged ändringar. Det ursprungliga Smart
Home-checkoutets tidigare ändringar är bevarade. Standalone-kopian baseras på
ett lokalt P0075-källkodssnapshot med syntetisk Git-historik; publicera inte
den historiken direkt. Vid synkning ska ändringarna appliceras på aktuell
upstream-historik och granskas utan att skriva över parallellt arbete.

## Senare godkänd flashning

Överföringen är nu kvitterad:69/69 paket och full applikationsradering. Normal
uppstart återstår att verifiera efter fysisk DIP/omstart. Se
`smart-home/requirements/package-runs/P0076/flash-verification.md`.

`P0076-effect-dip-r1-flashfix.zip` ersätter tidigare ZIP för källkod och
överföringsverktyg. BIN är oförändrad. Rättelsen gäller Shellys deklarationsordning
och har39 godkända tester. Det äldre paketet bevaras som byggproveniens.

## Verifierad normal uppstart

Efter fysisk omstart är P0076 r1, DIP0x61/adress1 och stabilt processor-ID nu
verifierade.20/20 lässvar är CRC-giltiga och CN105-värden uppdateras. Se
`smart-home/requirements/package-runs/P0076/normal-verification.md`. Styrning
aktiverades inte. Shelly-skripten är stoppade och tillfällig UART-baud återställd.
