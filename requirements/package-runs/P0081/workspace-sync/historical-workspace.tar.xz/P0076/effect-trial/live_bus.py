"""P0076 supervised site transport. No network activity on import.

Only FC04 and explicitly armed 6000W/38C/180s EFFECT or AUTO are permitted.
No persistent serial changes, flash, reboot, native bypass or other controls.
"""
import base64,fcntl,hashlib,json,time
from datetime import datetime,timezone
from pathlib import Path
from urllib.request import Request,urlopen

HOST='DEVICE_HOST';SLOT=8;DEVICE='shellypro2-80f3dac8bfec'
def utc():return datetime.now(timezone.utc).isoformat()
def crc16(data):
    c=65535
    for b in data:
        c^=b
        for _ in range(8):c=(c>>1)^(0xa001 if c&1 else 0)
    return c
def with_crc(b):return b+crc16(b).to_bytes(2,'little')
class ModbusException(RuntimeError):
    def __init__(self,code):self.code=code;super().__init__('Modbus exception '+str(code))
def validate_words(words):
    if len(words)!=8 or any(type(w)is not int or not 0<=w<=65535 for w in words) or not 1<=words[1]<=65535:
        raise ValueError('Invalid command word shape/sequence')
    if words[0]==0xc076:
        if words[2:]!=[5,6000,3800,180,1,3]:raise ValueError('Only fixed authorized EFFECT intent')
    elif words[0]==0xc072:
        if words[2:]!=[1,0,0,0,0,2]:raise ValueError('Only AUTO restoration')
    else:raise ValueError('Command magic')
def bridge_source(ttl_s):
    if not 120<=ttl_s<=4500:raise ValueError('Bridge lifetime bound')
    return '''let trialUart=UART.get(0);
if(!trialUart)throw new Error('UART_UNAVAILABLE');
let trialActive=false,trialArmed=false,trialWaiting=false,trialDone=false;
let trialRaw='',trialExpected=0,trialFunction=0,trialStarted=0,trialError='';
function trialCRC(s){let c=65535;for(let i=0;i<s.length;i++){c=c^s.charCodeAt(i);for(let j=0;j<8;j++)c=(c>>>1)^((c&1)?40961:0);}return c;}
function trialWord(s,i){return s.charCodeAt(i)*256+s.charCodeAt(i+1);}
function trialRestore(){trialActive=false;trialArmed=false;trialWaiting=false;trialUart.configure({baud:115200,format:'8N1'});return JSON.stringify({restored:true});}
function trialBegin(){if(trialActive)throw new Error('ACTIVE');trialUart.configure({baud:9600,format:'8N1'});trialActive=true;return JSON.stringify({baud:9600,format:'8N1'});}
function trialArm(){if(!trialActive||trialWaiting||trialError)throw new Error('ARM_GATE');trialArmed=true;return JSON.stringify({armed:true});}
function trialSend(encoded){
 if(!trialActive||trialWaiting||trialError)throw new Error('TX_GATE');
 let s=atob(encoded);if(s.charCodeAt(0)!==1||trialCRC(s)!==0)throw new Error('FRAME');
 let fn=s.charCodeAt(1),n=0;
 if(fn===4){
   let addr=trialWord(s,2),qty=trialWord(s,4);
   if(s.length!==8||qty<1||qty>16||addr+qty>384)throw new Error('READ_RANGE');n=5+2*qty;
 }else if(fn===16){
   if(!trialArmed||s.length!==25||trialWord(s,2)!==300||trialWord(s,4)!==8||s.charCodeAt(6)!==16)throw new Error('WRITE_GATE');
   let w=[];for(let i=0;i<8;i++)w.push(trialWord(s,7+2*i));
   if(w[1]<1)throw new Error('SEQUENCE');
   if(w[0]===49270){if(w[2]!==5||w[3]!==6000||w[4]!==3800||w[5]!==180||w[6]!==1||w[7]!==3)throw new Error('EFFECT_SCOPE');}
   else if(w[0]===49266){if(w[2]!==1||w[3]!==0||w[4]!==0||w[5]!==0||w[6]!==0||w[7]!==2)throw new Error('AUTO_SCOPE');}
   else throw new Error('MAGIC');n=8;
 }else throw new Error('FUNCTION');
 trialRaw='';trialDone=false;trialExpected=n;trialFunction=fn;trialStarted=Shelly.getUptimeMs();trialWaiting=true;
 let sent=trialUart.send(s);if(sent!==s.length){trialError='SHORT_SEND';trialWaiting=false;}
 return JSON.stringify({sent:sent});
}
trialUart.recv(function(s){
 if(!trialWaiting){trialError='UNEXPECTED_RX';return;}
 if(Shelly.getUptimeMs()-trialStarted>2200){trialError='RX_TIMEOUT';trialWaiting=false;return;}
 trialRaw+=s;if(trialRaw.length>64){trialError='RX_OVERFLOW';trialWaiting=false;return;}
 if(trialRaw.length>=2&&trialRaw.charCodeAt(1)===(trialFunction|128))trialExpected=5;
 if(trialRaw.length>=trialExpected){
   if(trialRaw.length!==trialExpected||trialCRC(trialRaw)!==0)trialError='RX_FRAME';
   trialDone=true;trialWaiting=false;
 }
});
function trialResult(){
 if(trialWaiting&&Shelly.getUptimeMs()-trialStarted>2200){trialError='RX_TIMEOUT';trialWaiting=false;}
 return JSON.stringify({done:trialDone,waiting:trialWaiting,error:trialError,base64:btoa(trialRaw)});
}
function trialExpire(){trialRestore();Shelly.call('Script.Stop',{id:8});}
Timer.set(TTL_MS,false,trialExpire);
'''.replace('TTL_MS',str(ttl_s*1000))

class Session:
    def __init__(self,out,ttl_s=4500):
        self.out=Path(out);self.out.mkdir(parents=True,exist_ok=False)
        self._lock=(Path(__file__).resolve().parent/'.session.lock').open('a+')
        try:fcntl.flock(self._lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BaseException:self._lock.close();raise RuntimeError('Another local trial session owns the serial transport')
        self.ttl_s=ttl_s;self.changed=False;self.active=False;self.armed=False
    def save(self,name,obj):
        p=self.out/name;p.write_text(json.dumps(obj,indent=2)+'\n');p.chmod(0o600)
    def log(self,kind,obj):
        with (self.out/'events.jsonl').open('a') as f:f.write(json.dumps({'timestamp':utc(),'kind':kind,'data':obj})+'\n')
    def rpc(self,method,params=None):
        params=params or {};shown=dict(params)
        if 'code'in shown:shown['code']='sha256:'+hashlib.sha256(shown['code'].encode()).hexdigest()
        self.log('rpc_request',{'method':method,'params':shown})
        req=Request('http://'+HOST+'/rpc',data=json.dumps({'id':1,'method':method,'params':params}).encode(),headers={'Content-Type':'application/json'})
        try:
            with urlopen(req,timeout=8) as r:raw=r.read(65537)
            if len(raw)>65536:raise RuntimeError('RPC size')
            reply=json.loads(raw)
            if reply.get('id')!=1 or 'error'in reply:raise RuntimeError(str(reply))
            result=reply['result'];logged=result
            if method=='Script.GetCode':logged={**result,'data':'sha256:'+hashlib.sha256(result['data'].encode()).hexdigest()}
            self.log('rpc_response',logged);return result
        except Exception as e:self.log('rpc_error',str(e));raise
    def evaluate(self,code):
        return json.loads(self.rpc('Script.Eval',{'id':SLOT,'code':code})['result'])
    def identity(self,running):
        device=self.rpc('Shelly.GetDeviceInfo');serial=self.rpc('Serial.GetConfig',{'id':100})
        scripts=self.rpc('Script.List')['scripts']
        relays=[self.rpc('Switch.GetStatus',{'id':i})['output'] for i in (0,1)]
        if device.get('id')!=DEVICE or device.get('model')!='SPSW-202XE12UL':raise RuntimeError('Shelly identity')
        if serial.get('mode')!='js_uart' or serial.get('serial')!={'baud':115200,'format':'8N1'}:raise RuntimeError('Serial drift')
        own=[s for s in scripts if s['id']==SLOT]
        if len(own)!=1 or own[0]['name']!='P0075 write reference':raise RuntimeError('Slot identity')
        if not all(s['enable'] is False and s['running'] is (running and s['id']==SLOT) for s in scripts):raise RuntimeError('Serial ownership')
        if relays!=[False,False]:raise RuntimeError('Relay state')
        return {'device':device,'serial':serial,'scripts':scripts,'relays':relays}
    def read_code(self):
        text=''
        while True:
            p=self.rpc('Script.GetCode',{'id':SLOT,'offset':len(text),'len':1024});text+=p['data']
            if len(text)>18000:raise RuntimeError('Source size')
            if not p['left']:return text
            if not p['data']:raise RuntimeError('Source stalled')
    def start(self):
        self.save('preflight-shelly.json',self.identity(False))
        (self.out/'prior-script.js').write_text(self.read_code())
        source=bridge_source(self.ttl_s);(self.out/'bridge.js').write_text(source)
        self.save('bridge-manifest.json',{'sha256':hashlib.sha256(source.encode()).hexdigest(),'ttl_s':self.ttl_s})
        self.changed=True
        try:
            for offset in range(0,len(source),1024):self.rpc('Script.PutCode',{'id':SLOT,'code':source[offset:offset+1024],'append':offset!=0})
            if self.read_code()!=source:raise RuntimeError('Source readback')
            self.rpc('Script.Start',{'id':SLOT});time.sleep(.3)
            health=self.rpc('Script.GetStatus',{'id':SLOT})
            if not health['running'] or health.get('errors') or health['mem_free']<8192:raise RuntimeError('Script health')
            self.identity(True)
            if self.evaluate('trialBegin()')!={'baud':9600,'format':'8N1'}:raise RuntimeError('Runtime UART')
            self.active=True;time.sleep(.1)
        except BaseException:self.cleanup();raise
    def arm_control(self):
        if not self.active:raise RuntimeError('Not active')
        if self.evaluate('trialArm()')!={'armed':True}:raise RuntimeError('Arm')
        self.armed=True;self.log('control_scope_armed',{'watts':6000,'cap_cC':3800,'lease_s':180,'auto_restore':True})
    def exchange(self,frame):
        if not self.active:raise RuntimeError('Not active')
        self.log('rtu_tx',frame.hex());n=self.evaluate('trialSend('+json.dumps(base64.b64encode(frame).decode())+')')
        if n!={'sent':len(frame)}:raise RuntimeError('Short send')
        deadline=time.monotonic()+3
        while True:
            time.sleep(.10);r=self.evaluate('trialResult()')
            if r['error']:raise RuntimeError(r['error'])
            if r['done']:
                b=base64.b64decode(r['base64'],validate=True);self.log('rtu_rx',b.hex())
                if len(b)<5 or b[0]!=1 or crc16(b):raise RuntimeError('Bad Modbus frame')
                if b[1]==(frame[1]|128):
                    if len(b)!=5:raise RuntimeError('Exception length')
                    raise ModbusException(b[2])
                if b[1]!=frame[1]:raise RuntimeError('Function mismatch')
                return b
            if time.monotonic()>deadline:raise RuntimeError('Host RX timeout')
    def read(self,addr,qty):
        if type(addr)is not int or type(qty)is not int or not 0<=addr<384 or not 1<=qty<=16 or addr+qty>384:raise ValueError('Read range')
        b=self.exchange(with_crc(bytes([1,4])+addr.to_bytes(2,'big')+qty.to_bytes(2,'big')))
        if len(b)!=5+2*qty or b[2]!=2*qty:raise RuntimeError('Read shape')
        words=[int.from_bytes(b[i:i+2],'big') for i in range(3,3+2*qty,2)]
        self.log('read',{'address':addr,'values':words});return words
    def command(self,words):
        if not self.armed:raise RuntimeError('Control is not armed')
        validate_words(words)
        frame=with_crc(bytes.fromhex('01 10 01 2c 00 08 10')+b''.join(w.to_bytes(2,'big') for w in words))
        self.log('command',words);b=self.exchange(frame)
        if b!=with_crc(bytes.fromhex('01 10 01 2c 00 08')):raise RuntimeError('Write echo')
        return {'accepted':True,'words':words}
    def cleanup(self):
        errors=[];restored=False
        if self.changed:
            try:
                h=self.rpc('Script.GetStatus',{'id':SLOT})
                if h['running']:restored=self.evaluate('trialRestore()')=={'restored':True}
                else:errors.append('Volatile UART restoration unconfirmed: script stopped')
            except Exception as e:errors.append(str(e))
            for method,params in [('Script.Stop',{'id':SLOT}),('Script.SetConfig',{'id':SLOT,'config':{'enable':False}})]:
                try:self.rpc(method,params)
                except Exception as e:errors.append(str(e))
        final={}
        try:final=self.identity(False)
        except Exception as e:errors.append(str(e))
        result={'runtime_uart_restored':restored,'errors':errors,'final':final}
        self.save('cleanup.json',result);self.active=self.armed=False
        if not self._lock.closed:self._lock.close()
        return result
