#!/usr/bin/env python3
"""Render immutable P0076 trial logs offline; never imports the live transport.

Usage: /tmp/procon-dev-venv/bin/python plot_trial.py --run-dir PATH
Outputs PATH/report/{trial.png,trial.svg,samples.csv,report.json}.
"""
import argparse
import csv
from datetime import datetime, timedelta, timezone
import hashlib
import io
import json
import math
import os
from pathlib import Path
import tempfile

QUALITY = ('READY', 'WARMUP', 'PENDING', 'STALE', 'INVALID', 'ZERO_FLOW', 'DHW', 'LINK_LOSS')
PHASE = ('OFF', 'START', 'CAPTURE', 'HOLD', 'LIMITED', 'INVALID_FEEDBACK', 'RESTORING')
TELEMETRY = {0: 'brine_in_cC', 1: 'brine_out_cC', 3: 'supply_cC', 4: 'return_cC',
             6: 'primary_flow_cL_min', 7: 'water_heat_w', 8: 'compressor_hz',
             14: 'dhw_cC', 16: 'reported_flow_target_cC', 18: 'operating_mode', 19: 'heater_bits'}


def stamp(value):
    parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
    if parsed.tzinfo is None:
        raise ValueError('Log timestamp has no timezone')
    return parsed.astimezone(timezone.utc)


def number(value):
    return value if type(value) in (int, float) and math.isfinite(value) else None


def label(names, value):
    return names[value] if type(value) is int and 0 <= value < len(names) else 'UNKNOWN'


def load_records(path):
    """Read one immutable byte snapshot; tolerate only an unfinished last line."""
    source = path.read_bytes()
    snapshots, trials, ignored_partial = [], [], False
    lines = source.splitlines(keepends=True)
    for index, line in enumerate(lines):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except (ValueError, UnicodeDecodeError):
            if index == len(lines)-1 and not line.endswith(b'\n'):
                ignored_partial = True
                break
            raise ValueError('Invalid JSON on line ' + str(index+1)) from None
        kind, data = event.get('kind'), event.get('data')
        if kind not in ('snapshot', 'trial_sample') or not isinstance(data, dict):
            continue
        if 'feedback' not in data or 'telemetry' not in data:
            continue
        record = dict(data)
        record['_event_timestamp'] = event.get('timestamp')
        record['_event_line'] = index+1
        (trials if kind == 'trial_sample' else snapshots).append(record)
    selected = trials if trials else snapshots
    if not selected:
        raise ValueError('No recorded trial samples or decoded snapshots to plot')
    return selected, {'source_sha256': hashlib.sha256(source).hexdigest(),
                      'source_bytes': len(source), 'source_lines': len(lines),
                      'ignored_partial_last_line': ignored_partial,
                      'sample_kind': 'trial_sample' if trials else 'snapshot',
                      'active_trial_series_present': bool(trials)}


def flatten(records, metadata):
    first_time = stamp(records[0].get('timestamp') or records[0]['_event_timestamp'])
    is_trial = metadata['active_trial_series_present']
    first_elapsed = number(records[0].get('elapsed_s'))
    if is_trial and first_elapsed is None:
        raise ValueError('Trial sample has no finite elapsed_s')
    origin = first_time - timedelta(seconds=first_elapsed or 0)
    previous_elapsed = -math.inf
    flat = []
    for record in records:
        when = stamp(record.get('timestamp') or record['_event_timestamp'])
        elapsed = number(record.get('elapsed_s')) if is_trial else (when-origin).total_seconds()
        if elapsed is None or elapsed < previous_elapsed:
            raise ValueError('Sample elapsed time is absent or runs backwards')
        previous_elapsed = elapsed
        feedback, effect = record['feedback'], record.get('effect', {})
        control, native = record.get('control', {}), record.get('native', {})
        row = {'timestamp_utc': when.isoformat(), 'elapsed_s': elapsed,
               'elapsed_min': elapsed/60, 'event_line': record['_event_line'],
               'capture_s': record.get('capture_s'), 'feedback_quality': feedback.get('quality'),
               'feedback_quality_name': label(QUALITY, feedback.get('quality')),
               'feedback_ready': feedback.get('ready'), 'feedback_coherent': feedback.get('coherent'),
               'feedback_age_s': feedback.get('last_age_s'),
               'feedback_accepted_count': feedback.get('accepted_count'),
               'feedback_short_count': feedback.get('short_count'),
               'feedback_slow_count': feedback.get('slow_count'),
               'feedback_short_span_s': feedback.get('short_span_s'),
               'feedback_slow_span_s': feedback.get('slow_span_s'),
               'temperature_generation': feedback.get('temperature_generation'),
               'flow_generation': feedback.get('flow_generation'),
               'instant_w': feedback.get('instant_w'), 'short_w': feedback.get('short_w'),
               'slow_w': feedback.get('slow_w'),
               'effect_phase': effect.get('phase'), 'effect_phase_name': label(PHASE, effect.get('phase')),
               'effect_limit_reason': effect.get('limit_reason'),
               'effect_target_w': effect.get('target_w'),
               'effect_flow_target_cC': effect.get('flow_target_cC'),
               'effect_last_adjustment_cC': effect.get('last_adjustment_cC'),
               'effect_cumulative_up_cC': effect.get('cumulative_up_cC'),
               'effect_cumulative_down_cC': effect.get('cumulative_down_cC'),
               'effect_adjustments': effect.get('adjustments'),
               'control_state': control.get('state'), 'control_accepted_seq': control.get('accepted'),
               'control_applied_seq': control.get('applied'), 'control_lease_s': control.get('lease_s'),
               'control_error': control.get('error'), 'control_snapshot_saved': control.get('saved'),
               'control_restores': control.get('restores'),
               'native_flow_target_cC': native.get('flow'), 'native_flow_fresh': native.get('fresh09'),
               'native_control_mode': native.get('mode'), 'native_operating_mode': native.get('operating_mode')}
        telemetry = record['telemetry']
        for index, name in TELEMETRY.items():
            point = telemetry[index] if index < len(telemetry) else {}
            for suffix, key in [('', 'value'), ('_status', 'status'), ('_age_s', 'age_s'),
                                ('_coherent', 'coherent'), ('_generation', 'generation')]:
                row[name+suffix] = point.get(key)
        flat.append(row)
    metadata['origin_utc'] = origin.isoformat()
    metadata['origin_kind'] = 'ACTIVE start inferred from sample timestamp minus elapsed_s' if is_trial else 'First recorded snapshot'
    metadata['samples'] = len(flat)
    metadata['first_elapsed_s'] = flat[0]['elapsed_s']
    metadata['last_elapsed_s'] = flat[-1]['elapsed_s']
    metadata['quality_counts'] = {name: sum(row['feedback_quality_name'] == name for row in flat)
                                  for name in sorted({row['feedback_quality_name'] for row in flat})}
    return flat


def plot_values(rows):
    """Mask unavailable data instead of inventing zeros or filling gaps."""
    result = {key: [] for key in ('instant_kw', 'short_kw', 'slow_kw', 'supply_C',
                                 'return_C', 'target_C', 'compressor_hz')}
    for row in rows:
        age = number(row['feedback_age_s'])
        usable = (row['feedback_quality'] in (0, 2) and age is not None and age <= 20
                  and row['feedback_coherent'] is not False)
        for prefix in ('instant', 'short', 'slow'):
            value = number(row[prefix+'_w'])
            ok = usable and value is not None
            if prefix == 'instant':
                ok = ok and row['feedback_quality'] == 0 and bool(row['feedback_ready'])
            result[prefix+'_kw'].append(value/1000 if ok else math.nan)
        for name, output, scale, ttl in [('supply_cC', 'supply_C', 100, 20),
                                        ('return_cC', 'return_C', 100, 20),
                                        ('compressor_hz', 'compressor_hz', 1, 10)]:
            value, age = number(row[name]), number(row[name+'_age_s'])
            ok = value is not None and row[name+'_status'] == 1 and age is not None and age <= ttl
            result[output].append(value/scale if ok else math.nan)
        target = number(row['native_flow_target_cC'])
        result['target_C'].append(target/100 if target is not None and row['native_flow_fresh'] else math.nan)
    return result


def write_text(path, content):
    with tempfile.NamedTemporaryFile('w', encoding='utf-8', dir=path.parent,
                                     prefix='.'+path.name+'.', delete=False) as temporary:
        temporary.write(content)
        temp_name = temporary.name
    Path(temp_name).replace(path)


def render(run_dir):
    run_dir = run_dir.resolve()
    records, metadata = load_records(run_dir / 'events.jsonl')
    rows = flatten(records, metadata)
    values = plot_values(rows)
    report = run_dir / 'report'
    report.mkdir(exist_ok=True)
    # A temporary writable cache avoids changing the user's global matplotlib directory.
    with tempfile.TemporaryDirectory(prefix='p76-matplotlib-') as cache:
        os.environ.setdefault('MPLCONFIGDIR', cache)
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        from matplotlib.patches import Patch
        plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
                             'axes.spines.top': False, 'axes.spines.right': False,
                             'svg.fonttype': 'none'})
        fig, axes = plt.subplots(3, 1, figsize=(12.5, 9), sharex=True,
                                 gridspec_kw={'height_ratios': [1.4, 1, 0.85]})
        fig.subplots_adjust(left=.09, right=.975, top=.865, bottom=.155, hspace=.28)
        active = metadata['active_trial_series_present']
        outcome_path = run_dir / 'outcome.json'
        outcome = json.loads(outcome_path.read_text()) if outcome_path.exists() else {}
        if active:
            status = 'Hel timme registrerad' if outcome.get('completed_hour') else 'Partiell aktiv provserie'
        elif (run_dir / 'active-start.json').exists():
            status = 'ACTIVE bekräftades, men ingen aktiv provserie registrerades'
        else:
            status = 'Ingen bekräftad aktiv provserie — endast registrerade avläsningar'
        fig.suptitle('P0076 · 6 kW effektstyrning', x=.09, y=.965, ha='left',
                     fontsize=21, weight='bold', color='#193247')
        fig.text(.09, .92, status, ha='left', fontsize=11, color='#42546A')
        origin_text = stamp(metadata['origin_utc']).strftime('%Y-%m-%d %H:%M:%S UTC')
        fig.text(.09, .891, ('Start för aktiv tid: ' if active else 'Första avläsning: ')+origin_text,
                 fontsize=10, color='#42546A')
        x = [row['elapsed_min'] for row in rows]
        ax = axes[0]
        ax.axhspan(5, 7, facecolor='#D6EADD', alpha=.8, zorder=0, label='Utvärderingsband ±1 kW')
        ax.axhline(6, color='#355A44', ls='--', lw=1.3,
                   label='Begärt mål 6 kW (inte uppmätt utfall)')
        ax.plot(x, values['instant_kw'], color='#A5B9CA', lw=.8, marker='.', ms=2,
                label='Momentan uppskattning', zorder=2)
        ax.plot(x, values['short_kw'], color='#136D9C', lw=1.8, marker='.', ms=2,
                label='Kort medel · upp till 60 s', zorder=4)
        ax.plot(x, values['slow_kw'], color='#B06B29', lw=1.5, marker='.', ms=2,
                label='Långt medel · upp till 180 s', zorder=3)
        pending = [i for i, row in enumerate(rows) if row['feedback_quality'] == 2 and math.isfinite(values['short_kw'][i])]
        if pending:
            ax.scatter([x[i] for i in pending], [values['short_kw'][i] for i in pending],
                       s=13, facecolors='none', edgecolors='#76889A', lw=.7,
                       label='PENDING · tidigare giltigt medel', zorder=5)
        ax.set_ylabel('Uppskattad värmeeffekt (kW)')
        ax.legend(loc='best', fontsize=8.5, framealpha=.9, ncol=2)
        axes[1].plot(x, values['target_C'], color='#213F59', lw=1.6, marker='.', ms=2, drawstyle='steps-post', label='Avläst framledningsbörvärde')
        axes[1].plot(x, values['supply_C'], color='#B4513C', lw=1.3, marker='.', ms=2, label='Framledning')
        axes[1].plot(x, values['return_C'], color='#387E74', lw=1.3, marker='.', ms=2, label='Retur')
        axes[1].set_ylabel('Temperatur (°C)')
        axes[1].legend(loc='best', ncol=3, fontsize=8.5, framealpha=.9)
        axes[2].plot(x, values['compressor_hz'], color='#695194', lw=1.4, marker='.', ms=2, label='Kompressor')
        limited = [i for i, row in enumerate(rows) if row['effect_phase'] == 4]
        if limited:
            for i in limited:
                right = x[i+1] if i+1 < len(x) else x[i]
                for axis in axes:
                    if right > x[i]:
                        axis.axvspan(x[i], right, color='#EBC46C', alpha=.18, lw=0, zorder=0)
                    else:
                        axis.axvline(x[i], color='#C89537', alpha=.6, lw=.8)
            handles, labels = axes[2].get_legend_handles_labels()
            handles.append(Patch(facecolor='#EBC46C', alpha=.35))
            labels.append('LIMITED observerat')
            axes[2].legend(handles, labels, loc='best', fontsize=8.5)
        else:
            axes[2].legend(loc='best', fontsize=8.5)
        axes[2].set_ylabel('Kompressor (Hz)')
        axes[2].set_xlabel('Minuter från verifierad aktivering' if active else 'Minuter från första registrerade avläsningen')
        for axis in axes:
            axis.grid(axis='y', color='#DDE3E9', lw=.6)
            axis.set_axisbelow(True)
            axis.margins(x=.01)
        if len(x) == 1:
            axes[2].set_xlim(x[0]-.05, x[0]+.5)
        fig.text(.09, .063,
                 'Vattensidig effekt beräknad från flöde och temperaturdifferens; inte kalibrerad värmemätning eller COP.\n'
                 'Register läses vid olika tidpunkter. Ogiltiga värden visas som luckor; medelfönstrens faktiska täckning finns i CSV.',
                 ha='left', va='center', fontsize=9, color='#42546A', linespacing=1.7)
        fig.text(.09, .022, f"{len(rows)} avläsningar · källa events.jsonl · SHA-256 {metadata['source_sha256'][:16]}…",
                 fontsize=8, color='#697B8B')
        fig.savefig(report / 'trial.png', dpi=170, facecolor='white')
        fig.savefig(report / 'trial.svg', facecolor='white', metadata={'Date': None})
        plt.close(fig)
    buffer = io.StringIO(newline='')
    writer = csv.DictWriter(buffer, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
    write_text(report / 'samples.csv', buffer.getvalue())
    metadata.update({'rendered_utc': datetime.now(timezone.utc).isoformat(),
                     'report_status': status, 'requested_target_w': 6000,
                     'input_modified': False,
                     'measurement': 'Estimated water-side thermal output; non-atomic source reads, not calibrated heat or COP',
                     'plot_masks': 'Power: quality READY/PENDING and age<=20s; instant only READY. Temperatures status1 age<=20s; Hz status1 age<=10s. Missing values are gaps.',
                     'csv': 'Raw recorded scalar values and their status/age/coherence; no gap filling or interpolation',
                     'files': ['trial.png', 'trial.svg', 'samples.csv', 'report.json']})
    write_text(report / 'report.json', json.dumps(metadata, indent=2, ensure_ascii=False)+'\n')
    return metadata


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-dir', required=True, type=Path)
    args = parser.parse_args(argv)
    print(json.dumps(render(args.run_dir), indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
