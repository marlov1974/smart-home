let trialUart=UART.get(0);
if(!trialUart)throw new Error('UART_UNAVAILABLE');
let trialActive=false,trialArmed=false,trialWaiting=false,trialDone=false;
let trialRaw='',trialExpected=0,trialFunction=0,trialStarted=0,trialError='';
function trialCRC(s){let c=65535;for(let i=0;i<s.length;i++){c=c^s.charCodeAt(i);for(let j=0;j<8;j++)c=(c>>>1)^((c&1)?40961:0);}return c;}
function trialWord(s,i){return s.charCodeAt(i)*256+s.charCodeAt(i+1);}
function trialRestore(){trialActive=false;trialArmed=false;trialWaiting=false;trialUart.configure({baud:115200,format:'8N1'});return JSON.stringify({restored:true});}
function trialBegin(){if(trialActive)throw new Error('ACTIVE');trialUart.configure({baud:9600,format:'8N1'});trialActive=true;return JSON.stringify({baud:9600,format:'8N1'});}
function trialArm(){if(!trialActive||trialWaiting||trialError)throw new Error('ARM_GATE');trialArmed=true;return JSON.stringify({armed:true});}
function trialSend(encoded){
 if(!trialActive||trialWaiting||trialError)throw new Error('TX_GATE');
 let s=atob(encoded);if(s.charCodeAt(0)!==1||trialCRC(s)!==0)throw new Error('FRAME');
 let fn=s.charCodeAt(1),n=0;
 if(fn===4){
   let addr=trialWord(s,2),qty=trialWord(s,4);
   if(s.length!==8||qty<1||qty>16||addr+qty>384)throw new Error('READ_RANGE');n=5+2*qty;
 }else if(fn===16){
   if(!trialArmed||s.length!==25||trialWord(s,2)!==300||trialWord(s,4)!==8||s.charCodeAt(6)!==16)throw new Error('WRITE_GATE');
   let w=[];for(let i=0;i<8;i++)w.push(trialWord(s,7+2*i));
   if(w[1]<1)throw new Error('SEQUENCE');
   if(w[0]===49270){if(w[2]!==5||w[3]!==6000||w[4]!==3800||w[5]!==180||w[6]!==1||w[7]!==3)throw new Error('EFFECT_SCOPE');}
   else if(w[0]===49266){if(w[2]!==1||w[3]!==0||w[4]!==0||w[5]!==0||w[6]!==0||w[7]!==2)throw new Error('AUTO_SCOPE');}
   else throw new Error('MAGIC');n=8;
 }else throw new Error('FUNCTION');
 trialRaw='';trialDone=false;trialExpected=n;trialFunction=fn;trialStarted=Shelly.getUptimeMs();trialWaiting=true;
 let sent=trialUart.send(s);if(sent!==s.length){trialError='SHORT_SEND';trialWaiting=false;}
 return JSON.stringify({sent:sent});
}
trialUart.recv(function(s){
 if(!trialWaiting){trialError='UNEXPECTED_RX';return;}
 if(Shelly.getUptimeMs()-trialStarted>2200){trialError='RX_TIMEOUT';trialWaiting=false;return;}
 trialRaw+=s;if(trialRaw.length>64){trialError='RX_OVERFLOW';trialWaiting=false;return;}
 if(trialRaw.length>=2&&trialRaw.charCodeAt(1)===(trialFunction|128))trialExpected=5;
 if(trialRaw.length>=trialExpected){
   if(trialRaw.length!==trialExpected||trialCRC(trialRaw)!==0)trialError='RX_FRAME';
   trialDone=true;trialWaiting=false;
 }
});
function trialResult(){
 if(trialWaiting&&Shelly.getUptimeMs()-trialStarted>2200){trialError='RX_TIMEOUT';trialWaiting=false;}
 return JSON.stringify({done:trialDone,waiting:trialWaiting,error:trialError,base64:btoa(trialRaw)});
}
function trialExpire(){trialRestore();Shelly.call('Script.Stop',{id:8});}
Timer.set(4500000,false,trialExpire);
