"""Read-only EFFECT gate observation. Never arms control."""
import json,time
from pathlib import Path
from datetime import datetime,timezone
from live_bus import Session
def main():
    out=Path(__file__).resolve().parent/('preflight-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    s=Session(out,ttl_s=240)
    try:
        s.start();blocks={}
        for addr,n in [(0,16),(68,4),(72,15),(256,16),(272,11),(283,16),(248,8),(232,8),(100,16),(116,16),(352,16),(368,4)]:blocks[str(addr)]=s.read(addr,n)
        s.save('baseline.json',blocks);print(json.dumps({'out':str(out),'baseline':blocks}),flush=True)
        start=time.monotonic()
        while time.monotonic()-start<80:
            feedback=s.read(352,16);native=s.read(248,8)
            r={'elapsed_s':round(time.monotonic()-start,1),'feedback_352_367':feedback,'raw26_248_255':native}
            s.log('gate',r);print(json.dumps(r),flush=True);time.sleep(3)
    finally:
        result=s.cleanup();print(json.dumps({'cleanup':result}),flush=True)
if __name__=='__main__':main()
