#!/usr/bin/env python3
"""Supervised single-pump EFFECT trial. No writes without --execute --boundary-confirmed.

The imported live_bus Session owns the physical transport. Importing this module
does not construct a Session or contact a device. All addresses are zero based.
"""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import signal
import statistics
import sys
import time

TOOLS = Path(__file__).resolve().parents[1] / 'procon-melcobems-mini-a1m' / 'tools'
sys.path.insert(0, str(TOOLS))
from control_command import encode
from commission_units import decode_identity, decode_dip
from read_mvp import decode_effect, decode_feedback, signed32

EXPECTED_UID = 'REDACTED_DEVICE_UID'
TARGET_W = 6000
CAP_CC = 3800
LEASE_S = 180
DURATION_S = 3600
IDLE, QUEUED, SNAPSHOT, APPLY, ACTIVE, RESTORE, RESTORE_BLOCKED = range(7)
CONTROL_KEYS = ('state', 'accepted', 'applied', 'rejected', 'error', 'saved',
                'touched', 'mode', 'lease_s', 'acks', 'readbacks', 'restores',
                'original_power', 'original_mode', 'original_flow', 'original_dhw',
                'original_boost', 'current_power', 'current_mode', 'current_flow',
                'current_dhw', 'current_boost', 'action', 'actions', 'phase',
                'retries', 'persistent_recovery')


class GateError(RuntimeError):
    pass


class IdentityOrReset(GateError):
    """Writing any restore after this exception would risk the wrong RAM owner."""


def next_sequence(accepted):
    if type(accepted) is not int or not 0 <= accepted <= 65535:
        raise ValueError('Invalid accepted sequence')
    return 1 if accepted == 65535 else accepted + 1


def little_bytes(words):
    return bytes(byte for word in words for byte in (word & 255, word >> 8))


def read_snapshot(bus):
    raw = {}
    def read(addr, count):
        result = []
        for offset in range(0, count, 16):
            a, n = addr + offset, min(16, count - offset)
            words = bus.read(a, n)
            if len(words) != n or any(type(v) is not int or not 0 <= v <= 65535 for v in words):
                raise GateError('Malformed input-register response')
            raw[str(a)] = words
            result.extend(words)
        return result
    started = time.monotonic()
    meta = read(0, 16)
    api = read(68, 4)
    identity_words = read(72, 15)
    try:
        identity = decode_identity(identity_words[:12], requested_slave=1)
        identity['dip'] = decode_dip(identity_words[12:], identity)
    except ValueError as exc:
        raise IdentityOrReset(str(exc)) from exc
    if identity['uid96'] != EXPECTED_UID or identity['source'] != 3:
        raise IdentityOrReset('Physical UID/addressing differs from the verified Procon')
    if meta[:2] != [888, 76] or api[:3] != [1, 1, 15]:
        raise IdentityOrReset('Firmware/API identity changed')
    generation_before = read(180, 20)
    values = read(100, 40)
    statuses = read(140, 20)
    ages = read(160, 20)
    raw09, raw26 = little_bytes(read(232, 8)), little_bytes(read(248, 8))
    native_status = read(156, 4)
    native_age = read(176, 4)
    native_gen = read(196, 4)
    diagnostic28 = read(283, 13)
    raw28 = little_bytes(diagnostic28[5:13])
    generation_after = read(180, 20)
    control = dict(zip(CONTROL_KEYS, read(256, 27)))
    effect = decode_effect(read(320, 32))
    # Schema/quality/counts/age/generations/instant/short mean fit one FC04.
    # The slow mean and derivative are supplemental and may be newer.
    feedback = decode_feedback(read(352, 16) + read(368, 4))
    feedback['coherent'] = True
    telemetry = []
    for i in range(20):
        v = signed32(values[2*i], values[2*i+1])
        coherent = generation_before[i] == generation_after[i]
        telemetry.append({'value': v if v != -2147483648 else None,
                          'status': statuses[i], 'age_s': ages[i], 'generation': generation_after[i],
                          'coherent': coherent})
    # Each raw native payload is one atomic FC04 block. A broad generation
    # bracket cannot gate health because FAST updates normally occur during
    # the complete multi-block snapshot. Matching consecutive native settings
    # with new generations establish the external baseline in preflight.
    native = {'power': raw26[3], 'operating_mode': raw26[4], 'mode': raw26[6],
              'flow': int.from_bytes(raw09[5:7], 'big'),
              'dhw': int.from_bytes(raw26[8:10], 'big'), 'boost': raw28[3],
              'fresh26': raw26[0] == 0x26 and native_status[2] == 1 and native_age[2] <= 20,
              'fresh09': raw09[0] == 9 and native_status[0] == 1 and native_age[0] <= 20,
              'fresh28': raw28[0] == 0x28 and diagnostic28[0] == 1 and diagnostic28[1] <= 20,
              'raw09': raw09.hex(), 'raw26': raw26.hex(), 'raw28': raw28.hex(),
              'generation26': native_gen[2], 'generation09': native_gen[0],
              'generation28': diagnostic28[2]}
    result = {'timestamp': datetime.now(timezone.utc).isoformat(), 'monotonic_s': time.monotonic(),
              'capture_s': time.monotonic() - started, 'meta': meta, 'identity': identity,
              'control': control, 'effect': effect, 'feedback': feedback,
              'telemetry': telemetry, 'native': native, 'raw': raw}
    bus.log('snapshot', result)
    return result


def native_gate(snapshot, *, initial=False):
    native = snapshot['native']
    if not native['fresh26'] or not native['fresh09']:
        raise GateError('Fresh coherent GET26 and GET09 are unavailable')
    if native['power'] != 1 or native['operating_mode'] not in (2, 7):
        raise GateError('Pump is not already powered in space-heating mode')
    if native['mode'] not in (0, 1, 2) or not 4000 <= native['dhw'] <= 6000:
        raise GateError('Native settings outside documented encodings')
    if initial and not 2000 <= native['flow'] <= CAP_CC:
        raise GateError('Initial target outside the 20–38 C trial boundary')
    if not native['fresh28']:
        raise GateError('GET28 inhibit/ownership flags are not fresh')
    flags = bytes.fromhex(native['raw28'])
    if any(flags[i] > 1 for i in range(3, 11)) or flags[3] or flags[4] or flags[6] or flags[10]:
        raise GateError('Boost, holiday, Zone1 heating inhibit or external ownership is active')


def feedback_ready(snapshot):
    f = snapshot['feedback']
    return (f['coherent'] and f['quality'] == 0 and f['ready'] and
            f['short_count'] >= 3 and f['short_span_s'] >= 20 and
            f['last_age_s'] is not None and f['last_age_s'] <= 20 and
            f['short_w'] is not None)


def owned_active(snapshot, sequence):
    c, e = snapshot['control'], snapshot['effect']
    return (c['state'] == ACTIVE and c['saved'] == 1 and c['mode'] == 5 and
            c['accepted'] == sequence and c['applied'] == sequence and
            c['lease_s'] > 0 and e['target_w'] == TARGET_W and e['maximum_flow_cC'] == CAP_CC)


def renewal_confirmed(snapshot, sequence):
    c, e = snapshot['control'], snapshot['effect']
    return (c['state'] in (ACTIVE, APPLY) and c['saved'] == 1 and c['mode'] == 5 and
            c['accepted'] == sequence and c['applied'] == sequence and c['error'] in (0, 2) and
            c['lease_s'] > 0 and e['target_w'] == TARGET_W and e['maximum_flow_cC'] == CAP_CC)


def check_continuity(previous, current):
    elapsed = current['monotonic_s'] - previous['monotonic_s']
    device_delta = (current['meta'][9] - previous['meta'][9]) & 65535
    if device_delta > elapsed + 15 or current['identity']['uid96'] != previous['identity']['uid96']:
        raise IdentityOrReset('Device reset, clock discontinuity or identity change; automatic restore is forbidden')


def trial_safety(snapshot):
    c, f = snapshot['control'], snapshot['feedback']
    if snapshot['meta'][11] != 1:
        raise GateError('CN105 link is not connected')
    if c['state'] in (IDLE, RESTORE, RESTORE_BLOCKED) or c['saved'] != 1:
        raise GateError('EFFECT ownership ended or firmware started restoration')
    if c['error'] not in (0, 2):  # Exception06 busy records error2 without changing ownership.
        raise GateError('Firmware control error ' + str(c['error']))
    native_gate(snapshot)
    if snapshot['native']['mode'] != 1 or not 2000 <= snapshot['native']['flow'] <= CAP_CC:
        raise GateError('Native fixed-flow mode or 38 C target ceiling changed')
    if c['mode'] != 5 or snapshot['effect']['target_w'] != TARGET_W or snapshot['effect']['maximum_flow_cC'] != CAP_CC:
        raise GateError('EFFECT intent changed')
    for index in (3, 4, 6, 18):
        point = snapshot['telemetry'][index]
        if point['status'] != 1 or point['age_s'] > 20:
            raise GateError('Fresh primary telemetry lost')
    flow = snapshot['telemetry'][3]['value']
    if flow is not None and flow > 4000:
        raise GateError('Actual supply temperature exceeds 40 C')
    if f['quality'] not in (0, 2) or f['last_age_s'] is None or f['last_age_s'] > 20:
        raise GateError('Coherent heat feedback invalid or stale')


def accepted_points(records):
    result, seen = [], set()
    for row in records:
        f = row['feedback']
        key = f['accepted_count']
        # PENDING retains the last good accepted short mean. Its independent
        # accepted_count proves provenance even when the next FAST pair is
        # incomplete. It still must satisfy the published age/count/span bounds.
        usable = (f['coherent'] and f['quality'] in (0, 2) and f['short_count'] >= 3 and
                  f['short_span_s'] >= 20 and f['last_age_s'] is not None and
                  f['last_age_s'] <= 20 and f['short_w'] is not None)
        if key in seen or not usable:
            continue
        seen.add(key)
        result.append({'t': row['elapsed_s'], 'w': f['short_w'], 'instant_w': f['instant_w']})
    return result


def oscillations(points):
    """Six alternating sustained +/-1kW excursions within ten minutes, after warmup."""
    events, active_sign, start, last_t, emitted = [], 0, None, None, False
    for p in points:
        t, error = p['t'], p['w'] - TARGET_W
        if t < 900:
            continue
        sign = 1 if error > 1000 else -1 if error < -1000 else 0
        if last_t is not None and t - last_t > 30:
            active_sign, start, emitted = 0, None, False
        if sign != active_sign:
            active_sign, start, emitted = sign, t, False
        if sign and not emitted and t - start >= 30:
            if not events or events[-1]['sign'] != sign:
                events.append({'t': t, 'sign': sign, 'since': start})
            emitted = True
            if len(events) >= 6 and events[-1]['t'] - events[-6]['t'] <= 600:
                return {'detected': True, 'events': events, 'criterion': '6 alternating >1kW excursions, each >=30s, within600s after900s'}
        last_t = t
    return {'detected': False, 'events': events, 'criterion': '6 alternating >1kW excursions, each >=30s, within600s after900s'}


def analyse(records):
    points = accepted_points(records)
    end = records[-1]['elapsed_s'] if records else 0
    tail = [p for p in points if p['t'] >= max(900, end - 1200)]
    intervals = [b['t'] - a['t'] for a, b in zip(tail, tail[1:])]
    coverage = sum(min(20, gap) for gap in intervals)
    sufficient = end >= 2100 and len(tail) >= 50 and coverage >= 1080
    watts = [p['w'] for p in tail]
    osc = oscillations(points)
    def percentile(q):
        ordered = sorted(watts)
        return ordered[round((len(ordered)-1)*q)] if ordered else None
    result = {'target_w': TARGET_W, 'elapsed_s': end, 'unique_ready_pairs': len(points),
              'last20min_samples': len(tail), 'last20min_coverage_s': coverage,
              'sufficient_last20min_data': sufficient, 'oscillation': osc,
              'mean_w': statistics.mean(watts) if watts else None,
              'stdev_w': statistics.pstdev(watts) if watts else None,
              'min_w': min(watts) if watts else None, 'max_w': max(watts) if watts else None,
              'p05_w': percentile(.05), 'p95_w': percentile(.95),
              'fraction_within_500w': sum(abs(w-TARGET_W) <= 500 for w in watts)/len(watts) if watts else None,
              'fraction_within_1000w': sum(abs(w-TARGET_W) <= 1000 for w in watts)/len(watts) if watts else None,
              'measurement': 'Estimated water-side heat output; uncalibrated, not electrical input or COP'}
    result['stable'] = (sufficient and not osc['detected'] and result['fraction_within_1000w'] >= .8 and
                        result['p95_w'] - result['p05_w'] <= 2000)
    result['assessment'] = 'insufficient-data' if not sufficient else 'stable-within-evaluation-band' if result['stable'] else 'not-demonstrated-stable'
    return result


def restore_verified(snapshot, original, initial_restores, after_generations):
    c, n = snapshot['control'], snapshot['native']
    fields = ('power', 'mode', 'flow', 'dhw', 'boost')
    return (c['state'] == IDLE and c['saved'] == 0 and c['touched'] == 0 and
            ((c['restores'] - initial_restores) & 65535) >= 1 and
            all(c['current_' + key] == original[key] for key in fields) and
            n['fresh26'] and n['fresh09'] and n['fresh28'] and
            all(n['generation' + q] != after_generations[q] for q in ('26', '09', '28')) and
            all(n[key] == original[key] for key in ('power', 'mode', 'dhw', 'boost')) and
            # Returning to curve/room control permits its computed target to
            # evolve. ctl.current_flow proves the saved flow SET was read back
            # before native mode restoration; only fixed mode requires raw
            # GET09 to remain exactly at that value afterwards.
            (original['mode'] != 1 or n['flow'] == original['flow']))


class Supervisor:
    def __init__(self, bus, *, clock=time.monotonic, sleep=time.sleep):
        self.bus, self.clock, self.sleep = bus, clock, sleep
        self.previous = None
        self.original = None
        self.initial_restores = 0
        self.sequence = None
        self.possible_acceptance = False
        self.identity_lost = False
        self.records = []
        self.last = None

    def capture(self):
        try:
            current = read_snapshot(self.bus)
            if self.previous is not None:
                check_continuity(self.previous, current)
            self.previous = self.last = current
            return current
        except IdentityOrReset:
            self.identity_lost = True
            raise

    def send(self, words):
        from live_bus import ModbusException
        self.bus.log('command_attempt', {'words': words})
        try:
            self.bus.command(words)
        except ModbusException as exc:
            if exc.code == 6:
                self.bus.log('command_busy', {'sequence': words[1]})
                return False
            raise
        return True

    def preflight(self, timeout=180):
        until, generations, native_candidate, last_reason = self.clock()+timeout, None, None, None
        while self.clock() < until:
            s = self.capture()
            c = s['control']
            if c['state'] != IDLE or c['saved'] or c['touched']:
                raise GateError('Pre-existing control owner or unresolved restore')
            try:
                native_gate(s, initial=True)
                if s['meta'][11] != 1 or not feedback_ready(s):
                    raise GateError('Feedback has not reached coherent READY with three pairs over20s')
                pair = (s['feedback']['temperature_generation'], s['feedback']['flow_generation'])
                native_values = {key: s['native'][key] for key in ('power', 'mode', 'flow', 'dhw', 'boost')}
                native_generations = (s['native']['generation26'], s['native']['generation09'])
                if generations is None or native_candidate[0] != native_values:
                    generations = pair
                    native_candidate = (native_values, native_generations)
                    raise GateError('Waiting for both contributing sources to advance')
                if any(now == before for now, before in zip(pair, generations)):
                    raise GateError('Waiting for both contributing sources to advance')
                if any(now == before for now, before in zip(native_generations, native_candidate[1])):
                    raise GateError('Waiting for new GET26/09 confirming the same native baseline')
                self.original = native_values
                self.initial_restores = c['restores']
                self.sequence = next_sequence(c['accepted'])
                self.bus.save('baseline.json', s)
                return s
            except GateError as exc:
                last_reason = str(exc)
                self.bus.log('preflight_wait', {'reason': last_reason})
            self.sleep(3)
        raise GateError('Preflight timeout: ' + str(last_reason))

    def execute(self):
        self.preflight()
        self.bus.arm_control()
        effect_words = lambda seq: encode(seq, 'effect', lease=LEASE_S, target_w=TARGET_W,
                                        max_flow='38', boundary_verified=True)['words']
        until, sent = self.clock()+180, False
        while self.clock() < until:
            s = self.capture()
            c = s['control']
            if not sent:
                if c['state'] != IDLE or c['accepted'] != (65535 if self.sequence == 1 and c['accepted'] == 65535 else self.sequence-1):
                    raise GateError('Control ownership changed after preflight')
                native_gate(s, initial=True)
                if feedback_ready(s):
                    self.possible_acceptance = True
                    sent = self.send(effect_words(self.sequence))
                    if not sent:
                        self.possible_acceptance = False
                self.sleep(3)
                continue
            if c['accepted'] != self.sequence:
                raise GateError('Accepted sequence differs from trial command')
            if c['state'] in (IDLE, RESTORE, RESTORE_BLOCKED):
                raise GateError('Firmware rejected or aborted initial EFFECT apply')
            if owned_active(s, self.sequence):
                captured = {key: c['original_' + key] for key in self.original}
                if captured != self.original:
                    raise GateError('Firmware original snapshot differs from preflight baseline')
                if c['current_mode'] != 1 or c['current_flow'] != self.original['flow']:
                    raise GateError('Initial combined mode/flow apply is not independently verified')
                if s['native']['mode'] != 1 or s['native']['flow'] != self.original['flow']:
                    # Native blocks precede control blocks in acquisition; a
                    # legitimate apply during the snapshot needs another fresh
                    # observation, within the existing startup deadline.
                    self.sleep(3)
                    continue
                trial_safety(s)
                active_since = self.clock()
                renewed_at = active_since
                last_progress = active_since - 60
                self.bus.save('active-start.json', s)
                print(json.dumps({'event': 'verified_active', 'timestamp': s['timestamp'],
                    'sequence': self.sequence, 'target_w': TARGET_W, 'maximum_flow_cC': CAP_CC,
                    'duration_s': DURATION_S, 'original': self.original}), flush=True)
                break
            self.sleep(3)
        else:
            raise GateError('EFFECT did not become verified ACTIVE within180s')
        while True:
            start = self.clock()
            s = self.capture()
            s['elapsed_s'] = self.clock() - active_since
            self.records.append(s)
            self.bus.log('trial_sample', s)
            if self.clock() - last_progress >= 60:
                print(json.dumps({'event': 'progress', 'timestamp': s['timestamp'],
                    'elapsed_s': round(s['elapsed_s']), 'short_w': s['feedback']['short_w'],
                    'instant_w': s['feedback']['instant_w'], 'target_w': TARGET_W,
                    'flow_target_cC': s['native']['flow'], 'compressor_hz': s['telemetry'][8]['value'],
                    'state': s['control']['state'], 'phase': s['effect']['phase'],
                    'lease_s': s['control']['lease_s'], 'quality': s['feedback']['quality']}), flush=True)
                last_progress = self.clock()
            trial_safety(s)
            c = s['control']
            if c['accepted'] != self.sequence:
                raise GateError('Another command changed accepted sequence')
            if oscillations(accepted_points(self.records))['detected']:
                raise GateError('Sustained alternating output excursions detected')
            if s['elapsed_s'] >= DURATION_S:
                return {'completed_hour': True, 'analysis': analyse(self.records)}
            if self.clock()-renewed_at >= 60 and owned_active(s, self.sequence) and feedback_ready(s):
                new_seq = next_sequence(self.sequence)
                if self.send(effect_words(new_seq)):
                    confirmation = self.capture()
                    if not renewal_confirmed(confirmation, new_seq):
                        raise GateError('Lease renewal was not confirmed ACTIVE/applied')
                    self.sequence, renewed_at = new_seq, self.clock()
                    self.bus.log('lease_renewed', {'sequence': new_seq})
            if c['lease_s'] < 45 and self.clock()-renewed_at >= 90:
                raise GateError('Lease could not be renewed with coherent READY feedback')
            self.sleep(max(0, 10-(self.clock()-start)))

    def restore(self):
        if not self.possible_acceptance:
            return {'required': False, 'verified': False}
        if self.identity_lost:
            return {'required': True, 'verified': False, 'reason': 'Identity/reset uncertainty: no blind restore sent'}
        print(json.dumps({'event': 'restoration_started', 'sequence': self.sequence}), flush=True)
        until, auto_sent, restore_gens = self.clock()+360, False, None
        while self.clock() < until:
            try:
                s = self.capture()
                c, n = s['control'], s['native']
                if restore_gens is None:
                    restore_gens = {q: n['generation'+q] for q in ('26', '09', '28')}
                if restore_verified(s, self.original, self.initial_restores, restore_gens):
                    self.bus.save('restored.json', s)
                    print(json.dumps({'event': 'restoration_verified', 'timestamp': s['timestamp'],
                        'restores': c['restores'], 'native': n}), flush=True)
                    return {'required': True, 'verified': True, 'auto_sent': auto_sent}
                if c['state'] == IDLE and not c['saved'] and not c['touched'] and c['restores'] == self.initial_restores:
                    # Accepted before snapshot, but firmware safely aborted with no possible SET.
                    if c['accepted'] == self.sequence and all(n[k] == self.original[k] for k in self.original):
                        return {'required': True, 'verified': True, 'no_mutation': True, 'auto_sent': False}
                if not auto_sent and c['state'] in (ACTIVE, RESTORE_BLOCKED) and c['saved'] == 1:
                    if c['accepted'] not in (self.sequence, next_sequence(self.sequence)):
                        raise IdentityOrReset('Unknown command owner during restoration')
                    auto_words = encode(next_sequence(c['accepted']), 'auto')['words']
                    if self.send(auto_words):
                        self.sequence = auto_words[1]
                        auto_sent = True
            except IdentityOrReset as exc:
                self.identity_lost = True
                return {'required': True, 'verified': False, 'reason': str(exc)}
            except Exception as exc:
                self.bus.log('restore_observation_error', {'error': repr(exc), 'lease_fallback': True})
            self.sleep(3)
        return {'required': True, 'verified': False, 'auto_sent': auto_sent,
                'reason': 'Restoration verification timed out; saved firmware lease was not renewed'}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--boundary-confirmed', action='store_true')
    args = parser.parse_args(argv)
    if args.execute and not args.boundary_confirmed:
        parser.error('--execute requires --boundary-confirmed')
    from live_bus import Session
    bus = Session(args.output, ttl_s=4500)
    supervisor = Supervisor(bus)
    outcome = {'completed_hour': False, 'mode': 'execute' if args.execute else 'read-only-preflight'}
    def interrupted(signum, frame):
        raise KeyboardInterrupt('Stop requested; restore before cleanup')
    signal.signal(signal.SIGTERM, interrupted)
    try:
        bus.start()
        if args.execute:
            outcome.update(supervisor.execute())
        else:
            supervisor.preflight()
            outcome['preflight_ready'] = True
    except BaseException as exc:
        outcome['error'] = repr(exc)
    finally:
        # Do not let a second Ctrl-C interrupt compensation; device lease still bounds a lost host.
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        try:
            outcome['restoration'] = supervisor.restore()
            outcome['analysis'] = analyse(supervisor.records)
            bus.save('outcome.json', outcome)
            print(json.dumps(outcome, indent=2), flush=True)
        finally:
            bus.cleanup()
    return 0 if (outcome.get('completed_hour') and outcome['restoration']['verified']) or outcome.get('preflight_ready') else 1


if __name__ == '__main__':
    raise SystemExit(main())
