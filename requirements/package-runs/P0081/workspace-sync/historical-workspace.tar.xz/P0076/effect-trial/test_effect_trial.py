"""Offline supervisor guard, phase, sequence and stability-analysis regressions."""
import copy
import unittest
from run_effect_trial import (ACTIVE, APPLY, IDLE, GateError, IdentityOrReset, Supervisor,
    EXPECTED_UID, analyse, check_continuity, feedback_ready, little_bytes,
    native_gate, next_sequence, oscillations, owned_active, restore_verified,
    trial_safety, accepted_points, renewal_confirmed)


def snapshot(t=0, watts=6000, count=1):
    return {'timestamp': 'test', 'elapsed_s': t, 'monotonic_s': t, 'meta': [888, 76, 36, 1, 0, 0, 0, 0, 0, int(t), 0, 1],
            'identity': {'uid96': EXPECTED_UID},
            'native': {'power': 1, 'operating_mode': 2, 'mode': 1, 'flow': 2950, 'dhw': 5200,
                       'boost': 0, 'fresh26': True, 'fresh09': True, 'fresh28': True,
                       'raw28': (b'\x28' + bytes(15)).hex(),
                       'generation26': count, 'generation09': count, 'generation28': count},
            'control': {'state': ACTIVE, 'saved': 1, 'mode': 5, 'accepted': 8, 'applied': 8,
                        'lease_s': 120, 'error': 0, 'touched': 12, 'restores': 0,
                        'current_power': 1, 'current_mode': 1, 'current_flow': 2950,
                        'current_dhw': 5200, 'current_boost': 0},
            'effect': {'target_w': 6000, 'maximum_flow_cC': 3800, 'phase': 3},
            'feedback': {'coherent': True, 'quality': 0, 'ready': True, 'short_count': 8,
                         'short_span_s': 50, 'last_age_s': 1, 'short_w': watts, 'instant_w': watts,
                         'temperature_generation': count, 'flow_generation': count,
                         'accepted_count': count},
            'telemetry': [{'status': 1, 'age_s': 2, 'value': 3000} for _ in range(20)]}


class SupervisorTests(unittest.TestCase):
    def test_sequence_next_and_wrap(self):
        self.assertEqual([next_sequence(x) for x in (0, 1, 65534, 65535)], [1, 2, 65535, 1])
        for invalid in (-1, 65536, True, None):
            with self.assertRaises(ValueError):
                next_sequence(invalid)

    def test_raw_payload_little_endian(self):
        self.assertEqual(little_bytes([38, 256, 2, 514, 20500]), b'\x26\x00\x00\x01\x02\x00\x02\x02\x14\x50')

    def test_native_flags_allow_only_unrelated_cooling(self):
        s = snapshot()
        flags = bytearray.fromhex(s['native']['raw28'])
        flags[7] = flags[9] = 1
        s['native']['raw28'] = flags.hex()
        native_gate(s)
        for index in (3, 4, 6, 10):
            bad = copy.deepcopy(s)
            altered = bytearray(flags)
            altered[index] = 1
            bad['native']['raw28'] = altered.hex()
            with self.assertRaises(GateError):
                native_gate(bad)
        for key in ('fresh26', 'fresh09', 'fresh28'):
            bad = copy.deepcopy(s); bad['native'][key] = False
            with self.assertRaises(GateError):
                native_gate(bad)

    def test_phase_readiness_and_pending_behavior(self):
        s = snapshot()
        self.assertTrue(owned_active(s, 8))
        s['control']['state'] = APPLY
        self.assertFalse(owned_active(s, 8))
        self.assertTrue(renewal_confirmed(s, 8))
        self.assertFalse(renewal_confirmed(s, 9))
        trial_safety(s)  # A legitimate in-flight adjustment may be APPLY.
        s['feedback']['quality'] = 2; s['feedback']['ready'] = False
        self.assertFalse(feedback_ready(s))
        trial_safety(s)  # Partial FAST pair pauses, but is not a valid renewal sample.
        s['feedback']['last_age_s'] = 21
        with self.assertRaises(GateError):
            trial_safety(s)

    def test_native_dhw_overtemp_and_wrong_intent_abort(self):
        for mutate in (lambda s: s['native'].update(operating_mode=1),
                       lambda s: s['telemetry'][3].update(value=4001),
                       lambda s: s['effect'].update(target_w=7000),
                       lambda s: s['native'].update(flow=3801),
                       lambda s: s['control'].update(state=IDLE)):
            s = snapshot(); mutate(s)
            with self.assertRaises(GateError):
                trial_safety(s)

    def test_reset_detection_with_legitimate_uptime_wrap(self):
        old, new = snapshot(100), snapshot(110)
        old['meta'][9] = 65530; new['meta'][9] = 4
        check_continuity(old, new)
        old['meta'][9] = 100; new['meta'][9] = 3
        with self.assertRaises(IdentityOrReset):
            check_continuity(old, new)

    def test_restore_requires_counter_settings_and_fresh_independent_observation(self):
        s = snapshot(count=12)
        original = {k: s['native'][k] for k in ('power', 'mode', 'flow', 'dhw', 'boost')}
        s['control'].update(state=IDLE, saved=0, touched=0, restores=1)
        before = {'26': 11, '09': 11, '28': 11}
        self.assertTrue(restore_verified(s, original, 0, before))
        for mutate in (lambda s: s['control'].update(saved=1),
                       lambda s: s['control'].update(restores=0),
                       lambda s: s['native'].update(generation09=11),
                       lambda s: s['native'].update(flow=3000)):
            bad = copy.deepcopy(s); mutate(bad)
            self.assertFalse(restore_verified(bad, original, 0, before))

    def test_six_sustained_alternating_excursions(self):
        points = [{'t': t, 'w': 7500 if (t-900)//60 % 2 == 0 else 4500}
                  for t in range(900, 1270, 10)]
        self.assertTrue(oscillations(points)['detected'])
        self.assertFalse(oscillations([{'t': p['t'], 'w': 4500} for p in points])['detected'])
        self.assertFalse(oscillations([{'t': t, 'w': 7500 if t % 20 else 4500}
                                      for t in range(900, 1270, 10)])['detected'])
        self.assertFalse(oscillations([{'t': p['t']-900, 'w': p['w']} for p in points])['detected'])

    def test_stability_requires_coverage_and_unique_ready_measurements(self):
        good = [snapshot(t, 6000 + (t % 30 - 10)*10, t//10) for t in range(0, 3601, 10)]
        result = analyse(good)
        self.assertTrue(result['stable'])
        self.assertEqual(result['last20min_coverage_s'], 1200)
        self.assertFalse(analyse(good[:60])['stable'])
        for row in good:
            row['feedback']['accepted_count'] = 1
        result = analyse(good)
        self.assertEqual(result['unique_ready_pairs'], 1)
        self.assertEqual(result['assessment'], 'insufficient-data')

    def test_low_output_and_wide_variation_not_called_stable(self):
        low = [snapshot(t, 4000, t) for t in range(0, 3601, 10)]
        self.assertFalse(analyse(low)['stable'])
        wide = [snapshot(t, 6000 + (2000 if t % 60 < 30 else -2000), t) for t in range(0, 3601, 10)]
        self.assertFalse(analyse(wide)['stable'])

    def test_pending_retained_accepted_mean_and_hard_invalid(self):
        rows = [snapshot(10*i, count=i) for i in range(4)]
        for row in rows:
            row['feedback'].update(quality=2, ready=False, instant_w=None)
        self.assertEqual(len(accepted_points(rows)), 4)
        self.assertFalse(feedback_ready(rows[0]))
        rows[1]['feedback']['accepted_count'] = 0
        rows[2]['feedback']['quality'] = 3
        rows[3]['feedback']['last_age_s'] = 21
        self.assertEqual(len(accepted_points(rows)), 1)

    def test_curve_restoration_allows_recomputed_target_but_verifies_written_target(self):
        s = snapshot(count=12)
        original = {k: s['native'][k] for k in ('power', 'mode', 'flow', 'dhw', 'boost')}
        original['mode'] = 2
        s['control'].update(state=IDLE, saved=0, touched=0, restores=1, current_mode=2)
        s['native'].update(mode=2, flow=3100)
        before = {'26': 11, '09': 11, '28': 11}
        self.assertTrue(restore_verified(s, original, 0, before))
        s['control']['current_flow'] = 3000
        self.assertFalse(restore_verified(s, original, 0, before))

    def test_full_hour_with_busy_retry_renewals_and_restore_offline(self):
        from live_bus import ModbusException
        from contextlib import redirect_stdout
        from io import StringIO
        class Clock:
            now = 0
            def time(self): return self.now
            def sleep(self, seconds): self.now += seconds
        clock = Clock()
        class Bus:
            def __init__(self):
                self.commands = []; self.accepted = 0; self.state = IDLE
                self.saved = self.touched = self.restores = 0
                self.mode = 2; self.armed = False; self.busy_once = True; self.sent_at = 0
            def save(self, name, obj): pass
            def log(self, kind, obj): pass
            def arm_control(self): self.armed = True
            def command(self, words):
                assert self.armed
                if self.busy_once:
                    self.busy_once = False
                    raise ModbusException(6)
                assert words[1] == next_sequence(self.accepted)
                self.commands.append(words); self.accepted = words[1]; self.sent_at = clock.time()
                if words[2] == 5:
                    self.state = ACTIVE; self.saved = 1; self.touched = 12; self.mode = 1
                else:
                    self.state = IDLE; self.saved = self.touched = 0; self.mode = 2; self.restores += 1
        bus = Bus()
        class SimulatedSupervisor(Supervisor):
            generation = 0
            def capture(self):
                self.generation += 1; clock.sleep(.2)
                s = snapshot(clock.time(), count=self.generation)
                s['native']['mode'] = bus.mode
                s['control'].update(state=bus.state, accepted=bus.accepted, applied=bus.accepted,
                    saved=bus.saved, touched=bus.touched, restores=bus.restores,
                    mode=5 if bus.saved else 1, current_mode=bus.mode,
                    lease_s=max(0, 180-int(clock.time()-bus.sent_at)))
                for key, value in dict(power=1, mode=2, flow=2950, dhw=5200, boost=0).items():
                    s['control']['original_'+key] = value
                self.last = s
                return s
        supervisor = SimulatedSupervisor(bus, clock=clock.time, sleep=clock.sleep)
        with redirect_stdout(StringIO()):
            result = supervisor.execute()
            restore = supervisor.restore()
        self.assertTrue(result['completed_hour'])
        self.assertTrue(result['analysis']['stable'])
        self.assertTrue(restore['verified'])
        self.assertGreaterEqual(len(bus.commands), 50)
        self.assertEqual(bus.commands[-1][2], 1)
        self.assertEqual(bus.restores, 1)


if __name__ == '__main__':
    unittest.main()
