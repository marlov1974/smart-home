"""Offline transport regressions: a mocked UART/Shelly, never a live device."""
import base64
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

import live_bus as bus

EFFECT = [0xC076, 1, 5, 6000, 3800, 180, 1, 3]
AUTO = [0xC072, 2, 1, 0, 0, 0, 0, 2]


def command_frame(words):
    return bus.with_crc(bytes.fromhex('01 10 01 2c 00 08 10') +
                        b''.join(w.to_bytes(2, 'big') for w in words))


class HostTests(unittest.TestCase):
    def test_known_crc_and_read_frame(self):
        self.assertEqual(bus.with_crc(bytes.fromhex('01030000000a')).hex(),
                         '01030000000ac5cd')
        self.assertEqual(bus.crc16(command_frame(EFFECT)), 0)

    def test_exact_command_scope(self):
        bus.validate_words(EFFECT)
        bus.validate_words(AUTO)
        for i, v in [(0, 0xC072), (1, 0), (2, 4), (3, 6001), (4, 4000),
                     (5, 179), (6, 0), (7, 2)]:
            bad = EFFECT.copy()
            bad[i] = v
            with self.subTest(index=i), self.assertRaises(ValueError):
                bus.validate_words(bad)
        for bad in [EFFECT[:-1], EFFECT + [0], [True] + EFFECT[1:],
                    EFFECT[:1] + [65536] + EFFECT[2:]]:
            with self.assertRaises(ValueError):
                bus.validate_words(bad)

    def session(self, directory):
        # Keep offline tests independent of the live process lock and release
        # descriptors even when an assertion fails before mocked cleanup.
        with patch.object(bus, '__file__', str(Path(directory) / 'live_bus.py')):
            session = bus.Session(Path(directory) / 'run', ttl_s=120)
        self.addCleanup(lambda: session._lock.close() if not session._lock.closed else None)
        return session

    def test_local_lock_excludes_second_owner_before_any_rpc(self):
        with tempfile.TemporaryDirectory() as directory, \
             patch.object(bus, '__file__', str(Path(directory) / 'live_bus.py')), \
             patch.object(bus.Session, 'rpc') as rpc:
            first = bus.Session(Path(directory) / 'first', ttl_s=120)
            self.addCleanup(lambda: first._lock.close() if not first._lock.closed else None)
            with self.assertRaisesRegex(RuntimeError, 'Another local trial session'):
                bus.Session(Path(directory) / 'second', ttl_s=120)
            rpc.assert_not_called()
            first._lock.close()
            third = bus.Session(Path(directory) / 'third', ttl_s=120)
            self.addCleanup(lambda: third._lock.close() if not third._lock.closed else None)
            rpc.assert_not_called()

    def test_no_host_write_before_arming(self):
        with tempfile.TemporaryDirectory() as directory:
            session = self.session(directory)
            session.active = True
            with patch.object(session, 'exchange') as exchange:
                for words in (EFFECT, AUTO):
                    with self.assertRaisesRegex(RuntimeError, 'not armed'):
                        session.command(words)
                exchange.assert_not_called()

    def test_host_disallows_bad_read_and_armed_bad_command_before_io(self):
        with tempfile.TemporaryDirectory() as directory:
            session = self.session(directory)
            session.active = session.armed = True
            with patch.object(session, 'exchange') as exchange:
                for addr, qty in [(-1, 1), (384, 1), (383, 2), (0, 17),
                                  (0, 0), (True, 1), (0, True)]:
                    with self.assertRaises(ValueError):
                        session.read(addr, qty)
                bad = EFFECT.copy()
                bad[3] = 6500
                with self.assertRaises(ValueError):
                    session.command(bad)
                exchange.assert_not_called()

    def test_host_rejects_wrong_response_shapes_and_write_echo(self):
        with tempfile.TemporaryDirectory() as directory:
            session = self.session(directory)
            session.active = session.armed = True
            malformed = bus.with_crc(bytes.fromhex('0104011234'))
            with patch.object(session, 'exchange', return_value=malformed):
                with self.assertRaisesRegex(RuntimeError, 'Read shape'):
                    session.read(0, 1)
            wrong_echo = bus.with_crc(bytes.fromhex('0110012d0008'))
            with patch.object(session, 'exchange', return_value=wrong_echo):
                with self.assertRaisesRegex(RuntimeError, 'Write echo'):
                    session.command(EFFECT)

    def test_host_rejects_bad_reply_crc_sid_and_function(self):
        replies = [bus.with_crc(bytes.fromhex('0204020001')),
                   bus.with_crc(bytes.fromhex('0103020001')),
                   bytes.fromhex('01040200010000')]
        with tempfile.TemporaryDirectory() as directory:
            session = self.session(directory)
            session.active = True
            request = bus.with_crc(bytes.fromhex('010400000001'))
            for reply in replies:
                with self.subTest(reply=reply.hex()), \
                     patch.object(session, 'evaluate', side_effect=[
                         {'sent': len(request)},
                         {'done': True, 'waiting': False, 'error': '',
                          'base64': base64.b64encode(reply).decode()}]), \
                     patch.object(bus.time, 'sleep'), self.assertRaises(RuntimeError):
                    session.exchange(request)

    def test_cleanup_runtime_restore_and_stop_without_persistent_uart_change(self):
        with tempfile.TemporaryDirectory() as directory:
            session = self.session(directory)
            session.changed = session.active = session.armed = True
            methods = []

            def rpc(method, params=None):
                methods.append((method, params))
                return {'running': True} if method == 'Script.GetStatus' else {}

            with patch.object(session, 'rpc', side_effect=rpc), \
                 patch.object(session, 'evaluate', return_value={'restored': True}) as evaluate, \
                 patch.object(session, 'identity', return_value={'checked': True}):
                result = session.cleanup()
            self.assertTrue(result['runtime_uart_restored'])
            self.assertEqual(result['errors'], [])
            evaluate.assert_called_once_with('trialRestore()')
            self.assertIn(('Script.Stop', {'id': 8}), methods)
            self.assertFalse(any(method.startswith('Serial.Set') for method, _ in methods))
            self.assertFalse(session.active)
            self.assertFalse(session.armed)


NODE_RUNNER = r'''
const vm = require('node:vm');
const assert = require('node:assert/strict');
const input = JSON.parse(require('node:fs').readFileSync(0,'utf8'));
function fixture() {
  const st = {time:0, configs:[], sends:[], calls:[], timer:null, receiver:null};
  const uart = {
    configure(c) {st.configs.push(JSON.parse(JSON.stringify(c)));},
    send(s) {st.sends.push(s);return st.shortSend ? s.length-1 : s.length;},
    recv(f) {st.receiver=f;}
  };
  const context = vm.createContext({
    UART:{get(id){assert.equal(id,0);return uart;}},
    Shelly:{getUptimeMs(){return st.time;},call(m,p){st.calls.push([m,JSON.parse(JSON.stringify(p))]);}},
    Timer:{set(ms,repeat,f){assert.equal(repeat,false);st.timer={ms,f};}},
    atob:s=>Buffer.from(s,'base64').toString('latin1'),
    btoa:s=>Buffer.from(s,'latin1').toString('base64')
  });
  vm.runInContext(input.source,context);
  st.run = s => vm.runInContext(s,context);
  st.result = () => JSON.parse(st.run('trialResult()'));
  st.send = frame => st.run('trialSend('+JSON.stringify(Buffer.from(frame).toString('base64'))+')');
  st.rx = frame => st.receiver(Buffer.from(frame).toString('latin1'));
  return st;
}
function crc(b) {let c=65535;for(const v of b){c^=v;for(let i=0;i<8;i++)c=(c>>>1)^((c&1)?0xa001:0);}return c;}
function frame(b){b=Buffer.from(b);const c=crc(b);return Buffer.concat([b,Buffer.from([c&255,c>>>8])]);}
function read(addr=0,qty=1,sid=1){return frame([sid,4,addr>>>8,addr&255,qty>>>8,qty&255]);}
function command(words=input.effect,addr=300){const b=[1,16,addr>>>8,addr&255,0,8,16];for(const w of words)b.push(w>>>8,w&255);return frame(b);}
function active(){const st=fixture();st.run('trialBegin()');return st;}
const tests = {
  startup_and_restore() {
    const st=fixture();assert.equal(st.sends.length,0);assert.equal(st.configs.length,0);
    assert.throws(()=>st.run('trialArm()'),/ARM_GATE/);
    st.run('trialBegin()');assert.deepEqual(st.configs,[{baud:9600,format:'8N1'}]);
    assert.throws(()=>st.run('trialBegin()'),/ACTIVE/);
    st.run('trialArm()');st.run('trialRestore()');
    assert.deepEqual(st.configs[1],{baud:115200,format:'8N1'});
    assert.throws(()=>st.send(read()),/TX_GATE/);
  },
  no_write_before_arm() {
    const st=active();assert.throws(()=>st.send(command()),/WRITE_GATE/);
    assert.equal(st.sends.length,0);
    st.run('trialArm()');st.send(command());assert.equal(st.sends.length,1);
    assert.throws(()=>st.send(read()),/TX_GATE/);
  },
  restrictive_frames() {
    const st=active();st.run('trialArm()');
    for(const b of [read(0,0),read(383,2),read(0,17),read(384,1),read(0,1,0),
                   frame([1,6,0,0,0,1]),command(input.effect,301)])
      assert.throws(()=>st.send(b));
    const bad=read();bad[7]^=1;assert.throws(()=>st.send(bad),/FRAME/);
    assert.equal(st.sends.length,0);
  },
  exact_effect_and_auto_scope() {
    const st=active();st.run('trialArm()');
    for(const [i,value] of [[0,49266],[1,0],[2,4],[3,6001],[4,4000],[5,179],[6,0],[7,2]]) {
      const words=input.effect.slice();words[i]=value;assert.throws(()=>st.send(command(words)));
    }
    const wrongAuto=input.auto.slice();wrongAuto[3]=3800;assert.throws(()=>st.send(command(wrongAuto)),/AUTO_SCOPE/);
    assert.equal(st.sends.length,0);st.send(command(input.auto));assert.equal(st.sends.length,1);
  },
  fragmented_reply_and_exception() {
    const st=active();st.send(read());const reply=frame([1,4,2,0x12,0x34]);
    st.rx(reply.subarray(0,3));assert.equal(st.result().done,false);
    st.rx(reply.subarray(3));assert.equal(st.result().done,true);assert.equal(st.result().error,'');
    st.send(read());st.rx(frame([1,0x84,6]));assert.equal(st.result().done,true);assert.equal(st.result().error,'');
  },
  bad_crc_extra_and_unsolicited_rx() {
    let st=active();st.send(read());const bad=frame([1,4,2,0,1]);bad[6]^=1;st.rx(bad);assert.equal(st.result().error,'RX_FRAME');
    st=active();st.send(read());st.rx(Buffer.concat([frame([1,4,2,0,1]),Buffer.from([0])]));assert.equal(st.result().error,'RX_FRAME');
    st=active();st.send(read());st.rx(frame([1,4,2,0,1]));st.rx([0]);assert.equal(st.result().error,'UNEXPECTED_RX');
    assert.throws(()=>st.send(read()),/TX_GATE/);
    st=active();st.rx([0]);assert.throws(()=>st.run('trialArm()'),/ARM_GATE/);
  },
  timeout_and_delayed_rx() {
    const st=active();st.send(read());st.time=2201;assert.equal(st.result().error,'RX_TIMEOUT');
    st.rx(frame([1,4,2,0,1]));assert.notEqual(st.result().error,'');
    assert.throws(()=>st.send(read()),/TX_GATE/);
  },
  delayed_rx_without_host_poll_is_rejected() {
    const st=active();st.send(read());st.time=2201;
    st.rx(frame([1,4,2,0,1]));assert.equal(st.result().error,'RX_TIMEOUT');
    assert.throws(()=>st.send(read()),/TX_GATE/);
  },
  short_send_and_watchdog() {
    const st=active();st.shortSend=true;st.send(read());assert.equal(st.result().error,'SHORT_SEND');
    assert.throws(()=>st.send(read()),/TX_GATE/);
    st.timer.f();assert.deepEqual(st.configs.at(-1),{baud:115200,format:'8N1'});
    assert.deepEqual(st.calls,[['Script.Stop',{id:8}]]);
  },
  declaration_order_and_no_persistent_config() {
    // Node compilation plus explicit declaration ordering; live mJS acceptance is a separate gate.
    const s=input.source;
    assert(s.indexOf('function trialRestore(')<s.indexOf('function trialExpire('));
    assert(s.indexOf('function trialExpire(')<s.indexOf('Timer.set('));
    assert(s.indexOf('function trialCRC(')<s.indexOf('function trialSend('));
    assert(!s.includes('Serial.SetConfig'));assert(!s.includes('Shelly.Reboot'));
    assert.equal(fixture().timer.ms,120000);
  }
};
tests[input.test]();
'''


class BridgeTests(unittest.TestCase):
    def check_case(self, name):
        run = subprocess.run(['node', '-e', NODE_RUNNER],
                             input=json.dumps({'source': bus.bridge_source(120),
                                               'test': name, 'effect': EFFECT, 'auto': AUTO}),
                             text=True, capture_output=True, check=False)
        self.assertEqual(run.returncode, 0, run.stdout + run.stderr)


for case in ['startup_and_restore', 'no_write_before_arm', 'restrictive_frames',
             'exact_effect_and_auto_scope', 'fragmented_reply_and_exception',
             'bad_crc_extra_and_unsolicited_rx', 'timeout_and_delayed_rx',
             'delayed_rx_without_host_poll_is_rejected', 'short_send_and_watchdog',
             'declaration_order_and_no_persistent_config']:
    setattr(BridgeTests, 'test_' + case, lambda self, name=case: self.check_case(name))


if __name__ == '__main__':
    unittest.main(verbosity=2)
