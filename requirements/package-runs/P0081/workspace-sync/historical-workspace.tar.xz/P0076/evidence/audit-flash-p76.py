"""Read local flash evidence only; never contacts a device."""
import base64,hashlib,json,sys
from pathlib import Path
from datetime import datetime
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'procon-melcobems-mini-a1m/tools'))
from flash_plan import build_plan
log=ROOT/'live-flash-20261008T0300Z'
read=lambda name:json.loads((log/name).read_text())
digest=lambda data:hashlib.sha256(data).hexdigest()
image=(ROOT/'firmware/procon-p76.bin').read_bytes()
manifest=(ROOT/'firmware/procon-p76.json').read_bytes()
assert digest(image)=='dcd1efe7634fdf38a67c6ffcd8e95614a963b232619b788549256b64ff692b44'
plan=build_plan(image,json.loads(manifest))
assert len(plan.packets)==69 and plan.erase_bytes==98304 and len(plan.program_data)==16480
provenance=read('provenance.json')
assert provenance['image_source_sha256']==digest(image)
assert provenance['release_manifest_sha256']==digest(manifest)
assert provenance['program_sha256']==digest(plan.program_data)
assert provenance['source_sha256']==digest((log/'deployed.js').read_bytes())
erase=read('erase-result.json')
intent=read('erase-intent.json')
assert intent['tx_hex']==plan.erase_frame.hex() and intent['relative_offset']==0 and intent['length']==98304
assert erase['phase']=='erased' and erase['error']=='' and base64.b64decode(erase['base64'])==b'\x71'
pages=[]
for i,packet in enumerate(plan.packets):
    staged=read('page-%03d-staged.json'%i)
    intent=read('page-%03d-intent.json'%i)
    result=read('page-%03d-result.json'%i)
    assert staged['staged_valid'] and staged['next_page']==i
    assert intent['offset']==packet.offset and intent['tx_length']==len(packet.frame)
    assert intent['sha256']==digest(packet.frame)
    assert base64.b64decode(result['base64'])==b'\x73' and not result['error']
    assert result['next_page']==i+1 and result['sent']==len(packet.frame)
    assert result['phase']==('complete' if i==68 else 'page_ok')
    pages.append(result)
outcome=read('outcome.json'); final=read('final-state.json'); session=read('session.json')
assert session['phase']=='TRANSFER_ACKNOWLEDGED_AWAIT_NORMAL_BOOT'
assert outcome['transfer_acknowledged'] and outcome['cleanup_verified']
assert outcome['pages_with_direct_ack']==69 and outcome['image_bytes_acknowledged']==16480
assert final['relays']==[False,False] and not final['cleanup_errors']
assert all(s['running'] is False and s['enable'] is False for s in final['scripts'])
assert final['serial']['mode']=='js_uart' and final['serial']['serial']=={'baud':115200,'format':'8N1'}
assert final['device']['id']=='shellypro2-80f3dac8bfec'
begin=datetime.fromisoformat(read('erase-intent.json')['timestamp'])
end=datetime.fromisoformat(outcome['timestamp'])
summary={
    'transfer_audit':'PASS','firmware_sha256':digest(image),
    'erase_bytes':plan.erase_bytes,'application_bytes':len(image),
    'alignment_ff_bytes':4,'program_bytes':len(plan.program_data),
    'packets_with_direct_73':len(pages),'erase_direct_71':True,
    'elapsed_erase_to_cleanup_seconds':round((end-begin).total_seconds(),3),
    'page_first_rx_ms_minmax':[min(p['first_rx_ms'] for p in pages),max(p['first_rx_ms'] for p in pages)],
    'partial_uart_accepts':sum(p['tx_stats']['partial_accepts'] for p in pages),
    'zero_uart_accepts':sum(p['tx_stats']['zero_accepts'] for p in pages),
    'all_scripts_stopped_disabled':True,'relays':[False,False],
    'normal_boot_verified':False,'flash_readback_verified':False,
    'timestamp':outcome['timestamp'],
    'next_step':'Operator power-off, DIP10000110, power-on, then P76 read-only normal verification'
}
(log/'independent-audit.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
