"""P0076 offline audit and record from immutable normal-mode read logs."""
import hashlib,json,sys,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import verify_normal_p76 as reader
log=ROOT/'20261008T031222.287126Z-p76-normal-verification'
outcome_path=log/'outcome.json'
original=outcome_path.read_bytes()
data=json.loads(original)
assert data['complete'] and data['normal_boot_verified'] and data['all_frames_crc_valid']
assert data['runtime_uart_115200_restored'] and data['all_scripts_stopped_disabled']
assert not data['cleanup_errors'] and data['persistent_serial_modified'] is False
for sample,(addr,qty) in zip(data['samples'],reader.READS):
    assert sample['address']==addr and sample['quantity']==qty
    assert reader.decode_reply(bytes.fromhex(sample['rx_hex']),qty)==sample['values']
assert len(data['samples'])==20
unit=reader.decode_unit_identity(data['samples'][2]['values'])
assert unit==reader.decode_unit_identity(data['samples'][19]['values'])
final=json.loads((log/'final-state.json').read_text())
assert final['relays']==[False,False]
assert all(s['enable'] is False and s['running'] is False for s in final['scripts'])
assert final['serial']['mode']=='js_uart' and final['serial']['serial']=={'baud':115200,'format':'8N1'}
required=(3,4,8)
first,second=data['snapshots']
before=data['samples'][12]['values'];after=data['samples'][16]['values']
deltas=data['generation_deltas']
liveness=(second['cn105_linked'] and all(0<deltas[i]<32768 and before[i]==after[i]==1 for i in required))
assert liveness
rows=[]
for low_i,high_i in ((5,6),(13,14)):
    low=data['samples'][low_i];high=data['samples'][high_i]
    words=low['values']+high['values'];values={}
    for i,name in enumerate(reader.NAMES):
        raw=(words[2*i]<<16)|words[2*i+1]
        values[name]=None if raw==0x80000000 else raw-(1<<32) if raw&(1<<31) else raw
    rows.append({'low_block_timestamp':low['timestamp'],'high_block_timestamp':high['timestamp'],
                 'raw_values_by_documented_unit':values,'atomic_across_blocks':False,
                 'note':'Non-sentinel individual field observations; not a coherent system snapshot or heat/COP estimate.'})
audit={'normal_boot_verified':True,'unit_identity':unit,'responses_crc_valid':20,
       'cn105_communication_liveness_verified':bool(liveness),
       'required_direct_generation_deltas':{str(180+i):deltas[i] for i in required},
       'cn105_replies':[first['cn105_replies'],second['cn105_replies']],
       'cn105_errors':[first['cn105_errors'],second['cn105_errors']],
       'cn105_uart_errors':[first['cn105_uart_errors'],second['cn105_uart_errors']],
       'original_strict_cn105_updates_verified':data['cn105_updates_verified'],
       'strict_coherence_note':'Normal FAST updates occurred during both multi-block brackets. Original coherent values and flags remain unchanged; liveness is separate from cross-block value coherence.',
       'observed_values':rows,'cleanup_verified':True,'writes_to_heat_pump':0,
       'outcome_sha256':hashlib.sha256(original).hexdigest()}
(log/'offline-liveness-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
assert outcome_path.read_bytes()==original
public='''# P0076 normal boot and address-1 verification — 2026-10-08

After the operator confirmed DIP10000110 and power cycling, the flashed P0076 r1
application passed twenty fixed addressed FC04 reads. No FC16, heat control,
fault reset or further bootloader command was sent.

## Identity and addressing

- Input0/1 =888/76; revision/API/features/control state at68..71 =1/1/15/0.
- Input72..77 =1/1/1/3/1/1: schema1, effective/configured address1, hardware DIP,
  valid configuration and valid factory MCU UID.
- Input84..86 =97/1/0: raw0x61, startup samples agreed, no rejection reason.
- The full96-bit UID and all identity/DIP words matched in both reads.

This physically confirms the expected DIP10000110/raw0x61/address1 mapping on
the connected unit. It does not verify another address, every switch, a second
unit, or simultaneous two-unit operation.

## Communication and observations

All20 replies passed frame/CRC checks. CN105 remained linked. The reply counter
increased4→10; communication and UART error counters stayed0. Direct temperature
and Hz generations183/184/188 advanced6→11 between the completed brackets;
their second-bracket endpoint statuses were VALID. Both brine generations also
advanced. These establish communication liveness with fresh source updates.

Individual field observations, acquired in separate blocks:

| Field | First observation | Second observation |
|---|---|---|
| Brine service27 /28 |8 /7C |6 /6C |
| Flow /return temperature |28 /28C |28 /28C |
| Primary water flow |11L/min |11L/min |
| Compressor |0Hz |0Hz |
| DHW tank |49C |49C |
| Outdoor |10C |10C |

Brine service interpretation and whole-degree resolution retain their documented
limits. These values are not a simultaneous calibrated system snapshot. No COP
or EFFECT-control performance is inferred. Brine-pump run/step are still absent.

## Strict snapshot flag and final state

The original verifier reports `cn105_updates_verified=false`: that flag requires
unchanged source generations over each approximately9-second multi-block read.
Normal FAST updates during both brackets correctly prevent treating the values
as a coherent snapshot. The immutable original log is retained. A separate
offline audit records `cn105_communication_liveness_verified=true` from link,
direct-source generation progress and valid endpoint statuses, without relaxing
the original process-value coherence rule or issuing more device commands.

Runtime UART was restored to1152008N1, all Shelly scripts stopped/disabled and
both relay outputs stayedoff. Persistent serial configuration is unchanged
(js_uart1152008N1). Procon runs normal application96008N1/address1; the next read
tool must select the application baud while it owns the serial port.

Shared-bus operation, address2, supervised EFFECT response and reset-persistent
restoration remain unverified. No P0077 experiment was run.
'''
source=ROOT/'procon-melcobems-mini-a1m';sm=ROOT/'smart-home'
(source/'docs/p76-normal-verification.md').write_text(public)
private=public+'\n## Site identity and provenance\n\nUID: `'+unit['uid96']+'`. Raw evidence: `P0076/'+log.name+'/`.\nOriginal outcome SHA256: `'+audit['outcome_sha256']+'`.\nOnly local logs contain site endpoints and the full device identity.\n'
(sm/'requirements/package-runs/P0076/normal-verification.md').write_text(private)
for path,label,target in [
    (source/'docs/p76-flash-verification.md','Normal boot and address1 are now verified','p76-normal-verification.md'),
    (source/'docs/p76-verification.md','Subsequent normal boot and address1 verification passed','p76-normal-verification.md'),
    (sm/'requirements/package-runs/P0076/flash-verification.md','Normal boot and address1 are now verified','normal-verification.md'),
    (sm/'requirements/package-runs/P0076/verification.md','Subsequent normal boot and address1 verification passed','normal-verification.md')]:
    old=path.read_text();title,rest=old.split('\n',1)
    path.write_text(title+'\n\n['+label+']('+target+'). Statements below describe the earlier stage.\n'+rest)
with (sm/'requirements/package-runs/P0076/CHANGELOG.md').open('a') as f:
    f.write('\n- Operator-confirmed restart:20/20 FC04 responses validate P76 r1, DIP0x61,\n  address1 and stable validUID. CN105/FAST/A3 source generations advance with\n  zero reported communications errors. Runtime UART/cleanup verified.\n- Original strict coherence flags preserved; offline communication-liveness\n  audit distinguishes refreshing sources from a coherent multi-block snapshot.\n- New normal-verification reports and repository indexes updated. No firmware\n  changes or new heat commands. No further global knowhow promotion: this is\n  project-specific sample-coherence evidence, recorded in the verification report.\n')
with (ROOT/'README.md').open('a') as f:
    f.write('\n## Verifierad normal uppstart\n\nEfter fysisk omstart är P0076 r1, DIP0x61/adress1 och stabilt processor-ID nu\nverifierade.20/20 lässvar är CRC-giltiga och CN105-värden uppdateras. Se\n`smart-home/requirements/package-runs/P0076/normal-verification.md`. Styrning\naktiverades inte. Shelly-skripten är stoppade och tillfällig UART-baud återställd.\n')
for repo in (source,sm):
    names=sorted(set(subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=repo,text=True).splitlines()))
    (repo/'REPOSITORY_FILES.md').write_text('# Repository File Index\n\nThis file is generated from tracked Git files.\n\nUse it when GitHub/chat review contexts cannot enumerate repository files directly.\n\nTracked file count: '+str(len(names))+'\n\n## Files\n\n'+''.join('- `'+n+'`\n' for n in names))
    subprocess.run(['git','add','.'],cwd=repo,check=True)
    subprocess.run(['git','diff','--cached','--check'],cwd=repo,check=True)
with (ROOT/'evidence/p76-normal-sanitize.json').open('w') as f:
    subprocess.run(['python3','tools/sanitize.py'],cwd=source,stdout=f,check=True)
print(json.dumps({'normal_boot_verified':True,'address':1,'raw_dip':97,
                  'cn105_communication_liveness_verified':bool(liveness),
                  'latest_individual_field_observations':rows[-1],
                  'original_logs_unchanged':True,'reports_written':True},indent=2))
