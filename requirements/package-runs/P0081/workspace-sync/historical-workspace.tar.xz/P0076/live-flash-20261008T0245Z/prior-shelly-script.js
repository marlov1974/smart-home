let normalUart=UART.get(0);
if(!normalUart)throw new Error('UART_UNAVAILABLE');
let normalFrames=["\x01\x04\x00\x00\x00\x02\x71\xcb","\x01\x04\x00\x44\x00\x04\xb1\xdc","\x01\x04\x00\xb4\x00\x10\xb1\xe0","\x01\x04\x00\xb4\x00\x10\xb1\xe0"];
let normalIndex=0,normalActive=false,normalWaiting=false,normalRestored=false;
let normalRaw='',normalReceived=0,normalSent=0,normalStray=0,normalError='';
function normalRestore(){
  normalActive=false;normalWaiting=false;
  normalUart.configure({baud:115200,format:'8N1'});
  normalRestored=true;
  return JSON.stringify({restored:true,baud:115200,format:'8N1'});
}
normalUart.recv(function(data){
  if(!normalWaiting){normalStray+=data.length;return;}
  normalReceived+=data.length;
  normalRaw+=data.slice(0,64-normalRaw.length);
  if(normalReceived>64)normalError='RX_OVERFLOW';
});
function normalBegin(){
  if(normalActive||normalIndex!==0||normalRestored)throw new Error('BEGIN_ONCE');
  normalUart.configure({baud:9600,format:'8N1'});
  normalActive=true;
  return JSON.stringify({baud:9600,format:'8N1',read_only:true});
}
function normalRead(index){
  if(!normalActive||normalRestored||normalWaiting||normalError||normalStray||index!==normalIndex||index>=4)throw new Error('READ_GATE');
  normalRaw='';normalReceived=0;normalSent=0;normalWaiting=true;normalIndex++;
  normalSent=normalUart.send(normalFrames[index]);
  if(normalSent!==8)normalError='SHORT_SEND';
  return JSON.stringify({index:index,sent:normalSent});
}
function normalResult(index){
  if(!normalWaiting||index!==normalIndex-1)throw new Error('RESULT_GATE');
  normalWaiting=false;
  return JSON.stringify({index:index,sent:normalSent,received:normalReceived,base64:btoa(normalRaw),stray:normalStray,error:normalError});
}
Timer.set(120000,false,function(){normalRestore();Shelly.call('Script.Stop',{id:8});});
