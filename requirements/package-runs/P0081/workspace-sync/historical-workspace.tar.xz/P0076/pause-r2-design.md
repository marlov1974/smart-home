# P0076 r2 — operator-requested pause correction

Scope: offline firmware candidate correcting the observed startup latch and
normal standby abort. No hardware write, flash or new trial is part of this build.
Keep r1 logs and packaged images unchanged. Public-tree edits are local staged
work; this is not a synchronization or publication of the Smart Home checkout.

Review: WARN. A ten-minute native minimum-off time is operator-observed, not
verified protocol knowledge. No compressor force/start or bypass is introduced.
The native stop threshold and minimum sustainable heat output remain unknown.

Design and functions:
- effect_feedback_tick: require fresh valid Hz as well as existing sources.
  Classify native standby0 or heating2/7 with Hz0 as WAIT_NATIVE. Clear averages;
  allow zero water flow during this explicitly qualified pause only. Do not hide
  bad temperature/flow/Hz sensors, stale sources, link loss or DHW/cooling modes.
  After pause, classify a full60s of heating/Hz>0 and fresh paired samples as
  SETTLING; only then expose READY. Restarts reset the60s interval.
- ctl_tick/ctl_submit/ctl_reply/ctl_observe: preserve the original snapshot and
  lease during a qualified pause; renewals remain possible. Allow initial
  capture of a powered, unblocked native heating configuration during standby,
  but only its combined same-target fixed-mode selection, not target increments.
  Finish readback of an already sent write; suspend unsent adjustments and
  revalidate guards before reuse. Bound pause/recovery to20min without resetting
  it on renewals. Native power-off, external mode change, inhibits, hard-invalid
  feedback and expired lease still restore. Report a separate wait-timeout reason.
- effect_wait: mark WAIT/SETTLING, clear old derivative and pending response
  assessment; preserve cumulative budgets and all latched limits. Minimum60s
  adjustment interval begins after recovered feedback, preventing immediate
  reaction to startup ramp. No forced temperature nudge during idle.
- read_mvp: decode added quality8/9 and firmware revision2. Preserve existing
  wire formats and existing numeric states; append new states/reason only.

Tests: ten-minute pause with renewals and zero flow; delayed initial startup;
fresh post-start history; Hz blips; stale/invalid/DHW failures while waiting;
AUTO/lease/20min wait-timeout restoration; pending/inflight transaction races;
no unresponsive count or budget reset during pause; bounded minute adjustments;
existing sanitizer tests and actual ARM image integration; deterministic image.

Reducing cycling: avoid pre-start staircase and cold-start measurements driving
raises; retain measured-power hysteresis/derivative anticipation. Do not claim
cycles eliminated or infer an exact native temperature threshold from one run.
No persistent recovery across processor reset is added.

## Operator clarification: keep native heat demand during pause

The operator explicitly requested a target above current supply while waiting.
Supersedes the earlier blanket no-increments rule: effect_pause_demand requests
fresh supply+0.5C only with WAIT_NATIVE and0Hz. Limit each step to+1C/60s and
retain the command cap, cumulative+5C budget and every latched limit. A standby
increment never arms the non-response assessment. Already higher targets stay.

Add supply_cC to internal effect_measurement (not a wire ABI change), populated
from the validated telemetry source. effect_pending_demand identifies purpose so
ctl_tick/ctl_next permit guarded demand adjustments only during qualified pause
and discard unsent demand on restart. No demand raises during SETTLING. Complete
readback and account for an already-sent adjustment even if native state changes.
Tests cover target33.5C from measured33C, budget/cap exhaustion, cancellation at
restart and absence of false unresponsive counts. This change does not prove the
native restart temperature threshold or shorten Mitsubishi's timer.
