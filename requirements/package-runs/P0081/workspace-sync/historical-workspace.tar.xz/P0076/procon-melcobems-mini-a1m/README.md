# Procon MELCOBEMS MINI (A1M) replacement firmware

Independent community replacement firmware for the Procon MELCOBEMS MINI, also called A1M, providing Mitsubishi Electric Ecodan/Geodan heat pump CN105 telemetry over Modbus RTU. This project is not affiliated with or endorsed by Mitsubishi Electric or Procon.

The board target is STM32L433 on Procon R5B; both site CPUs were identified by the operator. Earlier revisions verified Modbus, CN105 telemetry, brine service candidates and supervised v2 control/restoration on one device. **P0076 r2 is an offline-tested candidate** adding delivered-water-power feedback control and DIP-selected addresses. r1 addressing and guarded restore were physically observed; r2 native-pause handling still requires isolated hardware validation. Native protections remain active, and restoration after reset/power loss is not implemented; unattended control remains blocked.

This repository is being prepared privately for public review. No vendor firmware, updater, manuals, private infrastructure logs or proprietary code is included. License: GPL-3.0-only; see [LICENSE](LICENSE) and [attribution](THIRD_PARTY_NOTICES.md).

## Build and test

On Apple Silicon macOS or x86_64 Linux, install Python3, Node.js, make, clang, curl and tar, then:

```sh
sh tools/setup.sh
make verify
```

The installer pins Arm GNU14.3.Rel1 and verifies its archive SHA256. Dependencies are isolated in .local. Build verification needs no vendor files, credentials, device or upstream private repository. See [building](docs/building.md). CI runs the same source build, host tests, actual-ELF ARM mock-peripheral tests, image bounds and deterministic BIN check.

## Capabilities

- DIP-selected Modbus address, 9600 8N1; input0=888, package76/revision2/API1/capabilities15.
- CN1052400 8E1 FAST telemetry and exclusive alternating A3 service27/28.
- Compressor Hz, brine candidates, supply/return, DHW/outdoor, primary flow, targets/status and coherent water-side watts.
- Preserved [v2 supervised controls](docs/control-v2.md) plus versioned [EFFECT control](docs/effect-control.md), filtered diagnostics and guarded restoration.
- [DIP addressing and MCU identity](docs/addressing.md), isolated provisioning and [offline host tools](docs/host-tools-p76.md).
- Brine-pump run/step and reliable live electrical COP remain unavailable. Water-side estimated power requires an operator-verified heating measurement boundary.

Read [register API](docs/modbus.md), [architecture](docs/architecture.md), [hardware](docs/hardware.md), [CN105 packets](docs/cn105-packets.md), [Geodan A3 findings](docs/a3-service-protocol.md) and [verification](docs/verification.md).

## Protocol research

The [Procon cross-reference](docs/cn105-procon-cross-reference.md) links original descriptor/handler evidence to RS485 registers. The [master catalog](docs/cn105-master-catalog.md) separately reconciles external sources, conflicts and unknowns. Numeric evidence is reproducible using optional privately obtained inputs; the firmware build and CI never require them. Research coverage is explicit and is not a claim that every possible device command is understood.

[Flashing/recovery](docs/flashing-and-recovery.md), [security](SECURITY.md), [contributing](CONTRIBUTING.md), [release process](docs/releases.md) and [public review checklist](docs/public-release-checklist.md). Suggested repository topics: procon, melcobems, a1m, mitsubishi-electric, ecodan, geodan, cn105, modbus, heat-pump, stm32, home-automation. Only the operator changes repository visibility.

## From-scratch platform specification

[P0074 engineering reference](docs/hardware-reference/overview.md) documents memory/startup, clocks, pins, UARTs, LEDs, watchdog and update boundaries separately from the application profile. Follow the [empty-project guide](docs/clean-room-guide/from-zero-to-led.md), [wire protocols](docs/protocol-reference/cn105-packets.md), [platform JSON](docs/platform-spec.json), [golden vectors](docs/verification-vectors.json) and [known unknowns](docs/known-unknowns.md). The [documentation-only independence review](docs/clean-room-guide/independence-review.md) states what can be reproduced and what remains unverified. No control support is added by this documentation package.

## Readback research

[P0075 readback research](docs/firmware-readback.md) adds discovery, bounded supervised experiment tools and offline exact dump comparison. Physical discovery works; [64 distinct read hypotheses](docs/firmware-readback-experiments.md) returned no data. Flash extraction remains blocked by the unknown read protocol. No new application firmware is included. Run `make readback-test` with Python3 and Node.js. Normal Modbus operation was restored and verified; a Shelly restart during test-script removal remains a documented cleanup anomaly.

A subsequent operator-authorized [write-reference comparison](docs/write-reference-experiments.md) measured negative write ACKs, incomplete-packet behavior and cached-ACK responses after silent read requests. It did not establish successful programming or a working flash reader. The two additional adapters remain bounded research tools with offline tests.

A further operator-authorized [single-byte opcode sweep](docs/opcode-sweep.md) completed `00..FF` once, without helper traffic: four responding opcodes and 252 silent values. `57` returned no bytes. At the end of that stage the research script was stopped/disabled and physical restoration was pending.

The later [delayed discovery comparison](docs/delayed-discovery.md) completed 58 prefix trials with 58 valid controls. Both `40` and `57` accept discovery above a transition near 1.56–1.58 seconds of measured send-call separation; boundary variation did not establish a stable opcode-specific distinction. Physical restoration was still pending at the end of that experiment.

Later P0075 follow-up: an explicitly authorized MVP-r3 transfer and normal reboot succeeded on the connected R5B. [Compact flash tooling](docs/compact-flashing.md) now preserves the full application erase while programming only the manifest-verified load image: 48 instead of410 packets for that external release. Run `make flash-test PYTHON=python3`. The compact transfer and revised sender are offline-tested; UART capacity above the conservative252-byte wire frame remains unqualified. That P0075 tooling stage did not change the application; P0076 now promotes the r3 baseline and adds the features above.
