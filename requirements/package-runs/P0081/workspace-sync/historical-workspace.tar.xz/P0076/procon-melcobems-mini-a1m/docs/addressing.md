# P0076 individual Modbus addresses

The same application image supports hardware DIP addresses 1 through 30 at
9600 8N1. It samples the switches at boot and retains that address until restart.
There is no runtime address write, software-address fallback or broadcast
configuration command. Software tests pass; physical switch correlation and
joining two devices remain operator validation steps.

## DIP configuration

Switch strings below are written in physical SW1 through SW8 order, with `1`
meaning ON. They are not conventional most-significant-bit-first binary strings.
The expected raw byte uses SW1 as bit 0 and SW8 as bit 7.

| Switch | GPIO input | Raw bit | Supported purpose |
|---|---|---|---|
| SW1 | PA4 | 0 | Address weight 1 |
| SW2 | PA5 | 1 | Address weight 2 |
| SW3 | PA6 | 2 | Address weight 4 |
| SW4 | PA7 | 3 | Address weight 8 |
| SW5 | PC4 | 4 | Address weight 16 |
| SW6 | PC5 | 5 | Must be ON: 9600, no parity |
| SW7 | PB0 | 6 | Must be ON: Modbus |
| SW8 | PB1 | 7 | Read and reported; no deadband behavior implemented |

Expected isolated configurations are `10000110` (raw `0x61`, address 1) and
`01000110` (raw `0x62`, address 2). Address 30 is `01111110` (raw `0x7e`).
Either SW8 position leaves the address unchanged.

The five address bits must select 1..30. Selection 0, software-address selector
31, unsupported serial/protocol bits or inconsistent startup samples disable
application Modbus. Internal effective address zero means no listener; it does
not accept broadcast requests. There is no automatic address-1 fallback.
Consequently unsupported configurations cannot be diagnosed over Modbus until
corrected physically. Change switches with power off, isolate the adapter,
restart it, then verify its identity before reconnecting other units.

The GPIO configuration matches the original application: the eight inputs use
pull-ups; IDR high is packed as 1 without inversion. Main reads three samples at
0, 5 and 10 ms with watchdog service before enabling either UART. Every sample
must agree. Changes after startup have no effect until restart. This avoids a
live address change during a command or an existing control lease.

The physical switches provide persistence through reset/power loss without
configuration writes, flash wear or a torn NVM record. Address persistence does
not make the control snapshot or lease persistent; those remain RAM-only.

## Evidence and limits

The pin map and GPIO configuration were established from the original R5
application at base `0x08008000`, size 96,692 bytes, SHA256
`2ae03b0cdc684bcccbf9f5281878175f5ca53b144e3e32cc223159fcc4654766`.
The evidence locations are:

| Original address | Observation |
|---|---|
| `0x080098BE`–`0x080098F6` | Input/pull-up initialization for masks PA `0xf0`, PC `0x30`, PB `0x03` |
| `0x0800A7D8` | GPIO helper returns 1 when the selected IDR bit is high |
| `0x0800F490` | Eight reads packed in the order shown above; no inversion |
| `0x0800F514` | Low five bits select address; bit 5 selects serial defaults; bit 6 selects protocol |
| `0x0800F8A4` | Modbus initializer stores the supplied address byte unchanged |
| `0x0800E274` | Startup invokes configuration decoding |
| `0x0800E324` | Main-loop DIP read updates diagnostic RAM without changing the selected address |

Only derived facts and addresses are documented here, not vendor bytes or
source. Hardware switch meanings are corroborated by the
[Mitsubishi A1M manual](https://library.mitsubishielectric.co.uk/pdf/download_full/3908)
and [A1M quick-start guide](https://planetdevices.com/wp-content/uploads/2024/05/ACC-BEMS-A1M_Quick_Start_Guide_V02.pdf).
The guides' address-zero default and software-address mode are deliberately not
implemented: unsupported selections remain silent to avoid an address collision.

This application-level evidence does not prove physical switch polarity on the
two installed boards or describe the bootloader internals. Isolated switch/raw
correlation is still required. The separate known bootloader DIP/power handoff
is unchanged; this application does not trigger bootloader entry. The original
application BIN does not contain the bootloader.

## Read-only identity, FC04 offsets 72–86

Read all fifteen words in one addressed request. Each 16-bit word is network
byte order. Each 32-bit UID word is represented high 16 first, then low 16.

| Input | Meaning |
|---|---|
| 72 | Identity schema 1 |
| 73 | Effective address 1..30 |
| 74 | Boot DIP address bits, raw value 0..31 |
| 75 | Configuration source 3: hardware DIP |
| 76 | Configuration valid: 1 valid, 0 disabled |
| 77 | UID valid: 0 for all-zero/all-FF sentinel, otherwise 1 |
| 78/79 | Factory UID word 0 high/low |
| 80/81 | Factory UID word 1 high/low |
| 82/83 | Factory UID word 2 high/low |
| 84 | Latched raw eight-bit DIP value |
| 85 | All three startup samples agree: 1 yes, 0 no |
| 86 | Rejection reason: 0 valid, 1 unstable, 2 address zero, 3 software selector 31, 4 unsupported serial/protocol |

Reasons are evaluated in the table's order: instability takes precedence over
address rejection, which takes precedence over unsupported serial/protocol.
Invalid configurations have no bus listener, so their diagnostics are available
only through local debug/test inspection, not through a fallback bus address.

The full MCU UID is independent of Modbus address and the common 888 marker.
Canonical identity text is three zero-padded eight-digit hexadecimal UID words
in word 0/1/2 order. Words `01234567/89abcdef/13579bdf`, for example, produce
`0123456789abcdef13579bdf`. UID is an observable identifier, not authentication.
An invalid UID blocks host commissioning/control and device-side FC16 controls.
After address, CRC and envelope-shape validation, FC16 returns exception 4
(server device failure) without entering the control handler. This applies to
both v2 and v3 envelopes. FC04 diagnostics remain readable at an otherwise valid
DIP address, so an invalid UID can be diagnosed without enabling control.

STM32L433 UID reads use `0x1FFF7590`, `0x1FFF7594` and `0x1FFF7598`. Sources:
[pinned ST CMSIS device header](https://github.com/STMicroelectronics/cmsis-device-l4/blob/ca0bfa2b8b68dc2994b27fba0a10dfd28d086ee1/Include/stm32l433xx.h#L1097)
and [ST HAL UID accessors](https://github.com/STMicroelectronics/stm32l4xx-hal-driver/blob/master/Src/stm32l4xx_hal.c).
The accessor reads only these three words. It never writes option bytes,
EEPROM, bootloader flash or flash control registers.

## Isolated provisioning and joining

1. Keep one adapter connected to the RS485 master. Record its physical pump
   label, full UID, firmware image hash and intended address.
2. Set the appropriate DIP switches with power off. After authorized flashing
   and restart, require raw `0x61` at address 1 or raw `0x62` at address 2,
   source 3, stable/valid configuration and the expected UID. Verify ordinary
   CN105 telemetry advances. Repeat a power cycle and compare identity.
3. Repeat for the second adapter with the first isolated. Require different
   valid UIDs, unique addresses and agreement with the isolated observations.
   A duplicate address/UID or unexpected raw DIP value blocks joining. A silent
   scan cannot prove there is no second unit at an address; collided replies
   cannot reliably discover duplicates.
4. Join sequentially with one RS485 master and checked termination, bias and
   wiring. Poll addresses interleaved and confirm UID and independent FAST/A3
   updates. Sequential reads are not simultaneous snapshots.
5. Retain desired state, sequence, lease, original-setting backups and recovery
   logs separately by UID/address. Each control envelope targets one slave.
   Broadcast 0 cannot change settings and wrong-address/CRC-invalid traffic
   cannot enter the control handler.

Recovery starts by isolating the affected adapter, correcting its DIP setting
with power off and restarting. Recover a damaged application through the
separate documented bootloader procedure. Rolling a unit back to an older
hardcoded-address-1 image requires isolation to avoid two address-1 units.
Do not reset the heat pump to recover an adapter addressing error.

Native tests exhaust all 256 DIP bytes and all request addresses, both SW8
positions, stability rejection, address 1/2/30 routing, UID word order, restart
latching, all-zero/all-FF UID control rejection and FC04/FC16 nonmutation gates.
Physical restart persistence,
shared-bus operation and supervised per-unit control/restore remain unverified.
