> P0076 adds [EFFECT control](effect-control.md), [DIP addressing](addressing.md)
> and the r3 [v2 control contract](control-v2.md). The earlier description below
> records the read-only baseline; current capabilities are package76/revision1.

# Architecture

Bare-metal Cortex-M4 C and ARM startup, no RTOS, allocation or flash persistence. Platform code initializes only required clocks, GPIO and USARTs, services watchdog and heartbeat, and polls both serial paths. CN105 polling also runs during RS485 transmit waits. Modbus replies are capped at16words to bound cooperative processing.

One CN105 transaction owner covers connect, FAST GET or A3. FAST sequence04/0C/14/0B/09/15/26 then service27; next FAST then service28. A service keeps ownership across pending retries, max10attempts, at least1000ms between request starts;800ms reply timeout and1000ms transmit-queue timeout,50ms turnaround. Reconnect waits for a bounded operation boundary. No SET packets exist.

service.c retains raw completion/status/age independently per channel. telemetry.c parses seven normal response types, validates ranges and computes signed deltas/water heat. Invalid values propagate. cn105.c verifies frame/header/checksum and expected query ownership. A same-query late replay has no transaction identifier and cannot be perfectly distinguished from a fresh reply.
