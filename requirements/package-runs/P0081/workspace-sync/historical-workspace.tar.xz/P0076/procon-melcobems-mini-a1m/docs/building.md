# Standalone build

Prerequisites Python3.10+,make,clang,curl,tar. Supported installer hosts: Apple Silicon macOS and x86_64 Linux. Run sh tools/setup.sh then make verify. Toolchain Arm GNU14.3.Rel1 and archive hashes are embedded in installer; Python versions pinned in tools/requirements.txt. .local and build are ignored. Override TOOLCHAIN/PYTHON for an equivalent separately installed toolchain if needed.

`make host-test` runs native ASan/UBSan suites and Python host helpers. `make verify`
also builds the ARM ELF, checks vectors/image bounds, executes mocked peripheral
scenarios and forces a second deterministic BIN build. No vendor image is required.
Research extractors accept optional privately supplied inputs outside the build.

P0076 promotes the previously tested r3 control baseline and adds the new features
summarized below. Hardware results from older images are not validation of P0076.
Cross-host equivalence must not be assumed from compiler version alone.

P0075 offline tests additionally require Node.js (`make readback-test`). They exercise a mocked discovery core, not hardware or an implemented flash-read wire protocol.

## P0076 candidate

The current build uses20KiB linked code and16KiB RAM bounds and emits a
compact `build/procon-mvp.bin`. Its JSON pins both compact SHA256 and the virtual
96KiB erase-envelope SHA256 for `tools/flash_plan.py`. Erase remains98304bytes;
programming does not transmit the FF tail. `make host-test` adds addressing,
coherent power filtering and EFFECT guard tests under ASan/UBSan.

`tools/package_candidate.py --objcopy .local/toolchain/bin/arm-none-eabi-objcopy`
packages the tested ELF/BIN, memory map, disassembly, metadata and per-file source
hashes under build. It performs no live action and does not publish a release.
The package remains hardware-unverified; firmware does not persist restore state.

The code bound increased from16KiB to20KiB for P0076 guard logic. This is
inside the already established96KiB application erase footprint; bootloader,
RAM/stack bounds and persistent storage behavior are unchanged.
