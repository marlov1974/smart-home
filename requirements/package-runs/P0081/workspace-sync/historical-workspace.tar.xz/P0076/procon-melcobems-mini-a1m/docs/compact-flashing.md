# P0075 compact application flashing

The managed flasher separates the erase extent from the bytes to program. For the
externally supplied MVP-r3 release, it erases application-relative `0..98303` and
programs only the 11,320-byte load image. The resident bootloader is excluded.

| Quantity | Previous transfer | Compact plan |
|---|---:|---:|
| Erase extent | 98,304 | 98,304 |
| Program payload bytes | 98,304 | 11,320 |
| 240-byte program packets | 410 | 48 |
| Final payload / wire bytes | 144 / 156 | 40 / 52 |
| Total program wire bytes | 103,224 | 11,896 |

The historical full-envelope transfer received direct `73` ACKs for all 410
packets, followed by the correct MVP-r3 identity and advancing CN105 generation
counters after an operator restart. Compact transfer and the revised sender have
offline verification only. No flash readback exists; `57` remains unresolved.
The standalone application remains its existing r1 source; this tooling change
does not import the separate r3 application or alter any firmware source/release.

## Image contract

`tools/flash_plan.py` requires a trusted release manifest with `base`,
`end_exclusive`, `raw_bytes`, `padded_bytes`, `initial_sp`, `reset_vector` and the
SHA256 of the full padded envelope. `raw_bytes` must come from build/ELF evidence.
Do not infer it by stripping a run of trailing `FF`: real load content can end
with those bytes too.

The planner verifies either the padded release or a raw/minimally aligned input
by reconstructing the same pinned 96-KiB envelope. Every omitted byte must be
`FF`. Program data is rounded only to an eight-byte boundary. A shortened erase
extent, changed hash, misplaced vectors or out-of-range data is rejected.

Create artifacts without contacting any device:

```sh
python3 tools/flash_plan.py /path/procon-mvp.bin /path/procon-mvp.json \
  --compact-output /path/mvp-r3.compact.bin --output /path/flash-plan.json
make flash-test PYTHON=python3
```

The JSON and BIN are created exclusively, without overwriting existing files.
The compact BIN is for this separately controlled erase path. Do not pass it to
a length-driven updater that erases only the short file's extent.

## Managed sender

`tools/flash_shelly.py` has `plan`, `preflight` and `program` actions. All require
explicit `--host`, `--device-id`, `--image`, `--manifest` and `--out`. Live actions
also require `--bootloader-confirmed` after a fresh physical DIP/power handoff.
The reviewed platform is Shelly Pro2, prepared maintenance slot 8 named
`P0075 write reference` (or explicitly supplied `--slot-name`), sole serial
owner, `js_uart`, 115200 8N1, other scripts disabled/stopped and both relays off.
The tool verifies these conditions; it does not reconfigure the installation.

Use `preflight` with a fresh output directory, then `program` with the same
arguments/output directory. Preflight verifies the deployed source, discovery
and first fully staged frame before any erase. Programming checks target,
release and source provenance again. It preserves the 96-KiB erase, requires a
direct `71` erase ACK and a direct `73` for each sequential write, and stops the
maintenance script on completion or error. There are no automatic retries or
resume after an uncertain transaction. A new session requires a new reviewed
physical handoff. Normal-mode boot verification remains a separate step.

The verified default remains 240 payload bytes / at most 252 wire bytes. Larger
offline plans do not enable larger writes in this sender. Partial acceptance
retains only the unsent suffix. A named recurring timer requested at 20 ms
services it, with fixed-size statistics for send calls, accepted counts,
zero/partial returns and actual service intervals. Status polling never drives
TX. A 1.2-second TX deadline is retained for these small frames; this is not an
8-KiB streaming sender.

## Larger-packet investigation, 2026-10-07

The failed historical 8,204-byte frame was fully staged and CRC checked on
Shelly. The UART path accepted only 256 bytes before the sender's own 1.2-second
deadline. Its initial RPC returned in 121 ms. The old log did not record each
later callback or send result, so it cannot distinguish a delayed/missing
continuation from driver backpressure after the first accepted bytes.

A subsequent experiment ran the unchanged old core on the same Shelly against
a simulated `send`, without obtaining a UART handle or transmitting to Procon.
All 8,204 bytes again staged correctly, leaving at least 11,116 bytes of reported
free script memory. Simple requested 1/10-ms timers were observed after 100/97
ms. These are measurements under that script/RPC workload, not a universal timer
floor. The instrumentation itself adds execution and serialization cost.

| Mock sender / requested timer | Calls | Accepted bytes before TX deadline |
|---|---:|---:|
| Old callback, 1 ms, accepts up to 256 each call | 13 | 3,328 |
| Old callback, 10 ms, accepts up to 256 each call | 13 | 3,328 |
| Old callback, 50 ms, accepts up to 256 each call | 10 | 2,560 |
| Old callback, 1 ms, zero after first acceptance | 13 | 256 |
| Named recurring callback, 10 ms, accepts up to 256 | 10 | 2,560 |
| Named recurring callback, 10 ms, zero after first | 10 | 256 |

Callbacks continued running. The deadline is demonstrably too short for the
instrumented large-frame path, while a zero-acceptance model reproduces the
historical 256-byte endpoint. This does not prove real driver backpressure or a
hard UART limit. The recurring timer is simpler to observe, not proven faster.
A generic 254-character RPC limit is contradicted by the actual successful
336-character Base64 payloads and earlier complete 8,204-byte staging.

Shelly's [UART API](https://shelly-api-docs.shelly.cloud/gen2/Scripts/APIs/UART/)
documents a sent-byte return count, without specifying a 256-byte limit. Its
[Timer API](https://shelly-api-docs.shelly.cloud/gen2/Scripts/APIs/Timer/) defines
requested scheduling intervals; measure actual service times on the target.
Do not concatenate Modbus read frames to fabricate a large-capacity test. A
physical larger-send qualification needs an isolated receiver/loopback or a
separately authorized bootloader experiment. No such test occurred here.

After the diagnostic, the prior maintenance source was restored, all scripts
were stopped/disabled, serial configuration was unchanged and both relays stayed
off. The pump's installed firmware was not erased or programmed during diagnosis.

## P0076 physical compact transfer

A later operator-authorized P0076 transfer completed with69 direct write ACKs
and the full96KiB erase. See [transfer evidence](p76-flash-verification.md),
including the pre-erase Shelly declaration-order correction. Normal application
boot remains unverified at this stage.
