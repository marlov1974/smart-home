# P0075 delayed discovery after 40 versus 57 — 2026-10-07

## Result

Discovery becomes accepted across a transition near **1.56–1.58 seconds of measured send-call separation**, with no reproducible opcode-specific distinction established. Treating `40` as a noncommand and `57` as a command was the operator's working hypothesis, not an independently proven classification. The results remain compatible with both prefixes passing through a common packet collection or timeout layer before command dispatch.

**58 prefix trials and 58 valid standalone discovery controls** completed in five bounded runs: 116 transactions, 174 accepted UART TX bytes and 1080 received bytes. All nonempty replies were exactly the pinned 12-byte discovery response with a valid checksum. Each prefix had 29 trials: 16 successful discovery replies and 13 silent windows. There were no partial-send, unexpected-reply, early/late-RX, memory or adapter halt events.

| Actual send-call separation | Discovery after `40` | Discovery after `57` | Sample selection |
|---|---:|---:|---|
| 1531–1533 ms | 0/3 | 0/3 | Repeated lower point, initial observation strategy |
| 1556–1557 ms | 0/3 | 1/3 | Final series without host polling during the gap |
| 1580–1581 ms | 3/3 | 3/3 | Same final series |
| 1606–1607 ms | 3/3 | 3/3 | Same final series |

The single `57` success at 1556 ms was followed by two silent `57` trials at that same measured gap. An earlier `57` trial was also silent at 1559 ms. Therefore neither a sharp deterministic threshold nor a stable difference between command classes follows from the boundary samples. `40` was silent up to 1557 ms and successful from 1580 ms among observed samples; `57` had overlapping success and silence in the boundary region. These are sample extrema, not universal firmware timer bounds.

The earlier broad pass was silent after both prefixes from measured 57–59 ms through approximately 1.53 seconds, and accepted discovery at approximately 1.73, 2.0–2.14 and 3.03 seconds. This new evidence is more specific than the previous two contiguous-pair trials, which supplied no deliberate gap.

## Method and timing refinement

Before each prefix trial, send only `5A`, require its complete matching checksum-valid response, finish the three-second observation window, then leave at least 200 ms quiet. Send one prefix byte (`40` or `57`) and later send one `5A` byte, with no extra UART byte in the interval. Observe for three seconds after the actual second send. Alternate prefix order across requested delay settings and repetition rounds. There is no physical reset between trials; a successful control proves responsiveness rather than complete parser reset.

The first pass requested gaps 0, 10, 50, 100, 250, 500, 1000, 1500, 1700, 2000 and 3000 ms. Refinements repeated requested gaps of 1550/1600 ms three times per prefix and 1500 ms twice more, then tested 1525 ms. Those 40 prefix trials exposed a confound: the requested 1525 ms trial ran at 1661 ms for `40` (success) but 1559 ms for `57` (silence). That apparent difference cannot be assigned to the opcode.

The documented extension allowed at most 60 prefix trials total; **58 were used**. Its final 18 trials repeated requested gaps of 1525/1550/1575 ms three times per prefix. The host made no status RPC during the requested gap or receive window, instead reading the result afterward. Device source and UART bytes stayed identical. In that final series, actual gaps closely grouped at 1556–1557, 1580–1581 and 1606–1607 ms. This reduced observed timing variation, without proving its sole cause.

All times refer to Shelly monotonic timestamps around `UART.send` calls and receive callbacks, not independent measurements on the RS485 wire. A requested zero delay still produced 57–59 ms between calls. Scheduling, serial driver timing and device timer granularity can affect the observed boundary. Accepted-byte counts are not a wire trace. No complete `57` frame, read payload, negative read ACK, firmware dump or internal handler was obtained.

## Evidence and implementation

[Complete sanitized per-trial results](delayed-discovery-results.json) include requested and actual gaps, prefix/tail send durations, receive timing and separate run metadata. Raw-evidence inventory SHA256: `331f663d0ebaf9620c4150fec0ab99102b795902ceadf5b38b5698dbe59f6256`. The JSON preserves all earlier timing-variable trials as well as the final matched series; it must not be reduced to requested delays alone. Raw UART/RPC records, site identifiers and the site-specific runner remain private.

`tools/shelly/delay_probe.js` supplies only standalone discovery or separately sent `40`/`57` followed by `5A`, up to 100 requested transactions per instance and 128 RX bytes per transaction. It starts passively. A receive event before the tail suppresses the scheduled tail and halts; partial sends, unsolicited/late/active RX, overflow, invalid clocks or transport errors stop further progression. Native adapter functions expose JSON/base64 via the existing management interface. A passive timer keeps that adapter available; it never generates UART traffic.

`make readback-test PYTHON=python3` passed, including **20 new offline delay-probe cases** plus the existing suites. These cover passive load, fixed frames, busy/argument/count limits, actual timing and delayed callbacks, pre-tail receive, cancellation/stale callbacks, partial/error sends, late/active receive, overflow and the native adapter. An independent offline audit checked all 116 sequence/intention/result pairs, accepted-byte counts, response identity and checksum, callback timestamps, classifications and recorded cleanup outcomes. It also confirmed that the published aggregation matches the raw records. Firmware source, release images and G2 runtime are unchanged.

## Final state

At **2026-10-07T15:31:59.993283+00:00**, management-only reads verified the same pinned Shelly identity/firmware, own script stopped and disabled, original scripts stopped/disabled, both relays off, and Serial still `js_uart` at 115200 8N1. The temporary slot is retained; no deletion, relay change, heat-pump control or physical reset was performed. No further probes are scheduled.

Procon's last confirmed maintenance DIP is `00000000`; the operator deferred the physical return to `10000110` with Procon power removed and subsequent restart until the evening. Status remains `WAITING_FOR_OPERATOR_RESTORE`; readback remains `BLOCKED_READ_PROTOCOL`. After that physical confirmation, restore the exact saved normal Serial profile and verify normal identity and advancing telemetry. The current test does not substitute for that handoff.
