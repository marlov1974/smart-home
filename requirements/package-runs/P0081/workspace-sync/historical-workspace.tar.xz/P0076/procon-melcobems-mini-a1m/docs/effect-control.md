# P0076 EFFECT control — revision 2

EFFECT regulates one powered pump's estimated space-heating output by changing the Zone1 flow target. It does not command compressor Hz or pump speed. This is an offline-tested implementation awaiting supervised hardware validation. It is not a calibrated heat meter or an unattended controller.

The existing P0072 r3 v2 controls and telemetry remain compatible; see [v2 control API](control-v2.md). The firmware identity is input0=888, input1=76, input68=2, telemetry API input69=1. Each physical unit has its own DIP-selected address, command sequence, lease, feedback and snapshot; see [DIP addressing](addressing.md).

## Atomic command contract

Send one addressed FC16 request at zero-based holding offset300, quantity8, bytecount16. The eight words are big-endian on Modbus. There are no writable staging registers and no broadcast control. Confirm the physical unit's UID and address before issuing a command.

| Word | EFFECT v3 value |
|---|---|
| 0 | Magic `0xC076` |
| 1 | Sequence1–65535; first1 after application boot;65535 wraps to1 |
| 2 | Mode5, EFFECT |
| 3 | Target watts1000–12000, integer W, for this single pump |
| 4 | Maximum Zone1 flow target3000–4000, centidegrees C |
| 5 | Lease90–1800 seconds |
| 6 | Exactly1: operator/controller confirms the measured water circuit currently represents the intended space-heating path |
| 7 | Envelope version3 |

Example words for a6kW target,40C ceiling and15-minute lease are `[0xC076,1,5,6000,4000,900,1,3]`. The target is a request within protocol bounds, not proof that a particular pump can deliver it. Targets18/24/27kW are rejected for an individual unit. Routing confirmation does not validate a heat meter boundary automatically; verify the actual hydraulic layout before a live trial.

V2 remains `[0xC072,sequence,mode,flow,DHW,lease,flags,2]` with its existing modes0–4 and bounds. V2 AUTO, `[0xC072,next_sequence,1,0,0,0,0,2]`, cancels EFFECT and restores its snapshot. V3 does not redefine v2 mode codes or accept v3 aliases for legacy commands.

Both versions share one per-device sequence and exclusive session. An exact duplicate of all eight accepted words succeeds without extending the lease. The next sequence with identical EFFECT target/cap/flags renews an ACTIVE session without new SETs or a new snapshot; only its lease duration may change. Different intent requires AUTO restoration first. Renewal is allowed during native pauses and suspended adjustments of an already-applied session. A suspended initial action is still busy until its first readback completes. Invalid encoding/range/sequence returns exception03; unavailable feedback, conflicting ownership or unavailable restoration returns06. FC16 acceptance means accepted into RAM, not applied to the heat pump. Bad UID refuses writes through the Modbus gate.

## Entry, SET verification and restoration

Entry requires either at least three accepted feedback pairs spanning20seconds in fresh space-heating mode2/7, or qualified WAIT_NATIVE/SETTLING feedback, and an already-powered heat pump. Native operating status0 is permitted as standby; it does not authorize powering on or forcing the compressor. The snapshot reads GET26,GET09,GET28. It rejects power-off, DHW/cooling/unknown operating mode, boost, invalid native values, relevant holiday/server/Zone1 heating inhibits and an existing flow target above the requested cap. It does not silently clamp an unsafe starting target or start heating from OFF.

When changing native control from curve/room mode to fixed flow, EFFECT sends one coherent `TYPE41 / payload32 / flags0x88` update containing mode1 and the captured flow target together. Fresh GET28 and GET26 guards precede it; the current DHW target is preserved in the payload. A mode-only write could expose an unrelated previously stored fixed-flow target, so it is not used. Both MODE and FLOW are marked possibly touched before transmission, even if the acknowledgement is lost. GET26 must confirm mode1 and then GET09 must confirm the exact captured target before the command becomes applied. The protocol references and field encoding are recorded in [effect-startup-reference.md](effect-startup-reference.md); r1 physical acceptance was observed in the first trial; r2 pause behavior still needs hardware validation.

Every later flow adjustment repeats fresh GET28→GET26 guards, sends the existing flow SET, waits for settling and verifies GET09. Generic `0x61` acknowledgements are hints only. Missing SET acknowledgement still leads to readback because the write may have applied. Readback retries are bounded; a timeout or mismatch triggers compensation. Control never interrupts an A3 operation or its pending retries. Between adjustments it yields ownership so FAST and A3 continue.

One original observable snapshot is retained across every adjustment and lease renewal. AUTO, lease expiry, hard-invalid feedback, link loss, native inhibits or unexpected operating mode stop new increases and queue restoration at a transaction boundary. Restoration restores the captured flow target before the original control mode, retaining the snapshot if verification fails. A blocked restoration retries the bounded plan after5seconds and remains explicitly unverified. The snapshot covers the documented readable settings; it cannot reconstruct an unobservable historical fixed setpoint that was hidden while curve mode was active.

Normal incomplete FAST pairs produce `PENDING`: they pause decisions and SETs, preserve the session, and yield the bus. A suspended action resumes only with coherent feedback and fresh guards. It must not hold CN105 ownership while waiting for the FAST packets that make its own feedback valid. A pending feedback state is not a successful measurement.

## Measurement contract

Water-side watts reuse `i7 = trunc(flow_cL_min × (supply_cC − return_cC) ×418 /60000)`. This assumes water density/heat capacity. Whole-L/min flow resolution, temperature resolution, sampling skew and hydraulic routing limit accuracy. It is not COP; no electric input is inferred.

The sampler tracks the independent GET0C temperature generation and GET14 flow generation. Both must be new; a changed sum of generations is insufficient. Supply/return must come from the same GET0C sample, flow must be positive, return must not exceed supply, compressor Hz must be fresh and positive, sources must be valid and no more than20seconds old (Hz has its stricter10second telemetry TTL), and temperature/flow skew must not exceed2seconds. A fresh GET26 heating mode must follow the contributing pair. Accepted observations are spaced at least4seconds apart. Invalid, stale, DHW, zero-flow or link-loss observations empty the averaging window; they are never smoothed into apparent validity.

The short arithmetic mean uses accepted observations within60seconds; the slow mean uses180seconds. Counts and actual endpoint spans are published, so the requested window is not mistaken for actual coverage. READY requires at least three observations and20seconds of span. The short mean controls EFFECT; the slow mean is diagnostic. The ring is bounded to64observations. Counts and accepted-generation diagnostics describe protocol sampling, not independent calibrated measurements.

Quality codes:0 READY,1 WARMUP,2 PENDING,3 STALE,4 INVALID,5 ZEROFLOW,6 DHW,7 LINKLOSS,8 WAIT_NATIVE,9 SETTLING. Instantaneous/filtered signed32 values use `0x80000000` for unavailable data. Consult quality and age even when an older mean remains visible during PENDING.

## Native pause and restart (r2)

Fresh valid operating status0, or heating2/7 with0Hz, produces WAIT_NATIVE.
Temperature, flow and Hz sensors must still be fresh and in range. Zero flow
and negative supply/return delta are permitted only in this qualified pause;
no watts are inferred and averaging history is emptied. Cooling, DHW, invalid
sensors, stale sources and link loss retain their failure behavior. Passive
GET26/28 observations continue checking power, native control mode and inhibits.

The original snapshot, budget, latched limits and running lease survive a pause.
Power-error increments are suspended. With confirmed0Hz, a separate bounded
start-demand rule requests measured supply+50cC (0.5C): at most+100cC per60s
since the preceding verified adjustment, never beyond the command cap or the
session's remaining+500cC budget. A higher existing target is left unchanged.
These increments preserve native demand; they do not force a compressor start
and do not count as failed power response. If bounds prevent the margin,
TEMPERATURE_CAP/CUMULATIVE_CAP is reported and the bound is respected.
An unsent power increment is discarded on pause; an unsent start-demand increment
is discarded on restart. A possibly sent increment completes readback and remains
charged to the budget. All increments retain fresh GET28/26 guards and readback.
Initial fixed-mode selection may still set the unchanged captured target using
the guarded combined command; it does not raise the target or force a start.

After a pause, heating with positive Hz must persist for60seconds, with fresh
paired observations, before READY returns. Any new pause restarts this interval.
The next regulator decision is at least60seconds after the last WAIT/SETTLING
observation. Previous derivative and unfinished response assessment are discarded,
but real prior unresponsive counts and cumulative/latched limits are retained.

A continuous wait/recovery period is bounded to1200seconds (20minutes), including
settling; renewals do not restart this timer. This allows the operator-observed
10minute pause without asserting a verified Mitsubishi minimum-off setting.
Expiry of either this wait bound or the ordinary command lease restores the
snapshot. A180second lease therefore still needs renewal during a10minute pause.
The20minute bound is an r2 firmware constant, distinct from configurable lease.

This prevents power-error-driven pre-start increases and reactions to the initial
cold power ramp; standby increments have only the explicit start-margin purpose. Existing deadband and derivative anticipation remain. It does not
promise continuous operation below native minimum output or eliminate cycling;
exact native stop/start thresholds and achieved stability need a new trial.

## Regulator bounds and phases

The first adjustment is no earlier than60seconds after initial capture. Thereafter the interval begins at verified completion of the previous adjustment, with a minimum60seconds. There is no integral term.

| Condition | Decision |
|---|---|
| Error above+2000W | START, at most+100cC |
| Error above+1000W | CAPTURE, at most+50cC |
| Positive error outside deadband | CAPTURE, at most+25cC |
| Negative error | Corresponding−100/−50/−25cC bounded reduction |
| Absolute error≤500W | HOLD, no change |
| Already HOLD and absolute error<700W | Remain HOLD |
| Positive short-mean slope predicts reaching target−500W within30s | CAPTURE, withhold the increase |

All targets remain2000cC through the command ceiling, which is at most4000cC. The session's sum of all upward adjustments is at most500cC; decreases do not replenish that budget. Three consecutive upward adjustments each followed by less than250W measured gain stop further increases with `UNKNOWN_UNREACHABLE`. Temperature and cumulative caps also latch against further increases; overshoot can still cause reductions. The firmware does not invent a hydraulic/compressor-limit diagnosis from low output alone. Distinguishing those physical causes requires separate measurements and review.

The derivative used for anticipation is the change in the short mean between regulator decisions. Sampler endpoint slope is a separate diagnostic. Quantized/noisy data may prevent convergence. The initial hardware goal of roughly±0.5–1kW is an evaluation band, not a precision promise.

Phases:0 OFF,1 START,2 CAPTURE,3 HOLD,4 LIMITED,5 INVALID_FEEDBACK,6 RESTORING,7 WAIT_NATIVE,8 SETTLING. A failure after a possible write moves directly to RESTORING with its retained reason; INVALID_FEEDBACK can describe failure before a write. Restore-blocked detail remains in legacy control state256=6.

Reasons:0 OK,1 BAD_FEEDBACK,2 NATIVE_INHIBIT,3 MODE_CHANGED,4 TEMPERATURE_CAP,5 UNKNOWN_UNREACHABLE,6 CUMULATIVE_CAP,7 LINK_LOST,8 LEASE_EXPIRED,9 ABORTED,10 TEMPERATURE_FLOOR,11 READ_TIMEOUT,12 READBACK_MISMATCH,13 WAIT_TIMEOUT. Existing error260 adds8 for EFFECT abort; legacy errors retain their meanings.

## Read-only diagnostics

All addresses are zero-based FC04 input offsets. Multiword values below are high word first. Signed integers use two's complement. Legacy256–298 retain their meanings;320–383 form the EFFECT extension.

| Address | Meaning |
|---|---|
| 320 | EFFECT diagnostic schema1 |
| 321 /322 | Phase /reason |
| 323 /324 | Target W /flow ceiling cC |
| 325–326 | Instantaneous signed32 W |
| 327–328 | Short mean signed32 W |
| 329–330 | Slow mean signed32 W |
| 331–332 | Target minus short mean, signed32 W; unavailable sentinel preserved |
| 333 /334 /335 | Quality /ready /short accepted count |
| 336 /337 | Last accepted observation age s /short span s |
| 338 | Last verified control flow target cC; not a continuously polled native target |
| 339 | Last verified adjustment, signed16 cC |
| 340 /341 | Seconds since verified adjustment /compressor Hz |
| 342 /343 | Decision count /verified adjustment count |
| 344 /345 | Sum upward/downward cC this session |
| 346 /347 | Consecutive unresponsive increases /pending flow target cC,0 if none |
| 348 | Regulator short-mean derivative W/min, saturated signed16 |
| 349 | Initially captured flow cC |
| 350 | 1: settings from a session before a reset are unknown |
| 351 | 0: durable restoration unsupported |
| 352 | Feedback diagnostic schema1 |
| 353 /354 | Sampler quality /ready |
| 355 /356 | Short /slow sample count |
| 357 /358 | Actual short /slow endpoint span s |
| 359 | Age of last accepted observation s,65535 if unknown/saturated |
| 360 /361 | Last accepted temperature /flow generation, wrapping16bit |
| 362–363 | Accepted observation count, unsigned32 |
| 364–365 /366–367 /368–369 | Sampler instantaneous /short /slow signed32 W |
| 370–371 | Sampler endpoint derivative, signed32 W/min |
| 372–383 | Reserved0 |

Counters wrap at their stored width. A historical applied sequence alone does not establish active control or completed restoration. Check state256, error260, snapshot261, touched262, lease264 and restoration count267 alongside these diagnostics. AUTO's applied sequence advances only after verified restoration.

## Reset and hardware handoff limits

A reset or power loss destroys the RAM snapshot, lease and session. Startup is read-only and does not send a guessed AUTO command. Input282=0 and351=0 advertise no durable restoration;350=1 advertises unknown pre-reset state. The heat pump may retain a setting written before the reset. Save the original readable native settings outside the Procon before a supervised trial. An independently validated persistent recovery design is required before unattended use.

Offline tests exercise the controller, distinct-sample filter, limits, pending-pair pauses, timeout/readback compensation, AUTO/lease restoration and reboot reporting. Mocked ARM execution validates the compiled application and mocked peripherals; neither proves physical DIP wiring, calibrated delivered heat, native response to the combined startup or control stability. Obtain a separate operator handoff before flashing/provisioning or applying EFFECT. Validate one pump first, including the relevant hydraulic route, modest reachable targets, explicit AUTO and lease expiry. Do not overwrite both units before one-unit validation. P0076 does not authorize multi-hour brine/COP experiments or combined18–27kW dispatch.
