# P0076 EFFECT startup: one mode-and-target request

Review identified a startup hazard in a mode-only transition from the heating
curve to fixed-flow mode. GET09 reports the current flow target; it does not
prove that the native controller's hidden stored fixed-flow target has the same
value. Switching only the mode could therefore select an old target above the
EFFECT temperature cap, while the replacement retained the curve target in its
local cache and waited60seconds before the first adjustment. A matched mode
readback alone would not detect that condition.

Two independently inspected, pinned public source trees support selecting mode
and target in the same SET32 payload:

- [m000c400 `Ecodan.cpp`, commit5d11f087dab622532904c4976a84d3dd5978772c, lines175–184](https://github.com/m000c400/Mitsubishi-CN105-Protocol-Decode/blob/5d11f087dab622532904c4976a84d3dd5978772c/Ecodan.cpp#L175)
  actively combines the zone-setpoint and heating-mode flags when its flow-target
  setter builds and transmits a request. Its
  [header definitions](https://github.com/m000c400/Mitsubishi-CN105-Protocol-Decode/blob/5d11f087dab622532904c4976a84d3dd5978772c/EcodanDecoder.h#L91)
  identify those flags as80 and08. The same header identifies packet type41,
  settings query32 and fixed-flow mode01. Its
  [encoder](https://github.com/m000c400/Mitsubishi-CN105-Protocol-Decode/blob/5d11f087dab622532904c4976a84d3dd5978772c/EcodanDecoder.cpp#L544)
  places the selected flags in byte1, Zone1 mode in byte6 and the Zone1 target in
  bytes10–11.
- [F1p `Ecodan.cpp`, commit7687d11e8f4ec23de13f2c95bcdf76ebe9daebb5, line309](https://github.com/F1p/Home-Assistant-Mitsubishi-CN105-to-MQTT/blob/7687d11e8f4ec23de13f2c95bcdf76ebe9daebb5/Ecodan.cpp#L309)
  states that mode selection can be combined with the flow write; that project
  separates them because they have separate MQTT topics. Its
  [flow encoder, lines1244–1270](https://github.com/F1p/Home-Assistant-Mitsubishi-CN105-to-MQTT/blob/7687d11e8f4ec23de13f2c95bcdf76ebe9daebb5/EcodanDecoder.cpp#L1244)
  independently confirms the32 payload layout, Zone1 selector00, mode byte6,
  target bytes10–11 and preservation of the current DHW target in bytes8–9.
  Its Zone1-mode flag is08; the Zone2 flag10 remains absent.

This supports a narrowly scoped startup request: SET32 mask88, Zone1 only,
fixed-flow mode01, the captured current flow target within the requested cap,
and the freshly read current DHW target. It avoids a deliberately separate
mode-only interval. Mark both mode and flow touched before transmission so a
lost acknowledgement cannot omit either from restoration. Obtain fresh GET28
protection and GET26 state before the SET, then require both matching fresh
GET26 mode and GET09 flow readbacks before declaring the session active. A SET
acknowledgement alone is insufficient. Ordinary feedback adjustments keep their
minimum60second interval after initialization.

This is a reference-backed request format, not a claim that internal Mitsubishi
application timing or the physical pump has been verified. The single-unit
hardware gate must still verify combined startup, both readbacks, cap behaviour,
AUTO/lease restoration and preservation of unrelated settings. No control bytes
were sent during this review, and no vendor source or binary content is copied
into this note.
