# P0075 firmware readback research

## Current result

The completed read-only phase below is historical. The later [write-reference experiment](write-reference-experiments.md) and completed [single-byte opcode sweep](opcode-sweep.md) have separate authorizations and accounting. The sweep sent all 256 values once without helper traffic; four responded, while `57` and 251 other values were silent. Script stop/disable and the maintained Serial profile were verified at 14:39:00 UTC. Procon remains in maintenance mode, with physical restoration deferred until the evening; no further UART traffic is scheduled.

As of the completed experiments on **2026-10-07 at 12:26:49 UTC**, Shelly-to-Procon bootloader discovery works, but **no flash bytes have been read**. All 64 distinct read candidates in the four series produced no response. See the [complete experiment catalog and counts](firmware-readback-experiments.md). There is no verified read request, response format, address convention, integrity check or supported read length. The outcome remains `BLOCKED_READ_PROTOCOL`; neither a successful backup nor an installed-image hash comparison is claimed.

The operator explicitly authorized bounded trial-and-error `0x57` experiments, discovery checks between attempts, temporary Shelly transport changes and the required Shelly reboots. This superseded the original package's prohibition on speculative read frames for this supervised investigation. It did not authorize erase, programming, EEPROM access, status-changing commands, option-byte changes, heat-pump controls or disabling native safeties. None of those operations was intentionally sent.

The research script was stopped at the end of that series. The operator subsequently returned Procon to normal mode, and exact Shelly configuration and normal communication were verified restored for that phase. A post-reboot test-script deletion caused an unexpected Shelly restart, documented below. No firmware read or backup was obtained.

## What is established on this hardware

The active Windows protocol and evidence limits are documented in [boot-update](hardware-reference/boot-update.md). A standalone `5A` request receives a 12-byte `7A` response with a valid additive checksum. The connected device consistently reports:

| Discovery field | Observed value |
|---|---:|
| Maximum flash field | 225280 bytes (`0x37000`) |
| Maximum EEPROM field | 255 bytes (`0x00FF`) |
| Erase-block field | 2048 bytes |
| Maximum write-page field | 8192 bytes |

These are decoded protocol fields, not a CPU identity, read-capability bitmap, verified physical density or permission to access that entire range. The installed P0072 r3 reference remains the pinned **98304-byte application image at `0x08008000`**. Discovery does not enlarge the intended readback scope or establish a maximum read size. In particular, the 98304-byte flash value in the published synthetic decoder fixture is not this device's live discovery result.

The tested transport is Shelly Pro 2 firmware 2.0.0 with its Modbus add-on. The actual `Serial:100` component advertises `js_uart`. Changing to that mode at 115200 8N1 returned `restart_required=true`; **UART handle 0 became available only after an operator-approved Shelly reboot**. Handle 100 did not provide the required UART object. This is a mapping established for this device/profile, not a universal identifier rule. No guessed direction-pin polarity or undocumented UART configuration was used.

The operator confirmed that Shelly is the only RS485 master and that the original Procon DIP setting is `10000110`. The pre-maintenance snapshot recorded the complete Serial configuration, device identity, script configuration/code/state, and an idle P0072 r3 control session. Existing scripts were already stopped and disabled. Snapshots and identifiers remain local.

Discovery exchanges establish useful physical binary traffic and request/reply turnaround on this path. They do not qualify arbitrary byte values, large responses, full-duplex operation or every half-duplex timing condition.

## Completed experiments and interpretation

Every completed read-candidate series below uses a fixed, reviewed request catalog, one outstanding transaction and a three-second receive window. Standalone discovery is checked before and between read hypotheses. Any unexpected read response stops the series for analysis; responses are not automatically labelled flash data. A discovery reply shows continued responsiveness, **not proof that every internal parser state was reset**.

| Series | Hypothesis or control | Result |
|---|---|---|
| Initial absolute-address series | Four address/length layouts, each with sum8, CRC32+sum8, neither, or CRC32; address `0x08008000`, count 16 | 16 read requests returned no bytes; all 17 separate discovery checks succeeded |
| Parser controls | Eight short sequences composed only of `00`, `57` and `5A` | Sequences starting with `5A` each yielded one discovery reply; the tested sequences starting with `00` or `57` yielded none. All nine separate discovery checks succeeded |
| Relative/alias discrimination | The same 16 layout/trailer combinations, wire address `0x00008000`, count 16 | No read response; all 17 discovery checks succeeded |
| Shared-envelope hypothesis | `57`, length16, address32, zero-filled dummy bytes, then sum8 or CRC32+sum8; addresses `0x08008000` and `0x00008000`, counts 1/4/16/32 | All 16 requests returned no bytes; all 17 discovery checks succeeded |
| Length and field padding | Counts 1/4/64 with two layouts and two addresses; four additional field-padding forms | All 16 requests returned no bytes; all 17 discovery checks succeeded |

The parser controls are consistent with the first byte or receive grouping affecting dispatch. They do not prove the implementation, a receive timeout, or an exact packet boundary. For example, two adjacent `5A` bytes produced one observed response, which is insufficient to distinguish device grouping, discarded bytes and other receive behavior. Callback timestamps include Shelly scheduling and are not oscilloscope measurements of wire timing.

Wire address `0x00008000` was chosen because an application-relative interpretation would select `0x08010000`, while an ordinary main-flash alias interpretation would select `0x08008000`. Those are hypotheses; remapping and address validation are still unknown. No response validated either interpretation. The shared-envelope series tested whether the receiver might wait for length-associated dummy bytes before checking the frame; its silence did not validate that model.

Earlier one-shot tests also tried the length16/address32 form with and without CRC32, and zero-byte completion probes. A delayed zero probe could have missed an unknown parser timeout. In the immediate probe, the measured first gap was 62 ms and later gaps about 39–41 ms despite a requested 10 ms timer. Those negative results therefore cannot exclude a shorter timing requirement.

No `77` success, `76` failure or identifiable application bytes have been observed. An unimplemented or disabled `57` operation remains possible, alongside untested framing, addressing, timing and session prerequisites. Repeating a working discovery exchange cannot distinguish these possibilities.

## Supplied software: separate responsibilities

### Offline decoding, capture and comparison

`tools/readback.py` performs no network or UART acquisition. Its `read_request` function still raises `BLOCKED_READ_PROTOCOL`; the offline tool has not been promoted to a working flash reader.

The decoder can validate the documented synthetic discovery fixture:

```sh
python3 tools/readback.py decode-discovery '7a0080010000010008002024'
```

`Capture` is a storage primitive for independently obtained, already protocol-validated bytes. It requires ascending contiguous offsets and bounded blocks, flushes/fsyncs each append, and writes coverage and hash metadata when finished. Missing data is never replaced with padding or reference bytes. A partial file or unfinished manifest cannot qualify as a complete capture. Raw dumps, traffic, manifests containing local details and restoration snapshots stay outside Git.

The offline comparator accepts two distinct completed captures and a pinned reference:

```sh
python3 tools/readback.py compare <read1> <read2> <reference> \
  --sha256 <pinned-sha> --base 0x08008000 --length 98304 \
  --code-length <release-raw-bytes>
```

It reports `MATCH`, `MISMATCH`, `INCOMPLETE_READ`, `UNSTABLE_READ` or `REFERENCE_UNCONFIRMED`, checks whole-image length/hash/coverage, and diagnoses code and padding separately. Reports cap contiguous difference ranges at 32. Equal files do not establish physical provenance or independent reads; a cached response or copied file cannot count as a second acquisition. No two physical firmware captures currently exist.

### Discovery core and live adapter

`tools/shelly/readback_core.js` is an injected-I/O discovery engine. It has no UART configuration, deployment or recovery logic. Its only transmitted frame is `5A`; authenticated operations are discover/status/ack/stop. One 12-byte response is retained, sequence replay retrieves the cached result without another transmit, and the host must save a result before acknowledging it. Its limit is 20 discoveries per core instance, with a three-second transaction timeout, initial 15-minute passive lifetime and subsequent 60-second inactivity timeout. Bad framing/checksum, overflow, unsolicited data or timeout makes the instance silent.

`tools/shelly/readback_bridge.js` is the deployed adapter for that core. It binds the separately qualified UART handle, registers an authenticated POST endpoint, bounds request bodies to 512 characters and returns bytes as base64. A generated local session/token prefix is required and must never be committed or exposed in logs. The adapter does not change Serial configuration, reboot, enable autostart or initiate discovery by itself.

### Experimental probe scripts

`probe_core.js`, `zero_probe.js`, `immediate_zero_probe.js` and `variant_series.js` are bounded research tools, not a general firmware-download API. The first probe core contains two fixed hypotheses. The series adapter receives a locally prepared fixed catalog and accepts only catalog indices or standalone discovery; it does not accept an arbitrary binary payload from an HTTP request. A series allows at most 16 listed probes and 17 discoveries, uses session/token and sequence checks, and retains at most 128 received bytes. Unexpected data or overflow halts read-hypothesis execution. The special parser-control mode validates discovery-shaped replies only.

`tools/experimental_probe.py` is the reusable host for an already prepared, supervised maintenance session. It validates catalog bytes against the bounded experiment vocabulary, compares target identity and script/Serial state with a private snapshot, verifies the complete uploaded source, saves results outside Git and stops its own script on success or failure. It never changes Serial mode, creates a script, reboots hardware or performs physical restoration. Its CLI requires `--session-dir`, `--catalog` and a new `--output` directory; the session must already contain the private `discovery-session.json` and `restoration-snapshot.json`. These are not safe defaults for a different device or a new session. Offline fake-transport tests do not count as a physical rerun of the factored host.

The series adapter is not the same state machine as the discovery core: do not assume it inherits the core's ACK protocol or inactivity expiry. It sends only on authenticated host requests, has no autonomous transmit loop and is deployed with autostart disabled. Generated secrets and raw records must remain local. No automatic bulk read or speculative write fallback exists.

### UART qualification helper and known cleanup anomaly

`tools/qualify_uart.py` is an experimental capability check. It verifies identity/configuration/script drift and idle application controls before changing mode; it sends no UART bytes and does not reboot. A mode change requiring reboot stops its qualification path. It is **not** a qualified autonomous maintenance workflow.

During qualification, deleting a stopped UART-inspection script timed out twice, and an unexpected restart was observed during one attempt. Causation is unresolved. The helper now stops and disables its own script, verifies Serial restoration, and deliberately retains the slot for post-reboot review. It never calls Script.Delete or reboots; cleanup failures remain separate from the primary error. Five offline fake-RPC tests cover this revised behavior. It is still not an unattended maintenance workflow. The supervised recovery restored and verified the original Serial mode and application identity before the later approved maintenance entry. For this session, stop/disable the temporary script, restore the saved Serial profile, perform only an approved required reboot, and review deletion afterward rather than immediately after UART ownership.

## Memory and verification limits

Discovery retains 12 bytes; experimental probes retain at most 128 bytes. A small HTTP chunk cannot stop a larger serial reply already in flight. The advertised 8192-byte write page is not a suitable unqualified receive allocation. An 8192-byte serial response occupies about 0.711 seconds at 115200 8N1, while 2048 bytes cover only about 0.178 seconds.

The final read-candidate series at 12:26:49 UTC reported shared JS free memory 23072 bytes, script used 2114 bytes, script peak 4354 bytes and system RAM free 116744 bytes before stopping. This is evidence for the small tested exchanges, not full-image or large-burst qualification. JS free memory is a shared pool. Runtime, driver callbacks, pending sends, cached bytes, base64 and JSON all contribute to memory use.

Offline tests exercise binary values, split/merged data, replay, partial sends, overflow, timeouts and comparison failures; the discovery-core test includes 1000 transactions across bounded mock sessions. They do not establish physical behavior for those synthetic cases. A future validated reader should begin with independently supported small blocks; the design target of 512 payload bytes and network chunks no larger than 1024 raw bytes remains conditional on protocol and measured transport support. The package's 2048-byte upper limit is not already qualified. Proposed floors of 16 KiB shared JS free and 32 KiB system free, and stopping on sustained growth above 4 KiB, are conservative supervision gates rather than guarantees.

Official API references: [Serial](https://shelly-api-docs.shelly.cloud/gen2/ComponentsAndServices/Serial/), [UART](https://shelly-api-docs.shelly.cloud/gen2/Scripts/APIs/UART/), [HTTPServer](https://shelly-api-docs.shelly.cloud/gen2/Scripts/APIs/HTTPServer/). Use the target's advertised mode spelling and verified mapping. The documented incoming HTTP limit is not a UART receive limit.

## Restoration and next evidence required

Maintenance entry and exit require both local snapshots and an operator-controlled physical handoff. Do not infer authorization to switch a different installation into UART mode or reboot it from this experiment. Before entry, account for all bus producers, application control state, relay startup behavior, exact original Serial configuration and script state. The operator changes power/DIP on **Procon only**; heat-pump power is not the maintenance control.

### Completed restoration — 2026-10-07

After the operator confirmed normal DIP10000110 and a Procon-only restart, a fixed read-only Modbus FC04 request through raw UART at9600 8N1 returned13bytes with valid CRC16 and identity3/1/3/0. Eight transmitted bytes included NULs and the request checksum. This establishes that known binary request at9600; it does not qualify115200 short-ACK timing or all256byte values. Exact original Shelly Serial configuration was restored and an approved required reboot performed. The original seven script id/name/enable/running states were verified. Telemetry generations183 and188 advanced86→100; Procon identity remained3/1/3/0 and both Shelly outputs werefalse.

Removing the stopped temporary slot8 after that reboot caused a connection reset and another unexpected Shelly restart (observed uptime160→24). Slot8 was nevertheless removed. Serial, identity, script list and outputs were verified again afterward. No retry of deletion occurred. This extends the earlier cleanup anomaly: a reboot before deletion did not prevent it. Future sessions should retain a stopped/disabled slot and review removal separately. Normal communication was restored at the end of that phase; the firmware-read result remains BLOCKED_READ_PROTOCOL, with no dump or hash comparison.

A usable firmware reader still needs a demonstrated request/reply contract, response integrity, address/count limits, overlapping/varied-address checks, qualified sustained transport and two independent complete captures against the pinned installed release. The available application-only vendor archive contains no resident bootloader image; its unused command enum does not supply those missing facts. No full-device backup, bootloader recovery or erase/program capability is delivered by P0075.

## Subsequent operator-authorized write reference

The [separate dated experiment](write-reference-experiments.md) adds bounded0x53 controls and a read/cached-ACK comparison after the read-only session above. It does not change the earlier counts or claim a working reader. Its valid write is limited to one eight-byte FF attempt inside the pinned image padding, without erase. It can affect hidden ECC despite unchanged visible data. The new `write_reference.js` and `read_ack_reference.js` expose only hardcoded operations and require a private local session/token prefix; no automatic startup or generic updater API is supplied.
