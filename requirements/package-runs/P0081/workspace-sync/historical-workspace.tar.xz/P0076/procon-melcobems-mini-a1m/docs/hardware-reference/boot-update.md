# Boot, update and recovery contract

Evidence: original application analysis, Windows-host static analysis, and historical operator flashing. This document separates **what the Windows host sends** from **what the device-resident bootloader actually implements**. The initial P0075 investigation was read-only. A later explicit operator instruction authorized the narrow write-reference experiment documented in [write-reference-experiments](../write-reference-experiments.md): one valid eight-byte FF attempt in application padding and bounded negative controls. This does not authorize erase, EEPROM, arbitrary programming or a general updater. Byte-layout documentation alone is not live authorization.

## 1. Application entry and image boundaries

```text
power/reset -> resident vendor boot/update selection
               | update mode -> host transfers application -> completion
               | normal boot -> application vector/MSP/reset entry
                                 -> startup -> clock/LED/watchdog/UART -> main
```

The exercised STM32 application base is `0x08008000`; the original application also sets VTOR there. Operator flashing has demonstrated that appropriately linked replacement images execute through the resident update path. The resident branch instructions, vector validation, hardware identification, authentication, DIP sampling and option-byte interactions have not been inspected. Do not generalize this memory map to every A1M or infer CPU compatibility from the R5/R5B label.

Host file offset zero is transmitted as update offset zero. On the exercised STM32 path it corresponds to application base `0x08008000`. The translation is performed on the device side and its implementation is unknown. This observation is NOT proof that an unused read command uses the same offsets, or that arbitrary absolute addresses are accepted.

The tested replacement release envelope is 98304 bytes (`0x18000`), ending at `0x0801FFFF` inclusive. Application content is followed by `0xFF`. An early short image was reported to erase only about 2 KiB and leave old application remnants; full-envelope padding is a project mitigation, not proof of physical erase coverage, flash density or a universal required file length. Preserve the boot reservation below `0x08008000`; do not prepend `0x8000` bytes or upload an ELF/ZIP. Existing conservative code/RAM allocation limits are unchanged by this protocol documentation.

## 2. Precisely identified Windows evidence

Static audit repeated 2026-10-07. The inputs were lawfully provided updater archives, not a device bootloader dump. Only independently described interoperability facts are published here; no vendor binaries or raw IL listings are included.

| Item | Identity |
|---|---|
| v3.1.05 archive | `Proon+Firmware+Update+Tool+(v3.1.05).zip` |
| Archive SHA-256 | `45e46af9892d16141db05bb6a03e4d51dbc06c46d88eb4dd56db5f5f853a4f12` |
| Inspected member | `Procon_R5_Firmware_Update Tool/FirmwareDownloader.dll` |
| DLL size / SHA-256 | 19456 bytes / `0de5a97616aa939f6302dacec4ce2f97de917df661b69c7208f76f6cf6330eec` |
| Assembly / runtime | `FirmwareDownloader`, assembly version 1.0.0.0; distribution requests .NET 7 Windows Desktop |
| Static coverage | All 27 method bodies, 1947 decoded IL instructions; all decoded branch targets land on instruction boundaries |
| Compared older archive | `A1M_R5_20240409_v3.1.03_FW.zip`; updater DLL, launcher EXE and PDB are byte-identical to the v3.1.05 bundle |

The archive's firmware version is not the updater assembly version. The bundled application BINs differ: v3.1.03 is 85992 bytes; v3.1.05 is 96692 bytes. The host selects the user-supplied local BIN; no alternative-image selection or conversion was found in the inspected worker.

Only four serial send sites exist, all in `Form1.backgroundWorker1_DoWork`: discovery, erase, block write, and last-ACK query. The three serial read sites receive discovery parameters and one-byte acknowledgements. Local `FileStream.Read` reads the selected PC file into memory; it does NOT read firmware from A1M. No firmware-to-output-file path was found. The updater does not back up the existing application before erasing it and does not perform post-write readback comparison.

## 3. Serial setup and host state machine

`Form1.init_serialport` configures **115200 baud, 8 data bits, no parity, 1 stop bit, no handshake**. It sets an infinite serial read timeout, opens the port and discards input. This is not the normal application's 9600-baud Modbus profile. No host baud selection, baud negotiation or auto-baud implementation was found; this does not exclude an unknown device-side feature.

Before starting the worker, the host checks that the selected file exists and is nonempty. After discovery it rejects a file larger than the reported maximum flash size. No host CPU/density signature, vector/header, firmware checksum/signature, or image-family compatibility validation was found in these checks. Device-side acceptance checks remain unknown.

The observed host flow is:

```text
open serial -> repeat discovery -> check file length
 -> request erase(offset=0, length=file length) -> wait for erase ACK
 -> read local BIN -> write successive blocks -> wait for each ACK
 -> report transfer finished -> close/dispose port
```

There is no backup stage, no serial firmware verification stage and no explicit reboot/jump command in this flow. Closing the PC port is not proof that the new application has started.

## 4. Complete command-constant inventory

These values are read from the CLI Constant metadata for `FirmwareDownloader.bootloaderCMD`, rather than guessed from gaps between opcodes. A defined enum value does not prove device implementation.

| Operation | Request | OK / response | Failure | Host use |
|---|---:|---:|---:|---|
| Discovery (`CHECK_PC_REQ`) | `0x5A` | `0x7A` | not defined here | Active |
| Flash erase | `0x51` | `0x71` | `0x70` | Active |
| Write flash | `0x53` | `0x73` | `0x72` | Active |
| Write EEPROM | `0x55` | `0x75` | `0x74` | Definitions only |
| Read flash | `0x57` | `0x77` | `0x76` | Definitions only |
| Read EEPROM | `0x59` | `0x79` | `0x78` | Definitions only |
| Read status | `0xA0` | `0xB0` | not defined here | Definitions only |
| Check last ACK | `0x50` | processed as the outstanding write ACK | no separate ACK constant | Active after missing write ACK |

`0x50` is not the unused `READ_STATUS=0xA0` operation and is not a flash-read command. The earlier proposed `0x52` flash-read code had no evidence; the actual read definition is `0x57`. These are raw bootloader bytes, not Modbus function codes or CN105 packet types.

## 5. Checksum and CRC rules verified from host arithmetic

All offsets below are byte offsets from the beginning of a packet. Multibyte fields are little-endian unless stated otherwise. `LE16` / `LE32` specify wire byte order, not host-language signedness.

The one-byte checksum is the **sum of preceding packet bytes modulo 256**. It is neither the CN105 subtractive checksum nor Modbus CRC16. Validation compares the final byte with that sum; it does not require the sum of the entire packet to be zero.

Write packets also contain reflected CRC-32 with polynomial `0xEDB88320`, initial internal state `0xFFFFFFFF`, final XOR `0xFFFFFFFF`, and no additional bit reversal after reflected processing. The host calls its internal CRC helper with initial argument zero, which the helper complements internally. The result is serialized least-significant byte first. Check value: ASCII `123456789` -> `0xCBF43926`.

CRC covers the write header AND data, excluding the trailing CRC and one-byte checksum. The additive checksum is calculated afterward and includes the four serialized CRC bytes. Independent offline bitwise and standard CRC calculations agreed on 15 fixtures, including all byte values and lengths through 8192; these checks are not device captures.

## 6. Discovery: exact host request and response layout

Request: one byte `5A`, no additional checksum. The code allocates a two-byte temporary array but writes only one byte.

Expected reply: 12 bytes.

| Bytes | Interpretation used by host |
|---|---|
| 0 | `7A` |
| 1-4 | Maximum flash size, LE32 |
| 5-6 | Maximum EEPROM size, LE16 |
| 7-8 | Erase-block size, LE16 |
| 9-10 | Maximum write-page size, LE16 |
| 11 | Sum of bytes 0-10 modulo 256 |

These fields are not a CPU ID, bootloader version, capability bitmap or proof of a readable memory range. In particular, maximum write size does not specify maximum read size.

Synthetic example, NOT a captured device response:

```text
7A 00 80 01 00 00 01 00 08 00 20 24
```

It decodes to maximum flash 98304, EEPROM 256, erase block 2048, maximum write 8192, checksum `24`. These illustrative values must never substitute for the actual discovery reply.

## 7. Erase: exact active-host frame

Documentation only; prohibited for P0075 readback.

```text
51 | offset LE32 | byte-count LE32 | checksum8
```

Total: 10 transmitted bytes. The host allocates 11 bytes but transmits only ten. It always supplies offset zero and the selected file's full length; it does not itself round that length using the reported erase-block size. Physical sector rounding and coverage remain device-side unknowns. There is no CRC32 in this erase request.

The host accepts a one-byte `71` as success and treats other received values as failure; `70` is the defined negative acknowledgement. It does not read back erased memory.

Synthetic example for offset zero, length 98304; never transmit as part of readback:

```text
51 00 00 00 00 00 80 01 00 D2
```

## 8. Write: exact active-host frame and block choice

Documentation only; prohibited for P0075 readback.

```text
53 | data-length LE16 | offset LE32 | data[N] | CRC32 LE32 | checksum8
```

| Bytes | Meaning |
|---|---|
| 0 | `53` |
| 1-2 | N, payload length LE16 |
| 3-6 | File-relative update offset LE32 |
| 7 through N+6 | N file bytes |
| N+7 through N+10 | CRC32 of bytes 0 through N+6, serialized LE32 |
| N+11 | Sum of bytes 0 through N+10 modulo 256 |

Total length is `N+12`. The host takes N from `device_MaxWritePageSize`, reduces it for the last partial block, and advances offset only after success. This explains the operator screenshot's 8192-byte progress increments. It is not a universal minimum payload or a physical erase-sector size. Smaller request lengths are representable and the host handles a final short write, but acceptance of arbitrary shorter blocks/alignment by the bootloader remains unverified.

On `73`, the host adds N to offset and subtracts N from remaining bytes. On `72`, it retries without advancing. It has no explicit finite overall negative-ACK retry budget. Other received values take an error path. A missing ACK leads to the separate `50` query described below, not firmware readback.

Synthetic four-byte example, offset zero, payload `00 01 FE FF`; NOT evidence that this write size is accepted:

```text
53 04 00 00 00 00 00 00 01 FE FF 3A E3 CF 25 66
```

CRC of the first 11 bytes is `0x25CFE33A`; checksum is `0x66`. Do not transmit this example in a read-only session.

## 9. Timing, missing replies and host limitations

These are observed host choices, not proven device timing requirements:

- Discovery polls at roughly 100 ms intervals for up to 20 iterations per attempt, then the outer loop can try again until cancellation. This is not proof of a two-second bootloader-entry window.
- Erase/write wait loops use a constructor-initialized 3000 ms threshold and roughly 100 ms sleeps.
- Each write iteration includes a 500 ms host delay before transmission. Transfer completion includes another 1000 ms sleep; exit/cleanup sleeps 3000 ms before cancellation/port disposal.
- After no write ACK, the host sends exactly one byte `50` and waits again. That query/wait path can repeat without a finite global retry limit. Replies are interpreted as the outstanding write acknowledgement, not a memory block or the `B0` status reply.

The discovery loop's buffered-byte threshold is 11, yet it requests a 12-byte read. It does not assemble/validate an exact returned length before examining the shared receive buffer. A replacement must implement bounded exact-length reception and must reject partial/stale data, not inherit this assumption. Polling a deadline does not make an infinite underlying read timeout safe.

The host reads the whole input BIN into memory and separately allocates the maximum write packet. Its fixed 256-byte `comPortBuffer` is used for discovery/ACKs; it is not evidence of a 256-byte firmware-read limit. Its block retransmission and input-discard behavior are not a safe general solution for a network bridge.

No host readback, per-block stored-flash comparison, automatic rollback, CPU-specific image conversion or remote power control was found. The transfer-finished message certifies only the worker reaching its end after expected acknowledgements.

## 10. Unused readback definitions and helper: exactly what is known

Flash read is defined as request `57`, success `77`, failure `76`; EEPROM read as `59`, `79`, `78`. No corresponding requests or reply parsers occur in any inspected method body. No method loads those read/status enum values as integer constants, and no additional serial-send sites implement such operations.

`Form1.bufferCRC32Check(byte[], int)` exists but has no static call or method-pointer reference in the assembly. It computes a CRC over `length-5` bytes, compares individual CRC bytes against buffer positions `length-i-2`, starts with result true and changes it to false on an equal-byte comparison. The comparison order is reversed relative to the active writer's CRC serialization. It is suspect unused code, not a correct validation oracle or proof of a read-response format. Do not infer a complete backup protocol merely from its name.

Unresolved before a usable readback implementation:

1. The full `57` request: address/count widths, order, valid values and checksum/CRC.
2. The response: placement of status/address/length/data, check fields, byte order, segmentation and end detection.
3. Relative versus absolute addressing, permitted regions, maximum/minimum read lengths and alignment.
4. Whether the connected bootloader implements readout and whether protections restrict it.
5. Timing, retries, effect of an incomplete request, and available flow control.

Therefore **there is no verified complete backup operation to enable in the Windows GUI**. P0075 may research a supported bounded read frame; when it cannot establish one safely it must report `BLOCKED_READ_PROTOCOL`, not guess a packet layout. A successful `5A` exchange alone does not prove `57` support. The write-frame format must not be relabeled as the read format without evidence. A dump of the application would still not establish full-device backup or successful restoration.

## 11. Static evidence locations and reproducibility

Method RVAs and metadata tokens identify the inspected DLL; they are not device addresses. IL offsets in this section start at the first opcode, excluding the CLI method header.

| Method | Method token | RVA |
|---|---|---|
| `crc_crc32` | `0x06000006` | `0x20A0` |
| `init_serialport` | `0x06000007` | `0x212C` |
| `buttonProgram_Click` | `0x0600000C` | `0x23CC` |
| `bufferChecksumCheckCalc` | `0x0600000D` | `0x24BC` |
| `bufferChecksumCheck` | `0x0600000E` | `0x24E3` |
| `bufferCRC32Check` (unused) | `0x0600000F` | `0x2510` |
| `bufferCRC32Calc` | `0x06000010` | `0x2558` |
| `ExitProcessLoop` | `0x06000011` | `0x2598` |
| `backgroundWorker1_DoWork` | `0x06000012` | `0x25F0` |

Worker code starts at DLL file offset `0x7FC`. Its four serial Write call sites are IL `0x0087`, `0x02EC`, `0x0542`, `0x05B7`; Read sites are `0x00F2`, `0x036E`, `0x0631`. The maximum-write-size load is IL `0x0427`, final-block cap `0x048F-0x0497`, and length encoding `0x04A6-0x04B5`.

Some earlier P0069 excerpt offsets include the 12-byte method header: e.g. its `0x0433` corresponds to opcode-relative `0x0427` here. Do not mix those conventions.

Read-flash field tokens are `0x04000010-0x04000012` with Constant rows at DLL file offsets `0x2284/0x228A/0x2290`. Read-EEPROM uses `0x04000013-0x04000015`, rows `0x2296/0x229C/0x22A2`; read-status/request-ACK uses `0x04000016/0x04000017`, rows `0x22A8/0x22AE`. The unused CRC-check method code is at file offset `0x71C`, length 60 bytes.

To reproduce: verify the DLL hash, parse PE/CLI metadata and Constant rows, inspect all methods and serial call sites, trace each transmitted length and field assignment, then independently calculate the synthetic examples. Do not execute the updater or open hardware just to inspect it. The audit is static-host evidence; complete bootloader support is not proven by metadata or by arbitrary byte-pattern searches.

## 12. Shelly transport and physical recovery boundary

P0075 uses separate sizes for a bootloader transaction, UART receive buffers and network chunks. Prefer small individually requested reads only after length/alignment support is evidenced. A smaller HTTP chunk cannot pause an already-started serial reply. Windows's 8192-byte write choice does not establish read granularity or a suitable Shelly heap allocation. Raw data, base64, JSON, driver buffers and retry-cache copies all require bounded memory. Do not copy the whole-image Windows buffering strategy to Shelly.

For the exercised update procedure: obtain the correct official instructions/recovery image separately, record DIP positions, disconnect competing RS485 masters, remove A1M CN105 power, set all eight A1M DIP switches OFF, prepare the host, then apply CN105 power as instructed. After completion remove power, restore DIP/RS485 settings and power up normally. P0075 arms read-only discovery instead of starting the Windows Program flow. The observation that all-OFF works does not identify separate baud/boot-select switches.

Verify heartbeat, Modbus identity and advancing CN105 counters after returning to normal operation. Do not mass-erase, change option bytes, overwrite the boot reservation or assume an unverified debug/recovery pinout. If the resident updater no longer responds, stop for board-specific recovery. Physical restoration from every failure mode has not been demonstrated.

This documentation amendment adds no updater implementation or live authorization. The lawful vendor updater remains the exercised programming dependency. P0075 permits discovery/read research and temporary Shelly transport setup only; erase/programming require a separate authorization and verification plan.
