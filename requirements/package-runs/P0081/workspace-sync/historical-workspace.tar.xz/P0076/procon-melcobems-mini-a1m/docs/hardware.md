> P0076 adds [EFFECT control](effect-control.md), [DIP addressing](addressing.md)
> and the r3 [v2 control contract](control-v2.md). The earlier description below
> records the read-only baseline; current capabilities are package76/revision1.

# Hardware evidence

Investigated interface: Procon MELCOBEMS MINI/A1M connected to Mitsubishi Geodan EHGT17D-YM9ED with FTC6. The MCU family is strongly inferred STM32L433 from original vector/reserved-interrupt pattern and peripheral code. Exact package/density was not physically read. This is not universal support for every A1M revision.

RS485: USART3,PC10 RX/PC11 TX AF7 with SWAP enabled; PD2 driver enable,96008N1,slave1. Omitting SWAP caused the first experimental image not to communicate. Corrected firmware returned input0=888 repeatedly and heartbeat blinked.

CN105: USART1,PA9 TX/PA10 RX AF7,24008E1, no swap. Physical compressor20Hz replies and repeated completed A3 responses confirm communication on the tested board. PC12 heartbeat toggles500ms. Pins are board-specific; verify before porting.

Application vectors0x08008000, conservative16KiB code/16KiB RAM link bounds, stack0x20004000. The96KiB update envelope pads FF through0x0801FFFF to overwrite the historical application footprint. It does not establish total flash density or erase the bootloader below0x08008000. Bootloader implementation itself was not extracted/verified.

## P0074 specification and subsequent observation

See the standalone [hardware reference](hardware-reference/overview.md) and [known unknowns](known-unknowns.md). A subsequent P0072 r1 read-only capture on 2026-10-07 produced12groups over55s: GET04 counts73→81, both brine completion counts36→40, protocol/UART/service failures0. Compressor0Hz, brine5/5C, supply/return32/32C, primary flow10–11L/min and DHW45.5–46C were decoded. This verifies ongoing acquisition, not simultaneous display calibration or nonzero heat/COP accuracy. Earlier pending statements describe build-time status. Controls remain unavailable.
