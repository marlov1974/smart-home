# Known unknowns and scope limits

Evidence:? unless a cited observed subset is named. These are concrete limitations of the engineering specification, not tasks silently counted as completed.

| Unknown | Consequence / resolution needed |
|---|---|
| Exact MCU marking/package/flash density | L433-compatible assumption only; physically inspect part and validate memory before expanding16KiB code/RAM allocation |
| Full board netlist, transceiver/isolator parts, connector electrical limits, termination, bias, LED polarity/color/location, other LEDs/DIP/EEPROM/test pads | Existing board routes only; electrical measurements/schematic needed for a new PCB or direct connector adapter |
| Resident bootloader code, vector acceptance, erase coverage, entry conditions across revisions and supported block/alignment rules | Windows discovery/erase/write frames, checksums, ACKs and host timing are now documented in [boot/update](hardware-reference/boot-update.md); device-side behavior and a physically validated replacement updater remain unverified |
| Flash/EEPROM read request and response framing, read-address semantics, read-size limits and actual device support | Unused host constants 0x57/0x77/0x76 and 0x59/0x79/0x78 are verified, but the Windows worker does not use them. P0075's operator-authorized, bounded flash-read experiments obtained no read response; see [evidence](firmware-readback-experiments.md). No complete EEPROM read was performed; the subsequent single-byte sweep includes its opcode but does not supply a read frame. Discovery success is not backup success; bulk acquisition remains gated on a validated contract. The unused CRC-check routine is not a valid protocol oracle. |
| Whether watchdog is inherited active; actual period/window/option-byte settings; external watchdog | Frequent refresh recipe worked, but cannot guarantee all inherited states; inspect/measure with recovery access |
| Original/system reset clock state and reset flags preserved by bootloader | Explicit HSI16 reinitialization; reset history may be unavailable |
| Interrupt-driven platform profile | Polling recipe proven; use public ST IRQ definitions and validate any enabled interrupts separately |
| Full protocol semantics and runtime-generated commands | P0073 catalogs preserve unknowns, five external conflicts and partial bounded GET1C analysis |
| TH32/TH34 channel identity over changing/negative values, source sensor accuracy | Completed5C/display5 is one point; broader synchronized comparisons needed |
| Pump run/level meaning across models; brine pump run/step/RPM | Primary candidates are reference-derived; brine pump fields explicitly unavailable |
| Nonzero thermal-power accuracy, electrical power, COP, cumulative energy | Derived water heat is an uncalibrated estimate; no COP/energy implementation |
| Control SET field isolation, native-mode readback, acknowledgement, lease and reboot restoration | No control path exists; future actuation requires a separate reviewed protocol and physical validation |
| Long-duration behavior and all A1M/FTC revisions | Short hardware observations and mocks do not establish fleet support |

## Continuing development without vendor firmware

Start with [platform overview](hardware-reference/overview.md), [platform JSON](platform-spec.json), memory/boot/pin recipes, complete P0073 catalogs, current Modbus semantics, golden vectors and protocol state machines. They replace routine dependence on original-BIN analysis or current implementation source. New code should be specified against these artifacts, with independent tests.

When a required fact remains unknown, record the specific gap and gather lawful public documentation or bounded hardware evidence first. Original-firmware analysis is a last-resort research activity, not the normal development workflow; independently publish numeric/semantic conclusions and provenance only. Never publish vendor binaries/manuals/raw instruction dumps.

A competent developer can reproduce the documented read-only profile without reading existing source or original firmware, provided they have the supported board and its lawful update/recovery environment. A fully autonomous updater, new PCB, guaranteed watchdog configuration or safe actuator controller cannot be reconstructed from unproven facts; those are explicit blockers beyond the verified profile.

Earlier P0075 protocol-documentation amendment (2026-10-07): the Windows host protocol reference now consolidates all inspected active commands and unused read/status definitions, exact byte layouts, additive checksum and CRC32 rules, synthetic offline vectors, retry/timing observations and method/metadata provenance. This resolves a documentation gap, not the resident read protocol or its hardware validation. No updater or firmware code changed; no tracked paths were added, removed or moved.

P0075 execution (2026-10-07): [research and blockers](firmware-readback.md) implements discovery validation, bounded supervised experiments and offline transport/storage/compare tests. Physical discovery repeatedly succeeds through Serial100 `js_uart` at 115200 8N1 and UART0 after an approved Shelly reboot. All 64 distinct read candidates returned zero bytes. The 0x57 contract remains unknown; no firmware dump or image comparison exists. Direction timing, arbitrary binary TX integrity and sustained large replies remain unqualified. The operator subsequently restored normal DIP and power. A CRC-valid normal-mode raw-UART Modbus read and restored normal communication were verified. Test-script deletion still caused an unexpected Shelly restart even after the planned reboot; see the dated restoration record.

P0075 follow-up: [documented write controls and cached ACK](write-reference-experiments.md) demonstrate one-byte responses at115200 and negative ACK from incomplete0x53. The tested0x57 forms still returned no bytes and left the discovery ACK cached. This strengthens an absent/disabled-read hypothesis but does not establish it. One correct-format FF attempt returned72; no successful programming or erased/ECC state was established.

P0075 opcode follow-up: the explicitly authorized [pure single-byte sweep](opcode-sweep.md) completed all 256 values once, with no inserted discovery, ACK or other helper traffic. Exactly `50`, `51`, `53` and `5A` responded; 252 values, including `57`, were silent within three seconds. Opcode-only `51` and `53` negative responses arrived after about 1.62 seconds, consistent with finite incomplete-command handling, but no internal timeout or missing-command proof was established. The [per-opcode results](opcode-sweep-results.json) preserve the separate accounting. Management-only checks at 14:39:00 UTC verified the stopped/disabled research script and maintenance Serial profile; physical normal-mode restoration remains deferred until the evening. No further UART traffic is scheduled.

P0075 delayed-discovery follow-up: [58 prefix trials](delayed-discovery.md) show both `40` and `57` can suppress a following `5A` at short gaps and accept it after approximately 1.58 seconds of measured send-call separation. A `57` response at 1556 ms was not repeatable at that same measured gap. This supports considering a shared packet-collection/timeout layer; command dispatch and the implementation of `57` remain unresolved. It does not justify inferring missing support solely from a silent truncated request. Final script stop/disable is verified; operator restoration is pending.

## P0076 evidence boundary

The R5 original application now establishes the eight DIP GPIO inputs and raw
bit order; see [addressing](addressing.md). Replacement startup decoding is
offline-tested. Physical switch-to-address correlation and two-device operation
still need isolated commissioning. The bounded water-side EFFECT regulator is
an offline candidate, not a calibrated floor-heat meter or verified controller.
Post-reset restore persistence, accurate live electrical power/COP and confirmed
brine-pump speed remain unresolved. No P0077 experiment has been run.
