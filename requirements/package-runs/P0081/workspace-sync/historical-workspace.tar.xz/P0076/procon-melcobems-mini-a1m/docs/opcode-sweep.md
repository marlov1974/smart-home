# P0075 single-byte opcode sweep — completed 2026-10-07

## Status and separate authorization

The operator authorized a sequential single-byte sweep and explicitly clarified that **no helper commands should be inserted**. The sweep completed all **256 values, `00..FF`, once in ascending order**. Every recorded send accepted exactly one byte. Four opcodes responded and 252 were silent in their full observation windows. Final script stop/disable was verified; physical normal-mode restoration remains pending.

This experiment is separate from the [64 read-candidate series](firmware-readback-experiments.md) and the [write-reference comparison](write-reference-experiments.md). Their counts remain unchanged. The sweep is **not read-only**: a single unknown opcode can potentially trigger a reset, persistent change or memory operation. A short request and a silent response do not establish that it had no effect. The specific operator authorization for this installation is not permission to run the sweep on another device.

No working firmware-read protocol, dump, successful programming or image comparison was obtained from the sweep. Its purpose is to compare response behavior across individual command bytes, not to reconstruct complete commands from enum names.

## Exact method

The fixed sequence is one byte per request, ascending from `00` through `FF`, with no address, length, checksum, data, padding or completion bytes appended. No additional discovery, last-ACK query, keepalive, resynchronization byte or retry is sent between entries. In particular, `50` and `5A` appear only at their ordinary positions in the sequence; they are not repeated as health checks.

Each entry has a **3000 ms observation window**, measured by the Shelly script's monotonic clock. Received bytes are also counted against a **1700 ms classification boundary**. The early count and the full-window count are distinct: a response after 1700 ms but within the full window is not labelled wholly silent. The timing boundary is an observation aid, not a demonstrated device timeout.

`tools/shelly/opcode_sweep.js` provides the bounded adapter:

- An authenticated session and sequence bind each opcode to exactly its next position. Repeated requests for the same sequence return state without another UART transmission.
- A successful send must report exactly one accepted byte. Zero, partial/invalid send results or send exceptions halt the run; there is no resend path.
- Only one entry can be outstanding. The next entry requires an explicit host request after the prior window completes.
- At most 128 received bytes and 128 receive timestamps are retained per entry. Overflow, invalid binary data, a clock fault, reception outside the active window, or reception during the send call halt execution.
- Reception in the final 200 ms of a window causes `RX_STILL_ACTIVE` and stops progression rather than immediately starting another opcode.
- The endpoint accepts probe/status/stop operations, not an arbitrary byte string. There is no automatic transmit loop or script autostart.

Host status and health RPC calls are out-of-band Shelly management traffic; they do not intentionally transmit bytes to Procon. The saved send intents and terminal results were validated as an exact ascending one-byte sequence with no gaps or extra helper transmissions. UART accepted-byte records are not an independent wire capture.

The UART maintenance profile is the separately established handle at 115200 8N1. There is no physical reboot between opcodes. **The three-second gap does not prove that the bootloader resets its parser or other state before the next byte.** Consequently, later responses may depend on earlier bytes or cached state.

## Observed responses

The complete pass produced exactly four nonempty replies and 15 received bytes in total. All 15 bytes arrived by the 1700 ms classification boundary. Latencies are from the adapter's transaction start to its first receive callback, not measurements on the wire. The table also highlights two silent controls; the [validated per-opcode JSON](opcode-sweep-results.json) records every value.

| Single byte sent | Observed reply | First callback | Interpretation limit |
|---|---|---:|---|
| `47` | No bytes in 3000 ms | — | No response under this sequence and state; operation support remains unknown |
| `50` | One byte `7A` | 112 ms | Consistent with a cached status observation; no helper discovery preceded it within this sweep |
| `51` | One byte `70` | 1619 ms | The known erase opcode can return its defined negative reply without supplied erase parameters |
| `53` | One byte `72` | 1618 ms | The known write opcode can return its defined negative reply without supplied write parameters |
| `57` | No bytes in 3000 ms | — | Contrasts with the two known negative replies, but does not prove the read command is absent |
| `5A` | 12-byte discovery response | 111 ms | Demonstrates responsiveness at this point in the ordered sequence |

The approximately 1.62-second negative replies to opcode-only `51` and `53` are consistent with incomplete-command handling that might include a timeout. This is a hypothesis: neither the internal receive timeout nor the reason for failure has been decoded. The silence following `57` is a useful contrast under the same observation method, not proof of a missing implementation. Read dispatch, error reporting or prerequisites could differ.

The discovery response retains the previously observed fields: maximum-flash field 225280 bytes, maximum-EEPROM field 255 bytes, erase-block field 2048 bytes and maximum-write-page field 8192 bytes. These do not establish readable memory bounds or a read capability.

## Verified final accounting

The first send intent was recorded at **2026-10-07 14:24:20.841084 UTC**; the final transaction result was recorded at **14:38:33.204434 UTC**. Total host duration, including the run's final cleanup, was **852.945 seconds**. The later management-only verification described below was a separate check.

| Measurement | Verified result |
|---|---:|
| Intended opcodes / matching terminal results | 256 / 256 |
| Ascending contiguous sequence | `00..FF`, once each |
| Accepted UART transmit bytes | 256, exactly one per entry |
| Appended parameters, retries or helper UART transmissions | 0 |
| Responding opcodes / silent opcodes | 4 / 252 |
| Received bytes by 1700 ms / by the full 3000 ms window | 15 / 15 |
| Missing results or sequence/count errors | 0 |
| Late-response, overflow, partial-send or health-guard termination | 0 |

`47`, `55`, `57`, `59` and `A0` each returned zero bytes throughout their full three-second windows. The known updater's active command bytes responded, while its unused declared read/status command bytes did not. No replacement read opcode was identified by this one-byte method. The absence of a response still does not establish that an opcode is unsupported.

The complete sanitized data is maintained once in [opcode-sweep-results.json](opcode-sweep-results.json). Its raw-evidence inventory SHA-256 is `26eed6fef16890fb01bd2a894122aa35a62eac61a6c8db5aef10e769a041f3fc`. This evidence inventory identifier is not a firmware hash. The report does not duplicate the JSON or publish the underlying private management records.

These 256 sweep transactions are separate from the earlier 64 read candidates, 26 write/reference transactions and isolated `41` example. Their historical totals are unchanged.

`make readback-test PYTHON=python3` passed with the existing suites plus 46 write-reference cases, 34 fixed read/ACK cases, 12 pure-sweep cases and 5 offline summary cases. The sweep tests include 256 ordered mock requests. Offline cases do not count as hardware samples. Only three fixed flash-read forms from the read/ACK adapter were exercised on hardware; its other `59` and `A0` forms were not run through that adapter. Their single-byte values were included in this sweep.

Raw management records, identifiers, session secrets and any possible firmware contents remain private. Published content is limited to relevant request bytes, response classifications and non-identifying measurements.

## Remaining limitations

This is one sequential pass with no reset between entries. It tests a particular parser history, firmware state, baud rate and timeout window. It does not identify a complete command format, demonstrate that a silent opcode is unsupported, or prove that the installation was unchanged.

Captured one-byte replies establish that this transport can receive those responses at the observed timing. Very early turnaround and direction-enable behavior have not been measured on the wire. Callback timing includes scheduling; exact millisecond equality or differences should not be assigned device semantics without independent evidence.

## Final bridge state and physical handoff

Shelly-only management reads at **2026-10-07 14:39:00.294893 UTC** verified the previously pinned identity and firmware, the temporary slot stopped and disabled, all original scripts still stopped and disabled, both relays off, and Serial still `js_uart` at 115200 8N1. No UART byte was sent after `FF`; in particular, there was no final discovery or cached-ACK query. The temporary slot is retained because deletion previously caused unexpected restarts.

Normal operation was restored after the earlier read-only phase, then the operator re-entered maintenance for subsequent experiments. The current Procon DIP position last confirmed by the operator is `00000000`. Physical return to the saved normal `10000110` setting with Procon power removed, followed by restart, remains deferred until the evening. No further automated probe or normal Modbus poll is scheduled.

Cleanup status is **WAITING_FOR_OPERATOR_RESTORE**; firmware readback remains **BLOCKED_READ_PROTOCOL**. After physical confirmation, restore the exact saved Serial configuration and perform an approved Shelly reboot if required, then verify normal identity and advancing telemetry. The completed sweep and management verification do not by themselves restore or verify normal Procon/CN105 operation.

## Later paired-opcode check — 2026-10-07

The operator next explicitly requested `40 5A`, then `57 5A`. Each was sent once as one contiguous two-byte UART transmission, without a deliberate inter-byte gap. Each had a 3000 ms receive window, followed by an out-of-band result read. No standalone discovery or other helper command was inserted. These two transactions and four transmitted bytes are separate from the 256-byte sweep above.

| Transmitted bytes | Bytes accepted | Received within 3000 ms | Result read after TX |
|---|---:|---:|---:|
| `40 5A` | 2 | 0 | 3273 ms |
| `57 5A` | 2 | 0 | 3290 ms |

Both windows completed without an observed byte or receive/overflow error. This does not uniquely implicate `57`: the `40` prefix also prevented an observed discovery response in this contiguous-pair test. Handling an entire burst according to its first byte, discarding trailing bytes, or retaining parser state are possible explanations. There was no physical reset between pairs, and no final standalone `5A` was sent, so post-test Procon responsiveness is unverified. A successful standalone discovery from the earlier sweep is a historical comparison, not a concurrent control. No read handler, packet length or timeout was proven by this check.

The small local adapter accepted only the two fixed pairs, once each in order, capped RX at 128 bytes, and rejected replay/order errors or late RX. An offline mock verified passive load, exact frames, order/replay handling, three-second windows, receive timing and late-RX stop before hardware use. A sandbox network denial occurred during the initial identity request, before script changes or UART transmission; the authorized network retry then ran the test once.

The research script was stopped and disabled again, read back at 2026-10-07T14:45:51.506871+00:00. Serial and physical restoration status remain unchanged: maintenance at 115200 8N1, operator return to normal mode pending. Raw logs and this site-specific one-shot runner remain local.
