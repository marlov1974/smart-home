# P0076 r1 physical transfer — 2026-10-08

[Normal boot and address1 are now verified](p76-normal-verification.md). Statements below describe the earlier stage.

The operator separately authorized flashing after the offline package delivery.
The connected R5B bootloader acknowledged the full application erase and all
69 sequential write packets. Normal application boot, DIP polarity and runtime
functionality still require the operator's physical DIP/power handoff and reads.
This is transfer evidence, not a flash-content readback or a control trial.

| Quantity | Observed |
|---|---|
| Application BIN |16,476 bytes |
| Programmed bytes |16,480: BIN plus four FF alignment bytes |
| Erase extent |98,304 bytes, application0x08008000 through0x0801FFFF |
| Erase ACK |Direct0x71 |
| Write ACKs |69 direct0x73, sequential |
| Largest packet |240 payload /252 wire bytes |
| Last packet |160 payload /172 wire bytes |
| Erase through cleanup |378.774 seconds |
| Write first-response timing |1920–2152 ms |
| Partial /zero UART accepts |0 /0 |

BIN SHA256: `dcd1efe7634fdf38a67c6ffcd8e95614a963b232619b788549256b64ff692b44`. The resident bootloader was outside
the erase/program plan. No long FF tail was sent. All frames and direct ACKs
were audited against the immutable release plan and local RPC/intent/result logs.

## Startup correction before erase

The first preflight failed at Script.Start: `ReferenceError: newStats is not
defined`. Local declaration hoisting differed from the Node mock. This attempt
emitted no UART request; no erase or programming occurred. Cleanup confirmed
all scripts stopped/disabled. The eager statistics initializer was moved after
the local function declaration, with no change to firmware or protocol frames.

The second preflight passed deployed-source readback, discovery, full first-frame
staging/CRC and heap health, before erase. Flash-core regression tests now include
a declaration-order model and a negative historical-order test:39 pass. Planner
16 and host9 tests also pass. This models the observed runtime difference, not
a full Shelly interpreter. The reusable lesson is recorded in Smart Home knowhow.

## Final state and next verification

All Shelly scripts are stopped and disabled; both relays remain off. Persistent
serial remains js_uart1152008N1. No EFFECT, FC16 heat command or P0077 experiment
was run. Bootloader readback is still unavailable; no checksum of physical flash
contents is claimed.

With Procon power off, restore physical SW1..8 to10000110 for address1 and restart.
Then use only addressed FC04 at9600 8N1 to verify marker/package888/76,
revision/API/features1/1/15, raw DIP0x61, stable valid address1, full valid UID
and advancing CN105 telemetry generations. The earlier P72/r3 normal verifier
must not be reused with its old expected identity. Shared-bus operation and
supervised EFFECT response remain separate validation stages.
