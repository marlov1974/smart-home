# P0076 candidate verification

[Subsequent normal boot and address1 verification passed](p76-normal-verification.md). Statements below describe the earlier stage.

This report records the initial offline completion. A later separately authorized
[physical transfer](p76-flash-verification.md) is now acknowledged; normal boot is still pending.

Status, 2026-10-08: offline verification complete, hardware pending. No P0076 device flash,
physical DIP test, heat-pump command or P0077 experiment was performed.

The compact image is16476bytes at08008000, SHA256
`dcd1efe7634fdf38a67c6ffcd8e95614a963b232619b788549256b64ff692b44`.
Its virtual96KiB erase-envelope digest is
`1a16d8b46f4a1542433778dfd90c12c296695d9ac71a219d17a075c7aa85df94`.
Linked code is bounded to20KiB inside the existing96KiB application footprint.
BSS is1688bytes;16KiB RAM and the linker's2KiB minimum stack reserve are unchanged.
The compact managed transfer needs69 frames of at most240payload bytes; erase
still covers98304bytes. No FF tail is transmitted as application payload.

## Checks

- The actual Cortex-M4 ELF passes all 37 ARM cases, including DIP addresses 1/2,
  startup latching, invalid configuration/UID refusal, existing v2 controls and
  coherent EFFECT warmup, pending FAST pairs and verified AUTO restoration.
  Separate modeled boots prove routing gates; they are not a simultaneous
  two-device electrical bus or collision-timing test.
- A forced rebuild reproduces the exact BIN SHA256 above. Image bounds, vectors,
  source publication checks and `git diff --check` pass.
- Seven native C suites pass under Clang ASan/UBSan: Modbus, CN105 ownership,
  telemetry, legacy control, EFFECT, coherent feedback and DIP/identity routing.
  Legacy84 native-flag cases remain, plus20,000 malformed Modbus requests.
- All256 DIP bytes are checked; supported addresses1/2/30 are routed independently.
  Instability,0/31, unsupported SW6/SW7, broadcast, wrong slave, badCRC and invalid
  UID control are rejected. Raw address/identity diagnostics remain explicit.
- Host command/read/commission suites:30 tests pass, including unchanged v2
  golden bytes, v3 limits, identity/DIP proof and duplicate SID/UID rejection.
- Compact planner16, host sender9 and Shelly mock37 tests pass. Existing P0075
  readback/research regressions pass; no experiment is run by these mocks.
- Catalog/platform documentation checks and current P0076 document links pass.
- EFFECT tests cover pending generation pairs, invalid/stale/zero-flow/DHW/link
  feedback, bounds/quantization/hysteresis/derivative, native rejects, delays,
  snapshot retention and AUTO/expiry/error restoration. Combined startup with
  hidden45C fixed target is checked, including separate mode/flow readbacks,
  lostACK, missing/wrong flow readback and unknown reset-time recovery.

## Emulator qualification

The actual ELF runs on explicitly selected Cortex-M4 with modeled UID/GPIO/UART,
TIM2 and clock registers. An abstract4instructions/us clock corresponds to an
assumed4cycles/instruction at16MHz; it is not a hardware timing measurement.
The old1instruction/us clock falsely exceeded RTU timing under the larger code.
A second harness issue skipped an unconditional POP following Thumb IT: restricting
read hooks to the MMIO range made the same unchanged ELF pass. This agrees with
[upstream Unicorn issue2309](https://github.com/unicorn-engine/unicorn/issues/2309).
The write whitelist and no-flash-write checks remain active for all writes.

## Remaining physical gates

The operator-requested five-bit DIP model supports addresses 1 through 30,
rather than software-configurable 1 through 247. The established setting
`10000110` remains address 1. Unsupported switch settings have no fallback
listener; this intentionally avoids assigning duplicate default addresses.

Individually confirm raw DIP, effective address and MCU UID before joining units;
then verify restart persistence and interleaved reads/independent CN105 progress.
Only after a separate operator handoff may a supervised single-pump EFFECT trial
verify heating measurement boundary, combined startup/readbacks, reachable low/
medium targets, cap behavior and AUTO/lease restoration. Reset loses the RAM
snapshot and blocks unattended use. Water-side power is not calibrated floor
heat or live COP. No long-duration or combined18–27kW dispatch is included.

## Revision 2: native pauses and bounded start demand (2026-10-08)

The r1 physical6kW trial exposed a premature unresponsive latch before compressor
start and autonomous restoration when native operating status became0. The r2
candidate separates qualified native wait from hard-invalid feedback. The
operator's approximately10minute off-time is a hypothesis, not a verified native
parameter. No timer, service setting or Mitsubishi protection is overridden.

WAIT_NATIVE clears historical watts while preserving session/snapshot/lease and
all budgets/latched limits. A powered, uninhibited pump may keep this mission
through a normal pause. With0Hz, a separate start-demand rule requests fresh
supply+0.5C, at most+1C per60s, within the command cap and cumulative+5C limit.
An already higher target remains unchanged. These raises never count as failed
power response. On restart an unsent demand is discarded; a transmitted one is
read back and accounted for.60s of fresh positive-Hz heating observations precede
READY; the regulator then retains its minimum60s adjustment interval. Waiting
and settling are bounded to20min, unaffected by renewals; the command lease may
expire sooner. Hard-invalid/stale/link/DHW/inhibit conditions still restore.

Offline verification covers two10minute zero-flow pauses with the real sampler
and controller, fresh restart, target margin at33C, budget/cap refusal, no false
unresponsive counts, guard/readback races, pending initial acceptance, positive-Hz
pulses, FAST source ordering, timer wrap, AUTO, lease and wait-timeout restoration.
Eight native C executables use ASan/UBSan; Python host suites and protocol/flash
regressions pass. The final image is17812bytes, with RAM/stack reserve checked
by the image-bound validator (exact BSS is in the build size report). Its compact
program SHA256 is `a92da1c2b2289c3045dfb18ce0295960222d3a3df1949413afae46b005012118`.
Deterministic rebuilding reproduces that hash. All37 compiled ARM regression cases pass for that final image; the native
pause/demand scenarios additionally pass in the sanitizer model. Source and artifact manifests identify the tested candidate.

Physical verification of r2, the adequacy of0.5C native demand margin, reduced
cycling and6kW stability remain pending. Earlier live supervisor scripts pin r1
and reject pause quality; they must be adapted and tested before another r2 live
trial. Do not reuse the old r1 hour runner unchanged. No live command, flash,
GitHub publication or Smart Home production activation was performed in this
correction. Project-specific lessons are kept here; no global knowhow promotion.
