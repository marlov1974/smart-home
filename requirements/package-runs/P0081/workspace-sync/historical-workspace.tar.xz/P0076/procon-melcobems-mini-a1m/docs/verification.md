> P0076 current verification is recorded in [P0076 verification](p76-verification.md).
> Historical results below describe their named baseline, not the new candidate.

# Verification scope

Local standalone verification passes native CRC/RTU/parser/scheduler/telemetry tests with ASan/UBSan,4offline helper tests and13actual-ELF ARM scenarios. Includes pending retries without interleaved FAST requests, simultaneous serial traffic, malformed frames, zero vs invalid, stale/wrap behavior, thermal arithmetic/sign/bounds/skew, heartbeat and write rejection. Mock peripherals are not hardware proof. BIN is deterministic on the tested toolchain and matches prior baseline. Vector/application bounds and96KiBFF envelope checked.

Historical hardware: input888/heartbeat,20Hz compressor with increasing replies, and repeated A3/27/28 completion with single-point5C comparison. Current expanded MVP fields remain unvalidated on hardware. No live commands, writes or flash were performed by the export. Native control/lease/acknowledgement features do not exist in this revision.

Hosted CI status must be checked for the published commit, independently of these local results. See public-release-checklist.md. Research catalogs expose unresolved confidence and are not tests of availability on every Mitsubishi model.

GitHub Actions run37579002118 passed for f7bc989 on Linux, including toolchain installation,all tests,determinism,sanitization and generated artifact upload. Subsequent revisions require their own run.

## P0074 specification and subsequent observation

See the standalone [hardware reference](hardware-reference/overview.md) and [known unknowns](known-unknowns.md). A subsequent P0072 r1 read-only capture on 2026-10-07 produced12groups over55s: GET04 counts73→81, both brine completion counts36→40, protocol/UART/service failures0. Compressor0Hz, brine5/5C, supply/return32/32C, primary flow10–11L/min and DHW45.5–46C were decoded. This verifies ongoing acquisition, not simultaneous display calibration or nonzero heat/COP accuracy. Earlier pending statements describe build-time status. Controls remain unavailable.
