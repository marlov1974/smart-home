# P0075 write-reference and cached-ACK experiments — 2026-10-07

## Result and scope

The operator explicitly authorized a bounded `0x53` write-reference experiment to learn how the bootloader handles a known command before comparing `0x57`. This is a later authorization than the earlier read-only series. **Every write attempt returned the direct negative acknowledgement `72`; no `73` success was observed.** Three subsequent `57` read probes returned no bytes, and their paired `50` last-ACK queries returned `7A`.

No erase command was sent. Only one frame with valid CRC and checksum was attempted, at a fixed application-relative offset with eight `FF` data bytes. There was no automatic retry of that frame. Its rejection is not proof that flash or hidden ECC remained unchanged; no physical readback exists. This experiment did not deliver a successful programming operation, firmware extraction, image comparison or backup.

The first completed transaction result was recorded at **13:51:04.403066 UTC** and the last at **14:01:51.975372 UTC**, on 2026-10-07. The temporary script was stopped and disabled, and `running:false` was verified at **14:02:31.987244 UTC**. The operator chose to restore normal mode later that evening. Current cleanup status is **WAITING_FOR_OPERATOR_RESTORE**: Shelly remains in UART maintenance mode at 115200 8N1, and Procon's last confirmed DIP setting is `00000000`. No further transmission is active or authorized pending the operator's physical handoff.

## Fixed write target and the FF limitation

The proposed wire frame follows the independently established host writer:

```text
53 | length LE16 | application-relative offset LE32 | data | CRC32 LE32 | sum8
```

The fixed length was 8 bytes and offset was `0x00017000`. Under the exercised update mapping, this corresponds to `0x0801F000–0x0801F007`, inside the pinned 98304-byte application envelope and well beyond its executable content. The reference image contains `FF` there. **Expected reference bytes do not establish that the physical cells were erased.** No resident-bootloader region, option bytes or EEPROM was targeted.

An `FF` write is not guaranteed to be a no-op on the inferred STM32L433-compatible flash. ST's RM0394 describes 64 data bits plus 8 ECC bits and programming that calculates ECC from a double word. The resulting caution is that unchanged visible data can coexist with a programming operation on hidden ECC; this experiment has no ECC readback. See [ST RM0394, embedded Flash memory](https://www.st.com/resource/en/reference_manual/rm0394-stm32l41xxx42xxx43xxx44xxx45xxx46xxx-advanced-armbased-32bit-mcus-stmicroelectronics.pdf). The exact fitted MCU remains unconfirmed.

Three fixed 20-byte requests were defined; these are our generated request bytes, not extracted firmware:

| Index | Purpose | Exact request hex |
|---|---|---|
| 0 | Valid CRC32 and sum8; attempted once only | `53080000700100ffffffffffffffff22aae82ea6` |
| 1 | Incorrect CRC32, recomputed valid sum8 | `53080000700100ffffffffffffffff23aae82ea7` |
| 2 | Valid CRC32, incorrect sum8 | `53080000700100ffffffffffffffff22aae82ea7` |

The CRC is the established reflected CRC-32/ISO-HDLC over header and data, serialized little-endian. The final sum8 includes the serialized CRC. Invalid frames were negative controls; rejection does not by itself identify which validation stage failed. No arbitrary address/data endpoint, erase fallback or automatic programming sequence was enabled.

## Accounting

Counts cover only this follow-up, across three host-script epochs. An epoch is a replacement of the local research adapter, not a claim of a physical Procon reboot.

| Transaction category | Count | Observed response |
|---|---:|---|
| Standalone discovery `5A` | 11 | Eleven identical valid 12-byte discovery replies |
| Complete write frames `53` | 6 | Six direct one-byte `72` replies |
| Incomplete write prefix `53`, tail withheld | 1 | One direct `72` before the scheduled tail; tail never sent |
| Read hypotheses `57` | 3 | No received bytes within 3 seconds each |
| Last-ACK queries `50` | 5 | Four one-byte `7A`; one one-byte `72` |
| Total transactions | 26 | 176 UART-accepted TX bytes; 144 received bytes |
| Valid complete write attempts | 1 | Included in the six complete writes above; returned `72` |
| Successful program acknowledgements / erased pages requested | 0 / 0 | No `73`, no erase command |

The six complete writes comprise the three distinct requests above, followed by three split deliveries of the same bad-CRC request. A fourth split delivery stopped after its 19-byte prefix. Do not report those repeated timing controls as additional distinct write formats. The read probes repeat two earlier candidate formats and add a one-byte opcode control; they do not add three newly discovered read protocols.

## Baseline cached ACK and classifier correction

After an initial successful discovery, a one-byte `50` query returned **one byte `7A`**, first observed 160 ms after that transaction began. This was not another complete discovery response. The initial adapter classified it as `RAW_RESPONSE` and halted, because its ACK classifier did not yet accept the discovery marker as cached state.

The classifier was corrected to preserve and label `7A` as a last-ACK observation. The adapter was replaced and its code verified before any `53` request had been sent. This software correction did not establish a new device behavior and did not retransmit a valid write. The later write-reference results belong to epoch 2.

After the first bad-CRC write had returned direct `72`, a following `50` returned cached **`72`** at 168 ms. Thus the query can expose a different observed status after a known write attempt. It is not an independent acknowledgement that the current query programmed anything.

## Complete write references

Times below are the UTC timestamps at which final transaction results were saved, not exact wire transmit times. Latency is from the adapter's transaction start to its first receive callback.

| Request | Final result UTC | Accepted bytes | Direct reply | First RX latency |
|---|---|---:|---|---:|
| Bad CRC, valid sum8 | 13:53:26.657787 | 20 | `72` | 1985 ms |
| Valid CRC, bad sum8 | 13:53:48.360207 | 20 | `72` | 1648 ms |
| Valid CRC and sum8; single permitted attempt | 13:54:21.202049 | 20 | `72` | 2048 ms |

The valid frame's negative reply leaves multiple explanations open, including target flash state/ECC, validation or bootloader restrictions. It does not confirm that this target/length is accepted for successful programming, nor that the host checksum fields are the cause of rejection. The complete request format comes from static host evidence; this experiment did not demonstrate a successful write implementation.

## Split request and withheld-tail controls

Only the bad-CRC request was used. It was split after byte 19, leaving its final additive checksum byte as the one-byte tail. All timings are software observations. The `actual_gap_ms` field measures transaction-start to tail scheduling; the separately recorded send-call difference is included to avoid treating it as a wire-level inter-byte gap.

| Requested delay | Recorded tail-scheduling gap | Send-call separation | Accepted bytes | Direct reply | First RX latency from start | Final result UTC |
|---:|---:|---:|---:|---|---:|---|
| 20 ms | 91 ms | 95 ms | 20 | `72` | 1882 ms | 13:55:12.608062 |
| 200 ms | 210 ms | 213 ms | 20 | `72` | 1845 ms | 13:55:39.059251 |
| 1000 ms | 1017 ms | 1021 ms | 20 | `72` | 1863 ms | 13:55:47.686636 |
| 3500 ms | Tail never scheduled | No second send | 19 | `72` before tail | 1692 ms | 13:56:11.087031 |

For the last control, receipt of `72` while waiting for the tail triggered `RX_BEFORE_TAIL` and halted transmission. The 20th byte was not sent. This establishes that a response can occur before this proposed frame is complete. A receive timeout or early validation is plausible; the observations do not identify the bootloader's internal timeout or prove which bytes it parsed.

The roughly 1.65–2.05 second response latencies in these trials are not exact hardware timer measurements. Shelly scheduling, host polling and UART callback delivery remain part of the observation path.

## Read hypotheses followed directly by cached-ACK queries

A read-only adapter was then loaded as epoch 3. Each group used a successful discovery, one fixed read hypothesis and then `50`, **with no intervening discovery between the read and its paired ACK query**. Each read had a three-second receive window. Any read data would have halted the series for analysis.

| Exact read request hex | Accepted read bytes | Read response | Read result UTC | Paired `50` reply | ACK latency / result UTC |
|---|---:|---|---|---|---|
| `57` | 1 | None | 14:01:07.710062 | `7A` | 111 ms / 14:01:11.317900 |
| `57100000800008ef` | 8 | None | 14:01:36.625675 | `7A` | 113 ms / 14:01:40.375231 |
| `571000008000086e992697b3` | 12 | None | 14:01:48.308949 | `7A` | 110 ms / 14:01:51.975372 |

The 8- and 12-byte hypotheses request 16 bytes at absolute address `0x08008000`, using the length16/address32 layout with sum8 or CRC32+sum8. Neither is a verified read request.

Compared with the write reference, these read trials produced neither a direct response nor an observed replacement of the discovery-associated cached byte with `76` or `77`. That supports the narrower observation that **these read hypotheses do not behave like the tested write attempts**. It does not prove `57` is absent: read handling might use different cached state, ignore invalid requests, require another layout or prerequisite, or return data through a different path.

## What this adds, and what remains unresolved

The earlier concern that this transport might lose every one-byte response is weakened by repeated captured `72` and one-byte cached responses. It does not disappear for responses with a different, much earlier turnaround: direction-enable timing and actual wire timing were not measured. There is still no direct or cached evidence of a successful flash read.

All discovery replies remained identical and valid, reporting fields 225280/255/2048/8192 bytes. These are protocol fields, not proof of physical density or read capability. No `77`, `76`, firmware data or successful program `73` was observed during this follow-up. The lack of `73` must not be turned into a claim that flash/ECC is physically unchanged.

Offline verification includes **46 write-reference tests and 27 read/ACK-reference tests**. They exercise fixed-frame bounds, authorization, sequence/replay handling, the single-valid-write guard, partial sends, scheduling, early responses and receive limits. They are software tests and do not add hardware samples or prove successful physical programming.

Private per-transaction results and timestamped RPC records support this report. Only generated request bytes and summarized replies/timings are published; device identifiers, endpoints, tokens, full snapshots and firmware contents remain private. The final stopped/disabled maintenance state still requires the operator's Procon-only power/DIP restoration, exact saved Serial restoration and verified normal application/CN105 communication. See [the earlier read experiments](firmware-readback-experiments.md) for the separate 64-candidate series and [readback research](firmware-readback.md) for the transport and restoration boundaries.
