/* P0076: conservative staircase with derivative anticipation, no integrator. */
#include "effect.h"
#include "effect_feedback.h"
static uint16_t phase,reason,target,cap,initial,verified,decisions,adjustments;
static uint16_t up_total,down_total,unresponsive,pending,boot_unknown,limit_latched;
static int16_t last_delta;
static int32_t previous_w,last_up_w,derivative;
static uint32_t last_decision,last_adjustment,previous_at;
static uint8_t have_previous,assess_up,pending_demand;
static int32_t absolute(int32_t v){return v<0?-v:v;}
void effect_init(void){
    phase=EFFECT_OFF;reason=target=cap=initial=verified=decisions=adjustments=0;
    up_total=down_total=unresponsive=pending=limit_latched=0;boot_unknown=1;last_delta=0;
    previous_w=last_up_w=derivative=0;last_decision=last_adjustment=previous_at=0;
    have_previous=assess_up=pending_demand=0;
}
void effect_begin(uint16_t target_w,uint16_t cap_cC,uint32_t t){
    effect_init();target=target_w;cap=cap_cC;phase=EFFECT_START;
    last_decision=last_adjustment=t;
}
void effect_capture(uint16_t flow,uint32_t t){initial=verified=flow;last_decision=last_adjustment=t;}
void effect_stop(unsigned why,int restoring){
    reason=(uint16_t)why;phase=restoring?EFFECT_RESTORING:EFFECT_INVALID_FEEDBACK;pending=0;
}
void effect_restored(void){phase=EFFECT_OFF;pending=0;}
uint16_t effect_decide(const effect_measurement *m,uint16_t flow,uint32_t t){
    if(!m->ready){if(m->quality!=EF_PENDING)effect_stop(EFFECT_BAD_FEEDBACK,0);return 0;}
    if(phase==EFFECT_OFF || phase==EFFECT_RESTORING || phase==EFFECT_INVALID_FEEDBACK || pending)return 0;
    if(t-last_decision<60000u)return 0;
    last_decision=t;++decisions;
    int32_t measured=m->short_w,error_w=(int32_t)target-measured;
    derivative=0;
    if(have_previous && t-previous_at>=1000u)
        derivative=(int32_t)(((int64_t)(measured-previous_w)*60000)/(t-previous_at));
    previous_w=measured;previous_at=t;have_previous=1;
    if(assess_up){
        if(measured-last_up_w<250){if(unresponsive<3)++unresponsive;}else unresponsive=0;
        assess_up=0;
    }
    /* LIMITED is latched against further increases, but overshoot may reduce. */
    if(limit_latched && error_w>=-700){phase=EFFECT_LIMITED;reason=limit_latched;return 0;}
    int32_t abs_error=absolute(error_w);
    if(abs_error<=500 || (phase==EFFECT_HOLD && abs_error<700)){
        phase=EFFECT_HOLD;reason=EFFECT_OK;return 0;
    }
    if(error_w>0 && unresponsive>=3){phase=EFFECT_LIMITED;reason=limit_latched=EFFECT_UNKNOWN_UNREACHABLE;return 0;}
    if(error_w>0 && up_total>=500){phase=EFFECT_LIMITED;reason=limit_latched=EFFECT_CUMULATIVE_CAP;return 0;}
    int32_t projected=measured+derivative/2;
    if(error_w>0 && derivative>0 && projected>=(int32_t)target-500){phase=EFFECT_CAPTURE;return 0;}
    int32_t step;
    if(error_w>2000){phase=EFFECT_START;step=100;}
    else if(error_w>1000){phase=EFFECT_CAPTURE;step=50;}
    else if(error_w>0){phase=EFFECT_CAPTURE;step=25;}
    else {phase=EFFECT_CAPTURE;step=error_w< -2000?-100:error_w< -1000?-50:-25;}
    if(step>0 && step>500-(int32_t)up_total)step=500-(int32_t)up_total;
    int32_t next=(int32_t)flow+step;
    if(next>cap)next=cap;
    if(next<2000)next=2000;
    if(next==(int32_t)flow){phase=EFFECT_LIMITED;reason=step>0?EFFECT_TEMPERATURE_CAP:EFFECT_TEMPERATURE_FLOOR;if(step>0)limit_latched=reason;return 0;}
    reason=EFFECT_OK;pending=(uint16_t)next;last_up_w=measured;
    return pending;
}
int effect_pending_demand(void){return pending && pending_demand;}
uint16_t effect_pause_demand(const effect_measurement *m,uint16_t flow,uint32_t t){
    /* Native start demand is not a power-error correction. Never force Hz/on. */
    if(m->quality!=EF_WAIT_NATIVE || m->hz!=0 || pending || limit_latched ||
       phase==EFFECT_OFF || phase==EFFECT_RESTORING || phase==EFFECT_INVALID_FEEDBACK ||
       m->supply_cC<0 || m->supply_cC>10000 || t-last_adjustment<60000u)return 0;
    int32_t desired=m->supply_cC+50; /*0.5C above fresh measured supply*/
    if(desired<=flow){reason=EFFECT_OK;return 0;}
    if(flow>=cap){reason=limit_latched=EFFECT_TEMPERATURE_CAP;return 0;}
    if(up_total>=500){reason=limit_latched=EFFECT_CUMULATIVE_CAP;return 0;}
    int32_t next=(int32_t)flow+100;
    if(next>desired)next=desired;
    if(next>cap)next=cap;
    if(next>(int32_t)flow+500-up_total)next=(int32_t)flow+500-up_total;
    pending=(uint16_t)next;pending_demand=1;reason=EFFECT_OK;return pending;
}
void effect_discard_pending(void){pending=0;pending_demand=0;}
void effect_wait(unsigned quality,uint32_t t){
    if(phase==EFFECT_OFF || phase==EFFECT_RESTORING || phase==EFFECT_INVALID_FEEDBACK)return;
    phase=quality==EF_WAIT_NATIVE?EFFECT_WAIT_NATIVE:EFFECT_SETTLING;
    /* A native pause is not evidence that a running pump failed to respond. */
    assess_up=have_previous=0;derivative=0;last_decision=t;
}
void effect_verified(uint16_t flow,uint32_t t){
    if(pending && flow==pending){
        last_delta=(int16_t)((int32_t)flow-verified);
        if(last_delta>0){up_total=(uint16_t)(up_total+last_delta);assess_up=(uint8_t)!pending_demand;}
        else down_total=(uint16_t)(down_total-last_delta);
        ++adjustments;last_adjustment=t;
        /* Measured minimum interval starts at completed readback. */
        last_decision=t;pending=pending_demand=0;
    }
    verified=flow;
}
uint16_t effect_read(unsigned a,const effect_measurement *m,uint16_t flow,uint32_t t){
    int32_t value=0;
    if(a>=325 && a<=332){
        value=a<327?m->instant_w:a<329?m->short_w:a<331?m->slow_w:
            m->short_w==INT32_MIN?INT32_MIN:(int32_t)target-m->short_w;
        return a%2?(uint16_t)((uint32_t)value>>16):(uint16_t)value;
    }
    switch(a){
    case 320:return 1;case 321:return phase;case 322:return reason;
    case 323:return target;case 324:return cap;
    case 333:return m->quality;case 334:return m->ready;case 335:return m->pairs;
    case 336:return m->age_ms/1000u>65535u?65535:(uint16_t)(m->age_ms/1000u);case 337:return (uint16_t)(m->span_ms/1000u);
    case 338:return flow;case 339:return (uint16_t)last_delta;
    case 340:return (t-last_adjustment)/1000u>65535u?65535:(uint16_t)((t-last_adjustment)/1000u);
    case 341:return m->hz;case 342:return decisions;case 343:return adjustments;
    case 344:return up_total;case 345:return down_total;case 346:return unresponsive;
    case 347:return pending;case 348:return (uint16_t)(int16_t)(derivative>32767?32767:derivative< -32768?-32768:derivative);
    case 349:return initial;case 350:return boot_unknown;case 351:return 0;
    default:return 0;
    }
}
