'use strict';
// P0075 offline tests. UART, timers and management calls are in-memory doubles.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '../tools/shelly/flash_core.js'), 'utf8');
const context = {};
vm.runInNewContext(source, context, {filename: 'flash_core.js'});

// Node hoists declarations; Shelly's local declarations are initialized in order.
// Model that specific runtime difference without claiming full mJS emulation.
function withoutLocalHoisting(text) {
  const names = [];
  const transformed = text.replace(/^  function ([A-Za-z_$][\w$]*)\(([^\n)]*)\) \{/gm,
    (_, name, args) => {names.push(name); return '  let ' + name + ' = function(' + args + ') {';});
  assert(names.includes('newStats'), 'non-hoisting model must include the failed initializer');
  assert(names.includes('start') && names.includes('pump'), 'model must include forward references inside callbacks');
  assert(!/^  function /m.test(transformed), 'all direct local declarations must be modeled');
  return transformed;
}
function localOrderFactory(text) {
  const localContext = {};
  vm.runInNewContext(withoutLocalHoisting(text), localContext, {filename: 'flash_core.local-order.js'});
  return localContext.makeFlashCore;
}

const crcTable = Array.from({length: 256}, (_, i) => {
  let c = i;
  for (let bit = 0; bit < 8; bit++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  return c >>> 0;
});
function crc32(bytes) {
  let c = 0xffffffff;
  for (const b of bytes) c = (c >>> 8) ^ crcTable[(c ^ b) & 255];
  return (c ^ 0xffffffff) >>> 0;
}
assert.equal(crc32(Buffer.from('123456789')), 0xcbf43926);
function frame(offset, data) {
  const b = Buffer.alloc(data.length + 12);
  b[0] = 0x53; b.writeUInt16LE(data.length, 1); b.writeUInt32LE(offset, 3); data.copy(b, 7);
  b.writeUInt32LE(crc32(b.subarray(0, data.length + 7)), data.length + 7);
  b[b.length - 1] = b.subarray(0, -1).reduce((a, v) => a + v, 0) & 255;
  return b;
}
assert.equal(frame(0, Buffer.from([0, 1, 254, 255])).toString('hex'), '530400000000000001feff3ae3cf2566');
function imagePlan(size = 11320) {
  const data = Buffer.from(Array.from({length: size}, (_, i) => i & 255));
  const frames = Array.from({length: Math.ceil(size / 240)}, (_, i) =>
    frame(i * 240, data.subarray(i * 240, (i + 1) * 240)));
  return {data, frames, manifest: {erase_size: 98304, program_size: size, page_size: 240, crcs: frames.map(crc32)}};
}
const plan = imagePlan();
function discovery({flash = 225280, eeprom = 255, erase = 2048, write = 8192} = {}) {
  const b = Buffer.alloc(12);
  b[0] = 0x7a; b.writeUInt32LE(flash, 1); b.writeUInt16LE(eeprom, 5);
  b.writeUInt16LE(erase, 7); b.writeUInt16LE(write, 9);
  b[11] = b.subarray(0, 11).reduce((a, v) => a + v, 0) & 255;
  return b;
}
function setup({acceptedLimit = Infinity, interval = 20, manifest = plan.manifest, send = null,
  factory = context.makeFlashCore} = {}) {
  let now = 100, core, impl = send;
  const accepted = [], calls = [];
  const io = {
    now: () => now,
    send: data => {
      calls.push(Buffer.from(data, 'latin1'));
      const n = impl ? impl(data, {advance: ms => now += ms, receive: s => core.receive(s)})
        : Math.min(data.length, acceptedLimit);
      if (Number.isInteger(n) && n > 0 && n <= data.length)
        accepted.push(Buffer.from(data.slice(0, n), 'latin1'));
      return n;
    },
  };
  core = factory(io, structuredClone(manifest));
  return {
    core, calls, sender: fn => {impl = fn;}, bytes: () => Buffer.concat(accepted),
    clear: () => {calls.length = 0; accepted.length = 0;}, time: () => now,
    advance: ms => {now += ms;}, service: (ms = interval) => {now += ms; core.tick();},
    drain: () => {
      let max = 100;
      while (core.status().pending_pump) {assert(max-- > 0, 'unbounded pump'); now += interval; core.tick();}
    },
    rx: data => core.receive(Buffer.isBuffer(data) ? data.toString('latin1') : data),
  };
}
function stage(s, page = 0, packet = plan.frames[page]) {
  return s.core.append(page, 0, packet.toString('latin1'));
}
function identify(s) {s.core.discover(); s.drain(); s.rx(discovery()); assert.equal(s.core.status().phase, 'identified');}
function erased(s) {identify(s); stage(s); s.core.erase(); s.drain(); s.rx('\x71'); assert.equal(s.core.status().phase, 'erased');}
let passes = 0, failures = 0;
function test(name, run) {
  try {run(); passes++; process.stdout.write('PASS ' + name + '\n');}
  catch (e) {failures++; process.stderr.write('FAIL ' + name + ': ' + e.stack + '\n');}
}

test('non-hoisted local declarations initialize idle statistics and allow discovery', () => {
  const s = setup({factory: localOrderFactory(source)});
  let st = s.core.status();
  assert.equal(st.phase, 'idle'); assert.equal(st.error, ''); assert.equal(s.bytes().length, 0);
  assert.equal(st.tx_stats.send_calls, 0); assert.equal(st.tx_stats.min_requested, -1);
  identify(s); st = s.core.status();
  assert.equal(s.bytes().toString('hex'), '5a'); assert.equal(st.phase, 'identified');
  assert.equal(st.tx_stats.send_calls, 1); assert.equal(st.tx_stats.accepted_bytes, 1);
  assert.equal(st.tx_stats.min_requested, 1); assert.equal(st.tx_stats.max_requested, 1);
});
test('non-hoisting model rejects the historical eager newStats call before any UART send', () => {
  assert.equal((source.match(/  let stats = newStats\(\);/g) || []).length, 1);
  assert(source.includes('  let lastService = -1;'));
  const prior = source.replace('  let stats = newStats();\n', '')
    .replace('  let lastService = -1;', '  let lastService = -1, stats = newStats();');
  let sends = 0;
  assert.throws(() => localOrderFactory(prior)({now: () => 100, send: () => {sends++; return 0;}},
    structuredClone(plan.manifest)), error => error.name === 'ReferenceError' && /newStats/.test(error.message));
  assert.equal(sends, 0);
});

test('compact plan has 48 frames and final 40-byte payload / 52-byte wire frame', () => {
  assert.equal(plan.frames.length, 48); assert.equal(plan.frames[0].length, 252);
  assert.equal(plan.frames[47].length, 52); assert.equal(plan.frames[47].readUInt16LE(1), 40);
  assert.equal(plan.frames[47].readUInt32LE(3), 11280);
  const s = setup(); assert.equal(s.core.status().program_size, 11320); assert.equal(s.core.status().erase_size, 98304);
});
test('manifest rejects bad erase size, program bounds/alignment, page size/count and CRC values', () => {
  const changes = [m => m.erase_size--, m => m.erase_size = 12288, m => m.page_size = 248,
    m => m.crcs.pop(), m => m.crcs.push(0), m => m.crcs = null,
    ...[0, -8, 7, 11321, 98312, NaN, Infinity, '11320'].map(v => m => {m.program_size = v;}),
    ...[-1, 4294967296, 1.5, NaN, undefined, '1'].map(v => m => {m.crcs[0] = v;})];
  for (const change of changes) {const m = structuredClone(plan.manifest); change(m); assert.throws(() => setup({manifest: m}));}
  assert.throws(() => setup({manifest: {image_size: 98304, page_size: 240, crcs: plan.manifest.crcs}}));
});
test('positive aligned minimum and maximum program extents are accepted without changing erase envelope', () => {
  for (const size of [8, 240, 248, 98304]) {
    const p = imagePlan(size), s = setup({manifest: p.manifest});
    assert.equal(s.core.status().page_count, Math.ceil(size / 240));
    assert.equal(s.core.status().erase_size, 98304); assert.equal(s.bytes().length, 0);
  }
});
test('load, staging and repeated status reads emit no serial bytes', () => {
  const s = setup(); stage(s);
  for (let i = 0; i < 100; i++) assert.equal(s.core.status().staged_valid, true);
  assert.equal(s.bytes().length, 0); assert.equal(s.core.status().pending_pump, false);
});
test('erase requires discovery and a complete validated first frame', () => {
  const s = setup(); assert.throws(() => s.core.erase()); stage(s); assert.throws(() => s.core.erase());
  const t = setup(); identify(t); t.clear(); assert.throws(() => t.core.erase());
  assert.throws(() => stage(t, 0, plan.frames[0].subarray(0, 100))); assert.equal(t.bytes().length, 0);
});
test('erase remains exactly ten bytes for offset zero and 98304 regardless of compact program size', () => {
  const s = setup(); identify(s); stage(s); s.clear(); s.core.erase();
  assert.equal(s.bytes().toString('hex'), '510000000000800100d2');
  assert.equal(s.bytes().readUInt32LE(5), 98304); assert.equal(s.core.status().next_page, 0);
});
test('staging rejects wrong page/offset, partial/excess wire size and nonbinary text', () => {
  const s = setup();
  const text = plan.frames[0].toString('latin1');
  for (const args of [[1, 0, text], [0, 1, text], [0, 0, text.slice(0, 100)],
    [0, 0, text + 'x'], [0, 0, '\u0100' + text.slice(1)], [0, 0, '']])
    assert.throws(() => s.core.append(...args));
  assert.equal(s.core.status().staged_bytes, 0); assert.equal(s.bytes().length, 0);
});
test('completed staging refuses a second append without modifying staged bytes', () => {
  const s = setup(); stage(s); const before = s.core.status().staged_crc32;
  assert.throws(() => stage(s)); assert.throws(() => s.core.append(0, 252, 'x'));
  assert.equal(s.core.status().staged_crc32, before); assert.equal(s.core.status().staged_bytes, 252);
});
test('corrupt payload faults before any device write', () => {
  const s = setup(), bad = Buffer.from(plan.frames[0]); bad[100] ^= 1;
  assert.throws(() => stage(s, 0, bad)); assert.equal(s.core.status().error, 'STAGED_FRAME');
  assert.equal(s.bytes().length, 0); assert.throws(() => s.core.discover());
});
test('valid protocol frame with wrong pinned content faults before TX', () => {
  const s = setup(), payload = Buffer.from(plan.data.subarray(0, 240)); payload[100] ^= 1;
  assert.throws(() => stage(s, 0, frame(0, payload))); assert.equal(s.core.status().error, 'STAGED_CRC');
  assert.equal(s.bytes().length, 0);
});
test('wrong sequential application offset rejects even when its full frame CRC is pinned', () => {
  for (const offset of [8, 240, 0x08008000, 98304]) {
    const packet = frame(offset, plan.data.subarray(0, 240)), m = structuredClone(plan.manifest);
    m.crcs[0] = crc32(packet); const s = setup({manifest: m});
    assert.throws(() => stage(s, 0, packet)); assert.equal(s.core.status().error, 'STAGED_FRAME');
    assert.equal(s.bytes().length, 0);
  }
});
test('wrong opcode, encoded length, protocol CRC or checksum rejects even with pinned full CRC', () => {
  for (const index of [0, 1, 247, 251]) {
    const packet = Buffer.from(plan.frames[0]); packet[index] ^= 1;
    const m = structuredClone(plan.manifest); m.crcs[0] = crc32(packet);
    const s = setup({manifest: m}); assert.throws(() => stage(s, 0, packet));
    assert.equal(s.core.status().error, 'STAGED_FRAME'); assert.equal(s.bytes().length, 0);
  }
});
test('split discovery needs all twelve checksum-valid bytes', () => {
  const s = setup(), b = discovery(); s.core.discover(); s.rx(b.subarray(0, 5));
  assert.equal(s.core.status().discovery, false); s.rx(b.subarray(5)); assert.equal(s.core.status().phase, 'identified');
});
test('discovery checksum corruption halts', () => {
  const s = setup(), b = discovery(); b[11] ^= 1; s.core.discover(); s.rx(b);
  assert.equal(s.core.status().error, 'DISCOVERY_SUM');
});
test('discovery capacity must cover full erase envelope rather than compact prefix', () => {
  for (const args of [{flash: 11320}, {flash: 98303}, {erase: 1024}, {write: 4096}]) {
    const s = setup(); s.core.discover(); s.rx(discovery(args)); assert.equal(s.core.status().error, 'DISCOVERY_CAPACITY');
  }
});
test('bad discovery marker or extra discovery byte halts', () => {
  for (const b of [Buffer.from([0x79]), Buffer.concat([discovery(), Buffer.from([0])])]) {
    const s = setup(); s.core.discover(); s.rx(b); assert.equal(s.core.status().error, 'DISCOVERY_FRAME');
  }
});
test('erase negative or unrelated ACK halts without setting erased', () => {
  for (const ack of [0x70, 0x73, 0x7a]) {
    const s = setup(); identify(s); stage(s); s.core.erase(); s.rx(String.fromCharCode(ack));
    assert.equal(s.core.status().phase, 'fault'); assert.equal(s.core.status().erased, false);
  }
});
test('write negative or unrelated ACK halts without advancing offset', () => {
  for (const ack of [0x72, 0x71, 0x7a]) {
    const s = setup(); erased(s); s.core.program(0); s.rx(String.fromCharCode(ack));
    assert.equal(s.core.status().phase, 'fault'); assert.equal(s.core.status().next_page, 0);
  }
});
test('two coalesced ACKs halt rather than counting as success', () => {
  const s = setup(); erased(s); s.core.program(0); s.rx('\x73\x73');
  assert.equal(s.core.status().error, 'ACK_LENGTH'); assert.equal(s.core.status().next_page, 0);
});
test('duplicate later ACK faults without advancing another page', () => {
  const s = setup(); erased(s); s.core.program(0); s.rx('\x73'); s.rx('\x73');
  assert.equal(s.core.status().error, 'UNEXPECTED_RX'); assert.equal(s.core.status().next_page, 1);
});
test('partial sends transmit only exact suffixes without duplication', () => {
  const s = setup({acceptedLimit: 100}); erased(s); s.clear(); s.core.program(0); s.drain();
  assert.deepEqual(s.bytes(), plan.frames[0]); assert.deepEqual(s.calls.map(b => b.length), [252, 152, 52]);
  assert.equal(s.core.status().sent, 252); assert.equal(s.core.status().next_page, 0);
  s.rx('\x73'); assert.equal(s.core.status().next_page, 1);
});
test('zero-byte acceptance retries the same suffix and records fixed-size statistics', () => {
  const s = setup(); erased(s); s.clear(); let n = 0;
  s.sender(b => (++n === 2 ? 0 : Math.min(100, b.length))); s.core.program(0); s.drain();
  assert.deepEqual(s.bytes(), plan.frames[0]); assert.deepEqual(s.calls.map(b => b.length), [252, 152, 152, 52]);
  const st = s.core.status().tx_stats;
  assert.equal(st.send_calls, 4); assert.equal(st.requested_bytes, 608); assert.equal(st.accepted_bytes, 252);
  assert.equal(st.zero_accepts, 1); assert.equal(st.partial_accepts, 2);
  assert.equal(st.min_requested, 52); assert.equal(st.max_requested, 252);
  assert.equal(st.min_accepted, 0); assert.equal(st.max_accepted, 100);
  assert.equal(st.service_calls, 3); assert.equal(st.min_service_interval_ms, 20); assert.equal(st.max_service_interval_ms, 20);
  assert.equal(Object.keys(st).length, 12); assert(Object.values(st).every(v => typeof v === 'number'));
});
test('status reads do not service pending TX or reset the TX deadline', () => {
  const s = setup(); erased(s); s.clear(); s.sender(() => 0); s.core.program(0);
  for (let i = 0; i < 50; i++) {s.advance(10); assert.equal(s.core.status().pending_pump, true);}
  assert.equal(s.calls.length, 1); s.advance(701); assert.equal(s.core.status().error, 'TX_DEADLINE');
  assert.equal(s.core.status().pending_pump, false); s.service(); assert.equal(s.calls.length, 1);
});
test('no discovery, erase, page or append is accepted while TX or ACK is outstanding', () => {
  const s = setup({acceptedLimit: 100}); erased(s); s.clear(); s.core.program(0);
  for (const op of [() => s.core.program(0), () => s.core.program(1), () => s.core.erase(),
    () => s.core.discover(), () => stage(s)]) assert.throws(op);
  s.drain(); assert.deepEqual(s.bytes(), plan.frames[0]); assert.throws(() => s.core.program(0));
});
test('zero progress reaches a finite TX deadline under recurring service', () => {
  const s = setup({acceptedLimit: 0}); s.core.discover(); s.drain();
  assert.equal(s.core.status().error, 'TX_DEADLINE'); assert.equal(s.bytes().length, 0);
  assert.equal(s.calls.length, 61); assert.equal(s.core.status().pending_pump, false);
});
test('delayed service after TX deadline cancels the unsent suffix', () => {
  const s = setup({acceptedLimit: 100}); erased(s); s.clear(); s.core.program(0); s.service(1201);
  assert.equal(s.core.status().error, 'TX_DEADLINE'); assert.equal(s.calls.length, 1);
  assert.equal(s.bytes().length, 100); assert.equal(s.core.status().tx_stats.max_service_interval_ms, 1201);
});
test('TX call crossing deadline cannot transition to ACK waiting', () => {
  const s = setup({send: (b, io) => {io.advance(1201); return b.length;}});
  s.core.discover(); assert.equal(s.core.status().error, 'TX_DEADLINE');
});
test('ACK deadline starts after final partial acceptance', () => {
  const s = setup({acceptedLimit: 100}); erased(s); s.core.program(0); s.drain();
  const st = s.core.status(); assert.equal(st.tx_elapsed_ms, 40);
  s.advance(3500); assert.equal(s.core.status().phase, 'waiting'); s.advance(1); s.core.tick();
  assert.equal(s.core.status().error, 'ACK_TIMEOUT'); assert.equal(s.core.status().next_page, 0);
});
test('late ACK cannot advance before timer gets CPU time', () => {
  const s = setup(); erased(s); s.core.program(0); s.advance(3501); s.rx('\x73');
  assert.equal(s.core.status().error, 'ACK_TIMEOUT'); assert.equal(s.core.status().next_page, 0);
});
test('RX during incomplete TX cancels pending sends', () => {
  const s = setup({acceptedLimit: 100}); erased(s); s.clear(); s.core.program(0); s.rx('\x73'); s.service();
  assert.equal(s.core.status().error, 'UNEXPECTED_RX'); assert.equal(s.core.status().next_page, 0);
  assert.equal(s.bytes().length, 100); assert.equal(s.calls.length, 1);
});
test('reentrant RX fault inside send is never overwritten by waiting', () => {
  const s = setup({send: (b, io) => {io.receive('\x73'); return b.length;}});
  s.core.discover(); assert.equal(s.core.status().phase, 'fault'); assert.equal(s.core.status().pending_pump, false);
});
test('invalid UART return values halt', () => {
  for (const value of [-1, 2, 0.5, NaN, undefined, '1']) {
    const s = setup({send: () => value}); s.core.discover(); assert.equal(s.core.status().error, 'TX_RESULT');
  }
});
test('UART send exception halts and does not schedule retry', () => {
  const s = setup({send: () => {throw new Error('driver');}}); s.core.discover(); s.service();
  assert.equal(s.core.status().error, 'TX_ERROR'); assert.equal(s.calls.length, 1);
});
test('overflow RX remains bounded and halts', () => {
  const s = setup(); s.core.discover(); s.rx(Buffer.alloc(8192, 0x7a));
  assert.equal(s.core.status().error, 'RX_OVERFLOW'); assert.equal(s.core.status().raw.length, 64);
  assert.equal(s.core.status().received, 8192);
});
test('all 48 compact frames advance only on direct ACK and preserve all binary values', () => {
  const s = setup(); erased(s); s.clear(); const payloads = [];
  for (let page = 0; page < 48; page++) {
    const packet = plan.frames[page]; if (page) stage(s, page);
    const beforeCalls = s.calls.length, beforeBytes = s.bytes().length;
    assert.equal(packet.readUInt32LE(3), page * 240); assert.equal(packet.readUInt32LE(3) % 8, 0);
    s.core.program(page); assert.equal(s.calls.length, beforeCalls + 1);
    assert.deepEqual(s.bytes().subarray(beforeBytes), packet);
    assert.equal(s.core.status().phase, 'waiting'); assert.equal(s.core.status().next_page, page);
    s.rx('\x73'); assert.equal(s.core.status().next_page, page + 1);
    payloads.push(packet.subarray(7, -5));
  }
  assert.deepEqual(Buffer.concat(payloads), plan.data); assert.equal(new Set(plan.data).size, 256);
  assert.equal(s.core.status().phase, 'complete'); assert.equal(s.calls.length, 48);
  assert(s.calls.every(b => b.length <= 252)); assert.equal(s.calls.at(-1).length, 52);
  assert.equal(s.bytes().length, 11320 + 48 * 12);
  assert.throws(() => stage(s, 48, plan.frames[0])); assert.throws(() => s.core.program(48));
  assert.throws(() => s.core.erase()); assert.throws(() => s.core.discover());
});
test('gaps or repeated page requests cannot advance the sequential stream', () => {
  const s = setup(); erased(s); assert.throws(() => s.core.program(1)); s.core.program(0); s.rx('\x73');
  assert.throws(() => stage(s, 2)); assert.throws(() => s.core.program(0));
  assert.equal(s.core.status().next_page, 1); stage(s, 1); s.core.program(1); s.rx('\x73');
  assert.equal(s.core.status().next_page, 2);
});
test('native adapter has named 20-ms service, no nested timers, passive load and binary management bridge', () => {
  const sent = [], timers = []; let receiver, now = 100, limit = Infinity;
  const native = {
    FLASH_MANIFEST: structuredClone(plan.manifest),
    UART: {get: id => {assert.equal(id, 0); return {
      send: b => {const n = Math.min(limit, b.length); sent.push(Buffer.from(b.slice(0, n), 'latin1')); return n;},
      recv: cb => {receiver = cb;},
    };}},
    Shelly: {getUptimeMs: () => now, call: () => {throw new Error('unexpected management call');}},
    Timer: {set: (ms, repeat, fn) => {timers.push({ms, repeat, fn}); return timers.length;}},
    atob: s => Buffer.from(s, 'base64').toString('latin1'), btoa: s => Buffer.from(s, 'latin1').toString('base64'),
  };
  vm.createContext(native); vm.runInContext(source, native);
  assert.equal(sent.length, 0); assert.equal(typeof receiver, 'function');
  assert.deepEqual(timers.map(t => [t.ms, t.repeat, t.fn.name]),
    [[20, true, 'flashService'], [1800000, false, 'flashExpire']]);
  assert.equal(JSON.parse(vm.runInContext('flashStatus()', native)).phase, 'idle');
  vm.runInContext('flashDiscover()', native); receiver(discovery().toString('latin1'));
  let st = JSON.parse(vm.runInContext('flashStatus()', native));
  assert.equal(st.phase, 'identified'); assert.equal(st.raw, '');
  assert.equal(Buffer.from(st.discovery_base64, 'base64').toString('hex'), discovery().toString('hex'));
  native.encoded = plan.frames[0].toString('base64');
  assert.equal(vm.runInContext('flashAppend(0,0,encoded)', native), 252);
  vm.runInContext('flashErase()', native); receiver('\x71'); sent.length = 0;
  limit = 100; vm.runInContext('flashProgram(0)', native);
  for (let i = 0; i < 10; i++) vm.runInContext('flashStatus()', native);
  assert.equal(sent.length, 1); now += 20; timers[0].fn(); now += 20; timers[0].fn();
  assert.equal(timers.length, 2); assert.deepEqual(Buffer.concat(sent), plan.frames[0]); receiver('\x73');
  st = JSON.parse(vm.runInContext('flashStatus()', native)); assert.equal(st.next_page, 1);
  assert.equal(st.tx_stats.send_calls, 3); assert.equal(st.tx_stats.max_service_interval_ms, 20);
});

process.stdout.write(`${passes} passed, ${failures} failed\n`);
if (failures) process.exitCode = 1;
