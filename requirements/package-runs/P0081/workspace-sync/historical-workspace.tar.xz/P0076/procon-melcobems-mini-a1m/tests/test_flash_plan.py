"""P0075: compact image and full-erase safety contract, with no live I/O."""
import contextlib
import hashlib
import io
import json
from pathlib import Path
import struct
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from flash_plan import (
    APPLICATION_BASE, APPLICATION_BYTES, RAM_END, build_plan, main,
    make_erase_frame, make_write_frame,
)


def fixture(raw_size=11320):
    """Synthetic image metadata is intentionally independent of any real release."""
    raw = bytearray((index * 37 + 11) & 255 for index in range(raw_size))
    struct.pack_into('<II', raw, 0, RAM_END, APPLICATION_BASE + 397)
    envelope = bytes(raw) + b'\xff' * (APPLICATION_BYTES - raw_size)
    manifest = {
        'base': hex(APPLICATION_BASE),
        'end_exclusive': hex(APPLICATION_BASE + APPLICATION_BYTES),
        'raw_bytes': raw_size,
        'padded_bytes': APPLICATION_BYTES,
        'initial_sp': hex(RAM_END),
        'reset_vector': hex(APPLICATION_BASE + 397),
        'sha256': hashlib.sha256(envelope).hexdigest(),
    }
    return bytes(raw), envelope, manifest


def independent_crc32(data):
    """Bitwise oracle independent of the planner's binascii implementation."""
    crc = 0xFFFFFFFF
    for byte in data:
        crc ^= byte
        for _ in range(8):
            crc = (crc >> 1) ^ (0xEDB88320 if crc & 1 else 0)
    return crc ^ 0xFFFFFFFF


class FlashPlanTests(unittest.TestCase):
    def test_p76_extended_link_bound_does_not_extend_erase_or_bootloader(self):
        raw, _, manifest = fixture(20480)
        plan = build_plan(raw, manifest)
        self.assertEqual(plan.raw_bytes, 20480)
        self.assertEqual(plan.erase_bytes, APPLICATION_BYTES)
        self.assertEqual(plan.program_data, raw)
        oversized, _, oversized_manifest = fixture(20481)
        with self.assertRaises(ValueError):
            build_plan(oversized, oversized_manifest)

    def test_compact_write_preserves_full_erase_and_partial_last_frame(self):
        raw, envelope, manifest = fixture()
        plan = build_plan(envelope, manifest)
        self.assertEqual(plan.erase_bytes, 98304)
        self.assertEqual(plan.erase_frame.hex(), '510000000000800100d2')
        self.assertEqual(plan.program_data, raw)
        self.assertEqual(len(plan.packets), 48)
        self.assertEqual(plan.packets[-1].offset, 11280)
        self.assertEqual(len(plan.packets[-1].payload), 40)
        self.assertEqual(len(plan.packets[-1].frame), 52)
        self.assertEqual(b''.join(packet.payload for packet in plan.packets), raw)
        self.assertEqual([packet.offset for packet in plan.packets], list(range(0, 11320, 240)))
        summary = plan.as_dict()
        self.assertEqual(summary['omitted_erased_tail_bytes'], 86984)
        self.assertFalse(summary['readback_verified'])
        self.assertEqual(summary['program_frame_bytes'], 11320 + 48 * 12)

    def test_raw_and_padded_inputs_have_same_frames(self):
        raw, envelope, manifest = fixture()
        from_raw = build_plan(raw, manifest)
        from_padded = build_plan(envelope, manifest)
        self.assertEqual(from_raw.packets, from_padded.packets)
        self.assertNotEqual(from_raw.source_sha256, from_padded.source_sha256)
        self.assertEqual(from_raw.envelope_sha256, from_padded.envelope_sha256)

    def test_only_minimal_alignment_padding(self):
        raw, _, manifest = fixture(11321)
        plan = build_plan(raw, manifest)
        self.assertEqual(plan.program_data, raw + b'\xff' * 7)
        self.assertEqual(plan.as_dict()['alignment_padding_bytes'], 7)
        self.assertTrue(all(len(packet.payload) % 8 == 0 for packet in plan.packets))
        self.assertEqual(plan.erase_bytes, 98304)
        self.assertEqual(build_plan(plan.program_data, manifest).packets, plan.packets)
        with self.assertRaisesRegex(ValueError, 'alignment padding'):
            build_plan(raw + b'\x00' * 7, manifest)

    def test_raw_trailing_ff_is_preserved_not_trimmed(self):
        raw, _, manifest = fixture(11323)
        raw = raw[:-19] + b'\xff' * 19
        manifest['sha256'] = hashlib.sha256(raw + b'\xff' * (APPLICATION_BYTES - len(raw))).hexdigest()
        plan = build_plan(raw, manifest)
        self.assertEqual(plan.raw_bytes, 11323)
        self.assertEqual(len(plan.program_data), 11328)
        self.assertEqual(plan.program_data[:len(raw)], raw)

    def test_independent_crc_and_serialization_all_byte_values(self):
        self.assertEqual(independent_crc32(b'123456789'), 0xCBF43926)
        payload = bytes(range(256))
        frame = make_write_frame(8192, payload)
        self.assertEqual(frame[:7], bytes.fromhex('53000100200000'))
        self.assertEqual(frame[7:-5], payload)
        self.assertEqual(struct.unpack('<I', frame[-5:-1])[0], independent_crc32(frame[:-5]))
        self.assertEqual(frame[-1], sum(frame[:-1]) & 255)
        self.assertEqual(len(frame), len(payload) + 12)

    def test_max_packet_and_last_packet(self):
        raw, _, manifest = fixture()
        plan = build_plan(raw, manifest, payload_bytes=8192)
        self.assertEqual([len(packet.payload) for packet in plan.packets], [8192, 3128])
        self.assertEqual([packet.offset for packet in plan.packets], [0, 8192])

    def test_erased_extent_cannot_shrink_to_compact_image_or_next_page(self):
        raw, _, manifest = fixture()
        for length in (0, len(raw), 12288, 96256, 98305, 100352, True):
            with self.subTest(length=length), self.assertRaises(ValueError):
                build_plan(raw, manifest, erase_bytes=length)

    def test_non_ff_tail_rejected_even_with_matching_full_hash(self):
        _, envelope, manifest = fixture()
        damaged = bytearray(envelope)
        damaged[-1] = 0
        manifest['sha256'] = hashlib.sha256(damaged).hexdigest()
        with self.assertRaisesRegex(ValueError, 'non-FF'):
            build_plan(bytes(damaged), manifest)

    def test_bad_hash_and_wrong_source_length(self):
        raw, envelope, manifest = fixture()
        for image in (raw[:-1], raw + b'\xff', envelope[:-1], b''):
            with self.subTest(length=len(image)), self.assertRaises(ValueError):
                build_plan(image, manifest)
        for image in (bytes([raw[0] ^ 1]) + raw[1:], bytes([envelope[0] ^ 1]) + envelope[1:]):
            with self.subTest(length=len(image)), self.assertRaisesRegex(ValueError, 'SHA256'):
                build_plan(image, manifest)

    def test_metadata_bounds_types_and_hash_format(self):
        raw, _, manifest = fixture()
        mutations = (
            ('base', APPLICATION_BASE + 8), ('end_exclusive', APPLICATION_BASE + APPLICATION_BYTES + 2048),
            ('padded_bytes', 12288), ('raw_bytes', 0), ('raw_bytes', 20481),
            ('raw_bytes', True), ('raw_bytes', 11320.0), ('raw_bytes', '-1'),
            ('raw_bytes', '11320garbage'), ('initial_sp', None), ('sha256', 'f' * 63),
        )
        for field, value in mutations:
            changed = dict(manifest, **{field: value})
            with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                build_plan(raw, changed)
        changed = dict(manifest)
        del changed['raw_bytes']
        with self.assertRaisesRegex(ValueError, 'missing'):
            build_plan(raw, changed)
        with self.assertRaises(ValueError):
            build_plan(raw, [])

    def test_vectors_must_match_metadata_and_actual_raw_bounds(self):
        raw, _, manifest = fixture()
        with self.assertRaisesRegex(ValueError, 'metadata'):
            build_plan(raw, dict(manifest, reset_vector=APPLICATION_BASE + 401))
        for sp, reset in (
            (RAM_END - 8, APPLICATION_BASE + 397),
            (RAM_END, APPLICATION_BASE + 396),
            (RAM_END, APPLICATION_BASE + 1),
            (RAM_END, APPLICATION_BASE + len(raw) + 1),
            (RAM_END, 0x08000001),
        ):
            changed = bytearray(raw)
            struct.pack_into('<II', changed, 0, sp, reset)
            changed_manifest = dict(manifest, initial_sp=sp, reset_vector=reset)
            changed_manifest['sha256'] = hashlib.sha256(changed + b'\xff' * (APPLICATION_BYTES - len(raw))).hexdigest()
            with self.subTest(sp=sp, reset=reset), self.assertRaises(ValueError):
                build_plan(bytes(changed), changed_manifest)

    def test_bad_payload_limits_alignment_and_mutability(self):
        raw, _, manifest = fixture()
        for size in (0, 1, 7, 239, 241, 8193, 8200, -8, True, 240.0):
            with self.subTest(size=size), self.assertRaises(ValueError):
                build_plan(raw, manifest, payload_bytes=size)
        with self.assertRaises(ValueError):
            build_plan(bytearray(raw), manifest)
        with self.assertRaises(ValueError):
            make_write_frame(0, bytearray(8))

    def test_frame_helpers_reject_wraparound_and_unsafe_spans(self):
        for offset in (-8, 1, 0x100000000, APPLICATION_BYTES, True):
            with self.subTest(offset=offset), self.assertRaises(ValueError):
                make_write_frame(offset, b'\xff' * 8)
        for length in (0, 7, 8193, 8200):
            with self.subTest(length=length), self.assertRaises(ValueError):
                make_write_frame(0, b'\xff' * length)
        self.assertEqual(len(make_write_frame(APPLICATION_BYTES - 8, b'\xff' * 8)), 20)
        with self.assertRaises(ValueError):
            make_erase_frame(12288)

    def test_compact_cli_preserves_provenance_and_rejects_output_collisions(self):
        raw, envelope, manifest = fixture(11321)
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            image, meta = folder / 'image.bin', folder / 'image.json'
            compact, output = folder / 'compact.bin', folder / 'plan.json'
            image.write_bytes(envelope)
            meta.write_text(json.dumps(manifest))
            arguments = [str(image), str(meta), '--output', str(output), '--compact-output', str(compact)]
            self.assertEqual(main(arguments), 0)
            self.assertEqual(compact.read_bytes(), raw + b'\xff' * 7)
            evidence = json.loads(output.read_text())
            self.assertEqual(evidence['compact_artifact']['requires_erase_bytes'], 98304)
            self.assertEqual(evidence['compact_artifact']['sha256'], hashlib.sha256(compact.read_bytes()).hexdigest())
            self.assertEqual(evidence['alignment_padding_bytes'], 7)
            self.assertEqual(image.read_bytes(), envelope)
            with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                main(arguments)
            self.assertEqual(compact.read_bytes(), raw + b'\xff' * 7)
            self.assertEqual(json.loads(output.read_text()), evidence)
            for bad_arguments in (
                [str(image), str(meta), '--compact-output', str(folder / 'missing-provenance.bin')],
                [str(image), str(meta), '--output', str(folder / 'same'), '--compact-output', str(folder / 'same')],
                [str(image), str(meta), '--output', str(folder / 'failed-plan.json'), '--compact-output', str(image)],
            ):
                with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                    main(bad_arguments)
            self.assertFalse((folder / 'missing-provenance.bin').exists())
            self.assertFalse((folder / 'same').exists())
            self.assertFalse((folder / 'failed-plan.json').exists())
            self.assertEqual(image.read_bytes(), envelope)

    def test_cli_outputs_plan_without_overwriting_artifacts(self):
        raw, _, manifest = fixture()
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            image = folder / 'image.bin'
            meta = folder / 'image.json'
            output = folder / 'plan.json'
            image.write_bytes(raw)
            meta.write_text(json.dumps(manifest))
            self.assertEqual(main([str(image), str(meta), '--output', str(output)]), 0)
            self.assertEqual(json.loads(output.read_text())['program_bytes'], 11320)
            with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as raised:
                main([str(image), str(meta), '--output', str(image)])
            self.assertEqual(raised.exception.code, 2)
            self.assertEqual(image.read_bytes(), raw)


if __name__ == '__main__':
    unittest.main()
