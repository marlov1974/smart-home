"""P0075 offline host integration tests with an injected fake RPC transport."""
import base64
import binascii
import json
from pathlib import Path
import re
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from flash_shelly import FlashError, FlashSession
from test_flash_plan import fixture


class FakeShelly:
    """Protocol-shaped mock only; responses never stand in for physical evidence."""
    def __init__(self):
        self.device_id = 'shellypro2-012345abcdef'
        self.name = 'P0075 write reference'
        self.calls = []
        self.source = '// prior passive script\n'
        self.running = False
        self.enabled = False
        self.manifest = None
        self.frames = []
        self.erase_requests = []
        self.negative_page = None
        self.lost_page = None
        self.wrong_identity = False
        self.state = {'phase': 'idle', 'error': None, 'next_page': 0,
                      'staged_valid': False, 'staged_bytes': 0, 'staged_crc32': 0,
                      'erased': False, 'discovery': None}
        self.frame = b''

    def __call__(self, method, params):
        self.calls.append((method, dict(params)))
        if method == 'Shelly.GetDeviceInfo':
            return {'id': 'different' if self.wrong_identity else self.device_id, 'model': 'SPSW-202XE12UL'}
        if method == 'Serial.GetConfig':
            return {'mode': 'js_uart', 'serial': {'baud': 115200, 'format': '8N1'}}
        if method == 'Script.List':
            return {'scripts': [{'id': 7, 'name': 'other', 'running': False, 'enable': False},
                                {'id': 8, 'name': self.name, 'running': self.running, 'enable': self.enabled}]}
        if method == 'Switch.GetStatus':
            return {'output': False}
        if method == 'Script.GetCode':
            start, length = params['offset'], params['len']
            return {'data': self.source[start:start + length], 'left': max(0, len(self.source) - start - length)}
        if method == 'Script.PutCode':
            self.source = self.source + params['code'] if params['append'] else params['code']
            return {}
        if method == 'Script.Start':
            self.running = True
            self.manifest = json.loads(self.source.split('=', 1)[1].split(';\n', 1)[0])
            return {}
        if method == 'Script.Stop':
            self.running = False
            return {}
        if method == 'Script.SetConfig':
            self.enabled = params['config']['enable']
            return {}
        if method == 'Script.GetStatus':
            return {'running': self.running, 'mem_free': 20000, 'errors': []}
        if method == 'Script.Eval':
            return {'result': self.evaluate(params['code'])}
        raise AssertionError('Unexpected RPC ' + method)

    def evaluate(self, code):
        if code == 'flashStatus()':
            return json.dumps(self.state)
        if code == 'flashDiscover()':
            self.state.update(phase='identified', discovery={'max_flash': 225280, 'erase_block': 2048, 'max_write_page': 8192},
                              base64=base64.b64encode(bytes.fromhex('7a00700300ff000008002014')).decode())
            return None
        if code.startswith('flashAppend('):
            page, offset, encoded = json.loads('[' + code[len('flashAppend('):-1] + ']')
            if offset == 0:
                self.frame = b''
            if offset != len(self.frame):
                raise AssertionError('Unexpected staging offset')
            self.frame += base64.b64decode(encoded, validate=True)
            self.state.update(staged_valid=True, staged_bytes=len(self.frame),
                              staged_crc32=binascii.crc32(self.frame), next_page=page)
            return str(len(self.frame))
        if code == 'flashErase()':
            self.erase_requests.append(self.manifest['erase_size'])
            self.state.update(phase='erased', erased=True, base64=base64.b64encode(b'\x71').decode())
            return None
        match = re.fullmatch(r'flashProgram\(([0-9]+)\)', code)
        if match:
            page = int(match.group(1))
            self.frames.append(self.frame)
            if self.lost_page == page:
                self.state['phase'] = 'waiting'
                raise ConnectionError('simulated uncertain transport after one send')
            ack = b'\x72' if self.negative_page == page else b'\x73'
            self.state.update(phase='complete' if page + 1 == len(self.manifest['crcs']) else 'page_ok',
                              next_page=page + 1, sent=len(self.frame), base64=base64.b64encode(ack).decode(),
                              tx_elapsed_ms=34, first_rx_ms=1900)
            return None
        raise AssertionError('Unexpected evaluated expression ' + code)


class FlashShellyTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.folder = Path(self.temporary.name)
        raw, envelope, manifest = fixture()
        self.raw = raw
        self.image = self.folder / 'image.bin'
        self.manifest = self.folder / 'image.json'
        self.image.write_bytes(envelope)
        self.manifest.write_text(json.dumps(manifest))
        self.core = self.folder / 'core.js'
        self.core.write_text('// injected inert mock core; never deployed to hardware\n')
        self.fake = FakeShelly()
        self.tick = 0.0

    def sleep(self, delay):
        self.tick += delay

    def session(self, **changes):
        options = {'host': 'shelly.test.invalid', 'device_id': self.fake.device_id,
                   'image': self.image, 'manifest': self.manifest, 'out': self.folder / 'run',
                   'transport': self.fake, 'sleep': self.sleep, 'monotonic': lambda: self.tick,
                   'bootloader_confirmed': True, 'core_path': self.core}
        options.update(changes)
        return FlashSession(**options)

    def test_end_to_end_compact_48_packets_full_erase(self):
        session = self.session()
        session.preflight()
        self.assertEqual(self.fake.frames, [])
        self.assertEqual(self.fake.erase_requests, [])
        self.assertEqual(self.fake.manifest['erase_size'], 98304)
        self.assertEqual(self.fake.manifest['program_size'], 11320)
        result = session.program()
        self.assertTrue(result['transfer_acknowledged'])
        self.assertTrue(result['cleanup_verified'])
        self.assertEqual(result['pages_with_direct_ack'], 48)
        self.assertEqual(result['image_bytes_acknowledged'], 11320)
        self.assertEqual(self.fake.erase_requests, [98304])
        self.assertEqual(len(self.fake.frames), 48)
        self.assertEqual(len(self.fake.frames[-1]), 52)
        self.assertEqual(b''.join(frame[7:-5] for frame in self.fake.frames), self.raw)
        self.assertFalse(self.fake.running)
        self.assertFalse(self.fake.enabled)
        self.assertFalse(result['normal_boot_verified'])
        self.assertFalse(result['readback_verified'])
        forbidden = ('Serial.SetConfig', 'Shelly.Reboot', 'Switch.Set', 'Script.Delete')
        self.assertFalse(any(method in forbidden for method, _ in self.fake.calls))

    def test_negative_ack_never_advances_or_retries(self):
        session = self.session()
        session.preflight()
        self.fake.negative_page = 0
        with self.assertRaisesRegex(FlashError, 'DIRECT_ACK'):
            session.program()
        self.assertEqual(len(self.fake.frames), 1)
        self.assertFalse(self.fake.running)
        outcome = json.loads((session.out / 'outcome.json').read_text())
        self.assertEqual(outcome['pages_with_direct_ack'], 0)
        self.assertFalse(outcome['transfer_acknowledged'])
        calls = len(self.fake.calls)
        with self.assertRaisesRegex(FlashError, 'NO_REPLAY'):
            session.program()
        self.assertEqual(len(self.fake.calls), calls)

    def test_uncertain_send_is_consumed_without_retry(self):
        session = self.session()
        session.preflight()
        self.fake.lost_page = 0
        with self.assertRaises(ConnectionError):
            session.program()
        self.assertEqual(len(self.fake.frames), 1)
        self.assertEqual(self.fake.erase_requests, [98304])
        with self.assertRaisesRegex(FlashError, 'NO_REPLAY'):
            session.program()
        self.assertEqual(len(self.fake.frames), 1)

    def test_offline_plan_has_zero_rpc_and_refuses_existing_directory(self):
        session = self.session(bootloader_confirmed=False)
        result = session.offline_plan()
        self.assertEqual(result['program_bytes'], 11320)
        self.assertEqual((session.out / 'application.compact.bin').read_bytes(), self.raw)
        self.assertEqual(self.fake.calls, [])
        with self.assertRaises(FileExistsError):
            session.offline_plan()
        with self.assertRaises(FileExistsError):
            self.session().preflight()

    def test_live_actions_require_explicit_bootloader_confirmation(self):
        session = self.session(bootloader_confirmed=False)
        for action in (session.preflight, session.program):
            with self.assertRaisesRegex(FlashError, 'CONFIRMATION'):
                action()
        self.assertEqual(self.fake.calls, [])
        self.assertFalse(session.out.exists())

    def test_provenance_target_and_source_changes_block_before_network(self):
        session = self.session()
        session.preflight()
        calls = len(self.fake.calls)
        for changed in ({'host': 'other.test.invalid'}, {'device_id': 'shellypro2-ffffffffffff'}):
            with self.assertRaisesRegex(FlashError, 'PROVENANCE'):
                self.session(**changed).program()
        self.core.write_text('// changed source\n')
        with self.assertRaisesRegex(FlashError, 'PROVENANCE'):
            self.session().program()
        self.assertEqual(len(self.fake.calls), calls)
        self.assertEqual(self.fake.erase_requests, [])

    def test_wrong_device_stops_before_script_mutation(self):
        self.fake.wrong_identity = True
        with self.assertRaisesRegex(FlashError, 'TARGET_IDENTITY'):
            self.session().preflight()
        self.assertEqual([method for method, _ in self.fake.calls], ['Shelly.GetDeviceInfo'])
        self.assertEqual(self.fake.erase_requests, [])

    def test_wrong_live_source_consumes_session_and_stops(self):
        session = self.session()
        session.preflight()
        self.fake.source += '// unexpected mutation\n'
        with self.assertRaisesRegex(FlashError, 'RUNNING_SOURCE'):
            session.program()
        self.assertFalse(self.fake.running)
        self.assertEqual(self.fake.erase_requests, [])
        with self.assertRaisesRegex(FlashError, 'NO_REPLAY'):
            session.program()

    def test_unsupported_slot_rejected(self):
        with self.assertRaisesRegex(FlashError, 'SLOT_8'):
            self.session(slot=7)
        self.assertEqual(self.fake.calls, [])


if __name__ == '__main__':
    unittest.main()
