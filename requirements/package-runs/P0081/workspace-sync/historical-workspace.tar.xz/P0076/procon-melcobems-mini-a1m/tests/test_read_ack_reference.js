'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(__dirname+'/../tools/shelly/read_ack_reference.js','utf8'),ctx={};vm.createContext(ctx);vm.runInContext(source,ctx);
const session='s',token='0123456789abcdef0123456789abcdef',discovery=Buffer.from('7a00700300ff000008002014','hex').toString('latin1');
const frames=['57','57100000800008ef','571000008000086e992697b3','59','a0'];let cases=0;
function test(name,f){try{f();cases++;}catch(e){e.message=name+': '+e.message;throw e;}}
function make(accept){let n=100,seq=0,tx=[];let c=ctx.makeReadAckReferenceCore({now:()=>n,send:b=>{tx.push(b);return accept===undefined?b.length:accept;}},session,token);
return {c,tx,get seq(){return seq;},req:(op,index)=>{let r=c.request(session,token,seq+1,op,index);seq=r.seq;return r;},status:()=>c.request(session,token,seq,'status'),rx:b=>c.receive(b),advance:t=>{n+=t;c.tick();},discover:()=>{let r=c.request(session,token,seq+1,'discover');seq=r.seq;c.receive(discovery);n+=3000;c.tick();assert.equal(c.request(session,token,seq,'status').state,'discovery_ok');}};}
test('inert startup, auth, forbidden operations and gate',()=>{let s=make();s.advance(10000);assert.equal(s.tx.length,0);
assert.throws(()=>s.c.request(session,'bad',1,'discover'));for(const op of ['probe','split','write','erase','send'])assert.throws(()=>s.req(op));
assert.throws(()=>s.req('read_probe',0));assert.throws(()=>s.req('last_ack'));assert.equal(s.tx.length,0);});
for(let i=0;i<5;i++)test('fixed read frame '+i,()=>{let s=make();s.discover();s.req('read_probe',i);assert.equal(Buffer.from(s.tx[1],'latin1').toString('hex'),frames[i]);
assert.ok(![...Buffer.from(s.tx[1],'latin1')].some(b=>b===0x53||b===0x51||b===0x55));s.advance(2999);assert.equal(s.status().state,'waiting');s.advance(1);assert.equal(s.status().state,'no_response');});
test('duplicate sequence does not resend; changed/old/skipped reject',()=>{let s=make();s.discover();s.req('read_probe',1);s.c.request(session,token,2,'read_probe',1);assert.equal(s.tx.length,2);
assert.throws(()=>s.c.request(session,token,2,'read_probe',0));assert.throws(()=>s.c.request(session,token,1,'discover'));assert.throws(()=>s.c.request(session,token,4,'discover'));
s.advance(3000);s.c.request(session,token,2,'read_probe',1);assert.equal(s.tx.length,2);});
for(let code of [0x7a,0x72,0x73,0x76,0x77,0x78,0x79,0xb0])test('cache tag '+code,()=>{let s=make();s.discover();s.req('last_ack');s.rx(String.fromCharCode(code));s.advance(3000);
assert.equal(s.status().state,'last_ack_observed');assert.equal(s.status().ack_scope,'cached_observation_not_read_proof');assert.equal(s.status().halt,false);assert.throws(()=>s.req('last_ack'));});
test('one paired cache query after silent read',()=>{let s=make();s.discover();s.req('read_probe',0);s.advance(3000);s.req('last_ack');assert.equal(s.tx[2],'\x50');s.rx('\x7a');s.advance(3000);assert.equal(s.status().state,'last_ack_observed');assert.throws(()=>s.req('read_probe',1));});
for(let code of [0x7a,0x72,0x73,0x76,0x77,0x00])test('all read RX captured and halts '+code,()=>{let s=make();s.discover();s.req('read_probe',0);s.advance(15);s.rx(String.fromCharCode(code));
assert.equal(s.status().state,'captured');assert.equal(s.status().halt,true);assert.equal(s.status().first_rx_ms,15);assert.throws(()=>s.req('last_ack'));assert.throws(()=>s.req('discover'));assert.equal(s.tx.length,2);});
test('captured fragments remain bounded, no further TX',()=>{let s=make();s.discover();s.req('read_probe',2);s.rx('\x77');s.rx('ab');assert.equal(s.status().raw,'\x77ab');assert.equal(s.status().callbacks,2);
s.rx('x'.repeat(126));assert.equal(s.status().state,'RX_OVERFLOW');assert.equal(s.status().raw.length,128);assert.equal(s.status().received,129);assert.equal(s.tx.length,2);});
test('late RX after timeout halts; early unsolicited RX halts',()=>{let s=make();s.discover();s.req('read_probe',0);s.advance(3000);s.rx('\x76');assert.equal(s.status().state,'LATE_RX');assert.throws(()=>s.req('last_ack'));
let q=make();q.rx('x');assert.equal(q.status().state,'LATE_RX');assert.equal(q.tx.length,0);});
test('partial send never retries',()=>{let s=make(0);s.req('discover');s.advance(10000);assert.equal(s.status().state,'PARTIAL_SEND');assert.equal(s.tx.length,1);
let n=0,tx=[];let c=ctx.makeReadAckReferenceCore({now:()=>n,send:b=>{tx.push(b);return b.length===8?7:b.length;}},session,token);c.request(session,token,1,'discover');c.receive(discovery);n=3000;c.tick();c.request(session,token,2,'read_probe',1);assert.equal(c.request(session,token,2,'status').state,'PARTIAL_SEND');n=10000;c.tick();assert.equal(tx.length,2);});
test('discovery checks CRC sum, header and exact length',()=>{for(const raw of ['',discovery.slice(0,11),discovery.slice(0,11)+'\x00','x',discovery+'x']){let s=make();s.req('discover');s.rx(raw);s.advance(3000);assert.equal(s.status().halt,true);assert.throws(()=>s.req('read_probe',0));}});
test('unrecognized cached data halts and stays recorded',()=>{for(const raw of ['\x01','\x7a\x7a']){let s=make();s.discover();s.req('last_ack');s.rx(raw);s.advance(3000);assert.equal(s.status().state,'RAW_RESPONSE');assert.equal(s.status().raw,raw);}});
test('twelve transaction hard cap',()=>{let s=make();for(let i=0;i<6;i++){s.discover();s.req('last_ack');s.advance(3000);}assert.equal(s.tx.length,12);assert.throws(()=>s.req('discover'));assert.equal(s.tx.length,12);});
test('invalid indices and sequence rejected without TX',()=>{let s=make();s.discover();for(const i of [-1,5,0.5,'1',0x47])assert.throws(()=>s.req('read_probe',i));for(const seq of [-1,13,NaN,1.5])assert.throws(()=>s.c.request(session,token,seq,'discover'));assert.equal(s.tx.length,1);});
for(const index of [3,4])test('declared command RX captures without interpreting or retrying '+index,()=>{
let s=make();s.discover();s.req('read_probe',index);s.rx(index===3?'\x79':'\xb0');assert.equal(s.status().state,'captured');assert.equal(s.status().halt,true);
assert.equal(s.status().ack_scope,'unvalidated_read_hypothesis');assert.throws(()=>s.req('last_ack'));assert.equal(s.tx.length,2);
});
test('invalid clocks and send results fail closed',()=>{
for(const n of [NaN,Infinity,-1,'100'])assert.throws(()=>ctx.makeReadAckReferenceCore({now:()=>n,send:()=>{throw Error('no TX');}},session,token));
for(const n of [NaN,Infinity,-1,2,'1']){let s=make(n);s.req('discover');assert.equal(s.status().state,'SEND_ERROR');assert.equal(s.tx.length,1);}
let n=100,c=ctx.makeReadAckReferenceCore({now:()=>n,send:()=>{throw Error('must not send');}},session,token);n=99;c.tick();assert.equal(c.request(session,token,0,'status').state,'CLOCK');
});
test('stop is terminal; invalid RX is logged without further TX',()=>{
let s=make();s.discover();s.req('read_probe',1);s.c.request(session,token,2,'stop');s.advance(10000);assert.equal(s.status().state,'STOPPED');assert.throws(()=>s.req('discover'));assert.equal(s.tx.length,2);
let q=make();q.discover();q.req('read_probe',0);q.rx('\u0100');assert.equal(q.status().state,'NON_BINARY_RX');assert.equal(q.tx.length,2);
});
test('adapter remains inert and rejects arbitrary fields',()=>{let now=0,tx=[],endpoint,timer,rx;
let c={P75_READ_ACK_SESSION:session,P75_READ_ACK_TOKEN:token,UART:{get:n=>{assert.equal(n,0);return {send:b=>{tx.push(b);return b.length;},recv:f=>rx=f};}},Shelly:{getUptimeMs:()=>now},Timer:{set:(ms,r,f)=>{assert.equal(ms,50);timer=f;}},HTTPServer:{registerEndpoint:(name,f)=>{assert.equal(name,'read_ack_reference');endpoint=f;}},btoa:s=>Buffer.from(s,'latin1').toString('base64')};
vm.createContext(c);vm.runInContext(source,c);timer();assert.equal(tx.length,0);
function http(q){let r={send:()=>{}};endpoint({method:'POST',body:JSON.stringify(q)},r);return r;}
assert.equal(http({session,token:'bad',seq:1,op:'discover'}).code,403);assert.equal(http({session,token,seq:1,op:'discover',payload:'53'}).code,400);assert.equal(tx.length,0);
assert.equal(http({session,token,seq:1,op:'discover'}).code,200);rx(discovery);now=3000;timer();let r=JSON.parse(http({session,token,seq:1,op:'status'}).body);assert.equal(r.state,'discovery_ok');assert.equal(r.raw,'');assert.equal(r.base64,Buffer.from(discovery,'latin1').toString('base64'));});
console.log('PASS '+cases+' fixed read/ACK reference tests (offline only).');
