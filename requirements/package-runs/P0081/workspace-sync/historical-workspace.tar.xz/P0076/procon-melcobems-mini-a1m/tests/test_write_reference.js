'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(__dirname+'/../tools/shelly/write_reference.js','utf8');
const context={};vm.createContext(context);vm.runInContext(source,context);
const session='test-session',token='0123456789abcdef0123456789abcdef';
const discovery=Buffer.from('7a00700300ff000008002014','hex').toString('latin1');
const expected=[
  '53080000700100ffffffffffffffff22aae82ea6',
  '53080000700100ffffffffffffffff23aae82ea7',
  '53080000700100ffffffffffffffff22aae82ea7'
];
let cases=0;
function test(name,f){try{f();cases++;}catch(e){e.message=name+': '+e.message;throw e;}}
function fixture(accepted) {
  let clock=100,tx=[];
  const core=context.makeWriteReferenceCore({now:()=>clock,send:b=>{tx.push(b);return accepted===undefined?b.length:accepted;}},session,token);
  let seq=0;
  return {core,tx,get seq(){return seq;},setClock:n=>clock=n,advance:n=>{clock+=n;core.tick();},
    req:(op,index,split,gap)=>{const r=core.request(session,token,seq+1,op,index,split,gap);seq=r.seq;return r;},
    status:()=>core.request(session,token,seq,'status'),rx:b=>core.receive(b),
    discover:()=>{const r=core.request(session,token,seq+1,'discover');seq=r.seq;core.receive(discovery);clock+=3000;core.tick();assert.equal(core.request(session,token,seq,'status').state,'discovery_ok');},
    ack:()=>{core.receive('\x72');clock+=3000;core.tick();}};
}
function hex(s){return Buffer.from(s,'latin1').toString('hex');}
function crc32(b){let c=0xffffffff;for(const v of b){c^=v;for(let k=0;k<8;k++)c=c&1?(c>>>1)^0xedb88320:c>>>1;}return(c^0xffffffff)>>>0;}
test('fixed frames have exact independent checksum coverage',()=>{
  for(let i=0;i<3;i++) {
    let s=fixture();s.discover();s.req('probe',i);assert.equal(hex(s.tx[1]),expected[i]);
    let b=Buffer.from(s.tx[1],'latin1');assert.equal(b.length,20);assert.equal(b.readUInt16LE(1),8);assert.equal(b.readUInt32LE(3),0x17000);
    assert.equal(b.subarray(7,15).toString('hex'),'ffffffffffffffff');
    assert.equal(b.readUInt32LE(15)===crc32(b.subarray(0,15)),i!==1);
    assert.equal(b.subarray(0,19).reduce((a,v)=>(a+v)&255,0)===b[19],i!==2);
    assert.ok(![...b.subarray(1)].some(v=>[0x50,0x51,0x53,0x55,0x57,0x59,0xa0].includes(v)));
  }
});
test('no automatic startup, exact auth, gate and operation allowlist',()=>{
  let s=fixture();s.advance(5000);assert.equal(s.tx.length,0);
  assert.throws(()=>s.core.request(session,'wrong',1,'discover'));assert.throws(()=>s.core.request('wrong',token,1,'discover'));
  for(const op of ['send','erase','write','arbitrary'])assert.throws(()=>s.req(op));
  assert.throws(()=>s.req('probe',0));assert.throws(()=>s.req('last_ack'));
  for(const index of [-1,3,0.5,'0'])assert.throws(()=>s.req('probe',index));
  assert.equal(s.tx.length,0);
});
test('exact sequence replay never retransmits',()=>{
  let s=fixture();s.discover();s.req('probe',1);let before=s.tx.length;
  s.core.request(session,token,2,'probe',1);s.core.request(session,token,2,'probe',1);assert.equal(s.tx.length,before);
  assert.throws(()=>s.core.request(session,token,2,'probe',2));assert.throws(()=>s.core.request(session,token,1,'discover'));
  assert.throws(()=>s.core.request(session,token,4,'discover'));assert.throws(()=>s.req('discover'));
  s.advance(3000);s.core.request(session,token,2,'probe',1);assert.equal(s.tx.length,before);
});
test('only one valid write and no automatic retry',()=>{
  let s=fixture();s.discover();s.req('probe',0);s.rx('\x73');s.advance(3000);
  assert.equal(s.status().state,'ack');assert.equal(s.status().valid_used,true);
  s.advance(10000);assert.equal(s.tx.length,2);s.discover();assert.throws(()=>s.req('probe',0));
  s.req('probe',1);assert.equal(s.tx.length,4);
});
test('paired last ACK after no response, then requires new discovery',()=>{
  let s=fixture();s.discover();s.req('probe',1);s.advance(3000);assert.equal(s.status().state,'no_response');
  s.req('last_ack');assert.equal(hex(s.tx[2]),'50');s.rx('\x72');s.advance(3000);
  assert.equal(s.status().state,'last_ack_observed');assert.equal(s.status().ack_scope,'cached_state_not_current_write');
  assert.throws(()=>s.req('last_ack'));assert.throws(()=>s.req('probe',2));
});
test('baseline last ACK consumes fresh discovery gate',()=>{let s=fixture();s.discover();s.req('last_ack');s.advance(3000);assert.throws(()=>s.req('probe',1));});
test('baseline discovery tag from last ACK is observed cache, never write success',()=>{
  let s=fixture();s.discover();s.req('last_ack');s.rx('\x7a');s.advance(3000);
  assert.equal(s.status().state,'last_ack_observed');assert.equal(s.status().halt,false);
  assert.equal(s.status().ack_scope,'cached_state_not_current_write');assert.equal(s.status().valid_used,false);
  assert.equal(hex(s.status().raw),'7a');assert.equal(s.tx.length,2);s.discover();
});
test('last ACK after silent write can still report an earlier discovery tag',()=>{
  let s=fixture();s.discover();s.req('probe',1);s.advance(3000);s.req('last_ack');s.rx('\x7a');s.advance(3000);
  assert.equal(s.status().state,'last_ack_observed');assert.equal(s.status().ack_scope,'cached_state_not_current_write');
  assert.equal(s.status().paired_ack,false);assert.equal(s.status().halt,false);
});
test('last ACK73 remains cache observation, not current write success',()=>{
  let s=fixture();s.discover();s.req('last_ack');s.rx('\x73');s.advance(3000);
  assert.equal(s.status().state,'last_ack_observed');assert.equal(s.status().ack_scope,'cached_state_not_current_write');
});
test('discovery tag directly from53 still halts as unvalidated raw response',()=>{
  let s=fixture();s.discover();s.req('probe',1);s.rx('\x7a');s.advance(3000);
  assert.equal(s.status().state,'RAW_RESPONSE');assert.equal(s.status().halt,true);
  assert.equal(hex(s.status().raw),'7a');assert.equal(s.status().ack_scope,'current_transaction');
});
test('transaction cap is sixteen including discovery',()=>{
  let s=fixture();for(let i=0;i<8;i++){s.discover();s.req('last_ack');s.advance(3000);}
  assert.equal(s.tx.length,16);assert.throws(()=>s.req('discover'));assert.equal(s.tx.length,16);
});
for(const index of [1,2])for(const split of [7,19])for(const gap of [20,200,1000,3500])test('split '+[index,split,gap],()=>{
  let s=fixture();s.discover();s.req('split',index,split,gap);
  assert.equal(s.tx[1].length,split);assert.throws(()=>s.req('last_ack'));
  s.advance(gap-1);assert.equal(s.tx.length,2);s.advance(1);assert.equal(s.tx.length,3);
  assert.equal(hex(s.tx[1]+s.tx[2]),expected[index]);assert.equal(s.status().actual_gap_ms,gap);
  s.rx('\x72');s.advance(2999);assert.equal(s.status().state,'waiting');s.advance(1);
  assert.equal(s.status().state,'ack');assert.equal(s.status().rx_before_tail,0);
  assert.equal(s.status().first_rx_ms,gap);assert.equal(s.status().sent,20);
});
test('split valid frames and invalid timing/split cannot transmit',()=>{
  let s=fixture();s.discover();
  for(const args of [[0,19,20],[1,8,20],[1,19,0],[2,7,50],[2,7,3501]])assert.throws(()=>s.req('split',...args));
  assert.equal(s.tx.length,1);s.req('split',1,19,20);
});
for(const split of [7,19])test('any RX before tail halts without tail '+split,()=>{
  let s=fixture();s.discover();s.req('split',1,split,3500);s.advance(1000);s.rx('\x72');s.advance(10000);
  assert.equal(s.tx.length,2);assert.equal(s.status().state,'RX_BEFORE_TAIL');assert.equal(s.status().rx_before_tail,1);
  assert.equal(s.status().tail_at_ms,-1);assert.throws(()=>s.req('discover'));
});
test('scheduler overrun never sends the tail',()=>{
  let s=fixture();s.discover();s.req('split',1,19,20);s.advance(3020);
  assert.equal(s.status().state,'TAIL_SCHEDULING_TIMEOUT');assert.equal(s.tx.length,2);
});
for(const n of [0,1,19,21,-1,'20'])test('partial/invalid send halts '+n,()=>{
  let s=fixture();s.discover();s.core.tick();
  // An independent fixture exercises send validation on the one-byte discovery.
  let q=fixture(n);q.req('discover');q.advance(10000);assert.equal(q.tx.length,1);
  if(n===1)assert.equal(q.status().state,'DISCOVERY_TIMEOUT');
  else assert.ok(['PARTIAL_SEND','SEND_ERROR'].includes(q.status().state));
});
test('partial twenty-byte probe is not retried',()=>{
  let now=0,tx=[];
  let c=context.makeWriteReferenceCore({now:()=>now,send:b=>{tx.push(b);return b.length===20?19:b.length;}},session,token);
  c.request(session,token,1,'discover');c.receive(discovery);now=3000;c.tick();c.request(session,token,2,'probe',1);
  assert.equal(c.request(session,token,2,'status').state,'PARTIAL_SEND');now=9000;c.tick();assert.equal(tx.length,2);
});
test('discovery validates length/checksum, including fragmentation',()=>{
  let s=fixture();s.req('discover');s.rx(discovery.slice(0,5));s.rx(discovery.slice(5));s.advance(3000);assert.equal(s.status().state,'discovery_ok');
  for(const raw of ['',discovery.slice(0,11),discovery.slice(0,11)+'\x00','\x00',discovery+'\x00']){
    let q=fixture();q.req('discover');q.rx(raw);q.advance(3000);assert.equal(q.status().halt,true);assert.throws(()=>q.req('probe',1));
  }
});
test('raw unvalidated response remains logged and halts',()=>{
  let s=fixture();s.discover();s.req('probe',1);s.rx('\x77\x01');s.advance(3000);
  assert.equal(s.status().state,'RAW_RESPONSE');assert.equal(hex(s.status().raw),'7701');
});
test('overflow logs bounded data and total count',()=>{
  let s=fixture();s.discover();s.req('probe',1);s.rx('x'.repeat(33));assert.equal(s.status().raw.length,32);
  assert.equal(s.status().received,33);assert.equal(s.status().state,'RX_OVERFLOW');
});
test('late RX and idle RX halt and prohibit subsequent commands',()=>{
  let s=fixture();s.discover();s.req('probe',1);s.advance(3000);s.rx('\x72');assert.equal(s.status().state,'LATE_RX');assert.throws(()=>s.req('last_ack'));
  let q=fixture();q.rx('\x72');assert.equal(q.status().state,'LATE_RX');assert.equal(q.tx.length,0);
});
test('clock reversal halts',()=>{let s=fixture();s.setClock(99);s.advance(0);assert.equal(s.status().state,'CLOCK');assert.equal(s.tx.length,0);});
test('invalid clocks fail closed',()=>{
  for(const n of [NaN,Infinity,-1,'100'])assert.throws(()=>context.makeWriteReferenceCore({now:()=>n,send:()=>{throw Error('must not send');}},session,token));
  let s=fixture();s.setClock(NaN);s.advance(0);assert.equal(s.status().state,'CLOCK');assert.equal(s.tx.length,0);
});
test('explicit stop cancels pending tail',()=>{
  let s=fixture();s.discover();s.req('split',1,7,20);s.core.request(session,token,2,'stop');s.advance(1000);
  assert.equal(s.status().state,'STOPPED');assert.equal(s.tx.length,2);
});
test('adapter is inert until an authenticated fixed request',()=>{
  let now=0,tx=[],endpoint,rx,timer;
  const ctx={P75_WRITE_SESSION:session,P75_WRITE_TOKEN:token,
    UART:{get:n=>{assert.equal(n,0);return {send:b=>{tx.push(b);return b.length;},recv:f=>rx=f};}},
    Shelly:{getUptimeMs:()=>now},Timer:{set:(ms,repeat,f)=>{assert.equal(ms,10);timer=f;}},
    HTTPServer:{registerEndpoint:(name,f)=>{assert.equal(name,'write_reference');endpoint=f;}},
    btoa:s=>Buffer.from(s,'latin1').toString('base64')};
  vm.createContext(ctx);vm.runInContext(source,ctx);timer();assert.equal(tx.length,0);
  function http(body,method='POST'){let r={send:()=>{}};endpoint({method,body:typeof body==='string'?body:JSON.stringify(body)},r);return r;}
  assert.equal(http({session,token:'bad',seq:1,op:'discover'}).code,403);assert.equal(tx.length,0);
  assert.equal(http('x'.repeat(513)).code,400);assert.equal(http('{}','GET').code,400);
  assert.equal(http({session,token,seq:1,op:'erase'}).code,400);assert.equal(tx.length,0);
  assert.equal(http({session,token,seq:1,op:'discover',payload:'53'}).code,400);assert.equal(tx.length,0);
  assert.equal(http({session,token,seq:1,op:'discover'}).code,200);assert.equal(hex(tx[0]),'5a');
  rx(discovery);now=3000;timer();let r=JSON.parse(http({session,token,seq:1,op:'status'}).body);
  assert.equal(r.state,'discovery_ok');assert.equal(r.base64,Buffer.from(discovery,'latin1').toString('base64'));assert.equal(r.raw,'');
});
console.log('PASS '+cases+' bounded write-reference tests (offline only; no hardware).');
