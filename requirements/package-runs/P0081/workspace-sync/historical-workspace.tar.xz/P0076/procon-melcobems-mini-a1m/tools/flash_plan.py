"""P0075: offline, manifest-bound compact application flash plans.

The supplied release manifest is a trusted input. Its raw_bytes must come from
ELF/build evidence, never from stripping an arbitrary FF suffix. This module
checks the known MVP memory contract; it does not discover or operate hardware.
The 96 KiB erase envelope remains intact while only the load image is written.
"""
from __future__ import annotations

import argparse
import binascii
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re
import struct
import sys
from typing import Any, Mapping, Sequence

APPLICATION_BASE = 0x08008000
APPLICATION_BYTES = 98304
LINKED_IMAGE_LIMIT = 20480  # P0076 grows code only; 96KiB erase/RAM contract unchanged.
RAM_END = 0x20004000
ERASE_BLOCK_BYTES = 2048
PROGRAM_ALIGNMENT = 8
MAX_PAYLOAD_BYTES = 8192
DEFAULT_PAYLOAD_BYTES = 240
VECTOR_TABLE_BYTES = 99 * 4


def _integer(value: Any, name: str) -> int:
    if type(value) is int:
        return value
    if isinstance(value, str) and re.fullmatch(r"(?:0[xX][0-9a-fA-F]+|[0-9]+)", value):
        return int(value, 16 if value.lower().startswith("0x") else 10)
    raise ValueError(f"{name} must be an integer or unsigned decimal/hex string")


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def make_erase_frame(erase_bytes: int = APPLICATION_BYTES) -> bytes:
    """Build the known full-application erase; shrinking risks old-image residue."""
    if type(erase_bytes) is not int or erase_bytes != APPLICATION_BYTES:
        raise ValueError("erase_bytes must retain the complete 98304-byte application envelope")
    if erase_bytes % ERASE_BLOCK_BYTES:
        raise ValueError("erase extent must contain whole erase blocks")
    body = struct.pack("<BII", 0x51, 0, erase_bytes)
    return body + bytes([sum(body) & 0xFF])


def make_write_frame(offset: int, payload: bytes) -> bytes:
    """Build one reviewed 53 frame; this does not authorize its transmission."""
    if type(offset) is not int or offset < 0 or offset % PROGRAM_ALIGNMENT:
        raise ValueError("offset must be a nonnegative, eight-byte-aligned relative offset")
    if not isinstance(payload, bytes):
        raise ValueError("payload must be immutable bytes")
    if not 0 < len(payload) <= MAX_PAYLOAD_BYTES or len(payload) % PROGRAM_ALIGNMENT:
        raise ValueError("payload must contain 8..8192 bytes, aligned to eight bytes")
    if offset + len(payload) > APPLICATION_BYTES:
        raise ValueError("write frame extends beyond the supported application envelope")
    body = struct.pack("<BHI", 0x53, len(payload), offset) + payload
    crc_body = body + struct.pack("<I", binascii.crc32(body))
    return crc_body + bytes([sum(crc_body) & 0xFF])


@dataclass(frozen=True)
class WritePacket:
    offset: int
    payload: bytes
    frame: bytes


@dataclass(frozen=True)
class FlashPlan:
    base: int
    erase_bytes: int
    raw_bytes: int
    payload_bytes: int
    source_sha256: str
    envelope_sha256: str
    program_data: bytes
    erase_frame: bytes
    packets: tuple[WritePacket, ...]

    def as_dict(self) -> dict[str, Any]:
        """Return deterministic offline evidence; no device verification is implied."""
        return {
            "package": "P0075",
            "status": "OFFLINE_PLAN_ONLY",
            "base": hex(self.base),
            "relative_offset": 0,
            "erase_bytes": self.erase_bytes,
            "erase_end_exclusive": hex(self.base + self.erase_bytes),
            "raw_bytes": self.raw_bytes,
            "program_bytes": len(self.program_data),
            "alignment_padding_bytes": len(self.program_data) - self.raw_bytes,
            "omitted_erased_tail_bytes": self.erase_bytes - len(self.program_data),
            "payload_bytes": self.payload_bytes,
            "packet_count": len(self.packets),
            "source_sha256": self.source_sha256,
            "raw_sha256": _sha256(self.program_data[:self.raw_bytes]),
            "program_sha256": _sha256(self.program_data),
            "envelope_sha256": self.envelope_sha256,
            "erase_frame_hex": self.erase_frame.hex(),
            "program_frame_bytes": sum(len(packet.frame) for packet in self.packets),
            "readback_verified": False,
            "packets": [
                {
                    "offset": packet.offset,
                    "payload_bytes": len(packet.payload),
                    "frame_bytes": len(packet.frame),
                    "frame_crc32": binascii.crc32(packet.frame),
                    "frame_sha256": _sha256(packet.frame),
                    "frame_hex": packet.frame.hex(),
                }
                for packet in self.packets
            ],
        }


def build_plan(
    source: bytes,
    release_manifest: Mapping[str, Any],
    *,
    payload_bytes: int = DEFAULT_PAYLOAD_BYTES,
    erase_bytes: int | None = None,
) -> FlashPlan:
    """Validate a raw, minimally aligned or padded release and plan its extents.

    Required manifest fields are base, end_exclusive, raw_bytes, padded_bytes,
    initial_sp, reset_vector and sha256 (the full padded envelope's digest).
    All forms must reproduce that pinned envelope exactly. Metadata is trusted
    release/build evidence, not an automatically authenticated signature.
    """
    if not isinstance(source, bytes):
        raise ValueError("source must be immutable bytes")
    if not isinstance(release_manifest, Mapping):
        raise ValueError("release_manifest must be a mapping")
    required = ("base", "end_exclusive", "raw_bytes", "padded_bytes", "initial_sp", "reset_vector", "sha256")
    missing = [name for name in required if name not in release_manifest]
    if missing:
        raise ValueError("missing release manifest fields: " + ", ".join(missing))
    fields = {name: _integer(release_manifest[name], name) for name in required if name != "sha256"}
    expected_hash = release_manifest["sha256"]
    if not isinstance(expected_hash, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", expected_hash):
        raise ValueError("sha256 must be the pinned 64-digit padded-envelope digest")
    expected_hash = expected_hash.lower()
    if fields["base"] != APPLICATION_BASE or fields["end_exclusive"] != APPLICATION_BASE + APPLICATION_BYTES:
        raise ValueError("manifest must describe the supported 0x08008000..0x08020000 envelope")
    if fields["padded_bytes"] != APPLICATION_BYTES:
        raise ValueError("manifest padded_bytes must be 98304")
    raw_bytes = fields["raw_bytes"]
    if not VECTOR_TABLE_BYTES <= raw_bytes <= LINKED_IMAGE_LIMIT:
        raise ValueError("raw_bytes must fit the validated vector table and 20 KiB linked image region")
    aligned_bytes = raw_bytes + (-raw_bytes % PROGRAM_ALIGNMENT)
    if len(source) not in (raw_bytes, aligned_bytes, APPLICATION_BYTES):
        raise ValueError("source length must match raw, minimally aligned or full padded length")
    if len(source) == APPLICATION_BYTES:
        if _sha256(source) != expected_hash:
            raise ValueError("source SHA256 does not match the pinned padded release")
        if source[raw_bytes:] != b"\xff" * (APPLICATION_BYTES - raw_bytes):
            raise ValueError("omitted release tail contains non-FF bytes")
        raw = source[:raw_bytes]
    else:
        if source[raw_bytes:] != b"\xff" * (len(source) - raw_bytes):
            raise ValueError("minimal alignment padding contains non-FF bytes")
        raw = source[:raw_bytes]
        reconstructed = source + b"\xff" * (APPLICATION_BYTES - len(source))
        if _sha256(reconstructed) != expected_hash:
            raise ValueError("raw source does not reconstruct the pinned padded-release SHA256")
    initial_sp, reset_vector = struct.unpack_from("<II", raw)
    if initial_sp != fields["initial_sp"] or reset_vector != fields["reset_vector"]:
        raise ValueError("vector words do not match release metadata")
    if initial_sp != RAM_END or initial_sp % PROGRAM_ALIGNMENT:
        raise ValueError("initial SP must match the validated MVP SRAM boundary")
    if not reset_vector & 1 or not APPLICATION_BASE + VECTOR_TABLE_BYTES <= (reset_vector & ~1) < APPLICATION_BASE + raw_bytes:
        raise ValueError("reset vector must be Thumb code inside the actual raw application image")
    if type(payload_bytes) is not int or not 0 < payload_bytes <= MAX_PAYLOAD_BYTES or payload_bytes % PROGRAM_ALIGNMENT:
        raise ValueError("payload_bytes must be 8..8192 and aligned to eight bytes")
    erase_bytes = APPLICATION_BYTES if erase_bytes is None else erase_bytes
    erase_frame = make_erase_frame(erase_bytes)
    program_data = raw + b"\xff" * (-raw_bytes % PROGRAM_ALIGNMENT)
    if len(program_data) > erase_bytes:
        raise ValueError("erase extent does not cover the complete programmed image")
    packets = tuple(
        WritePacket(offset, program_data[offset:offset + payload_bytes], make_write_frame(offset, program_data[offset:offset + payload_bytes]))
        for offset in range(0, len(program_data), payload_bytes)
    )
    return FlashPlan(APPLICATION_BASE, erase_bytes, raw_bytes, payload_bytes, _sha256(source), expected_hash, program_data, erase_frame, packets)


def main(argv: Sequence[str] | None = None) -> int:
    """Read local artifacts and emit an offline JSON plan; never access hardware."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("image", type=Path, help="immutable raw, minimally aligned or padded release BIN")
    parser.add_argument("manifest", type=Path, help="trusted release manifest with raw length and padded SHA256")
    parser.add_argument("--payload-bytes", type=int, default=DEFAULT_PAYLOAD_BYTES)
    parser.add_argument("--erase-bytes", type=int, default=APPLICATION_BYTES)
    parser.add_argument("--output", type=Path, help="write JSON here instead of stdout (must not already exist)")
    parser.add_argument("--compact-output", type=Path, help="also create the minimally aligned program BIN; requires --output provenance JSON")
    args = parser.parse_args(argv)
    if args.compact_output and not args.output:
        parser.error("--compact-output requires --output to retain erase/provenance metadata")
    if args.compact_output and args.compact_output.resolve() == args.output.resolve():
        parser.error("compact BIN and provenance JSON destinations must differ")
    created = []
    try:
        plan = build_plan(args.image.read_bytes(), json.loads(args.manifest.read_text()), payload_bytes=args.payload_bytes, erase_bytes=args.erase_bytes)
        evidence = plan.as_dict()
        if args.compact_output:
            evidence["compact_artifact"] = {
                "name": args.compact_output.name,
                "bytes": len(plan.program_data),
                "sha256": _sha256(plan.program_data),
                "requires_erase_bytes": plan.erase_bytes,
                "warning": "Use the separate full erase extent before programming; BIN length is not erase length.",
            }
        output = json.dumps(evidence, indent=2) + "\n"
        if args.output:
            with args.output.open("x") as stream:
                created.append(args.output)
                if args.compact_output:
                    with args.compact_output.open("xb") as compact:
                        created.append(args.compact_output)
                        compact.write(plan.program_data)
                stream.write(output)
        else:
            sys.stdout.write(output)
    except (OSError, ValueError, TypeError) as error:
        for path in reversed(created):
            try:
                path.unlink()
            except OSError:
                pass
        parser.exit(2, f"flash plan rejected: {error}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
