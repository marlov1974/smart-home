#!/usr/bin/env python3
"""P0075: supervised application flash using a prepared Shelly Pro2 maintenance slot.

GPL-3.0-only. No live operation occurs on import or in the plan action. A physical
bootloader handoff is required for preflight/program. This tool never configures
Serial, changes relays, reboots, retries, resumes, or writes outside the explicit
application erase envelope. The compact BIN length is not the erase length.
"""
from __future__ import annotations

import argparse
import base64
import binascii
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import time
from typing import Callable
from urllib.request import Request, urlopen

from flash_plan import build_plan

SLOT = 8
DEFAULT_SLOT_NAME = 'P0075 write reference'
CORE_PATH = Path(__file__).resolve().parent / 'shelly' / 'flash_core.js'


class FlashError(RuntimeError):
    """A failed gate stops the session; it is never an automatic retry request."""


def require(condition, reason):
    if not condition:
        raise FlashError(reason)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def utc():
    return datetime.now(timezone.utc).isoformat()


class FlashSession:
    def __init__(self, *, host, device_id, image, manifest, out, slot=8,
                 slot_name=DEFAULT_SLOT_NAME, bootloader_confirmed=False,
                 transport: Callable | None = None, sleep=time.sleep,
                 monotonic=time.monotonic, core_path=CORE_PATH):
        require(type(slot) is int and slot == SLOT, 'ONLY_REVIEWED_SLOT_8_SUPPORTED')
        require(isinstance(host, str) and re.fullmatch(r'[A-Za-z0-9.-]{1,253}', host), 'HOST_FORMAT')
        require(isinstance(device_id, str) and re.fullmatch(r'shellypro2-[0-9a-fA-F]{12}', device_id), 'DEVICE_ID_FORMAT')
        require(isinstance(slot_name, str) and 0 < len(slot_name) <= 128, 'SLOT_NAME_FORMAT')
        self.host, self.device_id, self.slot_name = host, device_id, slot_name
        self.image_path, self.manifest_path, self.out = Path(image), Path(manifest), Path(out)
        self.confirmed = bootloader_confirmed is True
        self.sleep, self.monotonic = sleep, monotonic
        self.transport = transport or self._post
        image_data, manifest_data = self.image_path.read_bytes(), self.manifest_path.read_bytes()
        self.plan = build_plan(image_data, json.loads(manifest_data), payload_bytes=240)
        self.frames = tuple(packet.frame for packet in self.plan.packets)
        compact = {'erase_size': self.plan.erase_bytes, 'program_size': len(self.plan.program_data),
                   'page_size': self.plan.payload_bytes, 'crcs': [binascii.crc32(frame) for frame in self.frames]}
        self.source = 'let FLASH_MANIFEST=' + json.dumps(compact, separators=(',', ':')) + ';\n' + Path(core_path).read_text()
        require(self.source.isascii() and len(self.source) < 16000, 'REVIEWED_SOURCE_SIZE')
        self.provenance = {
            'host': host, 'device_id': device_id, 'slot': SLOT, 'slot_name': slot_name,
            'image_source_sha256': sha256(image_data), 'release_manifest_sha256': sha256(manifest_data),
            'envelope_sha256': self.plan.envelope_sha256,
            'program_sha256': sha256(self.plan.program_data),
            'erase_bytes': self.plan.erase_bytes, 'program_bytes': len(self.plan.program_data),
            'packet_count': len(self.frames), 'source_sha256': sha256(self.source.encode()),
        }

    def save(self, name, value):
        path = self.out / name
        path.write_text(json.dumps(value, indent=2) + '\n')
        path.chmod(0o600)

    def record(self, value):
        with (self.out / 'rpc.jsonl').open('a') as stream:
            stream.write(json.dumps({'timestamp': utc(), **value}) + '\n')

    def _post(self, method, params):
        body = {'id': 1, 'method': method, 'params': params}
        request = Request('http://' + self.host + '/rpc', data=json.dumps(body).encode(),
                          headers={'Content-Type': 'application/json'})
        with urlopen(request, timeout=10) as response:
            data = response.read(65537)
        require(len(data) <= 65536, 'RPC_RESPONSE_SIZE')
        reply = json.loads(data)
        require(isinstance(reply, dict) and reply.get('id') == 1, 'RPC_RESPONSE_ID')
        require('error' not in reply and 'result' in reply, 'RPC_ERROR: ' + str(reply.get('error')))
        return reply['result']

    def rpc(self, method, params=None):
        params = params or {}
        shown = dict(params)
        if 'code' in shown:
            shown['code'] = 'sha256:' + sha256(shown['code'].encode())
        self.record({'method': method, 'params': shown})
        try:
            result = self.transport(method, params)
        except BaseException as error:
            self.record({'method': method, 'error': str(error)})
            raise
        logged = result
        if method == 'Script.GetCode':
            logged = {**result, 'data': 'sha256:' + sha256(result['data'].encode())}
        self.record({'result': logged})
        return result

    def evaluate(self, code):
        return self.rpc('Script.Eval', {'id': SLOT, 'code': code})['result']

    def status(self):
        result = json.loads(self.evaluate('flashStatus()'))
        require(isinstance(result, dict), 'CORE_STATUS_TYPE')
        return result

    def identity(self, running):
        device = self.rpc('Shelly.GetDeviceInfo')
        require(device.get('id') == self.device_id and device.get('model') == 'SPSW-202XE12UL', 'TARGET_IDENTITY')
        serial = self.rpc('Serial.GetConfig', {'id': 100})
        require(serial.get('mode') == 'js_uart' and serial.get('serial') == {'baud': 115200, 'format': '8N1'}, 'SERIAL_DRIFT')
        scripts = self.rpc('Script.List')['scripts']
        own = [script for script in scripts if script.get('id') == SLOT]
        require(len(own) == 1 and own[0].get('name') == self.slot_name, 'MAINTENANCE_SLOT_IDENTITY')
        require(all(script.get('enable') is False and script.get('running') is (running and script.get('id') == SLOT)
                    for script in scripts), 'SCRIPT_EXCLUSIVITY')
        relays = [self.rpc('Switch.GetStatus', {'id': index})['output'] for index in (0, 1)]
        require(all(value is False for value in relays), 'RELAYS_NOT_OFF')
        return {'timestamp': utc(), 'device': device, 'serial': serial, 'scripts': scripts, 'relays': relays}

    def read_code(self):
        text = ''
        while True:
            result = self.rpc('Script.GetCode', {'id': SLOT, 'offset': len(text), 'len': 1024})
            text += result['data']
            require(len(text) < 18000, 'SCRIPT_READ_BOUND')
            if not result['left']:
                return text
            require(bool(result['data']), 'SCRIPT_READ_STALLED')

    def stage(self, page):
        frame = self.frames[page]
        for offset in range(0, len(frame), 512):
            data = base64.b64encode(frame[offset:offset + 512]).decode()
            result = self.evaluate('flashAppend(' + str(page) + ',' + str(offset) + ',' + json.dumps(data) + ')')
            if isinstance(result, str) and re.fullmatch(r'[0-9]+', result):
                result = int(result)
            require(type(result) in (int, float) and result == min(offset + 512, len(frame)), 'STAGING_LENGTH')
        state = self.status()
        self.save('page-%03d-staged.json' % page, state)
        require(state.get('staged_valid') is True and state.get('staged_bytes') == len(frame)
                and state.get('next_page') == page and not state.get('error'), 'STAGED_FRAME_GATE')
        require(state.get('staged_crc32') == binascii.crc32(frame), 'STAGED_FRAME_CRC')
        health = self.rpc('Script.GetStatus', {'id': SLOT})
        require(health.get('running') is True and not health.get('errors') and health.get('mem_free', 0) >= 4096, 'STAGING_HEALTH')
        return state, health

    def wait(self, expected, initial=0.2):
        self.sleep(initial)
        begin = self.monotonic()
        while True:
            state = self.status()
            require(not state.get('error'), 'CORE_ERROR: ' + json.dumps(state))
            if state.get('phase') in expected:
                return state
            require(state.get('phase') in ('sending', 'waiting'), 'UNEXPECTED_CORE_PHASE')
            require(self.monotonic() - begin <= 6, 'HOST_ACK_TIMEOUT')
            self.sleep(0.2)

    def stop(self):
        errors = []
        for method, params in (
            ('Script.Stop', {'id': SLOT}),
            ('Script.SetConfig', {'id': SLOT, 'config': {'enable': False}}),
        ):
            try:
                self.rpc(method, params)
            except Exception as error:
                errors.append({'method': method, 'error': str(error)})
        try:
            final = self.identity(False)
            final['cleanup_errors'] = errors
            self.save('final-state.json', final)
            return True
        except Exception as error:
            self.save('final-state.json', {'timestamp': utc(), 'state': 'STOP_UNVERIFIED',
                                          'cleanup_errors': errors, 'verification_error': str(error)})
            return False

    def prepare_directory(self):
        self.out.mkdir(mode=0o700, parents=False, exist_ok=False)
        self.save('manifest.json', self.plan.as_dict())
        self.save('provenance.json', self.provenance)

    def offline_plan(self):
        self.prepare_directory()
        compact = self.out / 'application.compact.bin'
        with compact.open('xb') as stream:
            stream.write(self.plan.program_data)
        compact.chmod(0o600)
        return {'phase': 'OFFLINE_PLAN_ONLY', 'out': str(self.out), **self.provenance}

    def preflight(self):
        require(self.confirmed, 'CURRENT_BOOTLOADER_CONFIRMATION_REQUIRED')
        self.prepare_directory()
        self.save('preflight.json', self.identity(False))
        self.save('authorization.json', {'timestamp': utc(), 'bootloader_confirmed': True,
                                        'scope': 'prepared slot8; full application erase then planned compact image only',
                                        **self.provenance})
        prior = self.out / 'prior-shelly-script.js'
        prior.write_text(self.read_code())
        prior.chmod(0o600)
        deployed = self.out / 'deployed.js'
        deployed.write_text(self.source)
        deployed.chmod(0o600)
        ready = False
        try:
            for offset in range(0, len(self.source), 1024):
                self.rpc('Script.PutCode', {'id': SLOT, 'code': self.source[offset:offset + 1024], 'append': offset != 0})
            require(self.read_code() == self.source, 'DEPLOY_READBACK_MISMATCH')
            self.rpc('Script.Start', {'id': SLOT})
            self.sleep(0.3)
            health = self.rpc('Script.GetStatus', {'id': SLOT})
            require(health.get('running') is True and not health.get('errors') and health.get('mem_free', 0) > 8192, 'START_HEALTH')
            require(self.status().get('phase') == 'idle', 'CORE_NOT_IDLE')
            self.evaluate('flashDiscover()')
            discovery = self.wait(('identified',))
            self.save('discovery.json', discovery)
            require(discovery.get('discovery'), 'DISCOVERY_NOT_VALIDATED')
            staged, health = self.stage(0)
            self.save('session.json', {'timestamp': utc(), 'phase': 'READY_NO_ERASE',
                                      'provenance': self.provenance, 'staged_first_frame': staged, 'health': health})
            ready = True
            return {'phase': 'READY_NO_ERASE', **self.provenance}
        finally:
            if not ready:
                self.stop()

    def program(self):
        require(self.confirmed, 'CURRENT_BOOTLOADER_CONFIRMATION_REQUIRED')
        state = json.loads((self.out / 'session.json').read_text())
        require(state.get('phase') == 'READY_NO_ERASE', 'SESSION_NOT_FRESH_NO_REPLAY')
        require(state.get('provenance') == self.provenance, 'SESSION_PROVENANCE_MISMATCH')
        require(json.loads((self.out / 'provenance.json').read_text()) == self.provenance, 'SAVED_PROVENANCE_MISMATCH')
        require((self.out / 'deployed.js').read_text() == self.source, 'SAVED_SOURCE_MISMATCH')
        state.update(phase='PROGRAM_VALIDATION', timestamp=utc())
        self.save('session.json', state)
        history, complete, cleanup_allowed, cleanup_verified = [], False, False, False
        try:
            self.identity(True)
            cleanup_allowed = True
            require(self.read_code() == self.source, 'RUNNING_SOURCE_MISMATCH')
            current = self.status()
            require(current.get('phase') == 'identified' and current.get('discovery') and not current.get('erased')
                    and current.get('staged_valid') is True and current.get('next_page') == 0
                    and current.get('staged_crc32') == binascii.crc32(self.frames[0]), 'PRE_ERASE_CORE_GATE')
            state.update(phase='ERASE_REQUESTED', timestamp=utc())
            self.save('session.json', state)
            self.save('erase-intent.json', {'timestamp': utc(), 'tx_hex': self.plan.erase_frame.hex(),
                                           'relative_offset': 0, 'length': self.plan.erase_bytes})
            self.evaluate('flashErase()')
            result = self.wait(('erased',))
            self.save('erase-result.json', result)
            require(base64.b64decode(result['base64'], validate=True) == b'\x71', 'ERASE_DIRECT_ACK_REQUIRED')
            state.update(phase='PROGRAMMING', erase_ack='71')
            self.save('session.json', state)
            for page, packet in enumerate(self.plan.packets):
                if page:
                    self.stage(page)
                self.sleep(0.5)
                self.save('page-%03d-intent.json' % page, {'timestamp': utc(), 'page': page,
                          'offset': packet.offset, 'tx_length': len(packet.frame), 'sha256': sha256(packet.frame),
                          'program_sha256': self.provenance['program_sha256']})
                self.evaluate('flashProgram(' + str(page) + ')')
                result = self.wait(('page_ok', 'complete'), initial=0.1)
                self.save('page-%03d-result.json' % page, result)
                expected_phase = 'complete' if page + 1 == len(self.frames) else 'page_ok'
                require(base64.b64decode(result['base64'], validate=True) == b'\x73'
                        and result.get('sent') == len(packet.frame) and result.get('next_page') == page + 1
                        and result.get('phase') == expected_phase, 'WRITE_DIRECT_ACK_REQUIRED')
                progress = {'timestamp': utc(), 'page': page + 1, 'pages': len(self.frames),
                            'accepted_image_bytes': packet.offset + len(packet.payload), 'ack': '73',
                            'tx_elapsed_ms': result.get('tx_elapsed_ms'), 'first_rx_ms': result.get('first_rx_ms')}
                history.append(progress)
                state['progress'] = history
                self.save('session.json', state)
            final = self.status()
            require(final.get('phase') == 'complete' and final.get('next_page') == len(self.frames)
                    and not final.get('error'), 'FINAL_TRANSFER_GATE')
            complete = True
            state.update(phase='TRANSFER_ACKNOWLEDGED_AWAIT_NORMAL_BOOT', timestamp=utc())
            self.save('session.json', state)
        except BaseException as error:
            if cleanup_allowed:
                try:
                    self.save('error-device-state.json', self.status())
                except Exception:
                    pass
            state.update(phase='STOPPED_INCOMPLETE', timestamp=utc(), error=str(error), progress=history)
            self.save('session.json', state)
            raise
        finally:
            if cleanup_allowed:
                cleanup_verified = self.stop()
            self.save('outcome.json', {'timestamp': utc(), 'transfer_acknowledged': complete,
                      'provenance': self.provenance, 'pages_with_direct_ack': len(history),
                      'image_bytes_acknowledged': history[-1]['accepted_image_bytes'] if history else 0,
                      'cleanup_verified': cleanup_verified, 'readback_verified': False, 'normal_boot_verified': False})
        require(cleanup_verified, 'TRANSFER_COMPLETE_CLEANUP_UNVERIFIED')
        return json.loads((self.out / 'outcome.json').read_text())


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('plan', 'preflight', 'program'))
    parser.add_argument('--host', required=True)
    parser.add_argument('--device-id', required=True)
    parser.add_argument('--image', type=Path, required=True)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--slot', type=int, default=SLOT)
    parser.add_argument('--slot-name', default=DEFAULT_SLOT_NAME)
    parser.add_argument('--bootloader-confirmed', action='store_true')
    args = parser.parse_args(argv)
    if args.action != 'plan' and not args.bootloader_confirmed:
        parser.error('live actions require a fresh physical bootloader handoff and --bootloader-confirmed')
    try:
        session = FlashSession(host=args.host, device_id=args.device_id, image=args.image,
                               manifest=args.manifest, out=args.out, slot=args.slot,
                               slot_name=args.slot_name, bootloader_confirmed=args.bootloader_confirmed)
        result = session.offline_plan() if args.action == 'plan' else getattr(session, args.action)()
        print(json.dumps(result, indent=2))
    except (OSError, ValueError, FlashError) as error:
        parser.exit(2, 'flash session stopped: ' + str(error) + '\n')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
