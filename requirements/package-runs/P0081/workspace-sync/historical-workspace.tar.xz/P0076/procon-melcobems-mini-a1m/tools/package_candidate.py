"""P0076: package own compact artifacts and source hashes; never flashes or publishes."""
import argparse, hashlib, json, re, shutil, subprocess
from pathlib import Path
from flash_plan import build_plan
ROOT = Path(__file__).resolve().parents[1]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT/'build/P0076-effect-pause-r2')
    parser.add_argument('--objcopy',required=True)
    args=parser.parse_args()
    dst=args.output.resolve()
    if dst.exists():
        raise SystemExit('Candidate directory already exists; select a new output to preserve it')
    image=ROOT/'build/procon-mvp.bin'
    metadata=json.loads(image.with_suffix('.json').read_text())
    plan=build_plan(image.read_bytes(),metadata)
    dst.mkdir(parents=True)
    for suffix in ('bin','elf','map','disasm.txt','json'):
        shutil.copy2(ROOT/('build/procon-mvp.'+suffix),dst/('procon-p76.'+suffix))
    subprocess.run([args.objcopy,'--strip-debug',str(dst/'procon-p76.elf')],check=True)
    path=dst/'procon-p76.map'
    text=path.read_text().replace(str(ROOT)+'/', '')
    text=re.sub(r'/(?:private/)?(?:var|tmp)/[^\s()]+','<temporary-object>',text)
    path.write_text(text)
    paths=[]
    for folder in ('firmware','tools','tests'):
        paths.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
    paths.append(ROOT/'Makefile')
    source={str(p.relative_to(ROOT)):digest(p) for p in sorted(paths)}
    encoded=json.dumps(source,sort_keys=True,separators=(',',':')).encode()
    (dst/'SOURCE.json').write_text(json.dumps({'package':'P0076','revision':metadata['revision'],'status':'offline-verified-candidate-hardware-pending','license':'GPL-3.0-only','source_files':source,'source_manifest_sha256':hashlib.sha256(encoded).hexdigest(),'toolchain':'Arm GNU 14.3.Rel1','vendor_artifacts_included':False},indent=2)+'\n')
    (dst/'FLASH_PLAN.json').write_text(json.dumps(plan.as_dict(),indent=2)+'\n')
    (dst/'README.txt').write_text('P0076 r2 EFFECT native-pause handling + DIP addressing; hardware validation pending.\nOne compact BIN for both units. Address comes from DIP at startup.\nProgram only compact BIN after separate full98304-byte application erase.\nNever erase/write the resident bootloader. Physical provisioning needs operator handoff.\nRAM-only restore is not safe for unattended control after reset.\n')
    for artifact in dst.iterdir():
        content=artifact.read_bytes()
        assert str(ROOT).encode() not in content, 'Build root leaked into artifact'
        assert not re.search(rb'/(?:Users|home|private/tmp|var/folders)/[^\s\x00]+',content), 'Host path in artifact'
    (dst/'SHA256SUMS').write_text(''.join(digest(p)+'  '+p.name+'\n' for p in sorted(dst.iterdir())))
    print(json.dumps({'candidate':str(dst),'bytes':len(image.read_bytes()),'sha256':digest(image),'frames':len(plan.packets)},indent=2))

if __name__=='__main__':
    main()
