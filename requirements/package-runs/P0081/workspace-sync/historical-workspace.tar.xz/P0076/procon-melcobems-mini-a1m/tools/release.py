"""Generate only this project's artifacts after deterministic rebuild.
SPDX-License-Identifier: GPL-3.0-only
"""
import argparse, hashlib, json, shutil, subprocess, re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--check-only',action='store_true');a=p.parse_args()
    original=(ROOT/'build/procon-mvp.bin').read_bytes()
    subprocess.run(['make','-B','all'],cwd=ROOT,check=True)
    assert (ROOT/'build/procon-mvp.bin').read_bytes()==original, 'Non-deterministic BIN'
    print('PASS deterministic BIN',hashlib.sha256(original).hexdigest())
    if a.check_only:return
    if subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip():raise SystemExit('Commit clean source before release')
    dst=ROOT/'release';dst.mkdir(exist_ok=True)
    for ext in ('bin','elf','map','disasm.txt','json'):
        shutil.copy2(ROOT/('build/procon-mvp.'+ext),dst/('procon-mvp.'+ext))
    # Release ELF needs symbols/sections, not host-specific DWARF paths.
    subprocess.run([str(ROOT/'.local/toolchain/bin/arm-none-eabi-objcopy'), '--strip-debug', str(dst/'procon-mvp.elf')],check=True)
    map_path=dst/'procon-mvp.map'
    map_text=map_path.read_text().replace(str(ROOT)+'/', '')
    map_text=re.sub(r'/(?:private/)?(?:var|tmp)/[^\s()]+', '<temporary-object>', map_text)
    map_path.write_text(map_text)
    for artifact in dst.glob('procon-mvp.*'):
        content=artifact.read_bytes()
        assert str(ROOT).encode() not in content, 'Build root leaked into release'
        assert not re.search(rb'/(?:Users|home|private/tmp|var/folders)/[^\s\x00]+',content), 'Host path in release'
    meta={'source_commit' :subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'status':'P0076 EFFECT/DIP hardware validation pending','license':'GPL-3.0-only','toolchain':'Arm GNU 14.3.Rel1','vendor_artifacts_included':False}
    (dst/'SOURCE.json').write_text(json.dumps(meta,indent=2)+'\n')
    (dst/'SHA256SUMS').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.name+'\n' for f in sorted(dst.iterdir()) if f.name!='SHA256SUMS'))
if __name__=='__main__':main()
