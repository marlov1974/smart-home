/* P0075 bounded delayed discovery experiment. GPL-3.0-only.
 * Only standalone 5A or separately sent 40/57 then 5A. No parameter payloads.
 * Send timestamps are bridge call times, not independent wire measurements.
 */
function makeDelayProbeCore(io) {
  let seq=0,epoch=0,state='idle',halt=false,done=false,error='';
  let prefix=null,gap=0,start=-1,prefixAt=-1,prefixEnd=-1,tailAt=-1,tailEnd=-1;
  let firstRx=-1,lastRx=-1,raw='',received=0,sent=0,events=[],sendBusy=false;
  let lastNow=io.now();
  if(typeof lastNow!=='number'||lastNow<0||lastNow-lastNow!==0)throw new Error('CLOCK_CONFIG');
  function fail(why){if(!halt){state=why;error=why;halt=true;done=true;epoch++;}}
  function now(){
    let n;
    try{n=io.now();}catch(e){fail('CLOCK_ERROR');return lastNow;}
    if(typeof n!=='number'||n<lastNow||n-n!==0){fail('CLOCK_ERROR');return lastNow;}
    lastNow=n;return n;
  }
  function finish(n){
    if(halt||state!=='waiting_response'||n<tailAt+3000)return;
    if(lastRx>=tailAt+2800){fail('RX_STILL_ACTIVE');return;}
    state=received?'response':'no_response';done=true;
  }
  function snapshot(){
    let origin=prefixAt>=0?prefixAt:tailAt;
    let copied=[];for(let i=0;i<events.length;i++)copied.push({at_ms:events[i].at_ms,bytes:events[i].bytes});
    return {seq:seq,prefix:prefix,gap_requested_ms:gap,start_ms:start,
      prefix_send_at_ms:prefixAt,prefix_send_end_ms:prefixEnd,tail_send_at_ms:tailAt,tail_send_end_ms:tailEnd,
      actual_gap_ms:prefixAt<0||tailAt<0?-1:tailAt-prefixAt,
      first_rx_ms:firstRx<0||origin<0?-1:firstRx-origin,first_rx_after_tail_ms:firstRx<0||tailAt<0?-1:firstRx-tailAt,
      first_rx_at_ms:firstRx,last_rx_at_ms:lastRx,rx_events:copied,sent:sent,received:received,
      raw:raw,state:state,done:done,halt:halt,error:error};
  }
  function result(){let n=now();finish(n);return snapshot();}
  function schedule(ms,fn,e){
    if(halt)return;
    try{io.schedule(ms,function(){if(e!==epoch||halt)return;fn();});}catch(x){fail('SCHEDULE_ERROR');}
  }
  function sendByte(byte,isTail){
    let n=now();if(halt)return;
    if(isTail)tailAt=n;else prefixAt=n;
    sendBusy=true;let accepted,threw=false;
    try{accepted=io.send(String.fromCharCode(byte));}catch(e){threw=true;}
    sendBusy=false;n=now();
    if(isTail)tailEnd=n;else prefixEnd=n;
    if(accepted===1)sent++;
    if(threw){fail('SEND_ERROR');return;}
    if(accepted!==1){fail(accepted===0?'PARTIAL_SEND':'SEND_ERROR');return;}
  }
  function tail(e){
    if(e!==epoch||halt||state!=='waiting_prefix_gap')return;
    let n=now();if(halt)return;
    if(n<prefixAt+gap){fail('EARLY_TIMER');return;}
    state='waiting_response';sendByte(0x5A,true);if(halt)return;
    let delay=tailAt+3000-now();if(halt)return;
    if(delay<=0){finish(lastNow);return;}
    schedule(delay,function(){let n=now();if(halt)return;if(n<tailAt+3000){fail('EARLY_TIMER');return;}finish(n);},e);
  }
  function begin(index,requestedGap){
    if(index!==-1&&index!==0&&index!==1)throw new Error('PREFIX');
    if(typeof requestedGap!=='number'||requestedGap%1!==0||requestedGap<0||requestedGap>5000)throw new Error('GAP');
    if(index===-1&&requestedGap!==0)throw new Error('BASELINE_GAP');
    let n=now();finish(n);
    if(halt)throw new Error('HALTED');
    if(state==='waiting_prefix_gap'||state==='waiting_response')throw new Error('BUSY');
    if(seq>=100)throw new Error('TRANSACTION_LIMIT');
    seq++;epoch++;let e=epoch;prefix=index<0?null:(index===0?0x40:0x57);gap=requestedGap;start=n;
    prefixAt=-1;prefixEnd=-1;tailAt=-1;tailEnd=-1;firstRx=-1;lastRx=-1;
    raw='';received=0;sent=0;events=[];done=false;error='';
    if(index===-1){
      state='waiting_response';sendByte(0x5A,true);
      if(!halt){let delay=tailAt+3000-now();if(!halt){if(delay<=0)finish(lastNow);else schedule(delay,function(){let n=now();if(halt)return;if(n<tailAt+3000){fail('EARLY_TIMER');return;}finish(n);},e);}}
    }else{
      state='waiting_prefix_gap';sendByte(prefix,false);
      if(!halt){let remaining=prefixAt+gap-now();if(!halt){if(remaining<=0)tail(e);else schedule(remaining,function(){tail(e);},e);}}
    }
    return snapshot();
  }
  function receive(data){
    if(data==='')return;
    if(typeof data!=='string'){fail('RX_TYPE');return;}
    let n=now();if(halt&&error==='CLOCK_ERROR')return;
    received+=data.length;if(firstRx<0)firstRx=n;lastRx=n;
    if(events.length<128)events.push({at_ms:n,bytes:data.length});
    for(let i=0;i<data.length;i++)if(data.charCodeAt(i)>255){fail('NON_BINARY_RX');return;}
    raw+=data.slice(0,128-raw.length);
    if(received>128){fail('RX_OVERFLOW');return;}
    if(halt)return;
    if(state==='waiting_prefix_gap'||(prefix!==null&&tailAt<0)){fail('PRE_TAIL_RX');return;}
    if(state!=='waiting_response'||tailAt<0||n>=tailAt+3000){fail('LATE_RX');return;}
    if(sendBusy)fail('RX_DURING_SEND');
  }
  function stop(){now();fail('STOPPED');return snapshot();}
  return {begin:begin,receive:receive,result:result,stop:stop};
}

let p75DelayCore=null;
function p75DelayJSON(value){value.base64=btoa(value.raw);delete value.raw;return JSON.stringify(value);}
function probe(prefix,gap){if(!p75DelayCore)throw new Error('ADAPTER_UNAVAILABLE');return p75DelayJSON(p75DelayCore.begin(prefix,gap));}
function result(){if(!p75DelayCore)throw new Error('ADAPTER_UNAVAILABLE');return p75DelayJSON(p75DelayCore.result());}
function stopProbe(){if(!p75DelayCore)throw new Error('ADAPTER_UNAVAILABLE');return p75DelayJSON(p75DelayCore.stop());}
if(typeof UART!=='undefined'&&typeof Shelly!=='undefined'&&typeof Timer!=='undefined'){
  let p75DelayUart=UART.get(0);if(!p75DelayUart)throw new Error('UART_UNAVAILABLE');
  p75DelayCore=makeDelayProbeCore({now:function(){return Shelly.getUptimeMs();},
    send:function(bytes){return p75DelayUart.send(bytes);},schedule:function(ms,fn){return Timer.set(ms,false,fn);}});
  p75DelayUart.recv(function(bytes){p75DelayCore.receive(bytes);});
  // Keep native Script.Eval functions available while awaiting an explicit probe.
  Timer.set(1000,true,function(){});
}
