/* P0075: bounded application updater. No arbitrary frames or absolute addresses.
 * The host pins provenance; each complete wire frame is validated before TX.
 * Physical compact-transfer validation is separate from these offline checks.
 */
function makeFlashCore(io, manifest) {
  if (!manifest || manifest.erase_size !== 98304 || manifest.page_size !== 240 ||
      typeof manifest.program_size !== 'number' || manifest.program_size % 8 !== 0 ||
      manifest.program_size < 8 || manifest.program_size > manifest.erase_size ||
      !manifest.crcs || manifest.crcs.length !== Math.ceil(manifest.program_size / 240))
    throw new Error('MANIFEST');
  let eraseSize = manifest.erase_size, programSize = manifest.program_size;
  let pageCount = manifest.crcs.length, frameCRCs = [];
  for (let i = 0; i < pageCount; i++) {
    let value = manifest.crcs[i];
    if (typeof value !== 'number' || value % 1 !== 0 || value < 0 || value > 4294967295)
      throw new Error('MANIFEST_CRC');
    frameCRCs.push(value);
  }
  let phase = 'idle', error = '', raw = '', received = 0, sent = 0;
  let started = -1, first = -1, txDone = -1, discovery = false, erased = false;
  let next = 0, staged = '', stagedCRC = 0, tx = '', txOffset = 0;
  let txKind = '', deadline = 0, requestId = 0, discoveryRaw = '', pendingPump = false;
  let lastService = -1;
  let crcNibble = [0x00000000, 0x1db71064, 0x3b6e20c8, 0x26d930ac,
    0x76dc4190, 0x6b6b51f4, 0x4db26158, 0x5005713c, 0xedb88320,
    0xf00f9344, 0xd6d6a3e8, 0xcb61b38c, 0x9b64c2b0, 0x86d3d2d4,
    0xa00ae278, 0xbdbdf21c];
  function newStats() {
    return {send_calls: 0, requested_bytes: 0, accepted_bytes: 0,
      zero_accepts: 0, partial_accepts: 0, min_requested: -1, max_requested: 0,
      min_accepted: -1, max_accepted: 0, service_calls: 0,
      min_service_interval_ms: -1, max_service_interval_ms: 0};
  }
  // Shelly evaluates local function declarations in order, without hoisting.
  let stats = newStats();
  function fail(reason) {
    if (!error) error = reason;
    phase = 'fault'; pendingPump = false;
  }
  function crc32(data) {
    let value = 0xffffffff;
    for (let i = 0; i < data.length; i++) {
      value = value ^ data.charCodeAt(i);
      value = (value >>> 4) ^ crcNibble[value & 15];
      value = (value >>> 4) ^ crcNibble[value & 15];
    }
    return (value ^ 0xffffffff) >>> 0;
  }
  function le(data, at, count) {
    let value = 0, factor = 1;
    for (let i = 0; i < count; i++) {value += data.charCodeAt(at + i) * factor; factor *= 256;}
    return value;
  }
  function payloadLength() {return next >= pageCount ? 0 : Math.min(240, programSize - next * 240);}
  function pageLength() {return next >= pageCount ? 0 : payloadLength() + 12;}
  function stageValid() {return next < pageCount && staged.length === pageLength() && stagedCRC === frameCRCs[next];}
  function checkDeadline() {
    if ((phase === 'sending' || phase === 'waiting') && io.now() > deadline)
      fail(phase === 'sending' ? 'TX_DEADLINE' : 'ACK_TIMEOUT');
  }
  function status() {
    checkDeadline();
    return {phase: phase, error: error, request_id: requestId, next_page: next,
      page_count: pageCount, erase_size: eraseSize, program_size: programSize,
      staged_bytes: staged.length, staged_crc32: stagedCRC, staged_valid: stageValid(),
      discovery: discovery, erased: erased, sent: sent, received: received, raw: raw,
      started_ms: started, tx_done_ms: txDone, first_rx_ms: first < 0 ? -1 : first - started,
      tx_elapsed_ms: txDone < 0 ? -1 : txDone - started, kind: txKind,
      discovery_raw: discoveryRaw, pending_pump: pendingPump,
      tx_stats: {send_calls: stats.send_calls, requested_bytes: stats.requested_bytes,
        accepted_bytes: stats.accepted_bytes, zero_accepts: stats.zero_accepts,
        partial_accepts: stats.partial_accepts, min_requested: stats.min_requested,
        max_requested: stats.max_requested, min_accepted: stats.min_accepted,
        max_accepted: stats.max_accepted, service_calls: stats.service_calls,
        min_service_interval_ms: stats.min_service_interval_ms,
        max_service_interval_ms: stats.max_service_interval_ms}};
  }
  function append(page, offset, part) {
    checkDeadline();
    if (error || phase === 'sending' || phase === 'waiting' || next >= pageCount ||
        page !== next || offset !== 0 || staged.length !== 0 || typeof part !== 'string')
      throw new Error('STAGE');
    if (part.length !== pageLength() || part.length > 252) throw new Error('STAGE_LENGTH');
    for (let i = 0; i < part.length; i++) if (part.charCodeAt(i) > 255) throw new Error('BINARY');
    let payload = payloadLength(), sum = 0;
    for (let i = 0; i < part.length - 1; i++) sum += part.charCodeAt(i);
    if (part.charCodeAt(0) !== 0x53 || le(part, 1, 2) !== payload ||
        le(part, 3, 4) !== next * 240 || le(part, 7 + payload, 4) !== crc32(part.slice(0, 7 + payload)) ||
        part.charCodeAt(part.length - 1) !== (sum & 255)) {
      fail('STAGED_FRAME'); throw new Error('STAGED_FRAME');
    }
    stagedCRC = crc32(part);
    if (stagedCRC !== frameCRCs[next]) {fail('STAGED_CRC'); throw new Error('STAGED_CRC');}
    staged = part;
    return staged.length;
  }
  function start(kind, data) {
    checkDeadline();
    if (error || phase === 'sending' || phase === 'waiting') throw new Error('BUSY');
    requestId++; raw = ''; received = 0; sent = 0; first = -1; txDone = -1;
    started = io.now(); deadline = started + 1200; lastService = started; stats = newStats();
    txKind = kind; tx = data; txOffset = 0; pendingPump = false; phase = 'sending';
    pump(); return requestId;
  }
  function pump() {
    if (phase !== 'sending') return;
    checkDeadline(); if (error) return;
    let remaining = tx.slice(txOffset), accepted;
    stats.send_calls++; stats.requested_bytes += remaining.length;
    if (stats.min_requested < 0 || remaining.length < stats.min_requested) stats.min_requested = remaining.length;
    if (remaining.length > stats.max_requested) stats.max_requested = remaining.length;
    try {accepted = io.send(remaining);} catch (e) {fail('TX_ERROR'); return;}
    if (typeof accepted !== 'number' || accepted % 1 !== 0 || accepted < 0 || accepted > remaining.length) {
      fail('TX_RESULT'); return;
    }
    stats.accepted_bytes += accepted;
    if (accepted === 0) stats.zero_accepts++;
    else if (accepted < remaining.length) stats.partial_accepts++;
    if (stats.min_accepted < 0 || accepted < stats.min_accepted) stats.min_accepted = accepted;
    if (accepted > stats.max_accepted) stats.max_accepted = accepted;
    sent += accepted; txOffset += accepted;
    if (error || phase !== 'sending') return;
    checkDeadline(); if (error) return;
    if (txOffset === tx.length) {
      txDone = io.now(); phase = 'waiting'; deadline = txDone + 3500; pendingPump = false;
    } else pendingPump = true;
  }
  function receive(data) {
    if (typeof data !== 'string') {fail('RX_TYPE'); return;}
    if (!data) return;
    checkDeadline(); received += data.length;
    if (first < 0) first = io.now();
    raw += data.slice(0, 64 - raw.length);
    if (error) return;
    if (received > 64) {fail('RX_OVERFLOW'); return;}
    if (phase !== 'waiting') {fail('UNEXPECTED_RX'); return;}
    if (txKind === 'discover') {
      if (raw.charCodeAt(0) !== 0x7a || raw.length > 12) {fail('DISCOVERY_FRAME'); return;}
      if (raw.length < 12) return;
      let sum = 0; for (let i = 0; i < 11; i++) sum += raw.charCodeAt(i);
      if ((sum & 255) !== raw.charCodeAt(11)) {fail('DISCOVERY_SUM'); return;}
      if (le(raw, 1, 4) < eraseSize || le(raw, 7, 2) !== 2048 || le(raw, 9, 2) !== 8192) {
        fail('DISCOVERY_CAPACITY'); return;
      }
      discoveryRaw = raw; discovery = true; phase = 'identified'; return;
    }
    if (raw.length !== 1) {fail('ACK_LENGTH'); return;}
    let ack = raw.charCodeAt(0);
    if (txKind === 'erase') {
      if (ack !== 0x71) {fail('ERASE_ACK_' + ack); return;}
      erased = true; phase = 'erased'; return;
    }
    if (txKind === 'page') {
      if (ack !== 0x73) {fail('WRITE_ACK_' + ack); return;}
      next++; staged = ''; stagedCRC = 0; tx = '';
      phase = next === pageCount ? 'complete' : 'page_ok'; return;
    }
    fail('KIND');
  }
  function tick() {
    if (phase !== 'sending' && phase !== 'waiting') return;
    let now = io.now(), gap = now - lastService;
    stats.service_calls++;
    if (stats.min_service_interval_ms < 0 || gap < stats.min_service_interval_ms) stats.min_service_interval_ms = gap;
    if (gap > stats.max_service_interval_ms) stats.max_service_interval_ms = gap;
    lastService = now;
    checkDeadline();
    if (phase === 'sending' && pendingPump) {pendingPump = false; pump();}
  }
  function discover() {
    if (erased || next !== 0) throw new Error('DISCOVERY_ORDER');
    return start('discover', '\x5a');
  }
  function erase() {
    if (!discovery || erased || next !== 0 || !stageValid()) throw new Error('ERASE_GATE');
    return start('erase', '\x51\x00\x00\x00\x00\x00\x80\x01\x00\xd2');
  }
  function program(page) {
    if (!erased || page !== next || !stageValid()) throw new Error('PAGE_GATE');
    return start('page', staged);
  }
  return {append: append, status: status, receive: receive, tick: tick,
    discover: discover, erase: erase, program: program};
}

let flashUart, flashCore;
function flashAppend(page, offset, base64) {return flashCore.append(page, offset, atob(base64));}
function flashStatus() {
  let result = flashCore.status();
  result.base64 = btoa(result.raw); result.raw = '';
  result.discovery_base64 = btoa(result.discovery_raw); result.discovery_raw = '';
  return JSON.stringify(result);
}
function flashDiscover() {return flashCore.discover();}
function flashErase() {return flashCore.erase();}
function flashProgram(page) {return flashCore.program(page);}
function flashService() {flashCore.tick();}
function flashExpire() {Shelly.call('Script.Stop', {id: 8});}
if (typeof FLASH_MANIFEST !== 'undefined') {
  flashUart = UART.get(0); if (!flashUart) throw new Error('UART');
  flashCore = makeFlashCore({now: function() {return Shelly.getUptimeMs();},
    send: function(bytes) {return flashUart.send(bytes);}}, FLASH_MANIFEST);
  flashUart.recv(function(bytes) {flashCore.receive(bytes);});
  Timer.set(20, true, flashService);
  Timer.set(1800000, false, flashExpire);
}
