/* Explicitly authorized PURE 00..FF sweep. GPL-3.0-only.
 * NOT READ-ONLY: unknown opcodes may erase/program/reset/persist. No recovery
 * guarantee; silence does not prove unsupported. No helper UART traffic.
 */
function makeOpcodeSweepCore(io, session, token) {
  if(typeof session!=='string'||!session||typeof token!=='string'||token.length<32)throw new Error('AUTH_CONFIG');
  let seq=0,opcode=-1,nextOpcode=0,state='idle',halt=false,raw='',received=0,by1700=0,callbacks=0,sent=0;
  let startAt=-1,firstAt=-1,lastRx=-1,rxAt=[],sendBusy=false,error='',lastNow=io.now(),lastContact=lastNow;
  if(typeof lastNow!=='number'||lastNow<0||lastNow-lastNow!==0)throw new Error('CLOCK_CONFIG');
  function fail(why){state=why;error=why;halt=true;}
  function now(){let n=io.now();if(typeof n!=='number'||n<lastNow||n-n!==0){fail('CLOCK');return lastNow;}lastNow=n;return n;}
  function result(){return {seq:seq,op:seq?'probe':'idle',opcode:opcode,next_opcode:nextOpcode,state:state,halt:halt,
    raw:raw,sent:sent,received:received,received_by_1700:by1700,callbacks:callbacks,start_at_ms:startAt,
    first_rx_at_ms:firstAt,first_rx_ms:firstAt<0?-1:firstAt-startAt,last_rx_at_ms:lastRx,rx_at_ms:rxAt.slice(),
    sweep_complete:nextOpcode===256&&state!=='waiting'&&!halt,error:error,interpretation:'unvalidated_opcode_response'};}
  function tick(){
    let n=now();if(halt)return;
    if(n-lastContact>=(seq===0?900000:120000)){fail('SESSION_EXPIRED');return;}
    if(state==='waiting'&&n-startAt>=3000){
      if(lastRx>=0&&lastRx>startAt+2800){fail('RX_STILL_ACTIVE');return;}
      state=raw.length?'probe_response':'no_response';
    }
  }
  function receive(data){
    if(data==='')return;
    let n=now();if(typeof data!=='string'){fail('RX_TYPE');return;}
    callbacks++;received+=data.length;if(firstAt<0)firstAt=n;lastRx=n;if(rxAt.length<128)rxAt.push(n);
    if(startAt>=0&&n-startAt<=1700)by1700+=data.length;
    for(let i=0;i<data.length;i++)if(data.charCodeAt(i)>255){fail('NON_BINARY_RX');return;}
    raw+=data.slice(0,128-raw.length);
    if(received>128){fail('RX_OVERFLOW');return;}
    if(halt||state!=='waiting'||n-startAt>=3000){fail('LATE_RX');return;}
    if(sendBusy)fail('RX_DURING_SEND');
  }
  function request(s,t,n,action,idx){
    if(s!==session||t!==token)throw new Error('UNAUTHORIZED');
    if(typeof n!=='number'||n%1!==0||n<0||n>256)throw new Error('SEQUENCE');
    if(action!=='probe'&&action!=='status'&&action!=='stop')throw new Error('OPERATION');
    if(action==='status'||action==='stop'){
      if(n!==seq||idx!==undefined)throw new Error('STATUS_ARGUMENTS');
      if(action==='stop')fail('STOPPED');else tick();lastContact=lastNow;return result();
    }
    if(typeof idx!=='number'||idx%1!==0||idx<0||idx>255||n!==idx+1)throw new Error('OPCODE_OR_SEQUENCE');
    if(n===seq){if(idx!==opcode)throw new Error('SEQUENCE_REUSE');tick();lastContact=lastNow;return result();}
    tick();if(halt)throw new Error('HALTED');
    if(n!==seq+1||idx!==nextOpcode||state==='waiting')throw new Error('BUSY_OR_ORDER');
    let started=now();if(halt)throw new Error('CLOCK');
    seq=n;opcode=idx;nextOpcode++;raw='';received=0;by1700=0;callbacks=0;sent=0;firstAt=-1;lastRx=-1;rxAt=[];error='';
    startAt=started;lastContact=started;state='waiting';sendBusy=true;
    let accepted;
    try{accepted=io.send(String.fromCharCode(opcode));}catch(e){sendBusy=false;fail('SEND_ERROR');return result();}
    sendBusy=false;
    if(typeof accepted!=='number'||accepted!==1){if(accepted===0)fail('PARTIAL_SEND');else fail('SEND_ERROR');}
    else sent=1;
    return result();
  }
  return {request:request,receive:receive,tick:tick};
}

if(typeof P75_SWEEP_SESSION!=='undefined'&&typeof P75_SWEEP_TOKEN!=='undefined'){
  let swUart=UART.get(0);if(!swUart)throw new Error('UART_UNAVAILABLE');
  let swCore=makeOpcodeSweepCore({now:function(){return Shelly.getUptimeMs();},send:function(b){return swUart.send(b);}},P75_SWEEP_SESSION,P75_SWEEP_TOKEN);
  swUart.recv(function(b){swCore.receive(b);});Timer.set(50,true,function(){swCore.tick();});
  HTTPServer.registerEndpoint('opcode_sweep',function(req,res){
    res.headers=[['Content-Type','application/json'],['Cache-Control','no-store']];res.code=400;res.body='{"error":"REQUEST"}';
    try{
      if(req.method==='POST'&&typeof req.body==='string'&&req.body.length<=512){
        let q=JSON.parse(req.body);
        if(!q||q.session!==P75_SWEEP_SESSION||q.token!==P75_SWEEP_TOKEN){res.code=403;res.body='{"error":"AUTH"}';}
        else{
          let unknown=false;for(let k in q)if(k!=='session'&&k!=='token'&&k!=='seq'&&k!=='op'&&k!=='opcode')unknown=true;
          if(unknown)throw new Error('FIELDS');
          let r=swCore.request(q.session,q.token,q.seq,q.op,q.opcode);r.base64=btoa(r.raw);r.raw='';res.code=200;res.body=JSON.stringify(r);
        }
      }
    }catch(e){res.code=400;res.body='{"error":"REJECTED"}';}res.send();
  });
}
