/* Bounded declared-read-opcode / cached-ACK comparison. GPL-3.0-only.
 * Fixed 57 read-flash hypotheses plus declared 59 read-EEPROM and A0 status.
 * Enum declarations do not prove device support or complete request formats.
 * No erase/program commands, unknown-opcode sweep, or arbitrary frames.
 * io.now() is monotonic milliseconds, io.send() returns accepted byte count.
 */
function makeReadAckReferenceCore(io, session, token) {
  if(typeof session!=='string'||!session||typeof token!=='string'||token.length<32)throw new Error('AUTH_CONFIG');
  let frames=['\x57','\x57\x10\x00\x00\x80\x00\x08\xef','\x57\x10\x00\x00\x80\x00\x08\x6e\x99\x26\x97\xb3','\x59','\xa0'];
  let seq=0,op='idle',index=-1,signature='',state='idle',halt=false,gate=false,paired=false;
  let raw='',received=0,callbacks=0,sent=0,startAt=-1,firstAt=-1,rxAt=[],sendBusy=false,error='';
  let lastNow=io.now();
  if(typeof lastNow!=='number'||lastNow<0||lastNow-lastNow!==0)throw new Error('CLOCK_CONFIG');
  function fail(why){state=why;error=why;halt=true;gate=false;paired=false;}
  function now(){let n=io.now();if(typeof n!=='number'||n<lastNow||n-n!==0){fail('CLOCK');return lastNow;}lastNow=n;return n;}
  function result(){return {seq:seq,op:op,index:index,state:state,halt:halt,raw:raw,sent:sent,received:received,
    callbacks:callbacks,start_at_ms:startAt,first_rx_at_ms:firstAt,first_rx_ms:firstAt<0?-1:firstAt-startAt,actual_gap_ms:-1,
    rx_at_ms:rxAt.slice(),discovery_gate:gate,paired_ack:paired,error:error,
    ack_scope:op==='last_ack'?'cached_observation_not_read_proof':'unvalidated_read_hypothesis'};}
  function tick(){
    let n=now();if(halt||state!=='waiting'||n-startAt<3000)return;
    if(op==='discover'){
      let sum=0;for(let i=0;i<11&&i<raw.length;i++)sum+=raw.charCodeAt(i);
      if(raw.length!==12||raw.charCodeAt(0)!==0x7a||(sum&255)!==raw.charCodeAt(11)){fail(raw.length?'DISCOVERY_INVALID':'DISCOVERY_TIMEOUT');return;}
      state='discovery_ok';gate=true;paired=false;return;
    }
    if(op==='read_probe'){state='no_response';paired=true;return;}
    if(raw.length===0){state='no_response';return;}
    if(raw.length===1&&(raw.charCodeAt(0)===0x7a||raw.charCodeAt(0)===0x72||raw.charCodeAt(0)===0x73||raw.charCodeAt(0)===0x76||raw.charCodeAt(0)===0x77||raw.charCodeAt(0)===0x78||raw.charCodeAt(0)===0x79||raw.charCodeAt(0)===0xb0)){
      state='last_ack_observed';return;
    }
    fail('RAW_RESPONSE');
  }
  function receive(data){
    if(data==='')return;
    let n=now();if(typeof data!=='string'){fail('RX_TYPE');return;}
    callbacks++;received+=data.length;if(firstAt<0)firstAt=n;if(rxAt.length<128)rxAt.push(n);
    for(let i=0;i<data.length;i++)if(data.charCodeAt(i)>255){fail('NON_BINARY_RX');return;}
    raw+=data.slice(0,128-raw.length);
    if(received>128){fail('RX_OVERFLOW');return;}
    // Retain additional fragments of a captured read reply, while forbidding TX.
    if(state==='captured'&&op==='read_probe'){
      if(n-startAt>=3000)error='LATE_RX';return;
    }
    if(halt||state!=='waiting'||n-startAt>=3000){fail('LATE_RX');return;}
    if(sendBusy){fail('RX_DURING_SEND');return;}
    if(op==='read_probe'){state='captured';halt=true;gate=false;paired=false;return;}
    if(op==='discover'&&(raw.charCodeAt(0)!==0x7a||raw.length>12))fail('DISCOVERY_INVALID');
  }
  function request(s,t,n,action,idx){
    if(s!==session||t!==token)throw new Error('UNAUTHORIZED');
    if(typeof n!=='number'||n%1!==0||n<0||n>12)throw new Error('SEQUENCE');
    if(action!=='discover'&&action!=='read_probe'&&action!=='last_ack'&&action!=='status'&&action!=='stop')throw new Error('OPERATION');
    if(action==='status'||action==='stop'){
      if(n!==seq||idx!==undefined)throw new Error('STATUS_ARGUMENTS');
      if(action==='stop')fail('STOPPED');else tick();return result();
    }
    if(action==='read_probe'){
      if(typeof idx!=='number'||idx%1!==0||idx<0||idx>4)throw new Error('INDEX');
    }else if(idx!==undefined)throw new Error('ARGUMENTS');
    let sig=action+':'+idx;
    if(n===seq){if(sig!==signature)throw new Error('SEQUENCE_REUSE');tick();return result();}
    tick();if(halt)throw new Error('HALTED');if(n!==seq+1||state==='waiting')throw new Error('BUSY_OR_SEQUENCE');
    if(action==='read_probe'&&!gate)throw new Error('DISCOVERY_REQUIRED');
    if(action==='last_ack'&&!gate&&!paired)throw new Error('ACK_GATE');
    seq=n;signature=sig;op=action;index=idx===undefined?-1:idx;raw='';received=0;callbacks=0;sent=0;firstAt=-1;rxAt=[];error='';
    gate=false;paired=false;startAt=now();state='waiting';
    let frame=action==='discover'?'\x5a':action==='last_ack'?'\x50':frames[index],accepted;
    if(halt)return result();sendBusy=true;
    try{accepted=io.send(frame);}catch(e){sendBusy=false;fail('SEND_ERROR');return result();}
    sendBusy=false;
    if(typeof accepted!=='number'||accepted%1!==0||accepted<0||accepted>frame.length)fail('SEND_ERROR');
    else {sent=accepted;if(sent!==frame.length)fail('PARTIAL_SEND');}
    return result();
  }
  return {request:request,receive:receive,tick:tick};
}

/* On Shelly, prepend P75_READ_ACK_SESSION/P75_READ_ACK_TOKEN locally.
 * Loading creates no TX; every complete frame requires an explicit request.
 */
if(typeof P75_READ_ACK_SESSION!=='undefined'&&typeof P75_READ_ACK_TOKEN!=='undefined'){
  let raUart=UART.get(0);if(!raUart)throw new Error('UART_UNAVAILABLE');
  let raCore=makeReadAckReferenceCore({now:function(){return Shelly.getUptimeMs();},send:function(b){return raUart.send(b);}},P75_READ_ACK_SESSION,P75_READ_ACK_TOKEN);
  raUart.recv(function(b){raCore.receive(b);});Timer.set(50,true,function(){raCore.tick();});
  HTTPServer.registerEndpoint('read_ack_reference',function(req,res){
    res.headers=[['Content-Type','application/json'],['Cache-Control','no-store']];res.code=400;res.body='{"error":"REQUEST"}';
    try{
      if(req.method==='POST'&&typeof req.body==='string'&&req.body.length<=512){
        let q=JSON.parse(req.body);
        if(!q||q.session!==P75_READ_ACK_SESSION||q.token!==P75_READ_ACK_TOKEN){res.code=403;res.body='{"error":"AUTH"}';}
        else{
          let unknown=false;for(let k in q)if(k!=='session'&&k!=='token'&&k!=='seq'&&k!=='op'&&k!=='index')unknown=true;
          if(unknown)throw new Error('FIELDS');
          let r=raCore.request(q.session,q.token,q.seq,q.op,q.index);r.base64=btoa(r.raw);r.raw='';res.code=200;res.body=JSON.stringify(r);
        }
      }
    }catch(e){res.code=400;res.body='{"error":"REJECTED"}';}res.send();
  });
}
