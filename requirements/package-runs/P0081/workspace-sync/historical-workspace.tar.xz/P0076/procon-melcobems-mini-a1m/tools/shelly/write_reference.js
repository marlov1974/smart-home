/* Bounded, operator-authorized bootloader write reference. GPL-3.0-only.
 * A valid FF write may program hidden ECC: it is NOT a guaranteed no-op.
 * No erase, arbitrary address/data, automatic start, or automatic retry.
 * io.now(): monotonic milliseconds; io.send(binaryString): accepted bytes.
 */
function makeWriteReferenceCore(io, session, token) {
  if (typeof session!=='string' || !session || typeof token !== 'string' || token.length < 32) throw new Error('AUTH_CONFIG');
  let frames = [
    '\x53\x08\x00\x00\x70\x01\x00\xff\xff\xff\xff\xff\xff\xff\xff\x22\xaa\xe8\x2e\xa6',
    '\x53\x08\x00\x00\x70\x01\x00\xff\xff\xff\xff\xff\xff\xff\xff\x23\xaa\xe8\x2e\xa7',
    '\x53\x08\x00\x00\x70\x01\x00\xff\xff\xff\xff\xff\xff\xff\xff\x22\xaa\xe8\x2e\xa7'
  ];
  let seq=0, op='idle', index=-1, split=0, gap=0, signature='';
  let state='idle', halted=false, gate=false, paired=false, validUsed=false;
  let raw='', received=0, callbacks=0, sent=0, startAt=-1, tailAt=-1, firstAt=-1;
  let beforeTail=0, sendAt=[], rxAt=[], frame='', phase='', sendBusy=false;
  let lastNow=io.now(), error='';
  if(typeof lastNow!=='number'||lastNow<0||lastNow-lastNow!==0)throw new Error('CLOCK_CONFIG');
  function fail(why) { state=why;error=why;halted=true;gate=false;paired=false; }
  function now() {
    let n=io.now();
    if (typeof n!=='number' || n-lastNow<0 || n-n!==0) { fail('CLOCK');return lastNow; }
    lastNow=n;return n;
  }
  function active() { return state==='waiting'; }
  function result() {
    return {seq:seq,op:op,index:index,split:split,gap_ms:gap,state:state,halt:halted,
      raw:raw,sent:sent,received:received,callbacks:callbacks,start_at_ms:startAt,
      tail_at_ms:tailAt,actual_gap_ms:tailAt<0?-1:tailAt-startAt,
      first_rx_at_ms:firstAt,first_rx_ms:firstAt<0?-1:firstAt-startAt,
      rx_before_tail:beforeTail,send_at_ms:sendAt.slice(),rx_at_ms:rxAt.slice(),
      valid_used:validUsed,discovery_gate:gate,paired_ack:paired,
      ack_scope:op==='last_ack'?'cached_state_not_current_write':'current_transaction',error:error};
  }
  function transmit(bytes) {
    sendAt.push(now());
    if(halted)return;
    sendBusy=true;
    let n;
    try { n=io.send(bytes); } catch(e) { sendBusy=false;fail('SEND_ERROR');return; }
    sendBusy=false;
    if(typeof n!=='number'||n%1!==0||n<0||n>bytes.length){fail('SEND_ERROR');return;}
    sent+=n;
    if(n!==bytes.length)fail('PARTIAL_SEND');
  }
  function finish() {
    if(op==='discover') {
      let sum=0;
      for(let i=0;i<11 && i<raw.length;i++)sum+=raw.charCodeAt(i);
      if(raw.length!==12||raw.charCodeAt(0)!==0x7a||(sum&255)!==raw.charCodeAt(11)) {
        fail(raw.length===0?'DISCOVERY_TIMEOUT':'DISCOVERY_INVALID');return;
      }
      state='discovery_ok';gate=true;paired=false;return;
    }
    if(raw.length===0)state='no_response';
    else if(op==='last_ack'&&raw.length===1&&(raw.charCodeAt(0)===0x7a||raw.charCodeAt(0)===0x72||raw.charCodeAt(0)===0x73))state='last_ack_observed';
    else if(raw.length===1&&(raw.charCodeAt(0)===0x72||raw.charCodeAt(0)===0x73))state='ack';
    else { fail('RAW_RESPONSE');return; }
    paired=(op==='probe'||op==='split');
  }
  function tick() {
    let n=now();
    if(halted||!active())return;
    if(phase==='prefix') {
      if(n-startAt>=gap+3000){fail('TAIL_SCHEDULING_TIMEOUT');return;}
      if(n-startAt>=gap) {
        tailAt=n;phase='tail';transmit(frame.slice(split));
      }
      return;
    }
    if(n-(tailAt>=0?tailAt:startAt)>=3000)finish();
  }
  function receive(data) {
    if(data==='')return;
    let n=now();
    if(typeof data!=='string'){fail('RX_TYPE');return;}
    callbacks++;received+=data.length;
    if(firstAt<0)firstAt=n;
    if(rxAt.length<32)rxAt.push(n);
    for(let i=0;i<data.length;i++)if(data.charCodeAt(i)>255){fail('NON_BINARY_RX');return;}
    raw+=data.slice(0,32-raw.length);
    if(received>32){fail('RX_OVERFLOW');return;}
    if(halted||!active()){fail('LATE_RX');return;}
    if(phase==='prefix') {beforeTail+=data.length;fail('RX_BEFORE_TAIL');return;}
    if(sendBusy){fail('RX_DURING_SEND');return;}
    if(n-(tailAt>=0?tailAt:startAt)>=3000){fail('LATE_RX');return;}
    if(op==='discover'&&(raw.charCodeAt(0)!==0x7a||raw.length>12)){fail('DISCOVERY_INVALID');}
  }
  function request(s,t,n,action,idx,cut,delay) {
    if(s!==session||t!==token)throw new Error('UNAUTHORIZED');
    if(typeof n!=='number'||n%1!==0||n<0||n>16)throw new Error('SEQUENCE');
    if(action!=='status'&&action!=='stop'&&action!=='discover'&&action!=='last_ack'&&action!=='probe'&&action!=='split')throw new Error('OPERATION');
    if(action==='status'||action==='stop') {
      if(n!==seq||idx!==undefined||cut!==undefined||delay!==undefined)throw new Error('STATUS_ARGUMENTS');
      if(action==='stop')fail('STOPPED');else tick();return result();
    }
    if(action==='probe'||action==='split') {
      if(typeof idx!=='number'||idx%1!==0||idx<0||idx>2)throw new Error('INDEX');
      if(action==='probe'&&(cut!==undefined||delay!==undefined))throw new Error('PROBE_ARGUMENTS');
      if(action==='split'&&(idx===0||(cut!==7&&cut!==19)||(delay!==20&&delay!==200&&delay!==1000&&delay!==3500)))throw new Error('SPLIT_ARGUMENTS');
    } else if(idx!==undefined||cut!==undefined||delay!==undefined)throw new Error('ARGUMENTS');
    let sig=action+':'+idx+':'+cut+':'+delay;
    if(n===seq) {
      if(sig!==signature)throw new Error('SEQUENCE_REUSE');
      tick();return result();
    }
    tick();
    if(halted)throw new Error('HALTED');
    if(n!==seq+1||active())throw new Error('BUSY_OR_SEQUENCE');
    if(action==='probe'||action==='split') {
      if(!gate)throw new Error('DISCOVERY_REQUIRED');
      if(idx===0&&validUsed)throw new Error('VALID_ALREADY_USED');
    }
    if(action==='last_ack'&&!gate&&!paired)throw new Error('ACK_GATE');
    seq=n;signature=sig;op=action;index=idx===undefined?-1:idx;split=cut===undefined?0:cut;gap=delay===undefined?0:delay;
    raw='';received=0;callbacks=0;sent=0;firstAt=-1;tailAt=-1;beforeTail=0;sendAt=[];rxAt=[];error='';
    gate=false;paired=false;startAt=now();state='waiting';phase=action==='split'?'prefix':'full';
    if(action==='discover')frame='\x5a';else if(action==='last_ack')frame='\x50';else frame=frames[index];
    if(index===0)validUsed=true;
    transmit(action==='split'?frame.slice(0,split):frame);
    return result();
  }
  return {request:request,receive:receive,tick:tick};
}

/* Define P75_WRITE_SESSION / P75_WRITE_TOKEN before loading on Shelly.
 * A Node/offline evaluation with neither constant does not create an adapter.
 */
if(typeof P75_WRITE_SESSION!=='undefined'&&typeof P75_WRITE_TOKEN!=='undefined') {
  let wUart=UART.get(0);
  if(!wUart)throw new Error('UART_UNAVAILABLE');
  let wCore=makeWriteReferenceCore({now:function(){return Shelly.getUptimeMs();},send:function(b){return wUart.send(b);}},P75_WRITE_SESSION,P75_WRITE_TOKEN);
  wUart.recv(function(b){wCore.receive(b);});
  Timer.set(10,true,function(){wCore.tick();});
  HTTPServer.registerEndpoint('write_reference',function(req,res){
    res.headers=[['Content-Type','application/json'],['Cache-Control','no-store']];
    res.code=400;res.body='{"error":"REQUEST"}';
    try {
      if(req.method==='POST'&&typeof req.body==='string'&&req.body.length<=512) {
        let q=JSON.parse(req.body);
        if(!q||q.session!==P75_WRITE_SESSION||q.token!==P75_WRITE_TOKEN){res.code=403;res.body='{"error":"AUTH"}';}
        else {
          let unknown=false;
          for(let key in q)if(key!=='session'&&key!=='token'&&key!=='seq'&&key!=='op'&&key!=='index'&&key!=='split'&&key!=='gap_ms')unknown=true;
          if(unknown)throw new Error('FIELDS');
          let r=wCore.request(q.session,q.token,q.seq,q.op,q.index,q.split,q.gap_ms);
          r.base64=btoa(r.raw);r.raw='';res.code=200;res.body=JSON.stringify(r);
        }
      }
    } catch(e) {res.code=400;res.body='{"error":"REJECTED"}';}
    res.send();
  });
}
