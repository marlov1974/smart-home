#!/usr/bin/env python3
"""Offline, sanitized validator for an explicitly authorized single-byte sweep.

SPDX-License-Identifier: GPL-3.0-only

No network or device access. Input files are never changed. Output is exclusive.
Silence does not establish that an opcode is unsupported. This cannot prove the
absence of persistent effects, original log overwrites, or physical wire bytes.
"""
import argparse
import base64
import hashlib
import json
import os
import re
import struct
from pathlib import Path

ENUM = {
    0x50: "check_last_ack", 0x51: "flash_erase", 0x53: "flash_write",
    0x55: "eeprom_write", 0x57: "flash_read", 0x59: "eeprom_read",
    0x5A: "discovery", 0xA0: "read_status",
}
SUCCESS = {"no_response", "probe_response"}
STOPS = {"CLOCK", "SESSION_EXPIRED", "RX_STILL_ACTIVE", "RX_TYPE",
         "NON_BINARY_RX", "RX_OVERFLOW", "LATE_RX", "RX_DURING_SEND",
         "SEND_ERROR", "PARTIAL_SEND", "STOPPED"}


def summarize(input_dir):
    root = Path(input_dir)
    if not root.is_dir():
        raise ValueError("INPUT_DIRECTORY_REQUIRED")
    errors, records = [], {"intent": {}, "result": {}}
    digest = hashlib.sha256()
    # Freeze the inventory once. During a live run, later files are deliberately
    # excluded; a missing/partly written tail is reported rather than guessed.
    for path in sorted(root.iterdir()):
        match = re.fullmatch(r"([0-9a-fA-F]{2})-(intent|result)\.json", path.name)
        if not match:
            continue  # never open session/RPC/credential files
        opcode, kind = int(match[1], 16), match[2]
        def problem(code):
            errors.append({"opcode": "%02X" % opcode, "record": kind, "code": code})
        if opcode in records[kind]:
            problem("DUPLICATE_OPCODE_RECORD")
            continue
        if path.is_symlink() or not path.is_file():
            problem("NONREGULAR_RECORD")
            continue
        raw = path.read_bytes()
        if len(raw) > 65536:
            problem("RECORD_SIZE_BOUND")
            continue
        digest.update(path.name.encode() + b"\0" + hashlib.sha256(raw).digest())
        try:
            value = json.loads(raw)
        except (ValueError, UnicodeError):
            problem("UNREADABLE_OR_PARTIALLY_WRITTEN_JSON")
            continue
        if not isinstance(value, dict):
            problem("RECORD_NOT_OBJECT")
            continue
        records[kind][opcode] = value
    intents, results = records["intent"], records["result"]
    keys = sorted(intents)
    prefix = 0
    while prefix in intents:
        prefix += 1
    if keys != list(range(len(keys))):
        errors.append({"code": "INTENT_COVERAGE_NOT_CONTIGUOUS_FROM_00"})
    for opcode in results:
        if opcode not in intents:
            errors.append({"opcode": "%02X" % opcode, "code": "RESULT_WITHOUT_INTENT"})
    rows, stopped, accepted, terminal = [], [], 0, 0
    missing = []
    for opcode in keys:
        intent = intents[opcode]
        row = {"opcode": "%02X" % opcode, "seq": opcode + 1,
               "documented_enum_definition": ENUM.get(opcode)}
        local_errors = []
        def check(condition, code):
            if not condition:
                local_errors.append(code)
                errors.append({"opcode": row["opcode"], "code": code})
        check(type(intent.get("seq")) is int and intent["seq"] == opcode + 1, "INTENT_SEQUENCE")
        check(type(intent.get("opcode")) is int and intent["opcode"] == opcode, "INTENT_OPCODE")
        check(intent.get("op") == "probe", "INTENT_OPERATION")
        check(type(intent.get("bytes")) is int and intent["bytes"] == 1, "INTENT_NOT_SINGLE_BYTE")
        check(intent.get("hex") == "%02x" % opcode, "INTENT_WIRE_BYTE")
        if opcode not in results:
            missing.append(opcode)
            row.update(status="missing_result", validation_errors=local_errors)
            rows.append(row)
            continue
        result = results[opcode]
        check(type(result.get("seq")) is int and result["seq"] == opcode + 1, "RESULT_SEQUENCE")
        check(type(result.get("opcode")) is int and result["opcode"] == opcode, "RESULT_OPCODE")
        check(result.get("op") == "probe", "RESULT_OPERATION")
        check(type(result.get("next_opcode")) is int and result["next_opcode"] == opcode + 1, "NEXT_OPCODE")
        state, halt, sent = result.get("state"), result.get("halt"), result.get("sent")
        if not isinstance(state, str):
            check(False, "STATE_NOT_STRING")
            state = "invalid_state"
        check(state in SUCCESS | STOPS | {"waiting"}, "UNKNOWN_STATE")
        check(type(halt) is bool and halt == (state in STOPS), "HALT_STATE_MISMATCH")
        check(type(sent) is int and sent in (0, 1), "TX_COUNT_BOUND")
        if state in SUCCESS or state == "waiting":
            check(sent == 1, "TX_NOT_ACCEPTED")
        accepted += int(type(sent) is int and sent == 1)
        terminal += int(state in SUCCESS and halt is False and sent == 1)
        if state in STOPS or halt is True:
            stopped.append(opcode)
        if state == "waiting" and opcode != keys[-1]:
            check(False, "INTENTS_AFTER_WAITING_RESULT")
        received, early = result.get("received"), result.get("received_by_1700")
        check(type(received) is int and 0 <= received <= 128, "RX_COUNT_BOUND")
        check(type(early) is int and type(received) is int and 0 <= early <= received, "BOUNDARY_1700_COUNT")
        data = b""
        try:
            value = result.get("base64")
            if not isinstance(value, str) or len(value) > 176:
                raise ValueError()
            data = base64.b64decode(value, validate=True)
            check(len(data) <= 128 and len(data) == received, "BASE64_RX_COUNT")
        except (ValueError, TypeError):
            check(False, "BASE64_INVALID_OR_TOO_LARGE")
        first, start, absolute, last = (result.get(k) for k in
            ("first_rx_ms", "start_at_ms", "first_rx_at_ms", "last_rx_at_ms"))
        callbacks, times = result.get("callbacks"), result.get("rx_at_ms")
        check(type(start) is int and start >= 0, "START_TIME")
        valid_times = (isinstance(times, list) and len(times) <= 128
                       and all(type(t) is int for t in times))
        check(valid_times, "RX_TIMES_FORMAT")
        check(type(callbacks) is int and type(received) is int and 0 <= callbacks <= received, "CALLBACK_COUNT")
        if valid_times and type(callbacks) is int:
            check(len(times) == min(callbacks, 128) and times == sorted(times), "CALLBACK_TIMES")
        if received == 0:
            check(first == -1 and absolute == -1 and last == -1 and callbacks == 0 and times == [] and early == 0, "EMPTY_RX_METRICS")
        elif type(received) is int and received > 0:
            clock_values = all(type(t) is int for t in (first, start, absolute, last))
            check(clock_values and first == absolute - start and first >= 0 and last >= absolute, "FIRST_RX_METRICS")
            if valid_times and times and clock_values:
                check(times[0] == absolute and times[-1] == last, "RX_ENDPOINT_TIMES")
                before = [t for t in times if t - start <= 1700]
                if not before:
                    check(early == 0, "BOUNDARY_1700_AFTER_ONLY")
                elif len(before) == len(times):
                    check(early == received, "BOUNDARY_1700_BEFORE_ONLY")
                else:
                    check(type(early) is int and 0 < early < received, "BOUNDARY_1700_MIXED")
        if state == "no_response":
            check(received == 0, "NO_RESPONSE_WITH_DATA")
        if state == "probe_response":
            check(type(received) is int and received > 0, "RESPONSE_WITHOUT_DATA")
        expected_complete = opcode == 255 and state in SUCCESS and halt is False
        check(result.get("sweep_complete") is expected_complete, "SWEEP_COMPLETE_FLAG")
        row.update(status=state if state in SUCCESS | STOPS | {"waiting"} else "invalid_state",
                   sent_bytes_accepted=sent if type(sent) is int else None,
                   received=received if type(received) is int else None,
                   received_by_1700=early if type(early) is int else None,
                   first_rx_ms=first if type(first) is int else None,
                   callbacks=callbacks if type(callbacks) is int else None,
                   validation_errors=local_errors)
        if len(data) == 1 and received == 1:
            row["single_byte_reply_hex"] = data.hex()
        elif len(data) > 1:
            row["multi_byte_payload_withheld"] = True
            if opcode == 0x5A and len(data) == 12 and data[0] == 0x7A and (sum(data[:-1]) & 255) == data[-1]:
                flash, eeprom, erase, page = struct.unpack("<IHHH", data[1:11])
                row["decoded_discovery"] = {"maximum_flash": flash, "maximum_eeprom": eeprom,
                    "erase_block": erase, "maximum_write_page": page, "checksum_valid": True}
        rows.append(row)
    if missing and missing != [keys[-1]]:
        errors.append({"code": "NONTAIL_MISSING_RESULT"})
    if stopped and any(k > min(stopped) for k in keys):
        errors.append({"code": "INTENTS_AFTER_STOP"})
    complete = not errors and not stopped and len(intents) == len(results) == terminal == 256
    status = "INVALID" if errors else ("COMPLETE" if complete else ("STOPPED" if stopped else "PARTIAL"))
    return {"status": status, "complete_00_through_ff": complete,
        "intent_count": len(intents), "result_count": len(results), "contiguous_intent_prefix": prefix,
        "one_byte_accepted_count": accepted, "completed_transaction_count": terminal,
        "responding_opcode_count": sum(bool(r.get("received")) for r in rows),
        "total_received_by_1700": sum(r.get("received_by_1700") or 0 for r in rows),
        "missing_results": ["%02X" % k for k in missing], "stopped_at": ["%02X" % k for k in stopped],
        "errors": errors, "opcodes": rows, "evidence_inventory_sha256": digest.hexdigest(),
        "timing": "1700 ms classification uses UART callback arrival, not measured wire arrival",
        "limitations": ["Single-opcode silence does not establish unsupported commands.",
            "Enum labels document host constants only; they do not prove device implementation.",
            "UART accepted counts are not an independent physical wire trace.",
            "Existing input-file overwrite history cannot be established from a final snapshot.",
            "No conclusion about persistent effects, cleanup, or restored normal operation."]}


def write_summary(input_dir, output):
    result = summarize(input_dir)
    fd = os.open(output, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    return result


def self_test():
    import tempfile
    import unittest
    class Tests(unittest.TestCase):
        def fixture(self, root, opcode, data=b"", early=None):
            intent = {"seq": opcode + 1, "op": "probe", "opcode": opcode, "hex": "%02x" % opcode, "bytes": 1}
            result = {"seq": opcode + 1, "op": "probe", "opcode": opcode, "next_opcode": opcode + 1,
                "state": "probe_response" if data else "no_response", "halt": False, "sent": 1,
                "received": len(data), "received_by_1700": len(data) if early is None else early,
                "base64": base64.b64encode(data).decode(), "start_at_ms": 100,
                "first_rx_ms": 50 if data else -1, "first_rx_at_ms": 150 if data else -1,
                "last_rx_at_ms": 150 if data else -1, "callbacks": 1 if data else 0,
                "rx_at_ms": [150] if data else [], "sweep_complete": opcode == 255}
            for kind, value in (("intent", intent), ("result", result)):
                (root / ("%02x-%s.json" % (opcode, kind))).write_text(json.dumps(value))
            return result
        def test_complete_and_sanitized_discovery(self):
            with tempfile.TemporaryDirectory() as d:
                root=Path(d)
                for i in range(256):self.fixture(root,i,bytes.fromhex("7a00700300ff000008002014") if i==0x5A else b"")
                summary=summarize(root)
                self.assertEqual(summary['status'],'COMPLETE')
                self.assertEqual(summary['opcodes'][0x5A]['decoded_discovery']['maximum_flash'],225280)
                self.assertNotIn('base64',json.dumps(summary));self.assertNotIn('7a007003',json.dumps(summary))
        def test_partial_tail(self):
            with tempfile.TemporaryDirectory() as d:
                root=Path(d);self.fixture(root,0);self.fixture(root,1)
                (root/'01-result.json').unlink()
                summary=summarize(root)
                self.assertEqual(summary['status'],'PARTIAL');self.assertEqual(summary['missing_results'],['01'])
        def test_gap_wrong_sequence_and_overflow(self):
            for kind in ('gap','seq','overflow'):
                with self.subTest(kind=kind),tempfile.TemporaryDirectory() as d:
                    root=Path(d);r=self.fixture(root,0)
                    if kind=='gap':self.fixture(root,2)
                    if kind=='seq':r['seq']=2
                    if kind=='overflow':r.update(received=129,base64=base64.b64encode(b'x'*128).decode(),state='RX_OVERFLOW',halt=True)
                    if kind!='gap':(root/'00-result.json').write_text(json.dumps(r))
                    self.assertEqual(summarize(root)['status'],'INVALID')
        def test_boundary_and_stop(self):
            with tempfile.TemporaryDirectory() as d:
                root=Path(d);r=self.fixture(root,0,b'ab',early=1)
                r.update(callbacks=2,rx_at_ms=[150,1900],last_rx_at_ms=1900)
                (root/'00-result.json').write_text(json.dumps(r))
                self.assertEqual(summarize(root)['status'],'PARTIAL')
                r['received_by_1700']=2;(root/'00-result.json').write_text(json.dumps(r))
                self.assertEqual(summarize(root)['status'],'INVALID')
                r['received_by_1700']=1;r.update(state='STOPPED',halt=True)
                (root/'00-result.json').write_text(json.dumps(r))
                self.assertEqual(summarize(root)['status'],'STOPPED')
        def test_exclusive_output_and_no_input_change(self):
            with tempfile.TemporaryDirectory() as d:
                root=Path(d);self.fixture(root,0,b'v');before=(root/'00-result.json').read_bytes()
                output=root/'summary.json';write_summary(root,output)
                with self.assertRaises(FileExistsError):write_summary(root,output)
                self.assertEqual(before,(root/'00-result.json').read_bytes())
                self.assertEqual(json.loads(output.read_text())['opcodes'][0]['single_byte_reply_hex'],'76')
    result=unittest.TextTestRunner().run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    return 0 if result.wasSuccessful() else 1


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--self-test',action='store_true')
    args=parser.parse_args(argv)
    if args.self_test:return self_test()
    if args.input is None or args.output is None:parser.error('--input and --output are required')
    try:result=write_summary(args.input,args.output)
    except (OSError,ValueError) as error:
        print('SUMMARY_FAILED '+type(error).__name__)
        return 2
    print('%s intents=%d results=%d accepted=%d'%(result['status'],result['intent_count'],result['result_count'],result['one_byte_accepted_count']))
    return 2 if result['errors'] else (0 if result['complete_00_through_ff'] else 1)


if __name__=='__main__':raise SystemExit(main())
