# P0076 EFFECT and device addressing

Last changed: P0076. Portable implementation lives in the standalone Procon
repository; Smart Home owns this integration contract and package evidence.

`tele_snapshot` exposes typed status/generation/millisecond age without changing
legacy telemetry. `effect_feedback_tick` accepts independent coherent GET0C and
GET14 generations only after a trailing heating GET26. It retains bounded60s/
180s windows, exposes coverage and quality, and never recounts cached pairs.

`effect_decide` applies minute-scale, bounded non-integrating changes with
hysteresis, derivative anticipation, temperature/cumulative limits and a latched
no-response stop. `ctl_feedback` and `ctl_tick` distinguish normal incomplete
pairs from invalid feedback. New SETs need fresh GET28/26 guards and matching
readback. `ctl_link_lost` requests guarded restoration at the next transaction
boundary. Existing v2 sequence, snapshot, lease and AUTO semantics remain shared.
No persistent reset-time restoration exists; unattended operation is blocked.

DIP decoding and `identity_init` provide one latched effective slave address and
read-only MCU UID. FC04/FC16 ignore broadcasts, other addresses and bad CRC before
mutation. Host commissioning requires an isolated physical-unit/UID/address map,
rejects duplicate identities/addresses and keeps sequence/lease state per device.
No application NVM programming or bootloader modifications are introduced.

See [package design](../../requirements/package-runs/P0076/design.md),
[verification](../../requirements/package-runs/P0076/verification.md) and standalone
`docs/effect-control.md`, `docs/addressing.md`, `docs/host-tools-p76.md`.
