# P0076 changelog

- Promoted the P0072 r3 supervised-control baseline into portable source, retaining
  all v2 modes and adding version3 EFFECT with per-unit1000..12000W targets.
- Added coherent independent source-generation feedback,60s/180s windows, quality,
  sample counts, bounded minute adjustments, readback, native guards and restore.
- Added one-image, startup-latched DIP address support, MCU UID and isolated
  commissioning validation. No NVM writes or bootloader changes.
- Extended read-only diagnostics to383 and preserved the legacy telemetry map.
- Built compact application artifacts with a separate full96KiB erase contract.
- Added native sanitizer, host/mock and actual-ELF tests. Hardware verification and
  reset-persistent restoration remain explicit deployment gates; P0077 unchanged.
- Final verification passes37 ARM cases and a deterministic16476-byte build.
- REPOSITORY_FILES.md updated in both working trees for source, tests and evidence.
- Project-specific emulator lessons recorded in attempts.md and standalone
  p76-verification.md; global knowhow promotion intentionally skipped because
  this run performed no live deployment and the findings concern this harness.

- Subsequent operator-authorized physical transfer: full application erase and
  all69 compact packets acknowledged; cleanup verified, normal boot pending.
- Corrected Shelly eager initialization after local declaration;39 flash-core
  tests now pass. Firmware image unchanged. Lesson promoted to Shelly knowhow.
- Added physical transfer report and updated repository file indexes.

- Operator-confirmed restart:20/20 FC04 responses validate P76 r1, DIP0x61,
  address1 and stable validUID. CN105/FAST/A3 source generations advance with
  zero reported communications errors. Runtime UART/cleanup verified.
- Original strict coherence flags preserved; offline communication-liveness
  audit distinguishes refreshing sources from a coherent multi-block snapshot.
- New normal-verification reports and repository indexes updated. No firmware
  changes or new heat commands. No further global knowhow promotion: this is
  project-specific sample-coherence evidence, recorded in the verification report.
