# P0076-B addressing implementation notes

2026-10-07 amendment: the user's request to use the physical DIP switches
supersedes the initial immutable per-image address proposal. The same image now
serves every unit. No compile-time slave profile or fallback address is shipped.

Original application SHA256
`2ae03b0cdc684bcccbf9f5281878175f5ca53b144e3e32cc223159fcc4654766`
provides the R5B pin mapping. Its input sampler at 0x0800F490 reads PA4/5/6/7,
PC4/5 and PB0/1 into bits 0 through 7. GPIO helper 0x0800A7D8 returns high=1;
there is no inversion. Initialization at 0x080098BE–0x080098F6 uses input mode
and pull-up for these eight pins. Decoder 0x0800F514 takes low five bits as
address; the Modbus initializer at 0x0800F8A4 stores this byte unchanged.
Application startup calls the decoder at 0x0800E274. The main loop's separate
sample at 0x0800E324 only updates diagnostic RAM, not the selected address.
This is binary-derived application evidence, not bootloader source or a physical
pin measurement. No vendor bytes or disassembly are distributed.

`platform_init` reproduces only the established DIP input/pull configuration.
`platform_dip_read` reads IDR values without writes and packs raw levels in the
original order. Main takes three samples at 0, 5 and 10 ms, refreshing the
watchdog while waiting, before enabling either UART; all three must agree.
`identity_init_dip(uid, raw, stable)` latches the boot configuration once.
`identity_validate_dip` is pure and returns an effective address or zero.
Supported configurations have low five bits 1..30 and bits 5/6 both set
(9600/no parity and Modbus). Bit 7 is exposed but does not enable vendor
thermostat deadband behavior. Address 0, software-address selector 31, unstable
samples and unsupported baud/protocol selection disable the listener. There is
no fallback to 1 and no broadcast listener/control path. Changing switches
requires power off/restart; this application does not enter a bootloader itself.

Identity FC04 offsets 72..83 retain schema/address/validity and MCU UID fields;
source 3 means DIP. New offsets 84/85/86 expose raw DIP, stability and rejection
reason (0 valid, 1 unstable, 2 address zero, 3 software selector, 4 unsupported
serial/protocol). UID order remains high16 then low16 per 32-bit word.
`platform_uid_word` reads the three ST-documented words starting at 0x1FFF7590.
A bad UID blocks host commissioning/control; it does not create another address.

Tests cover every DIP byte with stable/unstable samples, address 1/2/30,
unsupported/reserved modes, restart reconstruction, UID sentinels and high/low
order, all 256 request slave bytes, broadcast/CRC silence, no control entry for
wrong addresses and no mutation without a sufficient response buffer. Root
integration owns ARM GPIO fixtures, actual control-state isolation, main boot
sampling and host commissioning. Native tests do not establish electrical DIP
polarity on the physical units; isolated 0x61/address1 and 0x62/address2 reads
and restart/UID checks remain mandatory before joining a shared bus.

Physical switches persist without NVM writes, endurance cost or torn journal
risk. Recovery from unsupported configuration is an isolated power-off DIP
correction and restart. Bootloader entry/exit remains the known separate
operator procedure; the bootloader was not included in the analyzed BIN.
