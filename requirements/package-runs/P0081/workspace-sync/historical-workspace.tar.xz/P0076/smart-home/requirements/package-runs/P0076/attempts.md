# P0076 offline implementation record

2026-10-07. Fetched Smart Home main6aeffc4 and reviewed the narrowed P0076 package;
P0077 long-duration brine/COP work is separate. Existing staged P0075 changes in
the original checkout were preserved. Implementation uses isolated work copies.
Portable source starts from the previously prepared P0075 optimized-flash tree,
with the P0072 r3 control/telemetry files promoted as listed in r3-promotion.json.

Implemented independent coherent-power feedback, bounded EFFECT controller,
versioned commands, identity/address routing and offline commissioning helpers.
The initial immutable-profile address design was superseded when the operator
explicitly requested DIP addressing. Original application analysis located the
eight-pin sampler at0800F490 and address decoder0800F514. Application source uses
an independently written equivalent pin read and validated startup address.

Integration found and corrected EF_PENDING handling: new temperature without its
matching flow/mode must temporarily yield the CN105 control boundary so FAST can
complete the pair; treating this as hard failure aborted healthy sessions. New
regression checks also preserve invalid numeric sentinels without signed overflow.
The freestanding ARM build needed an explicit bounded memset implementation for
compiler-generated aggregate zeroing; no heap or libc dependency was added.

No network call to Shelly/Procon, flash operation, live Modbus command, actuator
change or multi-hour measurement was performed in the initial offline stage. Hardware results
from P0072/P0075 remain historical. New physical validation is still pending.

2026-10-08 final review found two additional guards: invalid MCU UID must reject
FC16 on the device, and EFFECT entry must set fixed mode and captured flow in
one combined update. Tests cover a hidden45C prior fixed target, lost ACK,
missing/wrong flow readback and restoration after an uncertain write.

The final actual-ELF suite passes37 cases. Emulator qualification was necessary:
an overly fast abstract guest clock falsely broke RTU intercharacter timing,
and an all-memory read hook corrupted Thumb IT execution. Selecting Cortex-M4,
using a documented abstract clock and limiting read hooks to actual peripherals
fixed the harness; the unchanged firmware then passed. Write whitelisting and
no-flash-write checks remain active. These are not physical timing measurements.
The exact compact BIN is deterministic across a forced rebuild.

## Subsequent operator-authorized physical flash, 2026-10-08

The operator explicitly stated that Procon was ready and authorized flashing
P0076. This authorizes the application transfer and subsequent read verification;
it does not enable EFFECT or P0077 experiments.

Preflight attempt1 stopped at Script.Start with ReferenceError(newStats), before
discovery, erase or any UART send. Shelly local function declarations were not
hoisted as Node's are. Moving the eager initializer after the declaration fixed
startup. The application BIN and erase plan are unchanged. Offline regressions
include both the failing historical order and the corrected construction path:
39 flash-core tests,16 planner tests and9 host tests pass.

Preflight attempt2 passed source readback, bootloader discovery and staged frame
CRC/health checks. Final transfer and cleanup evidence is recorded separately
in flash-verification.md. The reusable declaration-order lesson was promoted to
memory/knowhow/shelly.md.
