# P0076 implementation design

Portable code, tests and API docs belong in standalone; Smart Home retains this
coordination evidence. Preserve immutable prior releases and legacy v2 controls.

## Interfaces

Keep FC16 holding300/count8. Existing C072/version2 modes0..4 retain their exact
meaning. New C076/version3 mode5 is EFFECT: sequence, targetW1000..12000,
maximumflow3000..4000centidegrees, lease90..1800seconds, flags1 meaning explicitly
verified heating-path boundary. Other flags, broadcast commands and larger
single-unit power targets are rejected. V2 AUTO restores the original snapshot.
There is one shared sequence/lease owner per physical controller, never two
parallel command paths. Identical retries never extend leases. Different intents
require cancellation/restoration before a new session.

Reserve input320..383 for EFFECT diagnostics. Existing0..298 values retain their
semantics; identity/address adds a documented block in previously reserved72..86.
MVP telemetry API remains version1. New firmware identity identifies package76
and its revision; helpers must accept legacy revisions and the new feature bits.

## Feedback and regulation

Expose typed value/status/generation/millisecond-age snapshots from existing
telemetry. Use independent temperature(GET0C) and flow(GET14) generations: both
must advance before a new sample. Require matching supply/return acquisition,
source skew<=2000ms, fresh positive flow, nonnegative water heat and trailing
fresh GET26 confirming heating2/7. Do not equate cached values or derived counter
changes with new measurements. A pending partial pair blocks upward decisions;
hard invalidity/DHW/link loss clears windows and requests restoration.

Maintain bounded60s/180s windows with exposed counts, coverage and age. Require
three distinct samples spanning20s before entering EFFECT; report warming-up
instead of accepting stale history. Quantization is retained, not hidden by an
implied precision claim.

START/CAPTURE/HOLD use bounded target changes at least60s apart. Maximum upward
step100cC; soften to50/25near capture, with deadband/hysteresis and derivative
anticipation. No integrator. Respect20C floor and supplied maximum<=40C. Persistent
lack of response stops further increases and reports unreachable/unknown limit;
do not invent a confirmed hydraulic/compressor cause. Native inhibit and explicit
temperature caps have separate reasons. No direct Hz or pump-speed control.

Use the existing controller snapshot, SET encoding and matching fresh readback.
Curve/room-to-fixed entry uses one combined payload32 mask0x88 update for mode
and captured flow, avoiding exposure of an unrelated hidden fixed target.
Mark both settings possibly touched before TX; confirm mode with GET26 and the
exact captured flow with GET09 before reporting applied. Preserve current DHW.
Recheck GET28 protection flags and fresh GET26 before each EFFECT flow SET.
The controller returns to ACTIVE between bounded transactions, allowing normal
FAST/A3 polling; it must never hold the CN105 owner while waiting60s. Exclusive
A3 operations are never interrupted. Error, lost feedback/link or expired lease
defers restoration until the current transaction/service boundary. Reset starts
passively with recovery unsupported; expose that limitation explicitly.

## DIP address (operator steering)

The operator explicitly requested hardware DIP addressing after the initial
immutable-profile design. Trace the original R5 application GPIO read and address
conversion, then implement the evidenced mapping in one shared image. Preserve
current SW1..8=10000110 as address1; intended second unit01000110 as address2.
Primary vendor documentation assigns binary weights1,2,4,8,16 to SW1..5 and
reserves31 for software address. SW6ON selects9600/8N1, SW7ON Modbus.

Application address must latch at startup, never change mid-frame. New firmware
will use DIP1..30 and fail silently for invalid/unsupported configuration rather
than assign a colliding fallback. Any profile-only override is test-only, not the
shipping default. No EEPROM or bootloader writes. Bootloader allOFF behavior is
outside the application and remains untouched. Electrical pinmap and inversion
must be supported by original code; physical DIP correlation remains a separate
isolated-unit validation gate.

Identity72..83: schema1, effectiveaddress, configuredaddress, source3=DIP,
configvalid, UIDvalid, followed by three32-bit MCU UID words, high16 then low16.
Inputs84..86 report raw DIP, startup sample agreement and rejection reason.
Host join requires isolated expectedUID+address proof, uniqueSID/UID mapping and
interleaved reads. No broadcast provision or automatic fallback.

## Verification

Native ASan/UBSan suites cover measurements, controller phases, safety, addressed
Modbus and independent instances. Mock tests exercise quantization, response
delays, lease cancellation, native flags, link loss and reset reporting. Actual
ELF/ARM tests cover different startup DIP configurations and identity reads. Build compact
artifacts with full96KiB managed erase metadata and explicit hardware-pending
status. No new hardware validation is claimed. No P0077 runner is implemented.

P0076 integration expands only the linker code/load bound from16KiB to20KiB
(08008000..0800CFFF) for the additional guards. This is inside the existing
96KiB erase footprint, leaves bootloader untouched and retains16KiB SRAM with
a statically reserved2KiB stack. ELF and flash-plan validators share this bound.
