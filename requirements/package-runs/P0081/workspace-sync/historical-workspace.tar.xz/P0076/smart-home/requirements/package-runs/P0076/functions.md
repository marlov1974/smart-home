# P0076 function design

- `tele_snapshot(index,out)`: typed read-only access to existing telemetry with
  individual generation and millisecond age. No new decoding or wire effects.
- `effect_feedback_init/tick/read`: bounded distinct-pair filtering and quality;
  tested for partial pairs, wrap, skew, invalidity, DHW and finite windows.
- EFFECT controller helpers: versioned command validation, deterministic phase
  and setpoint decisions, counters/limits, reset reporting; existing ctl_submit,
  tick/next/reply integrate them with one snapshot, lease and readback owner.
- `platform_uid_word(index)`: read-only documented STM32 UID access, mocked on ARM.
- `identity_init_dip/modbus_address/identity_read`: latched DIP configuration validation,
  effective address and observable physical UID; no NVM writes.
- `modbus_reply`: route only addressed CRC-valid FC04/FC16 and echo actual slave;
  broadcasts/wrong addresses remain silent before any command mutation.
- Offline command encoder and read/commission helpers: explicit slave + UID map,
  v3 EFFECT envelope and identity validation, duplicate/join gating and separate
  unit sequences. No unsolicited live action from import or plan execution.
- Build/check helpers: deterministic DIP decoding and compact metadata;
  preserve oldrelease artifacts and full erase extent. Tests compare identities,
  register bounds, native/ARM behavior and source/artifact provenance.
