# P0076 normal boot and address-1 verification — 2026-10-08

After the operator confirmed DIP10000110 and power cycling, the flashed P0076 r1
application passed twenty fixed addressed FC04 reads. No FC16, heat control,
fault reset or further bootloader command was sent.

## Identity and addressing

- Input0/1 =888/76; revision/API/features/control state at68..71 =1/1/15/0.
- Input72..77 =1/1/1/3/1/1: schema1, effective/configured address1, hardware DIP,
  valid configuration and valid factory MCU UID.
- Input84..86 =97/1/0: raw0x61, startup samples agreed, no rejection reason.
- The full96-bit UID and all identity/DIP words matched in both reads.

This physically confirms the expected DIP10000110/raw0x61/address1 mapping on
the connected unit. It does not verify another address, every switch, a second
unit, or simultaneous two-unit operation.

## Communication and observations

All20 replies passed frame/CRC checks. CN105 remained linked. The reply counter
increased4→10; communication and UART error counters stayed0. Direct temperature
and Hz generations183/184/188 advanced6→11 between the completed brackets;
their second-bracket endpoint statuses were VALID. Both brine generations also
advanced. These establish communication liveness with fresh source updates.

Individual field observations, acquired in separate blocks:

| Field | First observation | Second observation |
|---|---|---|
| Brine service27 /28 |8 /7C |6 /6C |
| Flow /return temperature |28 /28C |28 /28C |
| Primary water flow |11L/min |11L/min |
| Compressor |0Hz |0Hz |
| DHW tank |49C |49C |
| Outdoor |10C |10C |

Brine service interpretation and whole-degree resolution retain their documented
limits. These values are not a simultaneous calibrated system snapshot. No COP
or EFFECT-control performance is inferred. Brine-pump run/step are still absent.

## Strict snapshot flag and final state

The original verifier reports `cn105_updates_verified=false`: that flag requires
unchanged source generations over each approximately9-second multi-block read.
Normal FAST updates during both brackets correctly prevent treating the values
as a coherent snapshot. The immutable original log is retained. A separate
offline audit records `cn105_communication_liveness_verified=true` from link,
direct-source generation progress and valid endpoint statuses, without relaxing
the original process-value coherence rule or issuing more device commands.

Runtime UART was restored to1152008N1, all Shelly scripts stopped/disabled and
both relay outputs stayedoff. Persistent serial configuration is unchanged
(js_uart1152008N1). Procon runs normal application96008N1/address1; the next read
tool must select the application baud while it owns the serial port.

Shared-bus operation, address2, supervised EFFECT response and reset-persistent
restoration remain unverified. No P0077 experiment was run.

## Site identity and provenance

UID: `REDACTED_DEVICE_UID`. Raw evidence: `P0076/20261008T031222.287126Z-p76-normal-verification/`.
Original outcome SHA256: `228f06c32869551a3dfd60bbcd46939e38655f4bbea9661e7f3703575f11f695`.
Only local logs contain site endpoints and the full device identity.
