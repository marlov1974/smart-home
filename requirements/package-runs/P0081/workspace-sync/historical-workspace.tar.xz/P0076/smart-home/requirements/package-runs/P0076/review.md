# P0076 review

WARN, proceed offline. Reviewed latest package at Smart Home commit6aeffc4.
The existing production checkout contains the previous authorized P0075 local
documentation changes; they are preserved. Work uses a clean checkout of the
fetched latest tree rather than merging or discarding that work.

The portable standalone tree still contains application r1, while P0076 explicitly
depends on the hardware-tested private P0072 r3 source. Promote only the owned,
portable r3 source/tests/helpers into standalone, with recorded hashes. Do not
export vendor/private live files. P0075 compact-flash tooling is a local prerequisite; P0076 changes only its
validated linked-image bound to20KiB while retaining the96KiB erase contract.

P0076 authorizes implementation, deterministic builds and offline tests only.
No flash, address assignment on hardware, EFFECT actuation or P0077 test runs.
Two CPUs are operator-confirmed STM32L433; both pumps share the borehole.

Operator steering superseded the initial immutable-profile proposal: implement
hardware DIP addressing in one image. Original BIN analysis establishes PA4..7,
PC4..5 and PB0..1 sampling and the low-five-bit address decoder. Match this
application behavior with input/pull-up configuration and startup latching;
physical switch correlation remains unverified. Invalid configuration stays
silent, without address1 fallback. Joining requires isolated UID/address proof.

Water-side W is a quantized estimate, not verified floor heat or COP. EFFECT is
restricted to an already valid heating path and an explicit operator assertion
that the meter/hydraulic boundary was checked. Missing process feedback cancels
regulation and requests bounded restoration. RAM-only snapshots still prohibit
unsupervised deployment and cannot restore after power loss.
