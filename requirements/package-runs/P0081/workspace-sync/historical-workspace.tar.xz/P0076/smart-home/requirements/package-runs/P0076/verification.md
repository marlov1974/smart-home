# P0076 verification — 2026-10-08

[Subsequent normal boot and address1 verification passed](normal-verification.md). Statements below describe the earlier stage.

This report records the initial offline completion. A later separately authorized
[physical transfer](flash-verification.md) is now acknowledged; normal boot is still pending.

**Offline completion condition met. Hardware validation remains pending.**
No P0076 image was flashed, no live device was read or written, and no P0077
experiment ran. The physical installation has not been changed by this package.

## Candidate and scope

Portable implementation belongs to the standalone repository. Smart Home stores
the package design, function catalog and verification/provenance. Isolated work
copies preserve the existing P0075 staged changes in the original checkout.
These prepared results have not yet been published to GitHub.

P0076 r1 includes the backward-compatible EFFECT interface, coherent power
feedback, guarded bounded flow adjustments and DIP-selected Modbus addresses.
Both units use the same BIN. Physical SW1..8 order: `10000110` selects address1;
`01000110` selects address2. Switches are latched at application startup.
The operator-requested hardware model supports1..30, rather than software
configuration1..247. Unsupported settings remain silent without a colliding
address1 fallback. Physical switch polarity and two-unit operation are unverified.

Compact BIN:16476 bytes at `0x08008000`, SHA256:
`dcd1efe7634fdf38a67c6ffcd8e95614a963b232619b788549256b64ff692b44`.
Full managed application erase remains98304 bytes. Only69 data frames of up
to240 bytes are transmitted. No application FF tail is required. Link limit is
20KiB inside that erase extent; BSS1688 bytes, RAM16KiB and minimum stack2KiB.
The resident bootloader is outside the application erase/write range.

## Executed checks

| Check | Result |
|---|---|
| Seven native C suites with ASan/UBSan | PASS |
| All256 DIP values, address routing, CRC/broadcast and UID guards | PASS |
| Legacy84 native inhibit combinations;20000 malformed requests | PASS |
| Host command/read/commission tests |30 PASS |
| Flash planner /host /Shelly mock |16 /9 /37 PASS |
| Existing readback/research mock regressions | PASS |
| Actual Cortex-M4 ELF with modeled peripherals |37 PASS |
| Forced deterministic image rebuild, vectors and bounds | PASS |
| Catalog/platform checks, document links, publication scan and diff check | PASS |

Commands used include `make host-test flash-test`, `make readback-test`,
`python tests/test_arm.py build/procon-mvp.elf`, a forced `make -B image`,
`python tools/sanitize.py` and `git diff --check`, with the pinned Arm GNU14.3.Rel1
toolchain. The ARM harness uses Unicorn2.1.4 and pyelftools0.33. Full local logs
are retained in the delivery evidence directory; artifact/source hashes are
recorded in candidate-manifest.json and the candidate SOURCE.json/SHA256SUMS.

The emulator uses an abstract clock and simulated peripherals. Separate
address1/address2 boots prove routing and nonmutation; they do not prove
simultaneous shared-bus collision timing. The integrated successful EFFECT/AUTO
scenario runs on one modeled unit. See standalone docs/p76-verification.md for
the qualified MMIO-hook workaround and the unchanged write whitelist.

## Physical handoff gates

Validate one unit first: DIP raw/effective address, full MCU UID, restart latching
and progressing CN105 telemetry. Repeat individually for the other unit before
joining and interleaving reads; duplicate addresses or UIDs block joining.
Confirm native acceptance and both readbacks of the combined0x88 startup.
Only after a separate operator handoff, test reachable low/medium EFFECT targets
with a verified heating measurement boundary and explicit AUTO/lease restoration.
RAM-only snapshots cannot restore a pre-reset session; unattended use is blocked.
Estimated water-side power is neither calibrated delivered floor heat nor live COP.

P0077 and multi-hour/combined18–27kW experiments remain outside this completion.
Global knowhow promotion was intentionally skipped; the emulator findings are
recorded as project-specific verification evidence.
