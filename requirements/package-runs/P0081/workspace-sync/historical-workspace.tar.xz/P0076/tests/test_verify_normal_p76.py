"""Offline protocol/identity/evidence checks; never contact Shelly or Procon."""
import importlib.util
from pathlib import Path
import re
import tempfile
import unittest
from unittest.mock import patch

MODULE = Path(__file__).resolve().parents[1] / 'verify_normal_p76.py'
spec = importlib.util.spec_from_file_location('normal_p76', MODULE)
normal = importlib.util.module_from_spec(spec)
spec.loader.exec_module(normal)

UID = [1, 1, 1, 3, 1, 1, 0x0123, 0x4567, 0x89ab, 0xcdef, 0x1357, 0x9bdf, 0x61, 1, 0]


def sample_fixture(first_generation=10, second_generation=12):
    samples = []
    for i, (address, quantity) in enumerate(normal.READS):
        words = [0] * quantity
        if address == 0:
            words[:2] = [888, 76]
            words[2:6] = [42, 1, 1, 100 if i == 0 else 108]
            words[9], words[11] = (20 if i == 0 else 58), 1
        elif address == 68:
            words = [1, 1, 15, 0]
        elif address == 72:
            words = UID[:]
        elif address == 180:
            words = [first_generation if i < normal.SECOND_SNAPSHOT_INDEX else second_generation] * 16
        elif address == 140:
            words = [1] * 16
            words[10:12] = [4, 4]  # explicitly unsupported brine pump fields
        elif address in (100, 116):
            values = [-300, -400, 100, 3500, 3000, 500, 1500, 5225,
                      42, 1, 0, 0, 1, 3, 5100, 700]
            start = (address - 100) // 2
            words = []
            for value in values[start:start + 8]:
                words.extend([(value & 0xffffffff) >> 16, value & 65535])
        elif address == 160:
            words = [1] * 16
        samples.append({'timestamp': f'test-{i:02d}', 'address': address,
                        'quantity': quantity, 'values': words})
    return samples


class VerifyNormalTests(unittest.TestCase):
    def test_fixed_requests_are_slave_one_fc04_crc_valid(self):
        self.assertEqual(len(normal.READS), 20)
        for address, quantity in normal.READS:
            frame = normal.request_frame(address, quantity)
            self.assertEqual(frame[:2], b'\x01\x04')
            self.assertEqual(len(frame), 8)
            self.assertEqual(normal.crc16(frame), 0)
            self.assertTrue(1 <= quantity <= 16)
        with self.assertRaises(ValueError):
            normal.request_frame(300, 8)
        with self.assertRaises(ValueError):
            normal.request_frame(0, 65535)

    def test_reply_requires_exact_address_function_length_and_crc(self):
        body = b'\x01\x04\x04\x03\x78\x00\x4c'
        reply = body + normal.crc16(body).to_bytes(2, 'little')
        self.assertEqual(normal.decode_reply(reply, 2), [888, 76])
        for bad in (reply[:-1], reply + b'\0', b'\x02' + reply[1:], reply[:-1] + bytes([reply[-1] ^ 1])):
            with self.assertRaises(ValueError):
                normal.decode_reply(bad, 2)

    def test_uid_and_switch_validation(self):
        unit = normal.decode_unit_identity(UID)
        self.assertEqual(unit['uid96'], '0123456789abcdef13579bdf')
        self.assertEqual(unit['raw_dip'], 0x61)
        for index in (*range(6), 12, 13, 14):
            words = UID[:]
            words[index] ^= 1
            with self.assertRaises(ValueError):
                normal.decode_unit_identity(words)
        for fill in (0, 65535):
            words = UID[:]
            words[6:12] = [fill] * 6
            with self.assertRaises(ValueError):
                normal.decode_unit_identity(words)

    def test_unchanged_values_with_advancing_generations_verify_cn105(self):
        evidence = normal.summarize_samples(sample_fixture())
        self.assertTrue(evidence['cn105_updates_verified'])
        self.assertEqual(evidence['required_source_registers'], [183, 184, 188])
        self.assertEqual(evidence['replies_delta_mod65536'], 8)
        self.assertEqual(evidence['snapshots'][1]['samples']['flow_cC']['value'], 3500)
        self.assertEqual(evidence['snapshots'][1]['samples']['brine_in_cC']['value'], -300)
        self.assertIsNone(evidence['snapshots'][1]['samples']['brine_pump_running']['value'])

    def test_unchanged_generations_are_inconclusive(self):
        evidence = normal.summarize_samples(sample_fixture(10, 10))
        self.assertFalse(evidence['cn105_updates_verified'])
        self.assertFalse(evidence['telemetry_generation_change_observed'])

    def test_wrap_and_reset_distinguished(self):
        self.assertTrue(normal.summarize_samples(sample_fixture(65535, 1))['cn105_updates_verified'])
        self.assertFalse(normal.summarize_samples(sample_fixture(100, 1))['cn105_updates_verified'])

    def test_brackets_reject_mixed_temperature_and_derived_power(self):
        samples = sample_fixture()
        samples[17]['values'][3] += 1
        evidence = normal.summarize_samples(samples)
        self.assertFalse(evidence['cn105_updates_verified'])
        values = evidence['snapshots'][1]['samples']
        self.assertIsNone(values['flow_cC']['value'])
        self.assertIsNone(values['heat_W']['value'])

    def test_stale_or_disconnected_sources_do_not_verify_cn105(self):
        for status in (0, 2, 3, 4):
            samples = sample_fixture()
            samples[12]['values'][8] = samples[16]['values'][8] = status
            self.assertFalse(normal.summarize_samples(samples)['cn105_updates_verified'])
        samples = sample_fixture()
        samples[10]['values'][11] = 0
        self.assertFalse(normal.summarize_samples(samples)['cn105_updates_verified'])

    def test_second_uid_or_identity_change_rejects(self):
        for index, word in ((19, 6), (18, 0), (18, 3), (10, 1)):
            samples = sample_fixture()
            samples[index]['values'][word] ^= 1
            with self.assertRaises(ValueError):
                normal.summarize_samples(samples)
        with self.assertRaises(ValueError):
            normal.summarize_samples(sample_fixture()[:-1])

    def test_no_confirmation_means_no_rpc_or_output_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch.object(normal, 'ROOT', Path(tmp)), patch.object(normal, 'urlopen') as rpc:
                with self.assertRaises(ValueError):
                    normal.run(False)
                rpc.assert_not_called()
                self.assertEqual(list(Path(tmp).iterdir()), [])

    def test_generated_engine_has_only_the_reviewed_wire_frames(self):
        source = normal.script_source()
        encoded = re.findall(r'"((?:\\x[0-9a-f]{2}){8})"', source)
        self.assertEqual(len(encoded), len(normal.READS))
        frames = [bytes(int(word, 16) for word in re.findall(r'\\x([0-9a-f]{2})', value)) for value in encoded]
        self.assertEqual(frames, [normal.request_frame(*entry) for entry in normal.READS])
        self.assertIn('index>=20', source)
        self.assertIn('Timer.set(120000,false', source)
        self.assertNotIn('Serial.SetConfig', source)
        self.assertNotIn('Switch.Set', source)


if __name__ == '__main__':
    unittest.main()
