"""Bounded read-only P0076 DIP/UID and telemetry verification after a confirmed normal-mode restart.

This file has no import-time network or filesystem side effects. Execution requires
the operator to have physically selected DIP10000110 and restarted Procon first.
Only fixed FC04 requests are transmitted. Serial.GetConfig remains unchanged;
UART baud is changed only at runtime and restored to115200 before stopping slot8.
"""
import argparse
import base64
import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
HOST = 'DEVICE_HOST'
SLOT = 8
# Exactly twenty addressed FC04 transactions; no write/control opcode is generated.
READS = ((0, 16), (68, 4), (72, 15),
         (180, 16), (140, 16), (100, 16), (116, 16), (160, 16), (140, 16), (180, 16),
         (0, 16), (180, 16), (140, 16), (100, 16), (116, 16), (160, 16), (140, 16), (180, 16),
         (68, 4), (72, 15))
SECOND_SNAPSHOT_INDEX = 10
SAMPLE_INTERVAL_SECONDS = 30
NAMES = ('brine_in_cC', 'brine_out_cC', 'brine_delta_cC', 'flow_cC', 'return_cC',
         'water_delta_cC', 'flow_cL_min', 'heat_W', 'compressor_Hz', 'compressor_running',
         'brine_pump_running', 'brine_pump_step', 'water_pump_running', 'water_pump_level',
         'dhw_cC', 'outdoor_cC')
SNAPSHOT_INDICES = ((0, 3, 4, 5, 6, 7, 8, 9), (10, 11, 12, 13, 14, 15, 16, 17))


def utc():
    return datetime.now(timezone.utc).isoformat()


def crc16(data):
    value = 0xffff
    for byte in data:
        value ^= byte
        for _ in range(8):
            value = (value >> 1) ^ 0xa001 if value & 1 else value >> 1
    return value


def request_frame(address, quantity):
    if (address, quantity) not in READS:
        raise ValueError('Only the fixed read-only verification plan is allowed')
    payload = b'\x01\x04' + address.to_bytes(2, 'big') + quantity.to_bytes(2, 'big')
    return payload + crc16(payload).to_bytes(2, 'little')


def decode_reply(raw, quantity):
    if len(raw) != 5 + 2 * quantity or raw[:3] != bytes((1, 4, 2 * quantity)) or crc16(raw):
        raise ValueError('Expected exact slave1 FC04 response with valid CRC16: ' + raw.hex())
    return [int.from_bytes(raw[i:i + 2], 'big') for i in range(3, 3 + 2 * quantity, 2)]


def decode_unit_identity(words):
    """Validate this isolated address-1 P76 boot configuration, without I/O."""
    if (not isinstance(words, list) or len(words) != 15
            or any(type(word) is not int or not 0 <= word <= 65535 for word in words)):
        raise ValueError('Expected fifteen uint16 identity words at FC04 offsets72..86')
    if words[:6] != [1, 1, 1, 3, 1, 1] or words[12:] != [0x61, 1, 0]:
        raise ValueError('Expected stable valid hardware DIP10000110/raw0x61/address1 and valid UID')
    uid_words = [(words[index] << 16) | words[index + 1] for index in (6, 8, 10)]
    if uid_words == [0, 0, 0] or uid_words == [0xffffffff, 0xffffffff, 0xffffffff]:
        raise ValueError('Invalid all-zero/all-FF factory UID')
    return {'schema': 1, 'effective_address': 1, 'configured_address': 1,
            'source': 3, 'configuration_valid': True, 'uid_valid': True,
            'uid_words': uid_words, 'uid96': ''.join(f'{word:08x}' for word in uid_words),
            'raw_dip': 0x61, 'stable': True, 'rejection_reason': 0}


def summarize_samples(samples):
    """Decode only the fixed completed plan; bracket changing telemetry values."""
    if len(samples) != len(READS):
        raise ValueError('Incomplete fixed FC04 sample plan')
    for entry, (address, quantity) in zip(samples, READS):
        if (entry.get('address'), entry.get('quantity')) != (address, quantity):
            raise ValueError('Unexpected sample ordering')
        words = entry.get('values')
        if (not isinstance(words, list) or len(words) != quantity
                or any(type(word) is not int or not 0 <= word <= 65535 for word in words)):
            raise ValueError('Unexpected sample word shape')
    unit = decode_unit_identity(samples[2]['values'])
    if unit != decode_unit_identity(samples[19]['values']):
        raise ValueError('DIP/UID changed during read-only verification')
    for index in (1, 18):
        if samples[index]['values'] != [1, 1, 15, 0]:
            raise ValueError('P0076 revision/API/features or idle control state mismatch')
    snapshots = []
    for indices in SNAPSHOT_INDICES:
        baseline, before, status_before, low, high, ages, status_after, after = [samples[i]['values'] for i in indices]
        if baseline[:2] != [888, 76]:
            raise ValueError('P0076 marker mismatch')
        values, decoded = low + high, {}
        for i, name in enumerate(NAMES):
            constituents = {2: (0, 1), 5: (3, 4), 7: (3, 4, 6), 9: (8,)}.get(i, ())
            coherent = all(before[j] == after[j] and status_before[j] == status_after[j]
                           for j in (i, *constituents))
            raw = (values[2 * i] << 16) | values[2 * i + 1]
            signed = raw - (1 << 32) if raw & (1 << 31) else raw
            decoded[name] = {'value': signed if coherent and status_after[i] == 1 else None,
                             'coherent': coherent, 'status': status_after[i],
                             'age_s': ages[i], 'generation': after[i]}
        snapshots.append({'timestamp': samples[indices[-1]]['timestamp'],
                          'cn105_linked': baseline[11] == 1, 'cn105_hz_valid': baseline[3] == 1,
                          'cn105_hz_age_s': baseline[4], 'cn105_replies': baseline[5],
                          'cn105_errors': baseline[7], 'cn105_uart_errors': baseline[12],
                          'uptime_s': baseline[9], 'generations': after, 'samples': decoded,
                          'atomic': False, 'hardware_calibrated': False})
    first, second = snapshots
    deltas = [(b - a) % 65536 for a, b in zip(first['generations'], second['generations'])]
    advanced = [180 + index for index, delta in enumerate(deltas) if 0 < delta < 32768]
    required = (3, 4, 8)  # independent temperature source and compressor Hz source
    fresh_sources = all(second['samples'][NAMES[i]]['value'] is not None for i in required)
    advancing_sources = all(0 < deltas[i] < 32768 for i in required)
    return {'unit_identity': unit, 'snapshots': snapshots,
            'telemetry_generation_change_observed': bool(advanced), 'generation_deltas': deltas,
            'advancing_generation_registers': advanced,
            'required_source_registers': [180 + i for i in required],
            'required_sources_fresh': fresh_sources, 'required_sources_advanced': advancing_sources,
            'cn105_updates_verified': bool(second['cn105_linked'] and fresh_sources and advancing_sources),
            'replies_delta_mod65536': (second['cn105_replies'] - first['cn105_replies']) % 65536}


def script_source():
    frames = ['"' + ''.join('\\x%02x' % byte for byte in request_frame(*entry)) + '"' for entry in READS]
    return '''let normalUart=UART.get(0);
if(!normalUart)throw new Error('UART_UNAVAILABLE');
let normalFrames=[FRAMES];
let normalIndex=0,normalActive=false,normalWaiting=false,normalRestored=false;
let normalRaw='',normalReceived=0,normalSent=0,normalStray=0,normalError='';
function normalRestore(){
  normalActive=false;normalWaiting=false;
  normalUart.configure({baud:115200,format:'8N1'});
  normalRestored=true;
  return JSON.stringify({restored:true,baud:115200,format:'8N1'});
}
normalUart.recv(function(data){
  if(!normalWaiting){normalStray+=data.length;return;}
  normalReceived+=data.length;
  normalRaw+=data.slice(0,64-normalRaw.length);
  if(normalReceived>64)normalError='RX_OVERFLOW';
});
function normalBegin(){
  if(normalActive||normalIndex!==0||normalRestored)throw new Error('BEGIN_ONCE');
  normalUart.configure({baud:9600,format:'8N1'});
  normalActive=true;
  return JSON.stringify({baud:9600,format:'8N1',read_only:true});
}
function normalRead(index){
  if(!normalActive||normalRestored||normalWaiting||normalError||normalStray||index!==normalIndex||index>=READ_COUNT)throw new Error('READ_GATE');
  normalRaw='';normalReceived=0;normalSent=0;normalWaiting=true;normalIndex++;
  normalSent=normalUart.send(normalFrames[index]);
  if(normalSent!==8)normalError='SHORT_SEND';
  return JSON.stringify({index:index,sent:normalSent});
}
function normalResult(index){
  if(!normalWaiting||index!==normalIndex-1)throw new Error('RESULT_GATE');
  normalWaiting=false;
  return JSON.stringify({index:index,sent:normalSent,received:normalReceived,base64:btoa(normalRaw),stray:normalStray,error:normalError});
}
Timer.set(120000,false,function(){normalRestore();Shelly.call('Script.Stop',{id:8});});
'''.replace('FRAMES', ','.join(frames)).replace('READ_COUNT', str(len(READS)))


def run(operator_normal_boot_confirmed):
    if not operator_normal_boot_confirmed:
        raise ValueError('Execution requires fresh operator confirmation of DIP10000110 and power cycle')
    out = ROOT / (datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ') + '-p76-normal-verification')
    out.mkdir(mode=0o700, exist_ok=False)

    def save(name, value):
        path = out / name
        path.write_text(json.dumps(value, indent=2) + '\n')
        path.chmod(0o600)

    def record(value):
        path = out / 'rpc.jsonl'
        with path.open('a') as stream:
            stream.write(json.dumps({'timestamp': utc(), **value}) + '\n')
        path.chmod(0o600)

    def rpc(method, params=None):
        params = params or {}
        shown = dict(params)
        if 'code' in shown:
            shown['code'] = 'sha256:' + hashlib.sha256(shown['code'].encode()).hexdigest()
        record({'method': method, 'params': shown})
        request = Request('http://' + HOST + '/rpc',
                          data=json.dumps({'id': 1, 'method': method, 'params': params}).encode(),
                          headers={'Content-Type': 'application/json'})
        with urlopen(request, timeout=10) as response:
            raw = response.read(65537)
        if len(raw) > 65536:
            raise RuntimeError('RPC response exceeds bound')
        reply = json.loads(raw)
        if 'error' in reply:
            record({'error': reply['error']})
            raise RuntimeError(method + ': ' + str(reply['error']))
        result = reply['result']
        logged = result
        if method == 'Script.GetCode':
            logged = {**result, 'data': 'sha256:' + hashlib.sha256(result['data'].encode()).hexdigest()}
        record({'result': logged})
        return result

    def evaluate(code):
        record({'eval_code': code})
        return json.loads(rpc('Script.Eval', {'id': SLOT, 'code': code})['result'])

    def identity(running):
        device = rpc('Shelly.GetDeviceInfo')
        if device['id'] != 'shellypro2-80f3dac8bfec' or device['model'] != 'SPSW-202XE12UL':
            raise RuntimeError('Unexpected Shelly identity')
        serial = rpc('Serial.GetConfig', {'id': 100})
        if serial['mode'] != 'js_uart' or serial['serial'] != {'baud': 115200, 'format': '8N1'}:
            raise RuntimeError('Unexpected persistent Serial configuration')
        scripts = rpc('Script.List')['scripts']
        own = [entry for entry in scripts if entry['id'] == SLOT]
        if len(own) != 1 or own[0]['name'] != 'P0075 write reference':
            raise RuntimeError('Unexpected owned script slot')
        if not all(entry['enable'] is False and entry['running'] == (running and entry['id'] == SLOT) for entry in scripts):
            raise RuntimeError('Another script is enabled/running, or owned script state differs')
        relays = [rpc('Switch.GetStatus', {'id': index})['output'] for index in (0, 1)]
        if relays != [False, False]:
            raise RuntimeError('Unexpected relay output state')
        return {'timestamp': utc(), 'device': device, 'serial': serial, 'scripts': scripts, 'relays': relays}

    def read_code():
        source = ''
        while True:
            part = rpc('Script.GetCode', {'id': SLOT, 'offset': len(source), 'len': 1024})
            source += part['data']
            if len(source) >= 18000:
                raise RuntimeError('Script size exceeds bound')
            if not part['left']:
                return source
            if not part['data']:
                raise RuntimeError('Script read stalled')

    save('scope.json', {'timestamp': utc(), 'operator_normal_boot_confirmed': True,
         'operator_dip': '10000110', 'plan': [{'address': a, 'quantity': n, 'tx_hex': request_frame(a, n).hex()} for a, n in READS],
         'constraints': 'Only FC04; runtime UART9600 restored115200; no persistent serial changes/reboot/control/erase/program'})
    source = script_source()
    save('source-manifest.json', {'sha256': hashlib.sha256(source.encode()).hexdigest(), 'length': len(source)})
    (out / 'normal-read-only-engine.js').write_text(source)
    (out / 'normal-read-only-engine.js').chmod(0o600)
    samples, changed, complete = [], False, False
    outcome = {'timestamp': utc(), 'normal_boot_verified': False, 'all_frames_crc_valid': False,
               'telemetry_generation_change_observed': False, 'persistent_serial_modified': False}
    failure = None
    try:
        preflight = identity(False)
        save('preflight.json', preflight)
        previous = out / 'prior-shelly-script.js'
        previous.write_text(read_code())
        previous.chmod(0o600)
        changed = True
        for offset in range(0, len(source), 1024):
            rpc('Script.PutCode', {'id': SLOT, 'code': source[offset:offset + 1024], 'append': offset != 0})
        if read_code() != source:
            raise RuntimeError('Uploaded source differs')
        rpc('Script.Start', {'id': SLOT})
        time.sleep(.3)
        health = rpc('Script.GetStatus', {'id': SLOT})
        if not health['running'] or health.get('errors') or health['mem_free'] < 8192:
            raise RuntimeError('Owned script unhealthy')
        identity(True)
        configured = evaluate('normalBegin()')
        if configured != {'baud': 9600, 'format': '8N1', 'read_only': True}:
            raise RuntimeError('Runtime UART setup unconfirmed')
        save('volatile-uart-start.json', configured)
        read_deadline = time.monotonic() + 100
        time.sleep(.25)
        for index, (address, quantity) in enumerate(READS):
            if index == SECOND_SNAPSHOT_INDEX:
                print(json.dumps({'phase': 'waiting_for_next_telemetry_snapshot', 'seconds': SAMPLE_INTERVAL_SECONDS}), flush=True)
                time.sleep(SAMPLE_INTERVAL_SECONDS)
            if time.monotonic() >= read_deadline:
                raise RuntimeError('Bounded normal-read window expired; stopping before the120s script timeout')
            save('%02d-intent.json' % (index + 1), {'timestamp': utc(), 'address': address, 'quantity': quantity,
                 'tx_hex': request_frame(address, quantity).hex()})
            sent = evaluate('normalRead(%d)' % index)
            if sent != {'index': index, 'sent': 8}:
                raise RuntimeError('Request send was not exactly eight bytes')
            time.sleep(1.2)
            result = evaluate('normalResult(%d)' % index)
            save('%02d-raw-result.json' % (index + 1), {'timestamp': utc(), **result})
            raw = base64.b64decode(result['base64'], validate=True)
            if result['index'] != index or result['sent'] != 8 or result['received'] != len(raw) or result['stray'] or result['error']:
                raise RuntimeError('Unexpected transaction state')
            words = decode_reply(raw, quantity)
            sample = {'timestamp': utc(), 'address': address, 'quantity': quantity, 'rx_hex': raw.hex(), 'values': words, 'crc16_valid': True}
            save('%02d-result.json' % (index + 1), sample)
            samples.append(sample)
            print(json.dumps(sample), flush=True)
            if index in (0, 10) and words[:2] != [888, 76]:
                raise RuntimeError('Unexpected P0076 firmware marker')
            if index in (1, 18) and words != [1, 1, 15, 0]:
                raise RuntimeError('Unexpected P0076 revision/API/features or non-idle control state')
            if index in (2, 19):
                unit = decode_unit_identity(words)
                if index == 19 and unit != decode_unit_identity(samples[2]['values']):
                    raise RuntimeError('DIP/UID changed during read-only verification')
            time.sleep(.15)
        evidence = summarize_samples(samples)
        outcome.update(normal_boot_verified=True, all_frames_crc_valid=True, **evidence,
                       note='Only FC04 was sent. Multi-block telemetry is generation/status bracketed. '
                            'A missing fresh sample or unchanged generation is inconclusive, not proof of firmware failure. '
                            'UID/DIP observation covers this isolated address-1 unit; shared-bus operation is not tested.')
        complete = True
    except BaseException as exc:
        failure = exc
        outcome['error'] = str(exc)
    finally:
        cleanup_errors = []
        restored = False
        if changed:
            # Attempt baud restoration while the owned script still runs, even if
            # upload/start/configuration or a transaction failed partway through.
            try:
                current = rpc('Script.GetStatus', {'id': SLOT})
                if current['running']:
                    restored = evaluate('normalRestore()') == {'restored': True, 'baud': 115200, 'format': '8N1'}
                else:
                    cleanup_errors.append({'step': 'runtime_uart_restore', 'error': 'Owned script already stopped; volatile UART restoration not independently confirmed'})
            except Exception as exc:
                cleanup_errors.append({'step': 'runtime_uart_restore', 'error': str(exc)})
            for method, params in [('Script.Stop', {'id': SLOT}), ('Script.SetConfig', {'id': SLOT, 'config': {'enable': False}})]:
                try:
                    rpc(method, params)
                except Exception as exc:
                    cleanup_errors.append({'step': method, 'error': str(exc)})
        stopped_verified = False
        try:
            final = identity(False)
            save('final-state.json', final)
            stopped_verified = True
        except Exception as exc:
            cleanup_errors.append({'step': 'final_state', 'error': str(exc)})
        outcome.update(timestamp=utc(), complete=complete, samples=samples,
                       runtime_uart_115200_restored=restored, all_scripts_stopped_disabled=stopped_verified,
                       cleanup_errors=cleanup_errors)
        save('outcome.json', outcome)
        print(json.dumps({'out': str(out), **outcome}), flush=True)
        if failure is None and (cleanup_errors or not restored or not stopped_verified):
            failure = RuntimeError('Cleanup not completely verified; inspect outcome.json')
    if failure is not None:
        raise failure
    return outcome


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--operator-normal-boot-confirmed', action='store_true',
                        help='Only after operator confirms DIP10000110 and Procon power cycle')
    arguments = parser.parse_args()
    if not arguments.operator_normal_boot_confirmed:
        parser.error('Fresh operator confirmation is required before normal-mode UART reads')
    run(arguments.operator_normal_boot_confirmed)
