"""P0078 passive baseline; no pump writes or control arming."""
import sys,time,json
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'P0076/effect-trial'))
from live_bus import Session
from run_effect_trial import read_snapshot,check_continuity,native_gate

def main():
    out=Path(__file__).parent/('baseline-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    s=Session(out,ttl_s=900); previous=None; start=time.monotonic()
    try:
        s.start()
        while time.monotonic()-start<620:
            r=read_snapshot(s)
            if previous:check_continuity(previous,r)
            errors=[]
            try:native_gate(r,initial=True)
            except Exception as e:errors.append(str(e))
            if r['control']['state']!=0 or r['control']['saved']:errors.append('Controller not idle')
            hz=r['telemetry'][8]
            if hz['value'] is None or hz['value']<=0 or hz['status']!=1 or hz['age_s']>20:errors.append('No fresh positive Hz')
            row={'elapsed_s':round(time.monotonic()-start,1),'Hz':hz,'flow':r['telemetry'][3],'return':r['telemetry'][4],'native':r['native'],'water':r['feedback'],'gate_errors':errors}
            s.log('baseline_sample',row); print(json.dumps(row),flush=True)
            previous=r;time.sleep(3)
        s.save('outcome.json',{'status':'OBSERVED_ONLY','duration_s':time.monotonic()-start})
    finally:print(json.dumps({'cleanup':s.cleanup(),'out':str(out)}),flush=True)
if __name__=='__main__':main()
