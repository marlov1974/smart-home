"""P0078 supervised authorized +2C trial; no network on import."""
import argparse,json,signal,time
from pathlib import Path
from step_scope import StepSession
from run_effect_trial import Supervisor,GateError,native_gate,next_sequence,encode,feedback_ready,signed32

def primary_sample(bus):
    for attempt in range(3):
        started=time.monotonic()
        before=bus.read(183,6); status_before=bus.read(143,6); values=bus.read(106,12)
        status=bus.read(143,6); age=bus.read(163,6); after=bus.read(183,6)
        points={i+3:{'value':signed32(values[2*i],values[2*i+1]),'status':status[i],
                     'age_s':age[i], 'generation':after[i], 'coherent':before[i]==after[i] and status_before[i]==status[i]}
                for i in (0,1,3,5)}
        result={'start_monotonic_s':started,'end_monotonic_s':time.monotonic(),'points':points}
        bus.log('primary_sample',result)
        if all(p['coherent'] and p['status']==1 and p['age_s']<=20 and p['value']!=-2147483648 for p in points.values()):return result
    raise GateError('No coherent fresh primary sample in three reads')

class StepSupervisor(Supervisor):
    def capture(self):
        s=super().capture()
        if getattr(self,'restoring',False):return s
        primary=primary_sample(self.bus)
        for i,p in primary['points'].items():s['telemetry'][i]=p
        s['primary_acquisition']=primary
        self.bus.log('qualified_snapshot',s)
        return s
    def restore(self):
        # Failed process telemetry must not obstruct AUTO and native readback.
        self.restoring=True
        return super().restore()

def baseline_gate(path):
    rows=[json.loads(x)['data'] for x in (path/'events.jsonl').read_text().splitlines() if json.loads(x)['kind']=='baseline_sample']
    if len(rows)<20 or rows[-1]['elapsed_s']-rows[0]['elapsed_s']<600:raise GateError('Ten minute baseline missing')
    if any(r['gate_errors'] for r in rows):raise GateError('Running baseline interrupted')
    # Conservative operational stability gate, not a model of native FTC.
    tail=[r for r in rows if r['elapsed_s']>=rows[-1]['elapsed_s']-300]
    hz=[r['Hz']['value'] for r in tail];temp=[r['flow']['value'] for r in tail]
    if max(hz)-min(hz)>6 or max(temp)-min(temp)>100:raise GateError('Baseline not stable within6Hz/1C for final5min')
    cleanup=json.loads((path/'cleanup.json').read_text())
    if cleanup['errors']:raise GateError('Prior transport cleanup unverified')
    if time.time()-(path/'outcome.json').stat().st_mtime>180:raise GateError('Baseline older than3min')
    return rows[-1]

def safety(s,target):
    native_gate(s)
    if s['meta'][11]!=1:raise GateError('CN105 link lost')
    for i in (3,4,6,8):
        p=s['telemetry'][i]
        if p['status']!=1 or p['value'] is None or p['age_s']>20:raise GateError('Missing/stale primary data')
    if s['telemetry'][3]['value']>4000:raise GateError('Supply above40C')
    if s['telemetry'][8]['value']<=0:raise GateError('Native compressor stop; end step without restart attempts')
    if s['native']['mode']!=1 or s['native']['flow']!=target:raise GateError('Fixed flow readback lost')
    c=s['control']
    if c['state']!=4 or c['saved']!=1 or c['mode']!=2 or c['error'] not in (0,2):raise GateError('Control ownership lost')

def execute(sup,target):
    s=sup.preflight()
    if target!=sup.original['flow']+200:raise GateError('Target no longer equals current baseline+2C')
    if s['telemetry'][8]['value'] is None or s['telemetry'][8]['value']<=0:raise GateError('Compressor stopped')
    sup.bus.arm_control()
    words=lambda seq:encode(seq,'fixed-flow',flow=target/100,lease=180)['words']
    sup.possible_acceptance=True
    if not sup.send(words(sup.sequence)):raise GateError('Initial command busy')
    until=time.monotonic()+90
    while time.monotonic()<until:
        s=sup.capture();c=s['control']
        if c['state']==4 and c['accepted']==c['applied']==sup.sequence:
            if any(c['original_'+k]!=v for k,v in sup.original.items()):raise GateError('Snapshot differs from original')
            if s['native']['mode']==1 and s['native']['flow']==target:
                safety(s,target);break
        if c['state'] in (0,5,6):raise GateError('Apply aborted')
        time.sleep(3)
    else:raise GateError('Readback deadline')
    sup.bus.save('active-start.json',s)
    start=renewed=time.monotonic()
    print(json.dumps({'event':'VERIFIED_STEP','target_cC':target,'original':sup.original,'hold_s':900}),flush=True)
    while time.monotonic()-start<900:
        s=sup.capture();safety(s,target);c=s['control']
        if c['accepted']!=sup.sequence:raise GateError('Other control owner')
        print(json.dumps({'event':'step_sample','elapsed_s':round(time.monotonic()-start),'hz':s['telemetry'][8]['value'],'flow_cC':s['telemetry'][3]['value'],'return_cC':s['telemetry'][4]['value'],'water_w':s['feedback']['short_w'],'lease_s':c['lease_s']}),flush=True)
        sup.bus.log('step_sample',s)
        if time.monotonic()-renewed>=60:
            if not feedback_ready(s):
                if time.monotonic()-renewed>=90:raise GateError('No valid feedback within renewal deadline')
                time.sleep(3);continue
            seq=next_sequence(sup.sequence)
            if not sup.send(words(seq)):raise GateError('Renewal busy')
            sup.sequence=seq
            v=sup.capture();safety(v,target)
            if v['control']['applied']!=seq or v['control']['accepted']!=seq:raise GateError('Renewal readback missing')
            renewed=time.monotonic()
        time.sleep(3)
    return {'completed_hold':True}

def main():
    p=argparse.ArgumentParser();p.add_argument('--baseline',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--target',type=int,required=True);p.add_argument('--execute',action='store_true');a=p.parse_args()
    baseline_gate(a.baseline)
    if not a.execute:raise SystemExit('Explicit --execute required')
    bus=StepSession(a.output,a.target);sup=StepSupervisor(bus);out={'completed_hold':False,'other_vp':'Operator reports enabled target27C; not independently observed'}
    def stop(signum,frame):raise KeyboardInterrupt('Operator stop')
    signal.signal(signal.SIGTERM,stop)
    try:
        bus.start();out.update(execute(sup,a.target))
    except BaseException as e:out['error']=repr(e);print(json.dumps({'event':'STOP','reason':repr(e)}),flush=True)
    finally:
        # Ignore further TERM during bounded restore; hardware lease still expires.
        signal.signal(signal.SIGTERM,signal.SIG_IGN)
        try:
            out['restore']=sup.restore()
            if out['restore'].get('verified'):
                until=time.monotonic()+120
                while time.monotonic()<until:
                    r=sup.capture();bus.log('post_restore',r);time.sleep(3)
        except BaseException as e:out['restore_error']=repr(e)
        out['cleanup']=bus.cleanup();bus.save('outcome.json',out);print(json.dumps(out),flush=True)
if __name__=='__main__':main()
