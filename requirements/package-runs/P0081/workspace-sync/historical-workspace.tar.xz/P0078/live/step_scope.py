"""P0078 one frozen fixed-flow step. Import has no network effects."""
import sys
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'P0076/effect-trial'))
import live_bus

class StepSession(live_bus.Session):
    def __init__(self,out,target,ttl_s=2400):
        if type(target)is not int or not 3000<target<=3800:raise ValueError('Target boundary')
        self.target=target
        super().__init__(out,ttl_s)
    def validate(self,w):
        if len(w)!=8 or any(type(x)is not int or not 0<=x<=65535 for x in w) or w[0]!=0xc072 or not 1<=w[1]<=65535:raise ValueError('Shape')
        if w[2:] not in ([2,self.target,0,180,1,2],[1,0,0,0,0,2]):raise ValueError('Outside frozen step scope')
    def source(self,ttl):
        src=live_bus.bridge_source(ttl)
        start=src.index('   if(w[0]===49270)')
        end=src.index('n=8;',start)
        return src[:start]+'''   if(w[0]!==49266)throw new Error('MAGIC');
   if(w[2]===2){if(w[3]!==TARGET||w[4]!==0||w[5]!==180||w[6]!==1||w[7]!==2)throw new Error('STEP_SCOPE');}
   else if(w[2]===1){if(w[3]!==0||w[4]!==0||w[5]!==0||w[6]!==0||w[7]!==2)throw new Error('AUTO_SCOPE');}
   else throw new Error('MODE');'''.replace('TARGET',str(self.target))+src[end:]
    def start(self):
        source=self.source(self.ttl_s)
        with patch.object(live_bus,'bridge_source',lambda ttl:source):super().start()
    def arm_control(self):
        if not self.active or self.evaluate('trialArm()')!={'armed':True}:raise RuntimeError('Arm')
        self.armed=True;self.log('control_scope_armed',{'fixed_flow_cC':self.target,'lease_s':180,'auto_restore':True})
    def command(self,w):
        self.validate(w)
        with patch.object(live_bus,'validate_words',self.validate):return super().command(w)
