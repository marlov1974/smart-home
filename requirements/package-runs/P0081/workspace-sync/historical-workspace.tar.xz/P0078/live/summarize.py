"""P0078 evidence reducer. Reads only local JSONL; no device operations."""
import argparse,csv,hashlib,json
from pathlib import Path
from datetime import datetime

def summarize(source,dest):
    dest.mkdir(parents=True,exist_ok=True)
    events=[json.loads(x) for x in source.read_text().splitlines()]
    qualified={x['data']['monotonic_s'] for x in events if x['kind']=='qualified_snapshot'}
    kind='qualified_snapshot plus unmatched snapshot' if qualified else 'snapshot'
    rows=[];seen=set()
    for e in events:
        if e['kind'] not in ('snapshot','qualified_snapshot'):continue
        if e['kind']=='snapshot' and e['data']['monotonic_s'] in qualified:continue
        s=e['data'];t=s['telemetry'];n=s['native'];f=s['feedback']
        def val(i):
            p=t[i]
            return p['value'] if p['coherent'] and p['status']==1 and p['age_s']<=20 else None
        flow,ret,hz=val(3),val(4),val(8)
        key=tuple(t[i]['generation'] for i in (3,4,6,8))
        new=key not in seen;seen.add(key)
        target=n['flow'] if n['fresh09'] else None
        row={'utc':s['timestamp'],'monotonic_s':s['monotonic_s'],'capture_s':s['capture_s'],'new_primary_generation_tuple':new,'flow_cC':flow,'return_cC':ret,'hz':hz,'flow_cL_min':val(6),'target_cC':target,'eT_cC':target-flow if target is not None and flow is not None else None,'water_short_w':f['short_w'] if f['quality'] in (0,2) and f['last_age_s'] is not None and f['last_age_s']<=20 else None,'feedback_count':f['accepted_count'],'mode':n['mode'],'operating_mode':n['operating_mode'],'brine_in_cC':val(0),'brine_out_cC':val(1),'raw28':n['raw28'],'sequence':s['control']['accepted'],'lease_s':s['control']['lease_s'],'other_vp_measured':False}
        rows.append(row)
    if rows:
        with (dest/'samples.csv').open('w') as file:
            w=csv.DictWriter(file,fieldnames=rows[0],lineterminator="\n");w.writeheader();w.writerows(rows)
    fields=('hz','flow_cC','return_cC','water_short_w','target_cC')
    stats={k:{'count':len(v),'min':min(v) if v else None,'max':max(v) if v else None} for k in fields for v in [[r[k] for r in rows if r[k] is not None]]}
    report={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'snapshot_kind':kind,'captures':len(rows),'statistics':stats,'limitations':['Source generation deduplication is not proof of simultaneous native/primary measurements','Other VP not measured','Water power is uncalibrated, not electrical power or COP','Curve-to-fixed mode change confounds target step','Missing or incoherent fields remain null']}
    (dest/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    return report
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('dest',type=Path);a=p.parse_args();print(json.dumps(summarize(a.source,a.dest),indent=2))
