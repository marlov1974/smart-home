import copy,json,subprocess,tempfile,unittest
from pathlib import Path
from step_scope import StepSession
from run_step import safety,primary_sample,GateError,baseline_gate
from test_live_bus import NODE_RUNNER

class Tests(unittest.TestCase):
    def scope(self):
        s=object.__new__(StepSession);s.target=3100;return s
    def test_host_scope(self):
        s=self.scope();w=[0xc072,1,2,3100,0,180,1,2];s.validate(w);s.validate([0xc072,2,1,0,0,0,0,2])
        for i,v in [(0,0xc076),(1,0),(2,5),(3,3150),(4,5000),(5,900),(6,0),(7,3)]:
            bad=w.copy();bad[i]=v
            with self.assertRaises(ValueError):s.validate(bad)
    def test_device_scope(self):
        source=self.scope().source(120)
        custom=NODE_RUNNER[:NODE_RUNNER.index('tests[input.test]();')]+'''
const st=active();st.run('trialArm()');
for(const [i,value] of [[0,49270],[1,0],[2,5],[3,3150],[4,5000],[5,900],[6,0],[7,3]]) {
 const w=input.effect.slice();w[i]=value;assert.throws(()=>st.send(command(w)));
}
st.send(command());st.rx(frame([1,16,1,44,0,8]));st.send(command(input.auto));
'''
        r=subprocess.run(['node','-e',custom],input=json.dumps({'source':source,'effect':[0xc072,1,2,3100,0,180,1,2],'auto':[0xc072,2,1,0,0,0,0,2]}),text=True,capture_output=True)
        self.assertEqual(r.returncode,0,r.stderr)
    def test_primary_torn_rejected(self):
        class Bus:
            def __init__(self):self.g=0
            def read(self,a,n):
                if a==183:self.g+=1;return [self.g]*n
                return [1]*n
            def log(self,*x):pass
        with self.assertRaises(GateError):primary_sample(Bus())
    def test_safety(self):
        s={'native':{'fresh26':True,'fresh09':True,'fresh28':True,'power':1,'operating_mode':2,'mode':1,'flow':3100,'dhw':5200,'raw28':'28000000000000010001000000000000'},'meta':[0]*16,'telemetry':[{'value':26,'status':1,'age_s':2} for _ in range(20)],'control':{'state':4,'saved':1,'mode':2,'error':0}}
        s['meta'][11]=1;s['telemetry'][3]={'value':3200,'status':1,'age_s':2};safety(s,3100)
        for field,value in [('value',4100),('age_s',21),('status',0)]:
            t=copy.deepcopy(s);t['telemetry'][3][field]=value
            with self.assertRaises(GateError):safety(t,3100)
        s['telemetry'][8]['value']=0
        with self.assertRaises(GateError):safety(s,3100)
    def test_baseline_short_blocked(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'events.jsonl').write_text('')
            with self.assertRaises(GateError):baseline_gate(p)
if __name__=='__main__':unittest.main()
