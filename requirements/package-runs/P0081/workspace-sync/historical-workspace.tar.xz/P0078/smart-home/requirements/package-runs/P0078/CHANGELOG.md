# P0078 — in progress, physical attempt1 stopped safely

Added review/design/function design, primary-manual findings, sanitized baseline/step data and physical findings. Local supervised harness validates one frozen fixed-flow intent and AUTO, brackets primary generations, uses180s leases, verifies restoration and preserves raw evidence.36 offline tests passed. One physical FIXED_FLOW31C command followed by verified AUTO restoration. No15-minute hold,35C test, firmware update or identified FTC model. Other VP condition corrected to unknown current target/activity contribution. Remaining active trial blocked by transition and experiment-boundary questions; offline model work remains pending.

Files added: repository file index updated with this evidence. No commit/push or production deployment claimed. No global knowhow promotion yet; see findings.
