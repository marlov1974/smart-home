# P0078 attempts

2026-10-08 physical attempt1 in progress: read-only preflight and600s baseline before the approved +2C/15minute step. Other pump operator-reported enabled27C. Host tests:31 existing transport/supervisor regressions passed;5 new fixed-step scope/gate tests passed. Shelly mJS transport compilation occurs at Session.start before arming. A local sandbox initially rejected the new baseline runner before any device call; rerun with network approval, not a hardware failure. No temperature write yet at this entry.

Operator can request stop in conversation; supervisor receives SIGTERM and restores through AUTO where identity/ownership remains known. Independent180s firmware lease expires without further host renewal. MCU-reset restoration remains unsupported. Device script TTL2400s is longer than test+restore; it only restores UART and stops the script, and is not claimed to restore pump settings.
