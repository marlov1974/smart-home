# P0078 physical attempt1 — STOP, restored

2026-10-08. User authorized starting the +2C trial and later requested tests above33C after observing actual supply already32.5–33C. A31C command was dispatched during cancellation handling;35C was **not** sent. Do not repeat31C.

Baseline:45 captures over614.9s between first/last observations;26Hz throughout, flow32–32.5C, native curve2 and reported target29C. Only9 primary snapshots passed broad generation-coherence checks; all45 filtered water-power observations were qualified, range2743–3338W. Raw values remain locally preserved; incoherent samples are null in sanitized output. At preflight narrow coherent samples showed33C/26Hz. Not an isolated fixed-mode temperature-step baseline.

## Observed timeline (UTC; local time UTC+2)

-06:37:18.364701: FC16 sequence9 FIXED_FLOW31C,180s lease dispatched. Prior baseline mode2/target29C; no active controller snapshot.
-06:37:32.288312: qualified snapshot mode1, still reported target29C, native operating mode0, supply33C,26Hz.
-06:37:48.032488: mode1/target31C verified, native operating mode0, supply32.5C,26Hz. Supervisor rejected continuing because native space-heating condition was lost.15-minute hold never started.
-06:37:58.707403: AUTO sequence10 dispatched.
-06:38:12.811873: restored mode2/target29C verified; snapshot0/touched0, restoration count1→2. Original power1/DHW52C/boost0 preserved.
-06:38:25: compressor0Hz observed. Two-minute post-restore observation completed; transport cleanup successful, runtime UART restored, all scripts stopped and both Shelly relays remained off. No firmware flash, service change or retry/start request.

## Interpretation and blockers

The mode change became visible before the higher target, and native heating ended during that transition. This supports a mode/target-transition problem as a candidate, not proof of a specific temperature threshold. Local P76 control source likewise schedules MODE before FLOW for ordinary FIXED_FLOW; EFFECT uses another path. The logs do not isolate whether mode switching, an internal threshold, external demand, or combined thermal behavior caused the stop.

Other VP was initially reported enabled at27C, then operator corrected that assumption: it runs the same heating/pump operation and current target is unknown. Its contribution is unmeasured. Therefore no claim of single-pump thermal isolation, continuous6kW capability, integral control, or a10minute restart lockout is supported.

**STOP for further active rounds:** resolve/verify the mode+target transition without the low intermediate target; wait for stable native running baseline and establish other VP conditions before the revised35C round. No blind raising during the stopped state. P78 full model comparison and offline simulation remain unfinished; this is physical attempt evidence, not package acceptance.

## Evidence

Local raw paths: P0078/live/baseline-20261008T062538Z and P0078/live/step-20261008T0636Z. Sanitized CSV/report files under baseline/ and step/ carry raw SHA256 provenance. Source/harness and exact transactions remain local. Transport+supervisor31 offline regressions and new scope/gate5 tests pass. Model identification INCONCLUSIVE.

Knowhow promotion considered: mode-transition intermediate targets and unknown shared-system activity deserve a reusable lesson, but causal interpretation needs further verification; intentionally retained as package evidence now.
