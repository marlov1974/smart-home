# P0078 function design

- passive_baseline.main(): creates a Session, reads snapshots for600s, logs raw/normalized records, always releases UART; never arms pump control. Reuses read_snapshot/check_continuity/native_gate. Freshness and runtime gate evidence inspected before active step.
- step_scope.validate_words(words): pure strict frozen fixed-flow intent180s or AUTO; rejects all other writes. Tests valid/invalid modes, bounds and versions.
- step_scope.bridge_source(ttl): derives audited transport with equivalent device-side allowlist, preserving CRC/ownership/read bounds.
- run_step.main(): baseline gate, single-step dispatch, readback, bounded lease renewal, restore and post-observation. Hardware side effects restricted to authorized control plus temporary transport script. Event log contains exact command and result. Snapshot/continuity and restore tests required.

No existing firmware functions change. Implementation refinements must be recorded before code.

Refinement before active execution: `primary_sample(bus)` performs a narrow generation bracket over flow/return/flow-rate/Hz rather than trusting the broad 20-field snapshot during ongoing updates. `StepSupervisor.capture()` replaces only these fields with independently coherent observations and logs their acquisition interval; no same-time guarantee across native/primary/feedback. `baseline_gate()` enforces duration, running native mode and final5-minute ranges; these are operational experiment criteria, not Mitsubishi parameters. User confirms other VP remains enabled at27C and authorizes trials above30C; no claim that its activity is measured. Renewal can defer pending feedback within90s, never on invalid/stale feedback.

- `summarize(source,dest)`: offline-only reducer for historical/supervised JSONL. Prefers qualified snapshots when available, preserves missing/incoherent as null, emits sanitized CSV and SHA256-linked field ranges. No network, no COP inference, no causal identification. Source timestamps remain full-capture stamps; narrow primary acquisition bounds retained in raw data.

`StepSupervisor.restore()` bypasses optional narrow primary qualification during restoration: missing process telemetry must not prevent AUTO or fresh native-setting verification. Identity/reset checks remain enabled. This is a safety refinement within the original restoration scope.
