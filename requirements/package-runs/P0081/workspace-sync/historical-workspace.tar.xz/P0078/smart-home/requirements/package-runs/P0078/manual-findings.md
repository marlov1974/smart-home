# P0078 primary-source findings

Manufacturer-authored OCH722A (December2020), EHGT17D-YM9ED.UK service manual, obtained2026-10-08 from distributor mirror:
https://ecoinnovation.lv/wp-content/uploads/2023/02/ZEMES_SILTUMSU%CC%84KNIS_GEODAN_SERVISA_INSTRUKCIJA.pdf

PDF and extraction retained locally at /tmp/p78-geodan-och722a.pdf and /tmp/p78-geodan.txt; copyrighted full text not republished.

- Page25 describes thermo differential settings, lower range−9..−1C and upper+3..+5C, documented defaults−5/+5C. Page94 lists these service settings; page95 footnote4 restricts Heating operation settings to Room temperature control. Therefore **do not transplant these numerical thresholds to fixed-flow control or claim they are this installation's current settings**.
- Page25 describes a10–60minute interval for room auto-adaptation processing. This is not evidence for a compressor restart lockout. Operator's observed approximate10minute stop is still a hypothesis.
- Page30 lists service52 as compressor frequency control state; page33 decodes current and protective temperature limit flags. This establishes a useful diagnostic candidate, not that arbitrary CN105 A3 requests are verified. No service52 query sent.
- No complete FTC compressor-Hz algorithm, integral state, or fixed-flow start/stop threshold established by this reading.

Physical experiment qualification: the observed baseline is curve mode2. The first authorized change will combine mode2→1 and +2C reported target. This is a valid observed response but cannot isolate temperature gain from mode-transition effects. Further within-fixed-mode calibration needs a separately bounded trial. Do not claim this single run confirms H1/H2/H3/H4.
