# P0079 additive standalone overlay

Not published; integrate only diagnostic/p79 into the existing repository. Update its tracked-file index on integration. Production targets remain unchanged.

- `diagnostic/p79/LICENSE`
- `diagnostic/p79/Makefile`
- `diagnostic/p79/README.md`
- `diagnostic/p79/SOURCE_SHA256.json`
- `diagnostic/p79/board-provenance.json`
- `diagnostic/p79/cn105.h`
- `diagnostic/p79/diag.c`
- `diagnostic/p79/diag.h`
- `diagnostic/p79/dump.py`
- `diagnostic/p79/fixture.c`
- `diagnostic/p79/linker.ld`
- `diagnostic/p79/main.c`
- `diagnostic/p79/platform.c`
- `diagnostic/p79/platform.h`
- `diagnostic/p79/probe.S`
- `diagnostic/p79/runtime.c`
- `diagnostic/p79/startup.S`
- `diagnostic/p79/test_arm.py`
- `diagnostic/p79/test_diag.py`
- `diagnostic/p79/test_sanitize.c`
- `diagnostic/p79/verify_image.py`
