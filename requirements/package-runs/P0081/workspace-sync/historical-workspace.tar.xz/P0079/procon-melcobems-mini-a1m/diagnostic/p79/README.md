# P0079 diagnostic r1 — offline candidate, not flashed

Temporary STM32L433 application at0x08008000; exact96KiB BIN. Replaces normal application and cannot back up the displaced app. No CN105 engine, Modbus writers, memory selectors, flash/EEPROM writer, reset command or protection changes. USART3 uses the verified R5B PC10/PC11 swap and PD2 DE,9600 8N1, fixed slave1. Only one matching unit/master may be connected.

Application envelope reads are implemented. Boot is deliberately READ_BLOCKED; external EEPROM is UNSUPPORTED until part,capacity,pins,bus ownership and address are proven. There is no speculative bus probing. Guarded precise access-fault recovery is instruction-tested, not physically validated; unexpected faults fail closed. No claim of universal device recovery or protection bypass.

## Build and tests

Separate directory and Makefile; not referenced by production build/release/deploy.

```
make TOOLCHAIN=/path/to/arm-toolchain PYTHON=/path/to/venv/bin/python all test sanitize-test arm-test
```

Needs GCC arm-none-eabi,clang,Python3,pyelftools,Unicorn and macOS or a host supporting the shared-library test build. Tests compile a fixture library locally; no network/device access. Unicorn JIT may require execution outside a restricted sandbox. Compiler disables if-conversion to avoid an observed Unicorn failure with multi-instruction IT blocks; this also makes the tested branches explicit. Do not silently remove those flags from the verified candidate.

ELF loads stay within app envelope;16KiB SRAM with2KiB reserved minimum stack. Candidate code2796bytes,bss24bytes,main frame includes256byte RX and167byte TX, no heap or full-memory buffers. Raw code is paddedFF to98304bytes; do not prepend boot bytes or send ELF/ZIP to updater. `build/diagnostic.json` pins image SHA256. Repeated full build must match.

## FC04 fixed indexed contract

All addresses zero-based. Wrong slave/broadcast/bad CRC silent. FC06,FC16 and all other functions exception1. Invalid starting offsets/quantities exception2. No cross-window register reads and no writable selector.

- addr0,qty16: identity words `[0xD079,1,79,1,129,81,1,32768,density_kB,1,UID0hi,UID0lo,UID1hi,UID1lo,UID2hi,UID2lo]`. Factory UID stays private. Density must be128 or256 to permit app reads; protocol never reads beyond0x0801FFFF.
- addr0x1000+i,qty81,i0..762: current diagnostic app; byte offset129*i.763 windows, final6bytes.
- addr0x2000+i,qty81,i0..254: boot-area metadata, READ_BLOCKED, zero actual bytes. No boot dereference; index255 and larger reject rather than describe an overrun.
- addr0x3000,qty81: EEPROM UNSUPPORTED, zero actual bytes. No I2C driver.

Each response is162data bytes (81registers), plus5 RTU framing bytes. Words0..15 metadata:

|Word|Meaning|
|---|---|
|0,1|magicD079,schema1|
|2,3|area1boot/2app/3EEPROM,status0valid/1blocked/2unsupported/4sequence exhausted|
|4..5|byte offset,32bit high word first|
|6|actual bytes; zero on blocked/unsupported|
|7..8|fresh capture sequence32bit; starts1, no reusable cache|
|9..10|CRC32 of actual data only, high word first|
|11,12,13|window index,window capacity129,densitykB|
|14..15|reserved zero|
|16..80|130-byte data container: original bytes in order, first byte high half of register|

Full129-byte windows have one zero padding byte; final6-byte window has124 padding bytes. Padding is never counted or written to BIN. Inaccessible windows clear all payload/count; metadata distinguishes READ_BLOCKED from genuine zeros/FF. CRC32 polynomialEDB88320, init/final XORFFFFFFFF. CRC16 standard Modbus low-byte first on wire. A fixed logical index may map to an odd physical byte offset, explicitly supported by byte loads; no arbitrary or misaligned caller-supplied address exists.

## Collector

`dump.py --help` is offline. After separately approved handoff, use explicit host,UID,candidateBIN,pinned returnBIN/hash and a new output directory with `--approved-diagnostic-handoff`. Only Serial.GetConfig and MbRtuClient.ReadInputRegisters are used. Requires existing mb_client9600 8N1. No automatic UART change, script upload, KVS or complete-image storage on Shelly. Current site preflight found js_uart115200; transport compatibility is a handoff blocker, not silently changed.

Two independent full passes are streamed into0600 files in a new0700 folder. Wrong identity/schema/index/offset/count, CRC, nonzero padding, missing reply, stale/reordered/reset sequence or changing identity fails. Partial files remain `.partial`; completed unequal passes yield UNSTABLE_READ with at most16 mismatch offsets. Matching app dumps must also match the candidate96KiB SHA; otherwise UNEXPECTED_DIAGNOSTIC_IMAGE. The manifest is private. Never upload raw vendor bytes,boot/EEPROM data or physical UID.

## Operator handoffs — not authorized by building

1. Before diagnostic flash: positively identify MCU/board; inventory every master; record current native settings and idle/no saved control lease using normal firmware. Exit/restore any active session. Snapshot/lease is RAM-only; flashing does not restore FTC settings. Recheck actual installed release and exact saved returnBIN hash. The local prior P76r1 compact return artifact is16476bytes, SHA256 `dcd1efe7634fdf38a67c6ffcd8e95614a963b232619b788549256b64ff692b44`; historical envelope hash `1a16d8b46f4a1542433778dfd90c12c296695d9ac71a219d17a075c7aa85df94`. These are historical file references, not fresh live byte-for-byte readback.
2. STOP for explicit diagnostic-flash approval. Operator alone controls power/DIP and approved vendor updater. Follow exact-board vendor procedure: power removed, allDIP OFF for updater; restore recorded normal DIP and power-cycle after transfer. Do not improvise mass erase/debug/protection operations. See existing standalone `docs/flashing-and-recovery.md` and `docs/hardware-reference/boot-update.md`; no updater rewrite in P79.
3. Verify heartbeat, diagnostic identity/UID,density and known app window before separately authorized full app capture. Boot returns READ_BLOCKED; EEPROM UNSUPPORTED. Do not expand ranges to obtain a result. If the Modbus transport is incompatible, stop for a separately reviewed arrangement.
4. STOP for a distinct restoration approval. Restore exact pinned normal image using vendor procedure; afterwards verify physical UID, release/capabilities, fresh independent CN105 counters and native settings, not just updater progress. Restore the pretest master/serial arrangement. If updater entry fails, stop for operator recovery.

## Evidence and provenance

Board primitives originate from hash-recorded local clean-room P76 sources. Upstream private platform.c inspected through GitHub connector: blob1cd9fad87bd0a62b2511368c2c4cc80eaf1b91ce; root AGENTS absent. Firmware writer/control/CN105 implementations are not linked. ST manufacturer header confirms UID_BASE1FFF7590 and FLASHSIZE_BASE1FFF75E0: https://github.com/STMicroelectronics/cmsis-device-l4/blob/master/Include/stm32l433xx.h . No full vendor image, original bootloader, secret or EEPROM content is included.
