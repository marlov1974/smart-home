/* P0079: fixed indexed FC04 windows; no writer or selector register. */
#include "diag.h"
static uint32_t sequence;
static uint16_t density_kb;
static uint32_t factory_uid[3];
void diag_init(uint16_t density,const uint32_t uid[3]){
 sequence=0;density_kb=density;for(unsigned i=0;i<3;i++)factory_uid[i]=uid[i];
}
uint16_t diag_crc16(const uint8_t *b,size_t n){
 uint16_t c=65535;while(n--){c^=*b++;for(unsigned i=0;i<8;i++)c=(c>>1)^((c&1)?0xa001:0);}return c;
}
uint32_t diag_crc32(const uint8_t *b,size_t n){
 uint32_t c=0xffffffffu;while(n--){c^=*b++;for(unsigned i=0;i<8;i++)c=(c>>1)^((c&1)?0xedb88320u:0);}return ~c;
}
static void word(uint8_t *p,uint16_t v){p[0]=(uint8_t)(v>>8);p[1]=(uint8_t)v;}
static void dword(uint8_t *p,uint32_t v){word(p,(uint16_t)(v>>16));word(p+2,(uint16_t)v);}
static size_t finish(uint8_t *out,size_t n){uint16_t c=diag_crc16(out,n);out[n]=(uint8_t)c;out[n+1]=(uint8_t)(c>>8);return n+2;}
size_t diag_reply(const uint8_t *r,size_t n,uint8_t *out,size_t cap){
 if(n<4 || n>256 || r[0]!=1 || diag_crc16(r,n))return 0;
 unsigned addr=0,qty=0,area=0,index=0;uint8_t error=0;
 if(r[1]!=4)error=1;
 else if(n!=8)return 0;
 else{
  addr=((unsigned)r[2]<<8)|r[3];qty=((unsigned)r[4]<<8)|r[5];
  if(addr==0 && qty==16)area=0;
  else if(qty!=DIAG_WORDS)error=2;
  else if(addr>=0x1000 && addr<0x12fb){area=2;index=addr-0x1000;}
  else if(addr>=0x2000 && addr<0x20ff){area=1;index=addr-0x2000;}
  else if(addr==0x3000)area=3;
  else error=2;
 }
 size_t bytes=error?0:(area?162:32);
 if(cap<5+bytes)return 0;
 out[0]=1;out[1]=error?(uint8_t)(r[1]|128):4;out[2]=error?error:(uint8_t)bytes;
 if(error)return finish(out,3);
 uint8_t *p=out+3;for(unsigned i=0;i<bytes;i++)p[i]=0;
 word(p,0xd079);word(p+2,1);
 if(!area){
  word(p+4,79);word(p+6,1);word(p+8,129);word(p+10,81);
  dword(p+12,APP_SIZE);word(p+16,density_kb);word(p+18,1); /* boot blocked */
  for(unsigned i=0;i<3;i++)dword(p+20+4*i,factory_uid[i]);
 }else{
  unsigned status=0,count=129;uint32_t offset=index*129u;
  if(area==2 && count>APP_SIZE-offset)count=APP_SIZE-offset;
  if(sequence==0xffffffffu){status=4;count=0;}else ++sequence;
  if(area==1){status=1;count=0;} /* boot access deliberately disabled */
  if(area==3){status=2;count=0;} /* unverified EEPROM */
  if(area==2 && density_kb!=128 && density_kb!=256){status=1;count=0;}
  for(unsigned i=0;i<count;i++){
   if(!diag_read_byte(0x08008000u+offset+i,p+32+i)){
    status=1;count=0;for(unsigned j=0;j<130;j++)p[32+j]=0;break;
   }
  }
  word(p+4,(uint16_t)area);word(p+6,(uint16_t)status);dword(p+8,offset);
  word(p+12,(uint16_t)count);dword(p+14,sequence);dword(p+18,count?diag_crc32(p+32,count):0);
  word(p+22,(uint16_t)index);word(p+24,129);word(p+26,density_kb);
 }
 return finish(out,3+bytes);
}
