/* P0079 isolated read-only diagnostic. */
#include <stdint.h>
#include <stddef.h>
#define DIAG_WORDS 81u
#define DIAG_BYTES 129u
#define APP_SIZE 98304u
uint16_t diag_crc16(const uint8_t *,size_t);
uint32_t diag_crc32(const uint8_t *,size_t);
size_t diag_reply(const uint8_t *,size_t,uint8_t *,size_t);
void diag_init(uint16_t density,const uint32_t uid[3]);
int diag_read_byte(uint32_t address,uint8_t *out);
int probe_byte(uint32_t address,uint8_t *out);
