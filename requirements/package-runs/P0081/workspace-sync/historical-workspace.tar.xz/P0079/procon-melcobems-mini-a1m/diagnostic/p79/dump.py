"""P0079 read-only collector. No network on import. No UART configuration writes."""
import argparse,hashlib,json,os,struct,zlib
from datetime import datetime,timezone
from pathlib import Path
from urllib.request import Request,urlopen
AREAS={'app':(2,0x1000,98304),'boot':(1,0x2000,32768),'eeprom':(3,0x3000,0)}
class InvalidRead(RuntimeError):pass
class Blocked(InvalidRead):pass

def words(value,n):
    if not isinstance(value,list) or len(value)!=n or any(type(w)is not int or not 0<=w<=65535 for w in value):raise InvalidRead('Malformed register response')
    return value

def identity(read):
    w=words(read(0,16),16)
    if w[:8]!=[0xd079,1,79,1,129,81,1,32768]:raise InvalidRead('Not the P79 diagnostic identity/layout')
    if all(v==0 for v in w[10:16]) or all(v==65535 for v in w[10:16]):raise InvalidRead('Invalid factory UID')
    return {'words':w,'density_kb':w[8],'uid96':''.join(f'{x:04x}' for x in w[10:16])}

def decode(w,area,index,previous):
    w=words(w,81);raw=struct.pack('>81H',*w)
    a,base,size=AREAS[area];offset=index*129;actual=min(129,max(0,size-offset))
    seq=(w[7]<<16)|w[8]
    if w[:3]!=[0xd079,1,a] or (w[4]<<16|w[5])!=offset or w[11]!=index or w[12]!=129 or any(w[14:16]):raise InvalidRead('Wrong region/offset/schema/reserved metadata')
    if previous is not None and seq!=previous+1:raise InvalidRead('Stale/reordered capture or device reset')
    if not 1<=seq<0xffffffff:raise InvalidRead('Invalid capture sequence')
    if w[3]:
        if w[6] or any(raw[32:]):raise InvalidRead('Blocked response leaked data')
        raise Blocked(f'{area}: '+{1:'READ_BLOCKED',2:'UNSUPPORTED',4:'SEQUENCE_EXHAUSTED'}.get(w[3],'INVALID_STATUS'))
    if area!='app' or w[13] not in (128,256) or w[6]!=actual or actual<=0:raise InvalidRead('Invalid count/density/range')
    data=raw[32:32+actual]
    if any(raw[32+actual:]):raise InvalidRead('Nonzero tail padding')
    if zlib.crc32(data)!=(w[9]<<16|w[10]):raise InvalidRead('Data CRC32 mismatch')
    return data,seq

def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(8192),b''):h.update(chunk)
    return h.hexdigest()

def double_dump(read,out,expected_uid,expected_app_sha,area='app'):
    out=Path(out);out.mkdir(mode=0o700,parents=False,exist_ok=False);out.chmod(0o700)
    report={'package':'P0079','status':'PARTIAL','area':area,'start_utc':datetime.now(timezone.utc).isoformat(),'passes':[],'current_diagnostic_not_displaced_firmware':True}
    previous=None
    try:
        before=identity(read);report['identity']=before
        if before['uid96']!=expected_uid:raise InvalidRead('Wrong physical UID')
        a,base,size=AREAS[area]
        for turn in (1,2):
            path=out/f'pass{turn}.partial'
            with path.open('xb') as f:
                path.chmod(0o600)
                for index in range(max(1,(size+128)//129)):
                    data,previous=decode(read(base+index,81),area,index,previous);f.write(data)
                f.flush();os.fsync(f.fileno())
            if path.stat().st_size!=size:raise InvalidRead('Gap or truncated image')
            if identity(read)!=before:raise InvalidRead('Identity changed during capture')
            final=path.with_suffix('.bin');path.rename(final)
            report['passes'].append({'pass':turn,'bytes':size,'sha256':digest(final),'last_sequence':previous,'completed_utc':datetime.now(timezone.utc).isoformat()})
        first=out/'pass1.bin';second=out/'pass2.bin';mismatches=[]
        with first.open('rb') as f,second.open('rb') as g:
            offset=0
            while True:
                x,y=f.read(4096),g.read(4096)
                if not x and not y:break
                for i,(a,b) in enumerate(zip(x,y)):
                    if a!=b and len(mismatches)<16:mismatches.append(offset+i)
                offset+=len(x)
        if mismatches or report['passes'][0]['sha256']!=report['passes'][1]['sha256']:
            report.update(status='UNSTABLE_READ',first_mismatch_offsets=mismatches)
        elif area=='app' and report['passes'][0]['sha256']!=expected_app_sha:
            report['status']='UNEXPECTED_DIAGNOSTIC_IMAGE'
        else:report['status']='VERIFIED_DOUBLE_READ'
    except Exception as e:
        report['status']='READ_BLOCKED' if isinstance(e,Blocked) else 'PARTIAL_ERROR';report['error']=str(e)
    finally:
        report['end_utc']=datetime.now(timezone.utc).isoformat()
        p=out/'manifest.json';p.write_text(json.dumps(report,indent=2)+'\n');p.chmod(0o600)
    return report

class RpcReader:
    def __init__(self,host):self.host=host
    def rpc(self,method,params):
        req=Request('http://'+self.host+'/rpc',data=json.dumps({'id':79,'method':method,'params':params}).encode(),headers={'Content-Type':'application/json'})
        with urlopen(req,timeout=5) as f:r=json.loads(f.read(8192))
        if r.get('id')!=79 or 'error' in r:raise InvalidRead('RPC failed')
        return r['result']
    def check_serial(self):
        s=self.rpc('Serial.GetConfig',{'id':100})
        if s.get('mode')!='mb_client' or s.get('serial')!={'baud':9600,'format':'8N1'}:raise InvalidRead('Existing Modbus9600 8N1 required; no automatic mode change')
    def __call__(self,addr,qty):return self.rpc('MbRtuClient.ReadInputRegisters',{'id':100,'sid':1,'addr':addr,'qty':qty})['values']

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--host',required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--uid',required=True);p.add_argument('--candidate',type=Path,required=True);p.add_argument('--return-bin',type=Path,required=True);p.add_argument('--return-sha256',required=True);p.add_argument('--area',choices=AREAS,default='app');p.add_argument('--approved-diagnostic-handoff',action='store_true');a=p.parse_args()
    if not a.approved_diagnostic_handoff:p.error('Separate operator-approved diagnostic handoff required')
    if a.candidate.stat().st_size!=98304 or digest(a.return_bin)!=a.return_sha256:p.error('Candidate envelope or pinned recovery image mismatch')
    reader=RpcReader(a.host);reader.check_serial();report=double_dump(reader,a.output,a.uid,digest(a.candidate),a.area)
    report['candidate_sha256']=digest(a.candidate);report['return_sha256']=a.return_sha256
    (a.output/'manifest.json').write_text(json.dumps(report,indent=2)+'\n');print(report['status'])
    raise SystemExit(0 if report['status']=='VERIFIED_DOUBLE_READ' else 2)
if __name__=='__main__':main()
