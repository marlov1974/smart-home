/* P0079 test-only reader; not linked into candidate. */
#include "diag.h"
unsigned reads,fail_at=0xffffffffu,variant;
int diag_read_byte(uint32_t a,uint8_t *out){
 reads++;if(a<0x08008000u || a>=0x08020000u || a==fail_at)return 0;
 *out=(uint8_t)((a-0x08008000u+variant)&255u);return 1;
}
