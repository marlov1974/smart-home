/* P0079 diagnostic only; CN105 is disabled, never initialized. */
#include "diag.h"
#include "platform.h"
#define REG(a) (*(volatile uint32_t *)(uintptr_t)(a))
extern uint8_t probe_load,probe_blocked;
extern void diagnostic_cn_off(void);
void cn_service(void){} /* USART3 wait hook cannot send CN105 */
void diagnostic_fault(uint32_t *frame){
 uint32_t ptr=(uint32_t)(uintptr_t)frame;
 uint32_t c=REG(0xe000ed28u),h=REG(0xe000ed2cu);
 if(ptr>=0x20000000u && ptr<=0x20003fe0u && !(ptr&3u) &&
    frame[6]==((uint32_t)(uintptr_t)&probe_load & ~1u) &&
    (c&0x202u) && !(c&0x3818u) && (h&0x40000000u)){
  frame[6]=(uint32_t)(uintptr_t)&probe_blocked & ~1u;
  REG(0xe000ed28u)=c;REG(0xe000ed2cu)=0x40000000u;
  __asm volatile("dsb\nisb":::"memory");return;
 }
 /* Unknown faults stay fail-closed without watchdog reboot loops. */
 for(;;)watchdog_refresh();
}
int diag_read_byte(uint32_t a,uint8_t *out){
 if(a<0x08008000u || a>=0x08020000u)return 0;
 return probe_byte(a,out);
}
int main(void){
 platform_init();diagnostic_cn_off();uart_init();
 uint8_t lo=0,hi=0;uint16_t density=0;uint32_t uid[3]={0,0,0};
 if(probe_byte(0x1fff75e0u,&lo) && probe_byte(0x1fff75e1u,&hi))density=(uint16_t)(lo|((unsigned)hi<<8));
 for(unsigned i=0;i<12;i++){uint8_t b=0;if(probe_byte(0x1fff7590u+i,&b))uid[i/4]|=(uint32_t)b<<(8*(i%4));}
 diag_init(density,uid);
 uint8_t input[256],output[167];unsigned len=0;int invalid=0;uint32_t last=micros();
 for(;;){
  watchdog_refresh();heartbeat(micros());uint32_t now=micros();
  if(len && now-last>=4000u){
   size_t n=invalid?0:diag_reply(input,len,output,sizeof output);
   len=0;invalid=0;if(n)(void)uart_send(output,n);
  }
  uint8_t byte;int error;
  if(uart_receive(&byte,&error)){
   now=micros();if(now-last>=4000u){len=0;invalid=0;}
   else if(len && now-last>1600u)invalid=1;
   if(error)invalid=1;
   if(len<sizeof input)input[len++]=byte;else invalid=1;
   last=now;
  }
 }
}
