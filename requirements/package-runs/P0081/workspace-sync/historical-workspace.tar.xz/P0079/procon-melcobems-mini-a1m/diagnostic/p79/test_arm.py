"""P0079 actual ARM image with mock peripherals; not physical proof."""
import struct,unittest
from pathlib import Path
from elftools.elf.elffile import ELFFile
from unicorn import Uc,UC_ARCH_ARM,UC_MODE_THUMB,UC_MODE_MCLASS,UC_HOOK_CODE,UC_HOOK_MEM_READ,UC_HOOK_MEM_WRITE
from unicorn.arm_const import *
def crc(b):
 c=65535
 for v in b:
  c^=v
  for _ in range(8):c=(c>>1)^(0xa001 if c&1 else 0)
 return struct.pack('<H',c)
def make():
 u=Uc(UC_ARCH_ARM,UC_MODE_THUMB|UC_MODE_MCLASS);u.ctl_set_cpu_model(UC_CPU_ARM_CORTEX_M4)
 for a,n in [(0x08000000,0x20000),(0x20000000,0x10000),(0x40000000,0x30000),(0x48000000,0x2000),(0xe000e000,0x2000),(0x1fff7000,0x1000)]:u.mem_map(a,n)
 u.mem_write(0x08008000,Path('build/diagnostic.bin').read_bytes());u.mem_write(0x1fff75e0,struct.pack('<H',128));u.mem_write(0x1fff7590,struct.pack('<III',0x12345678,0x9abcdef0,0x13579bdf))
 with Path('build/diagnostic.elf').open('rb') as f:
  e=ELFFile(f);symbols={s.name:s['st_value'] for s in e.get_section_by_name('.symtab').iter_symbols()}
 return u,symbols
class Arm(unittest.TestCase):
 def test_boot_read_and_no_control(self):
  for fn,addr,qty in [(4,0,16),(4,0x1000,81),(16,300,8),(4,0x2000,81)]:
   u,sym=make();r=struct.pack('>BBHH',1,fn,addr,qty);r+=crc(r)
   state={'ins':0,'next':0,'rx':None,'tx':bytearray()}
   def w(a,v):u.mem_write(a,struct.pack('<I',v&0xffffffff))
   def rd(a):return struct.unpack('<I',u.mem_read(a,4))[0]
   def code(uc,a,size,data):
    state['ins']+=1
    if a==(sym['Default_Handler']&~1) or a==(sym['HardFault_Handler']&~1):raise AssertionError('Unexpected fault')
    if state['ins']>360000:u.emu_stop()
   def readhook(uc,access,a,size,value,data):
    now=state['ins']//4
    if a==0x40021000:w(a,rd(a)|0x400)
    elif a==0x40021008:w(a,(rd(a)&~12)|((rd(a)&3)<<2))
    elif a==0x40000024:w(a,now)
    elif a==0x4000481c:
     if state['next']<len(r) and now>=20000+1042*state['next'] and state['rx'] is None:state['rx']=r[state['next']];state['next']+=1
     w(a,0xc0|(0x20 if state['rx'] is not None else 0))
    elif a==0x40004824:w(a,state['rx'] or 0);state['rx']=None
   def writehook(uc,access,a,size,value,data):
    if a==0x40004828:state['tx'].append(value&255)
    assert a!=0x40013828,'CN105 write'
    assert not 0x40022000<=a<0x40022400,'Flash control write'
    assert not 0x40005400<=a<0x40005c00,'I2C access'
   u.hook_add(UC_HOOK_CODE,code);u.hook_add(UC_HOOK_MEM_READ,readhook);u.hook_add(UC_HOOK_MEM_WRITE,writehook)
   sp,pc=struct.unpack('<II',u.mem_read(0x08008000,8));u.reg_write(UC_ARM_REG_SP,sp)
   try:u.emu_start(pc,0,count=400000)
   except Exception:
    pc=u.reg_read(UC_ARM_REG_PC);print('FAULT_PC',hex(pc),bytes(u.mem_read(pc,8)).hex(),flush=True);raise
   b=bytes(state['tx']);self.assertTrue(b);self.assertEqual(crc(b),b'\x00\x00');self.assertEqual(rd(0x40013800),0)
   if fn==16:self.assertEqual(b[1:3],b'\x90\x01')
   elif addr==0:self.assertEqual(b[3:7],bytes.fromhex('d0790001'))
   elif addr==0x1000:self.assertEqual(b[35:164],Path('build/diagnostic.bin').read_bytes()[:129])
   else:self.assertEqual(b[9:11],b'\x00\x01');self.assertFalse(any(b[35:-2]))
 def test_guarded_access_allowlist(self):
  u,s=make();end=0x20008000;u.reg_write(UC_ARM_REG_SP,0x20003ff0)
  for address,expected in [(0x08007fff,0),(0x08020000,0),(0x1fff7800,0),(0x20000000,0),(0x08008000,1),(0x0801ffff,1)]:
   u.reg_write(UC_ARM_REG_R0,address);u.reg_write(UC_ARM_REG_R1,0x20000000);u.reg_write(UC_ARM_REG_LR,end|1)
   u.emu_start(s['diag_read_byte'],end,count=1000);self.assertEqual(u.reg_read(UC_ARM_REG_R0),expected)
 def test_precise_fault_frame_recovery(self):
  u,s=make();frame=0x20001000;end=0x20008000;words=[0]*8;words[6]=s['probe_load']&~1;words[7]=0x1000000
  u.mem_write(frame,struct.pack('<8I',*words));u.mem_write(0xe000ed28,struct.pack('<I',0x8200));u.mem_write(0xe000ed2c,struct.pack('<I',0x40000000))
  u.reg_write(UC_ARM_REG_SP,0x20003ff0);u.reg_write(UC_ARM_REG_R0,frame);u.reg_write(UC_ARM_REG_LR,end|1)
  u.emu_start(s['diagnostic_fault'],end,count=1000);self.assertEqual(struct.unpack('<I',u.mem_read(frame+24,4))[0],s['probe_blocked']&~1)
if __name__=='__main__':unittest.main(verbosity=2)
