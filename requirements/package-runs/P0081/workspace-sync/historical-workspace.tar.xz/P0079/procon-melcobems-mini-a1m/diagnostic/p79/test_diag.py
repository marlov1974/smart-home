"""P0079 offline C protocol + host collector regression suite."""
import ctypes,hashlib,json,struct,subprocess,tempfile,unittest,zlib
from pathlib import Path
import dump
ROOT=Path(__file__).resolve().parent
subprocess.run(['clang','-shared','-fPIC','-Wall','-Wextra','-Werror','diag.c','fixture.c','-o','build/fixture.dylib'],cwd=ROOT,check=True)
lib=ctypes.CDLL(str(ROOT/'build/fixture.dylib'))
lib.diag_crc16.argtypes=[ctypes.c_char_p,ctypes.c_size_t];lib.diag_crc16.restype=ctypes.c_uint16
lib.diag_reply.argtypes=[ctypes.c_char_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.c_size_t];lib.diag_reply.restype=ctypes.c_size_t
UID='123456789abcdef013579bdf';DATA=bytes(range(256))*384;HASH=hashlib.sha256(DATA).hexdigest()
def reset(density=128):
 lib.diag_init(density,(ctypes.c_uint32*3)(0x12345678,0x9abcdef0,0x13579bdf))
 for name,v in [('reads',0),('variant',0),('fail_at',0xffffffff)]:ctypes.c_uint.in_dll(lib,name).value=v

def frame(payload):return payload+struct.pack('<H',lib.diag_crc16(payload,len(payload)))
def raw(addr,qty=81,fn=4,sid=1,capacity=167):
 r=frame(struct.pack('>BBHH',sid,fn,addr,qty));out=ctypes.create_string_buffer(200)
 n=lib.diag_reply(r,len(r),out,capacity);return out.raw[:n]
def read(addr,qty):
 b=raw(addr,qty)
 if not b or lib.diag_crc16(b,len(b)) or b[:2]!=b'\x01\x04' or b[2]!=2*qty:raise dump.InvalidRead('RTU exception/CRC/shape')
 return list(struct.unpack('>'+str(qty)+'H',b[3:-2]))
class Tests(unittest.TestCase):
 def setUp(self):reset()
 def test_identity_and_crc(self):
  self.assertEqual(dump.identity(read)['uid96'],UID)
  self.assertEqual(lib.diag_crc16(b'123456789',9),0x4b37)
  self.assertEqual(read(0,16)[:6],[0xd079,1,79,1,129,81])
 def test_all_windows_and_odd_padding(self):
  seq=None;out=bytearray()
  for i in range(763):
   w=read(0x1000+i,81);b,seq=dump.decode(w,'app',i,seq);out+=b
   self.assertEqual(len(b),6 if i==762 else 129)
  self.assertEqual(bytes(out),DATA)
 def test_repeated_1000(self):
  seq=None
  for i in range(1000):b,seq=dump.decode(read(0x1000+i%763,81),'app',i%763,seq)
  self.assertEqual(seq,1000)
 def test_blocked_no_dereference(self):
  for a,area in [(0x2000,'boot'),(0x3000,'eeprom')]:
   with self.assertRaises(dump.Blocked):dump.decode(read(a,81),area,0,None)
  self.assertEqual(ctypes.c_uint.in_dll(lib,'reads').value,0)
 def test_density_gate(self):
  for d in (0,64,512,65535):
   reset(d)
   with self.assertRaises(dump.Blocked):dump.decode(read(0x1000,81),'app',0,None)
   self.assertEqual(ctypes.c_uint.in_dll(lib,'reads').value,0)
 def test_fault_clears_partial(self):
  ctypes.c_uint.in_dll(lib,'fail_at').value=0x08008010
  w=read(0x1000,81);self.assertEqual(w[6],0);self.assertFalse(any(w[16:]))
  with self.assertRaises(dump.Blocked):dump.decode(w,'app',0,None)
 def test_bad_offsets_lengths_writes(self):
  for a,q in [(1,16),(0x0fff,81),(0x12fb,81),(0x20ff,81),(0x2100,81),(0x3001,81),(65535,125),(0x1000,0),(0x1000,120),(0x1000,82),(0x1000,80)]:self.assertEqual(raw(a,q)[1:3],b'\x84\x02')
  for fn in (3,6,16,23,255):self.assertEqual(raw(300,8,fn)[1:],frame(bytes([1,fn|128,1]))[1:])
  self.assertEqual(ctypes.c_uint.in_dll(lib,'reads').value,0)
 def test_crc_slave_and_small_output(self):
  self.assertEqual(raw(0x1000,capacity=166),b'');self.assertEqual(raw(0,16,sid=0),b'')
  bad=frame(bytes.fromhex('010400000010'))[:-1]+b'\xff';o=ctypes.create_string_buffer(200)
  self.assertEqual(lib.diag_reply(bad,len(bad),o,200),0)
 def test_host_rejects_metadata_crc_reset(self):
  good=read(0x1000,81)
  for i,v in [(0,0),(2,1),(4,1),(5,129),(6,128),(9,0),(11,1),(12,128),(14,1),(16,255),(80,255)]:
   bad=good.copy();bad[i]=v
   with self.assertRaises(dump.InvalidRead,msg=str(i)):dump.decode(bad,'app',0,None)
  with self.assertRaises(dump.InvalidRead):dump.decode(good,'app',0,good[8])
 def test_double_pass_and_permissions(self):
  with tempfile.TemporaryDirectory() as d:
   out=Path(d)/'capture';r=dump.double_dump(read,out,UID,HASH)
   self.assertEqual(r['status'],'VERIFIED_DOUBLE_READ');self.assertEqual(r['passes'][1]['last_sequence'],1526)
   self.assertEqual((out/'pass1.bin').read_bytes(),DATA);self.assertEqual((out/'pass2.bin').stat().st_mode&0o777,0o600)
 def test_double_mismatch(self):
  calls=0
  def unstable(a,q):
   nonlocal calls
   if a>=0x1000:
    calls+=1
    if calls>763:ctypes.c_uint.in_dll(lib,'variant').value=1
   return read(a,q)
  with tempfile.TemporaryDirectory() as d:
   r=dump.double_dump(unstable,Path(d)/'capture',UID,HASH);self.assertEqual(r['status'],'UNSTABLE_READ');self.assertEqual(r['first_mismatch_offsets'][0],0)
 def test_timeout_partial_and_uid(self):
  def timeout(a,q):
   if a==0x1002:raise TimeoutError('timeout')
   return read(a,q)
  with tempfile.TemporaryDirectory() as d:
   out=Path(d)/'capture';r=dump.double_dump(timeout,out,UID,HASH);self.assertEqual(r['status'],'PARTIAL_ERROR');self.assertFalse((out/'pass1.bin').exists());self.assertEqual((out/'pass1.partial').stat().st_size,258)
   r=dump.double_dump(read,Path(d)/'wrong','0'*24,HASH);self.assertEqual(r['status'],'PARTIAL_ERROR')
 def test_reset_between_passes(self):
  calls=0
  def resetting(a,q):
   nonlocal calls
   if a==0x1000:
    calls+=1
    if calls==2:reset()
   return read(a,q)
  with tempfile.TemporaryDirectory() as d:self.assertEqual(dump.double_dump(resetting,Path(d)/'capture',UID,HASH)['status'],'PARTIAL_ERROR')
if __name__=='__main__':unittest.main(verbosity=2)
