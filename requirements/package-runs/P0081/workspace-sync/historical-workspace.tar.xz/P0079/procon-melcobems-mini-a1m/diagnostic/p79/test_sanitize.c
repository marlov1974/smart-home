/* P0079 host-only exhaustive indexed bounds + malformed-frame stress. */
#include <assert.h>
#include <stdio.h>
#include "diag.h"
extern unsigned reads;
int main(void){
 uint32_t uid[3]={1,2,3};diag_init(128,uid);
 uint8_t r[256]={1,4,0,0,0,81},out[169];
 for(unsigned addr=0;addr<65536;addr++){
  r[2]=(uint8_t)(addr>>8);r[3]=(uint8_t)addr;uint16_t c=diag_crc16(r,6);r[6]=(uint8_t)c;r[7]=(uint8_t)(c>>8);
  unsigned before=reads;out[0]=0x5a;out[168]=0xa5;
  size_t n=diag_reply(r,8,out+1,167);assert(n==5||n==167);assert(out[0]==0x5a&&out[168]==0xa5);assert(diag_crc16(out+1,n)==0);
  if(addr<0x1000||addr>=0x12fb)assert(reads==before);
 }
 uint32_t seed=17;
 for(unsigned trial=0;trial<10000;trial++){
  for(unsigned i=0;i<256;i++){seed=seed*1664525u+1013904223u;r[i]=(uint8_t)(seed>>24);}
  size_t n=diag_reply(r,trial%257,out+1,trial%168);assert(n<=167);
 }
 puts("PASS:65536 window addresses and10000 malformed frames under ASan/UBSan");
}
