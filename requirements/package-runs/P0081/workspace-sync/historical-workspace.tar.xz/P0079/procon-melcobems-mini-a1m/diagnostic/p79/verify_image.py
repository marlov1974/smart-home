"""P0079 ELF limits and deterministic full96KiB envelope."""
import hashlib,json,struct,subprocess,sys
from pathlib import Path
from elftools.elf.elffile import ELFFile
p=Path(sys.argv[1]);base=0x08008000
with p.open('rb') as f:
 elf=ELFFile(f)
 assert elf['e_machine']=='EM_ARM'
 for seg in elf.iter_segments():
  if seg['p_type']=='PT_LOAD' and seg['p_filesz']:
   assert base<=seg['p_paddr'] and seg['p_paddr']+seg['p_filesz']<=0x08020000
 for sec in elf.iter_sections():
  if sec['sh_flags']&2 and sec['sh_size']:
   a,n=sec['sh_addr'],sec['sh_size'];assert (base<=a and a+n<=0x08020000) or (0x20000000<=a and a+n<=0x20004000)
raw=p.with_suffix('.raw');subprocess.run([sys.argv[2],'-O','binary',str(p),str(raw)],check=True)
b=raw.read_bytes();sp,reset=struct.unpack('<II',b[:8]);assert sp==0x20004000 and reset&1 and base<=reset<base+len(b);assert len(b)<=98304
image=b+b'\xff'*(98304-len(b));p.with_suffix('.bin').write_bytes(image)
p.with_suffix('.json').write_text(json.dumps({'package':'P0079','diagnostic_only':True,'base':hex(base),'end_exclusive':'0x08020000','raw_bytes':len(b),'bytes':len(image),'sha256':hashlib.sha256(image).hexdigest(),'boot':'READ_BLOCKED','eeprom':'UNSUPPORTED','physical_validation':'NOT_TESTED'},indent=2)+'\n')
