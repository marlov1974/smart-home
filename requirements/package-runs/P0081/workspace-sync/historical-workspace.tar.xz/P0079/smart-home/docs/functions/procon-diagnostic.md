# P0079 temporary diagnostic

Separate standalone `diagnostic/p79`; never included in production release. Build candidate is application-only, not a backup of displaced code.

- `diag_init`: bounded density/UID/counter initialization.
- `diag_reply`: exactFC04 identity/index dispatcher; rejects all writes; enforces81register window and allowlist before any callback; packs metadata/data/CRC. Native exhaustive bounds and ARM boot vectors.
- `diag_crc16`, `diag_crc32`: transport/data integrity; golden binary vectors.
- `probe_byte`, `diagnostic_fault`, `diag_read_byte`: fixed read instruction,precise fault-frame recovery,app-envelope allowlist. No protection mutation; boot/EEPROM blocked before callback. ARM instruction tests; physical unverified.
- `main`, `diagnostic_cn_off`, `cn_service`: disable inherited CN105 and poll9600RTU; empty service hook. ARM no-TX/write assertions.
- `identity`, `words`, `decode`: strict host schema/UID/range/count/sequence/CRC/padding validation.
- `double_dump`, `digest`: new private output directory,two independent streaming captures,exact comparison andSHA256;partial/unstable never success. Injected timeout/reset/mismatch tests.
- `RpcReader.rpc/check_serial/__call__`: read-only existing Modbus-client transport; no UART mode changes.
- `verify_image.py`: ELF/vector/load limits,96KiB FF envelope and manifest; repeated-build comparison.

Implementation and side effects are restricted to diagnostic scope. Hardware handoffs and normal-firmware restoration remain explicit operator operations. See package-runP0079/verification.md and standalone README.
