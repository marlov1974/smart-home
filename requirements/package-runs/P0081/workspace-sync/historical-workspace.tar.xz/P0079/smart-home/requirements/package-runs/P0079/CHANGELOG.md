# P0079 — offline candidate built; physical work pending

Added isolated read-only diagnostic firmware, bounded FC04 indexed-window protocol, private two-pass Mac collector, C/Python/ARM tests and operator handoff documentation in local standalone overlay `P0079/procon-melcobems-mini-a1m/diagnostic/p79`. No modifications to ordinary firmware,deploy or updater paths. App envelope only; boot READ_BLOCKED and EEPROM UNSUPPORTED. Diagnostic cannot back up an application it replaces.

Offline verification passed:13 protocol/collector tests,3 ARM methods(four boot scenarios),65536 address cases,10000 malformed-frame sanitizer cases,1000 repeated windows and deterministic96KiB build. Candidate SHA256 efcc12644faa6774c19df7231f86d184dcf5b04b2a152f08417e6139f2e7bb55.

Live action only Serial.GetConfig read; UART js_uart115200 unchanged, existing helper requires mb_client9600. No Procon dump,flash,control write or restoration operation. Saved return BIN hash checked locally; fresh native/lease/physical identity verification remains a preflash gate. Read README handoffs before physical work. TC8 not performed.

G2evidence and function catalog added; tracked index updated. Standalone additive file inventory shipped with candidate; upstream main unmodified. No GitHub commit/push claimed. Synch conflict resolved by clean current G2working copy with previousP78results intact. Knowhow considered: retained hardware/JIT/transport findings in package evidence; no global rule promoted from unvalidated hardware behavior.
