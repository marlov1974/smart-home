# P0079 function design

New diagnostic-only functions:
- diag_reply/diag_crc16: validate FC04/CRC/index/quantity, produce bounded identity/window/error frames; no bus writes beyond response. Native and ARM vectors,1000-window and malformed-frame tests.
- diag_reply(window branch)/diag_crc32: map fixed index to allowlisted span, capture byte callback, sequence,metadata/CRC; zero count on blocked/unsupported; no returned partial data. Test all edges,odd lengths,blocked callback.
- probe_byte/diagnostic_fault: one-instruction guarded load and precise fault-frame recovery, fixed internal allowlist callers; never modify protection. ARM emulation and disassembly; physical verification separately required.
- main/cn_service: polling RTU with empty CN105 service hook; diagnostic identity only. Build no CN105 engine.
- host identity/decode/collect/double_dump: strict protocol and provenance,private output,independent reads,comparison,mismatch range; injectable read transport. Timeouts/CRC/stale/reorder/gap/reset/partial capture tests.
- build verifier: ELF/vector/load bounds,raw96KiB padding,SHA256 manifest and deterministic reproduction.

No production functions removed/changed. Copied board primitives have local source SHA256 provenance; normal release tooling does not include diagnostic target.
