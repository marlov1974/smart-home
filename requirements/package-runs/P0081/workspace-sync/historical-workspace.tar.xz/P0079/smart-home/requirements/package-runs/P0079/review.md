# P0079 review — WARN

Clean G2 checkout7532ac0 fetched; main matches origin/main. P78 working tree preserved unchanged in separate directory, resolving working-copy sync conflict without discarding evidence. Package bootstrap used.

Standalone GitHub clone unavailable (private repository authentication); implement additive portable diagnostic under the intended standalone directory using hash-recorded local clean-room board primitives. No assertion of upstream synchronization/publication. No normal firmware changes. Offline build is authorized; flashing, dumping and restoration require separate handoffs.

App reads require verified density128/256KiB and guarded fault recovery. Boot area READ_BLOCKED by policy until accessible ranges/protection evidence exists. EEPROM unsupported: part/pins/ownership unknown. Never treat blocked regions as zeros. Live preflight deferred to handoff; known Shelly current UART mode is js_uart, not assumed mb_client. Helper will require already-configured Modbus client and never change UART mode. Recovery artifact still needs exact installed-image pinning before any flash.

Subsequent GitHub connector inspection succeeded: private repository metadata,platform.c blob1cd9fad87bd0a62b2511368c2c4cc80eaf1b91ce,file index and recovery references read. GitCLI authentication remains unavailable; no upstream publication performed.
