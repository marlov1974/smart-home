# P0079 verification — offline PASS, physical handoffs pending

Candidate diagnostic r1:98304bytes at0x08008000, SHA256 `efcc12644faa6774c19df7231f86d184dcf5b04b2a152f08417e6139f2e7bb55`. Compiled code2796bytes,bss24bytes. Independent forced rebuild byte-identical. ELF load/vector/RAM bounds passed. No normal firmware edited or diagnostic linked into production targets.

-13 Python tests exercise compiled C protocol and Mac collector: full96KiB binary fidelity, every byte0..255,129-byte odd windows/final6bytes,CRC16/CRC32,1000 repeated windows,all fixed-area edges,unsupported/blocked/partial reads,capacity,FC06/16 rejection,density gate,wrong UID,metadata/CRC corruption,duplicate/reorder sequence,reset between passes,timeouts,double mismatch,private output.
-3 ARM test methods execute actual ELF: four boot/RTU scenarios(identity,app,FC16 rejection,bootblocked), direct guarded-read allowlist endpoints, and synthetic precise-fault exception-frame recovery. Hooks assert no CN105 TX,flash-controller write or I2C operation. This is a simulated peripheral model; physical exception/protection behavior remains unverified.
-ASan/UBSan native executable:65536 indexed-address cases and10000 malformed frames passed; bounds canaries and unsupported-range no-dereference checks passed.
-Read-only site check: Serial.GetConfig only. Current js_uart115200 8N1 blocks the helper's required existing Modbus-client9600 8N1 mode. No Serial.SetConfig/script/device restart/pump write performed.
-Local historical return image16476bytes SHA256 `dcd1efe7634fdf38a67c6ffcd8e95614a963b232619b788549256b64ff692b44` confirmed against saved P76flash provenance. Not fresh live image readback; reverify installed version/UID/native settings/no lease at physical handoff.

Boot READ_BLOCKED by policy; EEPROM UNSUPPORTED by evidence. TC1–7 offline portions covered; physical TC1/4/5/6/7 and TC8 restoration NOT_TESTED. No memory capture or installation authorized/performed. Raw dumps/private UID are not in repository evidence.

Commands: `make ... all test sanitize-test`, Python `test_arm.py` outside sandbox for Unicorn JIT, then forced rebuild and byte comparison. Tools supplied via /tmp/procon-export/.local; distribution Makefile has portable configurable paths.
