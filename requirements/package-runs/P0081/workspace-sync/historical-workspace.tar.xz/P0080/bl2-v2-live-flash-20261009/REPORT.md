# P0080 BL2 protocol2 physical transfer — 2026-10-09

Operator authorized update with DIP00000000. Bootloader discovery/preflight passed. Full98304-byte application erase acknowledged71; all223 write packets acknowledged73, total53312 bytes. No retry. Original bootloader excluded, no option-byte changes. Image SHA256 c3f4cc3076e35df64b69efe81ce2a132d81b2e20d9c5d65b9cda11a485af8cb6.

Completed18:45:03 UTC. Cleanup verified: all scripts stopped/disabled, relays off, persisted Serial js_uart1152008N1. Firmware readback and normal boot NOT yet verified. Seven feature module binaries identical to installed snapshot version; BL2 changed to protocol2/data-only manifest fingerprint.

Next: power off Procon, DIP10000110, power on. Read-only verify via verify_bl2_v2_boot.py: status protocol2, full-set valid1, fingerprintd9dd3c62, same UID, snapshot sequence and CN105 updates; control idle. Do not use legacy protocol1 updater. No additional physical action performed.
