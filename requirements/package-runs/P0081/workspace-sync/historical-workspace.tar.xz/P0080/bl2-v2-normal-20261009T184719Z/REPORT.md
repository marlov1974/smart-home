# P0080 BL2 v2 normal-boot verification — 2026-10-09

Operator restored normal DIP and restarted. Three read-only FC04 status reads passed protocol2 gate, full-set-valid1, mode0, layout3833993797, manifest prefix CRC0xd9dd3c62 (3655154786), matching local release. Same UID5898296/909201410/540096578. Snapshot sequence1/2/3 and sample generations advance. CN105 linked, error/UART-error counters zero, uptime rises with no reset observed.

Latest frozen capture: compressor0Hz, supply/return28/28C, brine7/7C, primary flow13L/min, DHW50.5C, native target30.5C. No control lease or effect target enabled. Device-reported values only; no diagnosis of why compressor is stopped. Brine pump status/step remain unavailable.

Temporary UART helper stopped/disabled; runtime restored115200 and cleanup verified. No actuator/control writes, OTA entry, or flash writes during this verification. This validates physical status fingerprint reporting and normal boot. Protocol2 transfer/base-mismatch behavior remains emulator-tested, not a new physical OTA test.

Raw provenance: rpc.jsonl, samples.json, result.json, cleanup.json in this directory.
