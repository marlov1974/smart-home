"""P0080 read-only verification of D1 WAIT expiry, no control commands."""
import sys,json,struct,time
from pathlib import Path
from datetime import datetime,timezone
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'implementation-smart-home/procon/modular/tools'))
from shelly_ota import Sender,crc16
out=root/('d1-after-wait-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
s=Sender('DEVICE_HOST','shellypro2-80f3dac8bfec',out)
try:
 s.start();rows=[]
 for i in range(2):
  st=s.status(1);assert st['uid']==[5898296,909201410,540096578] and st['valid']==1 and st['mode']==0 and st['manifest_crc']==0xd9dd3c62,st
  b=struct.pack('>BBHH',1,4,0,16);r=s.exchange(b+crc16(b));assert len(r)==37 and r[:3]==bytes([1,4,32]) and r[-2:]==crc16(r[:-2])
  words=list(struct.unpack('>16H',r[3:-2]));rows.append({'timestamp':datetime.now(timezone.utc).isoformat(),'status':st,'base':words});print(rows[-1],flush=True)
  if i==0:time.sleep(8)
 assert rows[-1]['base'][11]==1 and rows[-1]['base'][9]>rows[0]['base'][9]
 (out/'result.json').write_text(json.dumps({'verified':True,'samples':rows},indent=2))
finally:s.stop();print('Evidence',out,flush=True)
