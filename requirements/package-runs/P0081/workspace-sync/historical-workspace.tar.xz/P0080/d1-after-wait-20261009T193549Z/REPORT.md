# D1 normal response after WAIT

D1 WAIT expiry physically verified2026-10-09 19:35:51–19:36:01 UTC: address1 sameUID, mode0, fullsetvalid1, correct prefixCRC, compressor26Hz valid, CN105 replies402→403, uptime2942→2952, errors0/UARTerrors0. No reset during observation. Read-only FC04; helper cleanup verified. Evidence P0080/d1-after-wait-20261009T193549Z.
