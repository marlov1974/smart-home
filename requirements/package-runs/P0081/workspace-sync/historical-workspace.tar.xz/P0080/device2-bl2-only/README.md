# P0080 device2 BL2-only installation

Operator replaced connected Procon, requested next address2 and BL2 first, rest via OTA. Exact validated release-bl2-v2 BL2 bytes retained; all feature slots/manifest erased. Full98304-byte application erase, only6584 BL2 load bytes programmed, original bootloader excluded. No UID modification: factory UID identifies hardware, Modbus address is DIP-selected.

After flash, power off and set DIP01000110 (DIP2,6,7 ON, all others OFF; switch order1..8), power on. RawDIP0x62 corresponds to address2. This follows prior address1 DIP10000110/raw0x61 convention. BL2-only status expected B180/protocol2/valid0/manifestCRC0. No CN105 module execution until all7 modules installed by OTA and valid manifest committed.

No effect control activated. Normal boot/new UID must be read before full-set OTA initialization. Older unit remains address1. Physical preboot discovery does not expose the factory UID.
