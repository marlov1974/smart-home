# P0080 second Procon: BL2-only installation,2026-10-09

Operator connected a different Procon in DIP00000000 and explicitly requested BL2 first, remaining firmware over OTA, next device address. Existing device1 UID remains5898296/909201410/540096578; new factory UID unknown until resident normal-mode read. No fabricated UID or persistent software address assigned: next Modbus address2 is selected with physical DIP01000110 (switches2,6,7 ON).

Exact protocol2 BL2 from release-bl2-v2 retained. Full application erase98304 bytes acknowledged71, only6584 load bytes written in28 packets, each direct73 ACK. Rest of application intentionally erased. Full image hash4670bb06b3ca0829106a5bb73141270dfcd77aafa05ac748f3c161a9ced84732. Original bootloader excluded, no option-byte writes. Transfer complete18:59:12 UTC; cleanup verified, scripts stopped/disabled, relays off. No normal-boot/readback verification yet.

Real C emulator test initialized this exact blank-feature image using all7 OTA chunks and compared all98304 bytes with release-bl2-v2: exact match,199 OTA frames. This is offline evidence; physical full-set initialization remains pending.

Next operator action: power off, DIP01000110, power on. Then read resident address2/status384: protocol2, valid0, CRC0, unique factory UID. Blank modules are expected and must not run CN105. Complete authorized OTA initialization with all7 modules, then verify valid1/fingerprintd9dd3c62 and telemetry. Native-state automatic gate cannot inspect FTC without modules; no pump commands have been sent by this BL2-only image.
