# P0080 two-device OTA preflight,2026-10-09

User confirmed both Procons on shared bus and authorized D1 WAIT then D2 installation. Planned WAIT900seconds (protocol supports1..3600). Known D1 responded at address1, protocol2/fullsetvalid1/fingerprintd9dd3c62/expected factory UID. D2 address2 status returned zero bytes during initial preflight and three subsequent read-only retries with1second receive windows. D1 remained mode0. No WAIT, OTA_ENTER, flash erase/write or pump control commands were sent. Temporary scripts stopped/disabled and runtime baud restored115200, cleanup verified.

Evidence ota-20261009T191331Z and probe-20261009T191506Z. Operator asked to confirm D2 power-cycle after DIP01000110 (2,6,7 ON). Full-set OTA awaits D2 resident reply/new UID; never send addressless transfer before both addressed devices are identified and D1 WAIT is acknowledged.
