"""P0080 authorized D1 WAIT + blank D2 full-set OTA, no FTC control commands."""
from pathlib import Path
import sys,json
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];M=ROOT/'implementation-smart-home/procon/modular'
sys.path.insert(0,str(M/'tools'))
from shelly_ota import Sender
from ota import plan
class Install(Sender):
 def start(self):
  super().start()
  d1=self.status(1);d2=self.status(2)
  assert d1['uid']==[5898296,909201410,540096578] and d1['valid']==1 and d1['manifest_crc']==0xd9dd3c62,d1
  assert d2['uid']!=d1['uid'] and d2['uid'] not in ([0,0,0],[0xffffffff]*3),d2
  assert d2['valid']==0 and d2['manifest_crc']==0 and d2['mode']==0,d2
  assert d1['layout']==d2['layout']==3833993797
  (self.out/'inventory.json').write_text(json.dumps({'d1':d1,'d2':d2,'wait_seconds':900,'authorization':'REDACTED'},indent=2))
  print('Confirmed D1',d1,flush=True);print('Confirmed blank D2',d2,flush=True)
 def enter(self,sid,cmd):
  super().enter(sid,cmd)
  (self.out/('handoff-%d.json'%sid)).write_text(json.dumps({'timestamp':datetime.now(timezone.utc).isoformat(),'sid':sid,'command':cmd,'seconds':900}))
  print('Handoff',sid,hex(cmd),'900 seconds',flush=True)
p=plan(M/'release-bl2-v2',M/'release-bl2-v2');p.update(mask=127,slots=list(range(7)),expected_manifest_crc=0)
out=ROOT/'device2-bl2-only'/('ota-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
s=Install('DEVICE_HOST','shellypro2-80f3dac8bfec',out)
try:s.transfer(p,2,[1],repair=True)
except BaseException as e:
 (out/'failure.json').write_text(json.dumps({'error':repr(e)}));raise
finally:s.stop();print('Evidence',out,flush=True)
