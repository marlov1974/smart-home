# P0080 D2 full OTA with D1 WAIT — 2026-10-09

Operator confirmed D2 reboot and both units on shared bus. D1 address1 factoryUID5898296/909201410/540096578 matched inventory, fullset valid/protocol2/fingerprintd9dd3c62 and native ready. Blank D2 address2 UID5373989/909201412/540096578 distinct, protocol2/valid0/CRC0 and same layout. No device identity was written: UID factory-read, address physically DIP-selected.

D1 acknowledged FE WAIT900s at2026-10-09T19:16:38.171761+00:00. D2 acknowledged FF ENTER. Native state on blank D2 is not observable before modules; known BL2-only image cannot issue FTC control. All7 modules installed,45056 padded firmware bytes,199 frames. Commit and EXIT succeeded with updated2s receiver window, no manual recovery. D2 rebooted, valid1/normal0/prefixCRC d9dd3c62/same UID confirmed. This is a successful physical protocol2 full-set OTA on a shared two-device bus.

Postboot three frozen snapshots1/2/3, CN105 linked, zero protocol/UART errors, generations advance. Latest device-reported values: compressor36Hz, flow34.5C, return30.5C, brine5.0/3.0C, primary flow14.0L/min, DHW51.5C. Control state0; no effect lease or pump setpoint writes.

Cleanup verified after uploader and reader: helper stopped/disabled, serial restored115200, relays off. D1 remains scheduled to leave WAIT approximately2026-10-09T21:31:38.171761+02:00; physical post-expiry D1 response not yet checked. WAIT retains native CN105 servicing and expires automatically; no early wake command exists in this implementation.

Evidence: device2-bl2-only/ota-20261009T191632Z and device2-normal-20261009T192246Z. Original earlier silent-D2 preflight retained; operator identified missing reboot. No Git commit/push.
