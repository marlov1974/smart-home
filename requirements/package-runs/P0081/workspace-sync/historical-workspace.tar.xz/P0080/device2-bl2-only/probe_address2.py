import sys,json,time
from pathlib import Path
from datetime import datetime,timezone
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'implementation-smart-home/procon/modular/tools'))
from shelly_ota import Sender,status_frame,crc16
s=Sender('DEVICE_HOST','shellypro2-80f3dac8bfec',root/'device2-bl2-only'/('probe-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')))
try:
 s.start();print('D1',s.status(1),flush=True)
 for i in range(3):
  r=s.exchange(status_frame(2),1.0);print('D2',i,r.hex(),flush=True)
  if r:break
  time.sleep(2)
finally:s.stop();print('Evidence',s.out,flush=True)
