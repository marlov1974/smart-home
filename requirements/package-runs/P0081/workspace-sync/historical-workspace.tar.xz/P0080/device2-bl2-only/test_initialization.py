"""P0080 exact BL2-only -> complete protocol2 image, offline real C OTA."""
from pathlib import Path
import sys,ctypes,struct
root=Path(__file__).resolve().parents[1];m=root/'implementation-smart-home/procon/modular'
sys.path.insert(0,str(m/'tools'))
from ota import plan,transactions,decode
c=ctypes.CDLL(str(m/'build-bl2-v2/ota-test.dylib'))
c.ota_handle.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.c_size_t];c.ota_handle.restype=ctypes.c_size_t;c.flash_at.restype=ctypes.c_void_p
image=(root/'device2-bl2-only/install.bin').read_bytes();c.reset_image(image);c.ota_reset();assert c.modules_valid()==0
p=plan(m/'release-bl2-v2',m/'release-bl2-v2');p.update(mask=127,slots=list(range(7)),expected_manifest_crc=0)
count=0
for b in transactions(p,[1,2,3]):
 out=ctypes.create_string_buffer(64);n=c.ota_handle(b,len(b),out,64);r=decode(out.raw[:n],b[2],struct.unpack('<H',b[4:6])[0]);assert r['status']==0,r;count+=1
assert c.modules_valid()==1
assert ctypes.string_at(c.flash_at(0x08008000),98304)==(m/'release-bl2-v2/install.bin').read_bytes()
print('PASS real C: exact BL2-only image + all7 OTA modules produces exact full release; frames',count)
