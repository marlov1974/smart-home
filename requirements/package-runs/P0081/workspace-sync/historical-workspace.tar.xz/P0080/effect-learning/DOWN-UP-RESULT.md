# VP1: nedsteg och större uppsteg — 2026-10-09

Alla tre avtalade perioder slutfördes: 15 minuter32,5 C, 20 minuter32 C och20 minuter38 C. VP2 verifierades avstängd under provet. Ingen ny firmware installerades under eller efter mätningen.

| Börvärde | Förlopp | Sista3 minuter, medel |
|---|---|---|
|32,5 C|38→40→42→44 Hz|44 Hz; fram31,5/retur27 C;5,96 kW|
|32 C|Kurvövergång gav stopp; återstart36→42→44→48→46 Hz|46 Hz; fram31,5/retur27 C;5,96 kW|
|38 C|Kurvövergång gav stopp; återstart36→42→52→60→58→60→62 Hz|62 Hz; fram34,07/retur28,07 C;7,94 kW|

Vattenflödet var19 l/min. Effekt är vattensidans beräknade värmetransport, inte elektrisk effekt. Givarnas0,5-C-steg ger ungefär0,66-kW-steg. Under kompressorstopp är kvarvarande värmetransport inte kompressorproduktion.

## Användbar första approximation

Tre tillstånd behövs: väntan efter stopp, uppstart och normal reglering. Återstarterna kom cirka5 minuter efter den första snapshoten med respektive nytt börvärde. Rapporteringen av0 Hz hade olika fördröjning: observerad0→positiv var300 respektive226 sekunder. Utifrån givargenerationernas tider blir intervallen279–320 respektive196–259 sekunder. Detta motsvarar inte en verifierad intern timer, men stöder inte antagandet att vi alltid måste vänta minst10 minuter.

Båda återstarter började36 Hz och fortsatte42 Hz efter ungefär1 minut. Därefter skilde de sig: 32-C-provet nådde48 Hz efter cirka3 minuter från återstart och reglerade ned till46; 38-C-provet nådde52 Hz efter cirka3 minuter och60 Hz efter cirka4 minuter, korrigerade till58 och ökade sedan långsamt till60/62. Större fel ger alltså tydligt kraftigare respons efter en liknande första startsekvens. Små nedregleringar är möjliga under fortsatt drift:48→46 och60→58 observerades utan stopp.

Som lokal startgissning för nästa regulatorversion motsvarade6 C högre börvärde cirka16 Hz och2 kW mer i den sena delen av dessa prov (ungefär2,7 Hz/C och0,33 kW/C). Det är en jämförelse mellan dessa driftpunkter, inte en generell statisk pumpkurva: returtemperatur och starthistorik skiljde sig. Använd framför allt de uppmätta tidsförloppen, inte enbart denna kvot.

Den långsamma delen kan approximeras som fel- och tidsberoende med diskreta frekvensändringar, men ett rent gradminuttröskelvillkor beskriver inte hela beteendet. Vid litet fel kan frekvensen ligga still länge; stort fel gav först snabb upptrappning och sedan mindre2-Hz-korrigeringar. Temperaturresponsen fortsatte efter Hz-ändringar. Ingen bestående upprepad Hz-pendling observerades under de avgränsade perioderna; korta toppar48/60 följda av2-Hz-sänkningar ska behållas i modellen.

## Viktig störning och nästa test

Nuvarande firmware krävde AUTO mellan nya mål. Kurvmålet30,5 C låg under faktisk framledning och FTC gick till vila under övergången. Nedsteget var därför inte ett rent nedsteg under obruten drift, och38-C-förloppet omfattade återstart. Den begärda direktuppdateringen har byggts/testats offline efter provet; nästa rena upp/ned-test ska använda den.

## Återställning och transport

VP1 återställdes med verifierad power1/kurvläge2. AUTO sekvens65 skickades tillVP2 vid21:47:47 UTC. Shelly-hjälpens uttryckliga3600000-ms-timer stoppade script8 vid21:47:56 UTC mitt under återläsningen; detta var hjälpkodens gräns, inte ett fel i VP eller ett påvisat Shelly-systemtak. Outcome.completed gäller mätperioderna, inte den då oavslutade slutverifieringen.

Ny verifiering04:18–04:19 UTC den10 oktober visade båda power1, mode2, DHW52 C, boost0, controlIDLE/saved0. D2 accepted/applied65 bekräftade den tidigare AUTO-ordern; ingen ytterligare styrorder skickades vid efterkontrollen. Kurvmålen hade därefter ändrats naturligt till31,5 respektive32 C och skrevs inte tillbaka till äldre värden. Hjälp och reläkontroll slutfördes, cleanup verified.

Evidens: `down-up-20261009T204755Z/{events,rpc}.jsonl`, `sequence-analysis.json`, `restoration.json`, samt `down-up-restore-20261010T041840Z/{restoration,cleanup}.json`. Analysverktyg:`analyze_sequence.py`.
