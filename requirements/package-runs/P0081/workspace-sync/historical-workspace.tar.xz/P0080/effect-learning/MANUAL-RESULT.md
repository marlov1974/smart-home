# Manuell identifiering av VP1 — 2026-10-09

## Syfte och genomförande

Ta fram en praktiskt användbar approximation för effektstyrning via framledningsbörvärde. D1=VP1 och D2=VP2 är operatörsbekräftat. VP2 stoppades och effektprovet kördes isolerat på VP1. Inga firmwareändringar. Procon höll ett fast temperaturbörvärde; Shelly/Mac förnyade 180-sekundersmandat och mätte, utan EFFECT-regulatorn.

Baslinje: kurvdrift, börvärde30,5 C, faktisk framledning29 C, kompressor34 Hz, vattenflöde19 l/min. Sex isolerade baslinjesnapshots. Fast börvärde32,5 C skickades20:19:31 UTC (22:19:31 lokal tid). Mode1 och mål3250 lästes tillbaka. Kompressorn fortsatte gå. Ursprunglig kurvdrift sparades och återställdes efter provet.

## Observerad respons

| Period | Hz | Framledning | Retur | Beräknad värmeeffekt |
|---|---:|---:|---:|---:|
| Baslinje, medel av6 snapshots |34|29,0 C|26,08 C|3,86 kW|
| Första ökningen, observerad cirka63 s efter kommandot |40|29,5 C|26,0 C|4,63 kW i denna snapshot|
| Platå, cirka4–9 min efter första entry-snapshot |40|30,0 C|26,5 C|4,63 kW,12 snapshots|
| Sen period, cirka10–12 min |42|30,5 C|26,7 C|5,03 kW,5 snapshots|

42 Hz observerades20:29:28 UTC, cirka10 minuter efter kommandot. 40 Hz hade hållits under nästan9 minuter. Inga observerade nedsteg eller kompressorstopp under kontrollperioden. Vattenflödet låg på19 l/min. Halvgradig temperaturupplösning motsvarar cirka0,66 kW per differenssteg vid detta flöde; momentan kW ska inte tolkas som en finupplöst effektmätning.

Extern integrering av börvärde minus framledning gav cirka26,4 K.min fram till första42-Hz-observationen, räknat från första entry-snapshot. Detta är vår valda referens, inte avläsning av någon intern räknare.

## Första arbetsmodell

Lokalt runt denna driftpunkt gav +2 C börvärde en snabb ändring på cirka+6 Hz inom en minut och totalt+8 Hz efter cirka10 minuter. Temperaturresponsen var långsammare: ungefär+0,5 C första minuten, +1 C efter4 minuter och +1,5 C efter10 minuter. Mätt termisk effekt ökade ungefär0,8–1,2 kW mot baslinjen.

Använd detta som en lokal stegmodell med snabb respons och långsam korrigering. Ett första grovt mått är3 Hz/C börvärdesändring för den snabba delen, eller4 Hz/C efter10 minuter. Dessa kvoter gäller det genomförda +2-C-steget och är inte en identifierad generell proportionalförstärkning mot temperaturfelet. Både temperaturfelet och returtemperaturen ändrades under provet.

Arbetsmodellen kan likna en proportionell reaktion plus en långsam, stegvis/integrerande korrigering. En enda fast gradminuttröskel är ännu inte en användbar modell: först kom en snabb6-Hz-ändring och sedan en lång platå med fortsatt temperaturunderskott. Nästa informativa prov är en annan stegamplitud med längre hålltid (exempelvis+1 C och därefter+3 C från jämförbar drift), följt av ett nedsteg. Jämför både tiden till nästa2-Hz-steg och ackumulerat temperaturfel. Målet är prediktion och praktisk styrning, inte att bevisa Mitsubishis implementation.

Tills vidare bör vår effektreglering inte lägga temperaturhöjningar på varandra varje minut: den observerade långsamma responsen fortsatte först efter cirka10 minuter. Börja med små steg och utvärdera Hz tidigt men värmeeffekt över flera minuter; justera denna arbetsregel med nästa prov.

## Avslut och återställning

Planerat15-minutershold avslutades i förtid efter ungefär12 minuter användbara stegsnapshots (cirka12,5 minuter från kommandot). Orsak: testskriptet krävde giltigt heat_W i varje snapshot. Den sista snapshoten hade färska temperaturer (120 ms), färskt vattenflöde (7295 ms) och42 Hz, men temperatur/flöde tillhörde olika mätomgångar och heat_W var korrekt markerat saknat/status2. Inget observerat VP-fel eller kommunikationsbortfall.

Efteråt ändrades endast testskriptet: primärgivare måste fortsatt vara giltiga/färska, men saknad härledd effekt får bli en datalucka. Analysverktyget utesluter saknad effekt ur kW-medelvärden och redovisar antalet giltiga effektprover. Detta beteende har inte körts i ett nytt fysiskt prov här.

Återställning verifierad för båda: power1, kurvläge2, mål30,5 C, varmvattenmål52 C, boost0, controlIDLE, saved0. Shelly-cleanup verifierad. VP2 återgick till native driftläge1; återställd power betyder inte bekräftad kompressorstart.

## Evidens

`manual-20261009T201601Z/events.jsonl`, `rpc.jsonl`, `original-settings.json`, `failure.json`, `restoration.json`, `cleanup.json`, `analysis.json`. Tiderna i analys.json utgår från första entry-snapshot20:19:44, inte exakt kommandotid. Källornas åldrar och generationer finns kvar i råloggen. Analys: `python3 analyze_manual.py manual-20261009T201601Z`.
