# Isolated VP1 EFFECT trial — 2026-10-09

Operator confirmed D1=VP1 and D2=VP2. Temporary VP2 OFF and VP1 EFFECT were authorized. Evidence: `run-20261009T200304Z/{events,rpc}.jsonl`, `failure.json`, `restoration.json`.

## Result

VP2 OFF succeeded: native power=0 and compressor=0 in two observations. VP1 remained at 28 Hz during the isolated baseline; sampled water-side heat was approximately 2.6–3.3 kW. This is calculated thermal output, not electrical consumption or COP.

EFFECT request: 4000 W, maximum target 38 C, renewable 180 s lease, intended observation 900 s. First submission returned BUSY; same sequence was then accepted at approximately 20:05:40 UTC. Firmware aborted before applied sequence advanced: accepted=1, applied=0, error=8, restores=1. EFFECT limit_reason=1 identifies BAD_FEEDBACK. No regulator decisions or adjustments occurred. The 15-minute regulation/stability test was therefore NOT completed.

At the first post-abort capture, feedback was WARMUP with two pairs spanning nine seconds; communication remained linked, compressor remained 28 Hz, flow/return 29.5/27 C, calculated heat 3309 W. The feedback window had been cleared since the ready pre-command observations. These readings are after the failure, not an atomic capture of its trigger.

Code inspection: control.c rejects non-ready feedback except PENDING, WAIT_NATIVE and SETTLING. effect_feedback.c clears the window for stale/invalid/zero-flow/DHW/link-loss observations; subsequent valid samples can report WARMUP. CN105 control transactions have priority over normal telemetry while control is busy. Telemetry starvation during entry is a hypothesis, not established by the current host samples. Do not attribute the abort to compressor restart lockout: no compressor stop was observed on VP1.

## Verified restoration and cleanup

VP1 restored automatically, verified 20:06:10 UTC. VP2 restored via addressed AUTO sequence3, verified 20:06:36 UTC. Both: control IDLE, saved=0, native power=1, curve mode=2, flow target30.5 C, DHW target52 C, boost=0. VP2 compressor was still0 at restoration, with native operating mode1; power restoration is not proof of immediate compressor restart.

Transport cleanup completed; helper script8 stopped/disabled and all scripts stopped. Both Shelly relay outputs remained false. No firmware changes or additional active trials performed.

## Next diagnostic requirement

Capture/latch feedback quality, source ages/generations and control phase at the first BAD_FEEDBACK trigger. Reproduce control-entry scheduling offline before changing any guard. Preserve stale/link/native-mode protections. A new sustained live trial is needed after the entry failure is understood; these observations cannot establish stable 4 kW or 6 kW regulation.
