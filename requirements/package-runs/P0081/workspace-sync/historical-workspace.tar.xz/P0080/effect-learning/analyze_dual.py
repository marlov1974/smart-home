"""P0080 summarize real dual EFFECT samples; no live I/O."""
import json,statistics,sys
from pathlib import Path
p=Path(sys.argv[1]);events=[json.loads(s) for s in (p/'events.jsonl').read_text().splitlines()]
result={}
for sid in (1,2):
 rows=[(x['data']['elapsed'],r) for x in events if x['kind']=='dual_sample' for r in x['data']['rows'] if r['sid']==sid and x['data']['elapsed'] is not None]
 def summary(v):
  return {'n':len(v),'min':min(v),'max':max(v),'mean':statistics.mean(v),'stdev':statistics.pstdev(v)} if v else None
 full=[r for _,r in rows];late=[r for t,r in rows if t>=max(0,rows[-1][0]-600)]
 def watts(rs):return [r['feedback']['short_w'] for r in rs if r['feedback']['quality']==0 and r['feedback']['short_w'] is not None and r['feedback']['short_w']>=0]
 w=watts(late);changes=[]
 for t,r in rows:
  target=r['native']['flow']
  if not changes or changes[-1]['target_cC']!=target:changes.append({'elapsed':t,'target_cC':target})
 result[sid]={'samples':len(rows),'elapsed_last':rows[-1][0] if rows else None,'all_ready_power_W':summary(watts(full)),'last10min_ready_power_W':summary(w),'last10min_within_500W':sum(abs(x-6000)<=500 for x in w)/len(w) if w else None,'target_changes':changes,'phases':sorted(set(r['effect']['phase'] for r in full)),'qualities':sorted(set(r['feedback']['quality_name'] for r in full))}
 for key in ('compressor_Hz','flow_cC','return_cC'):
  result[sid][key]=summary([r['snapshot']['samples'][key]['value'] for r in full if r['snapshot']['samples'][key]['status']==1])
(p/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
