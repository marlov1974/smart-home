"""Offline approximate thermal-energy and tracking analysis; no device I/O."""
import json, statistics, sys
from pathlib import Path
p=Path(sys.argv[1]); events=[json.loads(s) for s in (p/'events.jsonl').read_text().splitlines()]
start=next(e for e in events if e['kind']=='both_applied')
from datetime import datetime
origin=datetime.fromisoformat(start['time']).timestamp()
result={}
for sid in (1,2):
 rows=[]
 for e in events:
  if e['kind']!='dual_sample' or e['data']['elapsed'] is None:continue
  r=next(r for r in e['data']['rows'] if r['sid']==sid)
  t=datetime.fromisoformat(r['snapshot']['captured_at_host']).timestamp()-origin
  f=r['feedback']; n=r['native']; w=f['short_w']
  valid=f['quality'] in (0,2) and w is not None and 0<=w<100000 and f['last_age_s']<60
  if n['operating_mode'] in (0,1,6) or (f['quality']==8 and r['snapshot']['samples']['compressor_Hz']['value']==0):w=0;valid=True
  rows.append((t,w if valid else None,r))
 energy=coverage=0
 for (t0,w0,_),(t1,w1,_) in zip(rows,rows[1:]):
  a=max(0,t0);b=min(900,t1)
  if b<=a or t1-t0>90 or w0 is None or w1 is None:continue
  wa=w0+(w1-w0)*(a-t0)/(t1-t0);wb=w0+(w1-w0)*(b-t0)/(t1-t0)
  energy+=(wa+wb)/2*(b-a)/3600000;coverage+=b-a
 late=[w for t,w,r in rows if 600<=t<=900 and w is not None]
 inside=[t for t,w,r in rows if 0<=t<=900 and w is not None and 5500<=w<=6500]
 vals=[r['snapshot']['samples']['flow_cC']['value']/100 for t,w,r in rows if 0<=t<=900]
 result[sid]={'approx_heat_kWh_covered':energy,'coverage_s':coverage,'first_observed_5500_6500_s':min(inside) if inside else None,'last5min_mean_W':statistics.mean(late) if late else None,'last5min_min_W':min(late) if late else None,'last5min_max_W':max(late) if late else None,'last5min_stdev_W':statistics.pstdev(late) if late else None,'last5min_in_band_fraction':sum(5500<=w<=6500 for w in late)/len(late) if late else None,'actual_supply_max_C':max(vals) if vals else None,'sample_times_note':'Snapshot capture time; feedback read follows and is not atomic. Rolling heat power is approximate, not a calibrated energy meter.'}
(p/'energy-tracking.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
