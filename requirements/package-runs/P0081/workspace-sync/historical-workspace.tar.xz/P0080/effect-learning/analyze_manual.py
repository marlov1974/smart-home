"""Summarize actual-source readings, temperature error and accumulated K.min."""
import json,sys,statistics
from pathlib import Path
from datetime import datetime

def analyze(path):
 events=[json.loads(l) for l in (path/'events.jsonl').read_text().splitlines()]
 rows=[];integral=0;previous=None;start=None
 for event in events:
  if event['kind'] not in ('manual_baseline','manual_entry','manual_hold'):continue
  d=event['data'];s=d['snapshot']['samples'];ts=datetime.fromisoformat(d['snapshot']['captured_at_host']).timestamp()
  v=lambda k:s[k]['value']
  flow=v('flow_cC')/100;target=v('flow_target_cC')/100;e=target-flow
  if event['kind']!='manual_baseline' and start is None:start=ts
  if start is not None:
   if previous is not None:integral+=(e+previous[1])/2*(ts-previous[0])/60
   previous=(ts,e)
  rows.append({'time':d['snapshot']['captured_at_host'],'phase':event['kind'][7:],'timestamp':ts,'Hz':v('compressor_Hz'),'W':v('heat_W'),'flow_C':flow,'return_C':v('return_cC')/100,'flow_L_min':v('flow_cL_min')/100,'target_C':target,'error_K':e,'integral_K_min':integral,'source_generation':s['compressor_Hz']['generation']})
 for r in rows:r['elapsed_min']=(r['timestamp']-(start or rows[0]['timestamp']))/60
 buckets={}
 for r in rows:
  key='baseline' if r['phase']=='baseline' else str(int(max(0,r['elapsed_min'])))
  buckets.setdefault(key,[]).append(r)
 def mean(rs,f):
  values=[r[f] for r in rs if r[f] is not None]
  return round(statistics.mean(values),3) if values else None
 summary={k:{'samples':len(rs),'valid_power_samples':sum(r['W'] is not None for r in rs),**{f:mean(rs,f) for f in ('Hz','W','flow_C','return_C','flow_L_min','target_C','error_K')},'integral_K_min':round(rs[-1]['integral_K_min'],3)} for k,rs in buckets.items()}
 result={'rows':rows,'minute_means':summary,'integral_reference':'zero at first entry snapshot; not an internal FTC accumulator','timing':'host frozen-snapshot time, asynchronous source ages retained in raw events'}
 (path/'analysis.json').write_text(json.dumps(result,indent=2))
 print(json.dumps(summary,indent=2))
 return result
if __name__=='__main__':analyze(Path(sys.argv[1]))
