import json,sys,statistics
from pathlib import Path
from datetime import datetime
def stamp(s):return datetime.fromisoformat(s).timestamp()
def analyze(p):
 events=[json.loads(l) for l in (p/'events.jsonl').read_text().splitlines()]
 result={'stages':{},'notes':['Host snapshot times; asynchronous source ages retained. Thermal watts are water-side estimate, not electric input. AUTO/curve transitions confound clean step identification.']}
 for name in ('stabilize','down','up'):
  es=[e for e in events if e['kind'] in ('manual_'+name,'manual_'+name+'_entry')]
  if not es:continue
  rows=[];changes=[];prior=None;t0=stamp(es[0]['data']['snapshot']['captured_at_host'])
  for e in es:
   d=e['data'];s=d['snapshot'];v=s['samples'];t=stamp(s['captured_at_host'])
   r={'time':s['captured_at_host'],'minutes':(t-t0)/60,'hz_source_time':t-v['compressor_Hz']['age_ms']/1000,
      'Hz':v['compressor_Hz']['value'],'flow_C':v['flow_cC']['value']/100,'return_C':v['return_cC']['value']/100,
      'target_C':v['flow_target_cC']['value']/100,'flow_L_min':v['flow_cL_min']['value']/100,'heat_W':v['heat_W']['value'],
      'native_operating_mode':d['native']['operating_mode']}
   rows.append(r)
   if r['Hz']!=prior:changes.append(r);prior=r['Hz']
  late=[r for r in rows if r['minutes']>=rows[-1]['minutes']-3]
  def mean(k):
   vals=[r[k] for r in late if r[k] is not None]
   return statistics.mean(vals) if vals else None
  pauses=[];begin=None
  for i,r in enumerate(rows):
   if r['Hz']==0 and begin is None:begin=i
   elif r['Hz']>0 and begin is not None:
    pauses.append({'first_zero':rows[begin]['time'],'first_positive':r['time'],'observed_zero_to_positive_s':r['hz_source_time']-rows[begin]['hz_source_time'],
      'lower_bound_s':rows[i-1]['hz_source_time']-rows[begin]['hz_source_time'],
      'upper_bound_s':r['hz_source_time']-rows[max(0,begin-1)]['hz_source_time']});begin=None
  result['stages'][name]={'samples':len(rows),'span_min':rows[-1]['minutes'],'Hz_min':min(r['Hz'] for r in rows),'Hz_max':max(r['Hz'] for r in rows),
   'last_three_minutes_mean':{k:mean(k) for k in ('Hz','flow_C','return_C','heat_W')},'changes':changes,'pauses':pauses,'rows':rows}
 (p/'sequence-analysis.json').write_text(json.dumps(result,indent=2))
 for name,s in result['stages'].items():
  print(name,{k:v for k,v in s.items() if k not in ('rows','changes')})
  print('Hz steps',[(round(r['minutes'],2),r['Hz'],r['flow_C']) for r in s['changes']])
 return result
if __name__=='__main__':analyze(Path(sys.argv[1]))
