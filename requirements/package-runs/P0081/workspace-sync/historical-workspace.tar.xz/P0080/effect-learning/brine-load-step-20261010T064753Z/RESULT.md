# Brine load-step experiment — 2026-10-10

Completed with restoration and transport cleanup verified. D1=VP1, D2=VP2. All event timestamps are UTC (local time UTC+2).

## Method

Host-controlled FIXED_FLOW adjustments toward 4 kW thermal per pump, not the native EFFECT regulator. Initial native curve target 31.5 C on both. Steps of 0.5 C, at least 120 seconds apart per pump; final target 35 C. Thermal power calculated from primary water flow and temperature difference. Accepted five-minute window mean tolerance 3.4–4.6 kW. This achieved approximate loading, not an exact matched 4 kW test.

The earlier read-only attempt (../brine-load-step-20261010T062702Z) timed out after 20 minutes spanning VP1 DHW and restart wait; both units untouched, cleanup verified by runner. VP1 DHW produced about 6.3–7.5 kW at 68 Hz in observed samples, falling to about 5.6 kW toward completion. This is calculated thermal output, not electric consumption.

This run reached its baseline criterion after 802.5 seconds of active observation, at 07:04:01 UTC. VP2 was then restored out of FIXED_FLOW and commanded OFF. Post-stop observation lasted 385.9 seconds. Restoration followed.

## Comparison

Each reported window contains eight samples spanning about 278 seconds within the final five minutes of its phase. See analysis.json and events.jsonl for values and provenance.

| Measurement | Both running | VP2 stopped |
|---|---:|---:|
| VP1 mean calculated heat | 3.418 kW | 3.960 kW |
| VP2 mean calculated heat | 3.583 kW | not available in stopped feedback |
| VP1 brine inlet | 4 C throughout | mean 3.125 C; final seven samples 3 C |
| VP1 brine outlet | 2 C throughout | mean 2.125 C; final seven samples 2 C |
| VP1 brine pump | 3780–3810 rpm | 3780–3810 rpm |
| VP2 brine pump | 3780–3810 rpm | 0 rpm, fresh valid readings |
| VP1 water flow | 14–15 l/min | 19 l/min |
| VP2 water flow | 16 l/min | 0 l/min |
| VP2 water pump / compressor | on / 34 Hz | off / 0 Hz |

VP2 pump stop first qualified at 67.6 seconds and was confirmed in a second distinct RPM sample at 108.9 seconds. Nine distinct stopped RPM samples were recorded by completion. VP2 stopped-branch brine inlet reached 2 C and outlet ultimately 2 C.

## Interpretation

The active pump inlet became 1 C colder after stopping the other pump, despite the lower total heat output and nearly unchanged active brine pump RPM. This supports investigating bypass through the stopped parallel branch, consistent with the operator hypothesis, but does not identify the flow path or prove reverse circulation.

Limitations: VP1 heat increased by about 0.54 kW between windows; no direct brine flow or direction measurement; constant pump RPM does not imply constant flow; brine telemetry resolution is 1 C; source/pipe thermal transients and sensor lag remain possible. A repeat with matched VP1 output, followed by a controlled return to both-running operation, would strengthen the inference. Water-side flow increased in the active unit; zero stopped-branch meter reading does not establish sensitivity to low or reverse flow.

## Restoration

Both units verified power=1, curve mode=2, curve target=31.5 C, DHW target=52 C, boost=0, control IDLE and no saved session. Native operating state at final read was 0 on VP1 and 5 on VP2; settings restored does not mean both compressors were immediately running. Helper stopped and transport cleanup verified. No native EFFECT fix was made.
