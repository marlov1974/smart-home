"""P0080 supervised ~4kW per pump via direct fixed-flow feedback, then VP2 OFF."""
from trial import *
import statistics as stat

class LoadStep(Trial):
 def __init__(self,out):
  super().__init__(out);self.targets={};self.intent={};self.adjusted={};self.series=[]
 def command(self,sid,mode):
  if sid in self.unsafe or sid not in (1,2):raise GateError('Identity unsafe')
  if mode not in ('fixed-flow','off','auto'):raise GateError('Command outside experiment')
  self.identity(sid);c=self.control(sid);seq=c['accepted']%65535+1
  kw={'flow':self.targets[sid]/100} if mode=='fixed-flow' else {}
  p=encode(seq,mode,lease=0 if mode=='auto' else 300,slave=sid,**kw);b=bytes.fromhex(p['rtu_hex'])
  self.log('command_intent',p)
  if mode!='auto':self.owned.add(sid)
  reply=self.s.exchange(b)
  if reply==b[:6]+crc16(b[:6]):
   self.renewed[sid]=time.monotonic();self.intent[sid]=mode;return True
  if reply==bytes([sid,0x90,6])+crc16(bytes([sid,0x90,6])):return False
  raise GateError('Ambiguous control ACK '+reply.hex())
 def send_until(self,sid,mode):
  until=time.monotonic()+80
  while not self.command(sid,mode):
   if time.monotonic()>until:raise GateError('Control BUSY '+str((sid,mode)))
   time.sleep(2)
 def renew(self):
  for sid,mode in list(self.intent.items()):
   if mode=='auto' or time.monotonic()-self.renewed.get(sid,0)<80:continue
   c=self.control(sid)
   if c['state']==4 and c['applied']==c['accepted']:
    self.send_until(sid,mode)
   elif c['state'] in (0,5,6):raise GateError('Lease/control ended '+str(sid))
 def sample(self,sid):
  r=self.capture(sid)
  if sid==2:r['feedback']=decode_feedback(self.read(sid,352,20))
  r['pump_raw87_98']=self.read(sid,87,12)
  self.log('load_sample',r);return r
 def wait_heating(self):
  deadline=time.monotonic()+1200;stable=0
  while time.monotonic()<deadline:
   rows=[self.capture(s,s==1) for s in (1,2)]
   stable=stable+1 if all(r['native']['operating_mode']==2 and r['base'][3]==1 and r['base'][2]>0 and not r['control']['state'] and not r['control']['saved'] for r in rows) else 0
   print('WAIT HEATING',[(r['sid'],r['native']['operating_mode'],r['base'][2]) for r in rows],flush=True)
   if stable>=2:return
   time.sleep(15)
  raise GateError('Native heating unavailable after20min; no control writes')
 def enter(self):
  self.preflight()
  for sid in (1,2):
   r=self.sample(sid);s=r['snapshot']['samples']
   if r['native']['operating_mode']!=2 or s['compressor_Hz']['value'] is None or s['compressor_Hz']['value']<=0:raise GateError('Heating baseline lost')
   if s['flow_cC']['status']!=1:raise GateError('Initial flow missing')
   self.targets[sid]=max(3000,min(3800,max(max(r['native']['flow'],s['flow_cC']['value'])+100,
                                           getattr(self,'initial_targets',{}).get(sid,3000))))
   self.send_until(sid,'fixed-flow');self.adjusted[sid]=time.monotonic()
   until=time.monotonic()+90
   while True:
    self.renew();v=self.capture(sid,False);c=v['control']
    if c['state']==4 and c['applied']==c['accepted'] and v['native']['mode']==1 and v['native']['flow']==self.targets[sid]:break
    if c['state'] in (0,5,6) or time.monotonic()>until:raise GateError('Initial target not applied')
    time.sleep(2)
 def cycle(self,phase,regulate):
  self.renew();rows={sid:self.sample(sid) for sid in (1,2)};now=time.monotonic()
  for sid in regulate:
   r=rows[sid];n=r['native'];c=r['control'];s=r['snapshot']['samples'];f=r['feedback']
   if c['state'] not in (2,3,4) or not c['saved'] or c['mode']!=2:raise GateError('Fixed-flow session lost')
   if n['power']!=1 or n['operating_mode'] not in (0,2,7) or n['boost'] or any(n['flags28'][i] for i in (4,5,6,10)):raise GateError('Heating boundary lost')
   for key in ('flow_cC','return_cC','flow_cL_min','compressor_Hz'):
    if s[key]['status']!=1 or s[key]['age_ms']>20000:raise GateError('Primary data stale '+key)
   if s['flow_cC']['value']>4000:raise GateError('Flow exceeds40C')
   if f['quality'] not in (0,1,2,8,9):raise GateError('Heat feedback invalid '+str(f['quality']))
   # No increases during native pause; no lowering to/below actual flow.
   ready=c['state']==4 and c['applied']==c['accepted'] and n['flow']==self.targets[sid] and s['compressor_Hz']['value']>0
   w=f['short_w']
   if ready and f['ready'] and w is not None and now-self.adjusted[sid]>=120:
    target=self.targets[sid]
    if w<3400:target=min(3800,target+50)
    elif w>4600 and target-50>=s['flow_cC']['value']+50:target=max(3000,target-50)
    if target!=self.targets[sid]:
     self.targets[sid]=target;self.send_until(sid,'fixed-flow');self.adjusted[sid]=time.monotonic()
  item={'time_mono':now,'phase':phase,'rows':rows};self.series.append(item);self.log('load_cycle',item)
  print(phase,[(sid,rows[sid]['feedback']['short_w'],rows[sid]['base'][2],rows[sid]['native']['flow'],rows[sid]['snapshot']['samples']['brine_in_cC']['value'],rows[sid]['snapshot']['samples']['brine_out_cC']['value']) for sid in (1,2)],flush=True)
  return item
 def stable(self,seconds,sids):
  now=time.monotonic();w=[x for x in self.series if x['time_mono']>=now-seconds and x['phase']==self.series[-1]['phase']]
  if len(w)<6 or w[-1]['time_mono']-w[0]['time_mono']<seconds-65:return False
  for sid in sids:
   rr=[x['rows'][sid] for x in w]
   powers=[r['feedback']['short_w'] for r in rr]
   if any(v is None for v in powers) or not 3400<=stat.mean(powers)<=4600 or any(not 3000<=v<=5000 for v in powers[-3:]):return False
   for key in ('brine_in_cC','brine_out_cC'):
    ss=[r['snapshot']['samples'][key] for r in rr]
    if any(s['status']!=1 or s['age_ms']>45000 for s in ss) or len({s['generation'] for s in ss})<4:return False
    values=[s['value'] for s in ss];half=len(values)//2
    if max(values)-min(values)>100 or abs(stat.mean(values[:half])-stat.mean(values[half:]))>35:return False
   rpm=[r['pump_raw87_98'] for r in rr]
   if any(p[7]!=1 or p[8]>45 or not 0<p[6]<=9999 for p in rpm):return False
   values=[p[6] for p in rpm]
   if max(values)-min(values)>max(100,stat.mean(values)*.05):return False
  return True
 def experiment(self):
  self.wait_heating()
  # Reset transport helper's one-hour watchdog before the active experiment.
  self.s.stop();self.s=Sender('DEVICE_HOST','shellypro2-80f3dac8bfec',self.out/'active-transport');self.s.start()
  self.enter();start=time.monotonic()
  while time.monotonic()-start<1500:
   self.cycle('both_4kw',(1,2))
   if time.monotonic()-start>=600 and self.stable(300,(1,2)):break
   time.sleep(3)
  else:raise GateError('Both ~4kW/brine plateau not achieved in25min; no shutdown comparison')
  self.log('plateau_qualified',{'seconds':time.monotonic()-start,'target_W_per_unit':4000,'mean_tolerance_W':600,'temperature_resolution_cC':100})
  print('PLATEAU QUALIFIED; restoring VP2 session before OFF',flush=True)
  self.send_until(1,'fixed-flow')
  self.restore(2);self.send_until(2,'off')
  start=time.monotonic();stop_seen=0;last=None
  while time.monotonic()-start<600:
   x=self.cycle('vp2_off',(1,));r=x['rows'][2];p=r['pump_raw87_98'];s=r['snapshot']['samples'];c=r['control']
   if c['state'] in (0,5,6):raise GateError('VP2 OFF ownership lost')
   stopped=r['native']['power']==0 and r['base'][3]==1 and r['base'][2]==0 and p[7]==1 and p[8]<=30 and p[6]==0 and s['water_pump_running']['status']==1 and s['water_pump_running']['age_ms']<=20000 and s['water_pump_running']['value']==0
   if stopped and p[10]!=last:stop_seen+=1;last=p[10]
   if not stopped:stop_seen=0
   self.log('off_qualification',{'stopped':stopped,'distinct_zero_rpm':stop_seen,'elapsed':time.monotonic()-start})
   if time.monotonic()-start>300 and stop_seen<2:raise GateError('VP2 pump stop not continuously qualified')
   if time.monotonic()-start>=360 and stop_seen>=2 and self.stable(300,(1,)):break
   time.sleep(3)
  else:raise GateError('Post-shutdown plateau not reached within10min')
  (self.out/'outcome.json').write_text(json.dumps({'completed':True,'target_W_per_unit':4000,'off_sid':2,'interpretation':'temperature-direction evidence, not definitive hydraulic proof'},indent=2))

def main():
 out=ROOT/'effect-learning'/('brine-load-step-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'));t=LoadStep(out)
 def interrupt(*_):raise KeyboardInterrupt()
 signal.signal(signal.SIGINT,interrupt);signal.signal(signal.SIGTERM,interrupt)
 try:t.s.start();t.experiment()
 except BaseException as e:(out/'failure.json').write_text(json.dumps({'error':repr(e)}));raise
 finally:t.finish();print('Evidence',out,flush=True)
if __name__=='__main__':main()
