"""Supervised A-B-A brine test: both heating, VP2 off, restart on inlet drop."""
from brine_load_step import *


def fresh_inlet(row):
 s=row['snapshot']['samples']['brine_in_cC']
 return s if s['status']==1 and s['age_ms']<=45000 else None


def pumps_stopped(row):
 p=row['pump_raw87_98'];s=row['snapshot']['samples']['water_pump_running']
 return (row['native']['power']==0 and row['base'][3]==1 and row['base'][2]==0
         and p[7]==1 and p[8]<=30 and p[6]==0
         and s['status']==1 and s['age_ms']<=20000 and s['value']==0)


class ReturnStep(LoadStep):
 def __init__(self,out):
  super().__init__(out)
  # Physically applied in the previous run, without reaching stable VP2 load
  # before its20min bound. Start here instead of repeating the low-target ramp.
  self.initial_targets={1:3400,2:3550}

 def wait_heating(self):
  deadline=time.monotonic()+2100;stable=0
  while time.monotonic()<deadline:
   rows=[self.capture(s,True) for s in (1,2)]
   stable=stable+1 if all(r['native']['operating_mode']==2 and r['base'][3]==1 and r['base'][2]>0 and not r['control']['state'] and not r['control']['saved'] for r in rows) else 0
   print('WAIT HEATING (sid,mode,Hz,DHWcC)',[(r['sid'],r['native']['operating_mode'],r['base'][2],r['snapshot']['samples']['dhw_cC']['value']) for r in rows],flush=True)
   if stable>=2:return
   time.sleep(15)
  raise GateError('Native heating unavailable after35min; no control writes')

 def experiment(self):
  self.wait_heating()
  self.s.stop()
  self.s=Sender('DEVICE_HOST','shellypro2-80f3dac8bfec',self.out/'active-transport')
  self.s.start();self.enter();start=time.monotonic()
  # Active phases at most 20+8+18 minutes, leaving transport-watchdog margin.
  while time.monotonic()-start<1200:
   self.cycle('both_before',(1,2))
   if time.monotonic()-start>=600 and self.stable(300,(1,2)):break
   time.sleep(3)
  else:raise GateError('Both-load baseline not stable within20min')
  window=[x for x in self.series if x['time_mono']>=self.series[-1]['time_mono']-300]
  baseline=stat.median(x['rows'][1]['snapshot']['samples']['brine_in_cC']['value'] for x in window)
  self.log('baseline_qualified',{'inlet_cC':baseline,'samples':len(window),'target_W':4000,'tolerance_W':600})
  print('BASELINE QUALIFIED',baseline,'cC; VP2 OFF next',flush=True)
  self.send_until(1,'fixed-flow');self.restore(2);self.send_until(2,'off')
  start=time.monotonic();zero_count=drop_count=0;last_rpm=last_inlet=None;dropped=[]
  while time.monotonic()-start<480:
   x=self.cycle('vp2_off',(1,));r=x['rows'][2];p=r['pump_raw87_98']
   if r['control']['state'] in (0,5,6):raise GateError('VP2 OFF ownership lost')
   stopped=pumps_stopped(r)
   if not stopped:zero_count=0;last_rpm=None;drop_count=0;dropped=[]
   elif p[10]!=last_rpm:zero_count+=1;last_rpm=p[10]
   inlet=fresh_inlet(x['rows'][1])
   if inlet is None or inlet['value']>baseline-100:
    drop_count=0;dropped=[]
   elif zero_count>=2 and inlet['generation']!=last_inlet:
    drop_count+=1;dropped.append(inlet['value'])
   if inlet:last_inlet=inlet['generation']
   self.log('drop_check',{'elapsed':time.monotonic()-start,'stopped':stopped,'zero_samples':zero_count,
                          'drop_samples':drop_count,'inlet':inlet,'baseline_cC':baseline})
   if drop_count>=2:break
   if time.monotonic()-start>300 and zero_count<2:raise GateError('VP2 pump stop unconfirmed')
   time.sleep(3)
  else:raise GateError('No confirmed1C inlet drop within8min; restore both')
  trough=stat.median(dropped[-2:]);self.log('drop_confirmed',{'baseline_cC':baseline,'trough_cC':trough})
  print('DROP CONFIRMED',baseline,'->',trough,'cC; restarting VP2 now',flush=True)
  # AUTO restores the documented OFF session to its original powered curve mode.
  # Renew VP1 first: restore() is bounded at230s versus a300s lease.
  self.send_until(1,'fixed-flow');self.restore(2)
  self.log('restart_settings_restored',{'sid':2,'original':self.original[2]})
  start=time.monotonic();fixed=False;rise_count=0;last_gen=None;rise_at=None;running_seen=False
  while time.monotonic()-start<1080:
   x=self.cycle('both_after',(1,2) if fixed else (1,));r=x['rows'][2];n=r['native'];p=r['pump_raw87_98']
   if n['power']!=1 or n['boost'] or any(n['flags28'][i] for i in (4,5,6,10)):
    raise GateError('VP2 restart boundary lost')
   # Observe ordinary DHW if the native controller chooses it after restart.
   # Its source-side circulation remains relevant; log the unequal heat load.
   # Do not request FIXED_FLOW while VP2 is in DHW or override its priority.
   if n['operating_mode'] in (3,6):raise GateError('VP2 restarted in cooling/legionella; stop comparison')
   if not fixed and n['operating_mode']==2 and r['base'][2]>0:
    self.send_until(2,'fixed-flow');self.adjusted[2]=time.monotonic();fixed=True
    self.log('restart_fixed_requested',{'target_cC':self.targets[2]})
   running=p[7]==1 and p[8]<=30 and 0<p[6]<=9999
   if running and not running_seen:
    running_seen=True;self.log('restart_brine_running',{'elapsed':time.monotonic()-start,'rpm':p[6],'Hz':r['base'][2]})
   inlet=fresh_inlet(x['rows'][1])
   if not running or inlet is None or inlet['value']<trough+100:
    rise_count=0;rise_at=None
   elif inlet['generation']!=last_gen:
    rise_count+=1
    if rise_count==2:rise_at=time.monotonic();print('RISE CONFIRMED',inlet['value'],'cC; observing persistence',flush=True)
   if inlet:last_gen=inlet['generation']
   self.log('rise_check',{'elapsed':time.monotonic()-start,'running':running,'rpm':p[6],'Hz':r['base'][2],
                         'rise_samples':rise_count,'inlet':inlet,'trough_cC':trough,'fixed':fixed,
                         'vp2_native_mode':n['operating_mode'],
                         'vp2_heat_W':r['snapshot']['samples']['heat_W']})
   # Hold observation for three minutes after reversal; log whether both loads matched.
   if rise_at is not None and time.monotonic()-rise_at>=180:break
   time.sleep(3)
  result={'completed':True,'baseline_inlet_cC':baseline,'off_inlet_cC':trough,
          'rise_observed':rise_count>=2,'rise_persisted_180s':rise_at is not None and time.monotonic()-rise_at>=180,
          'vp2_brine_restarted':running_seen,'vp2_fixed_reentered':fixed,
          'both_loads_stable_after':self.stable(300,(1,2)) if fixed else False,
          'interpretation':'Observed temperature reversal supports but does not prove bypass; compare power, RPM and restart timing.'}
  (self.out/'outcome.json').write_text(json.dumps(result,indent=2));print('OUTCOME',result,flush=True)


def main():
 out=ROOT/'effect-learning'/('brine-return-step-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
 t=ReturnStep(out)
 def interrupt(*_):raise KeyboardInterrupt('operator/signal')
 signal.signal(signal.SIGINT,interrupt);signal.signal(signal.SIGTERM,interrupt)
 try:t.s.start();t.experiment()
 except BaseException as e:(out/'failure.json').write_text(json.dumps({'error':repr(e)}));raise
 finally:t.finish();print('Evidence',out,flush=True)


if __name__=='__main__':main()
