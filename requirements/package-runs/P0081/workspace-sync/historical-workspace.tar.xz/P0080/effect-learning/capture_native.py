"""Bounded dual EFFECT test, preserving one mission through ramp and settling.

"capture" names the firmware capture/offset law; this script controls hardware.
Requires --execute and a pinned --expected-crc. No network activity on import.
Snapshot header and feedback reads have separate timestamp brackets, so later
energy analysis can interpolate only supported intervals, never invent a tail.
"""
from rocket_native import Dual as PreviousDual
from trial import *


class CaptureDual(PreviousDual):
    def __init__(self, out, expected_crc, seconds=1800):
        if not 0 <= expected_crc <= 0xffffffff:
            raise ValueError('Expected CRC must be a uint32')
        if not 900 <= seconds <= 2400:
            raise ValueError('Duration must be900..2400 seconds')
        super().__init__(out)
        self.expected_crc = expected_crc
        self.seconds = seconds
        self.allowed_native_modes = {1: (0, 1, 2, 6, 7), 2: (0, 1, 2, 6, 7)}
        self.started = None
        self.wall_deadline = None
        self.summary = {}
        self.latest_full = {}

    def preflight(self):
        super().preflight()
        for sid in (1, 2):
            row = self.latest_full[sid]
            if row['native']['operating_mode'] in (0, 2, 7):
                flow = row['snapshot']['samples']['flow_cC']
                if flow['status'] != 1 or flow['age_ms'] >= 60000 or flow['value'] > 4000:
                    raise GateError('Preflight heating supply unavailable/above40C')

    def identity(self, sid):
        st = self.s.status(sid)
        if st['uid'] != UID[sid] or st['valid'] != 1 or st['mode'] != 0 or st['manifest_crc'] != self.expected_crc:
            self.unsafe.add(sid)
            raise GateError('Identity/image mismatch')
        base = self.read(sid, 0, 16)
        now = time.monotonic()
        if sid in self.previous:
            old, at = self.previous[sid]
            if ((base[9] - old) & 65535) > now - at + 15:
                self.unsafe.add(sid)
                raise GateError('Reset/clock discontinuity')
        self.previous[sid] = (base[9], now)
        if base[:2] != [888, 76] or base[11] != 1:
            raise GateError('CN105 not linked')
        return base

    def capture(self, sid, full=True):
        begin = time.monotonic()
        base = self.identity(sid)
        c = self.control(sid)
        control_t = time.monotonic()
        n = self.native(sid)
        native_t = time.monotonic()
        row = {'sid': sid, 't': begin, 'base': base, 'control': c, 'native': n,
               'control_captured_t': control_t, 'native_captured_t': native_t}
        if full:
            headers = []
            def read(a, num):
                before = time.monotonic()
                result = self.read(sid, a, num)
                after = time.monotonic()
                if a == 400:
                    headers.append({'begin_t': before, 'end_t': after,
                                    'utc_after': datetime.now(timezone.utc).isoformat()})
                return result
            row['snapshot'] = read_snapshot(read)
            # Last header belongs to the accepted snapshot if read_snapshot retried.
            freeze = headers[-1]
            midpoint = (freeze['begin_t'] + freeze['end_t']) / 2
            row['snapshot_capture'] = {**freeze, 'midpoint_t': midpoint,
                                       'attempts': len(headers)}
            row['effect'] = decode_effect(self.read(sid, 320, 32))
            feedback_begin = time.monotonic()
            row['feedback'] = decode_feedback(self.read(sid, 352, 20))
            feedback_end = time.monotonic()
            row['feedback_capture'] = {'begin_t': feedback_begin,
                                      'end_t': feedback_end,
                                      'midpoint_t': (feedback_begin + feedback_end)/2}
            heat = row['snapshot']['samples']['heat_W']
            row['heat_observation'] = {
                'captured_t': midpoint, 'value_w': heat['value'],
                'status': heat['status'], 'age_ms': heat['age_ms'],
                'generation': heat['generation'],
                'source_t_estimate': midpoint - heat['age_ms']/1000 if heat['status'] == 1 else None,
                'source_time_note': 'Estimate from cached sample age, not a synchronized physical measurement.'}
        row['completed_t'] = time.monotonic()
        if self.started is not None:
            row['elapsed'] = row['completed_t'] - self.started
            if full:
                row['measurement_elapsed'] = row['snapshot_capture']['midpoint_t'] - self.started
        self.log('capture', row)
        if full:
            self.latest_full[sid] = row
        return row

    def command(self, sid, mode):
        if sid in self.unsafe or sid not in (1, 2) or mode not in ('effect', 'auto'):
            raise GateError('Unsafe identity/reset or command')
        self.identity(sid)
        c = self.control(sid)
        seq = c['accepted'] % 65535 + 1
        args = {'target_w': 6000, 'max_flow': 55, 'boundary_verified': True} if mode == 'effect' else {}
        packet = encode(seq, mode, lease=0 if mode == 'auto' else 180, slave=sid, **args)
        self.log('command_intent', {'sid': sid, 'before': c, 'packet': packet})
        b = bytes.fromhex(packet['rtu_hex'])
        owned_before = sid in self.owned
        if mode != 'auto':
            self.owned.add(sid)
        r = self.s.exchange(b)
        if r == b[:6] + crc16(b[:6]):
            self.renewed[sid] = time.monotonic()
            self.log('command_ack', {'sid': sid, 'mode': mode, 'seq': seq})
            return True
        if r == bytes([sid, 0x90, 6]) + crc16(bytes([sid, 0x90, 6])):
            if not owned_before:
                self.owned.discard(sid)
            return False
        raise GateError('Ambiguous command ACK ' + r.hex())

    def wait_ready(self):
        end = time.monotonic() + 120
        while time.monotonic() < end:
            rows = [self.capture(sid) for sid in (1, 2)]
            print('WAIT HEATING', [(r['sid'], r['native']['operating_mode'],
                  r['base'][2], r['feedback']['quality_name']) for r in rows], flush=True)
            if all(r['native']['power'] == 1 and r['native']['operating_mode'] in (0, 2, 7)
                   and r['feedback']['quality'] in (0, 8, 9) for r in rows):
                return
            time.sleep(2)
        raise GateError('Both pumps not available in bounded120s readiness window')

    def guard(self, row, accepted):
        sid, c, n, f = row['sid'], row['control'], row['native'], row['feedback']
        samples = row['snapshot']['samples']
        if sid not in accepted:
            return
        if c['state'] in (0, 5, 6) or c['error'] not in (0, 2):
            raise GateError('Native EFFECT aborted ' + str((sid, c, f)))
        if n['power'] != 1 or n['operating_mode'] not in (0, 1, 2, 6, 7):
            raise GateError('Native heat priority changed ' + str(sid))
        if n['boost'] or any(n['flags28'][i] for i in (4, 5, 6, 10)):
            raise GateError('Native boost/inhibit boundary changed ' + str(sid))
        if n['mode'] == 1 and n['flow'] > 5500:
            raise GateError('Target above55C')
        # A missing value is not evidence that the heating temperature is safe.
        if n['operating_mode'] in (0, 2, 7):
            flow = samples['flow_cC']
            if flow['status'] != 1 or flow['age_ms'] >= 60000:
                raise GateError('Actual heating flow unavailable for60s')
            if flow['value'] > 4000:
                raise GateError('Actual heating flow exceeded40C')
        if f['quality'] not in range(10):
            raise GateError('Feedback hard invalid ' + str((sid, f)))

    @staticmethod
    def good_heating(row):
        f, s, n = row['feedback'], row['snapshot']['samples'], row['native']
        return (n['operating_mode'] in (2, 7) and s['compressor_Hz']['status'] == 1
                and s['compressor_Hz']['value'] > 0 and f['quality'] in (0, 2)
                and f['short_w'] is not None and f['last_age_s'] is not None
                and f['last_age_s'] < 60 and s['heat_W']['status'] == 1
                and s['heat_W']['age_ms'] < 60000)

    def run_dual(self):
        # Default1800s observation plus at most300s readiness/entry/endpoint work.
        self.wall_deadline = time.monotonic() + self.seconds + 300
        self.wait_ready()
        accepted, milestones = set(), set()
        began = time.monotonic()
        first95 = None
        good_since = None
        longest_good = 0.0
        while True:
            if time.monotonic() > self.wall_deadline:
                raise GateError('Bounded experiment wall deadline reached')
            rows = []
            for sid in (1, 2):
                if sid not in accepted and self.command(sid, 'effect'):
                    accepted.add(sid)
                r = self.capture(sid)
                rows.append(r)
                self.guard(r, accepted)
                c = r['control']
                if sid in accepted and c['state'] in (3, 4) and c['applied'] == c['accepted'] and time.monotonic() - self.renewed.get(sid, 0) > 60:
                    if not self.command(sid, 'effect'):
                        self.log('renew_busy', {'sid': sid})
                print('SAMPLE', sid, 'elapsed', round(time.monotonic()-self.started) if self.started else 'starting',
                      'Hz', r['base'][2], 'W', r['feedback']['short_w'],
                      'target', r['native']['flow']/100, 'phase', r['effect']['phase'],
                      'quality', r['feedback']['quality_name'], 'state', c['state'], flush=True)
            active = all(r['control']['state'] == 4 and r['control']['mode'] == 5
                         and r['control']['applied'] == r['control']['accepted']
                         and r['native']['mode'] == 1 for r in rows)
            if self.started is None and active:
                self.started = time.monotonic()
                self.log('both_applied', {'duration_s': self.seconds, 'target_w_each': 6000,
                         'mission_start_monotonic': self.started,
                         'mission_start_utc': datetime.now(timezone.utc).isoformat(),
                         'note': 'One uninterrupted mission; same-intent lease renewals only.'})
                print('BOTH APPLIED: CONTINUOUS TIMER', self.seconds, 'SECONDS', flush=True)
            if self.started is None and time.monotonic() - began > 180:
                raise GateError('EFFECT entry not confirmed in180s')
            if self.started is not None:
                now = time.monotonic()
                elapsed = now - self.started
                for r in rows:
                    r['measurement_elapsed'] = r['snapshot_capture']['midpoint_t'] - self.started
                    r['elapsed'] = r['completed_t'] - self.started
                good = all(self.good_heating(r) for r in rows)
                if first95 is None and good and all(r['feedback']['short_w'] >= 5700 for r in rows):
                    first95 = elapsed
                    self.log('both_first95', {'elapsed': elapsed, 'threshold_w': 5700})
                if first95 is not None and good:
                    if good_since is None:
                        good_since = elapsed
                    longest_good = max(longest_good, elapsed-good_since)
                else:
                    good_since = None
                for cutoff in sorted(set((900, self.seconds))):
                    if cutoff not in milestones and all(r['measurement_elapsed'] >= cutoff for r in rows):
                        milestones.add(cutoff)
                        self.log('cutoff_bracketed', {'cutoff_s': cutoff,
                            'measurement_elapsed_by_sid': {r['sid']: r['measurement_elapsed'] for r in rows},
                            'note': 'Post-cutoff observations exist for both devices; integrate only inside observed coverage.'})
                        print('CUTOFF BRACKETED', cutoff, flush=True)
                self.summary = {'first_both95_elapsed_s': first95,
                    'longest_continuous_good_heating_after95_s': longest_good,
                    'at_least10min_good_heating_after95': longest_good >= 600,
                    'requested_duration_s': self.seconds,
                    'actual_observation_elapsed_s': elapsed,
                    'milestones_bracketed_s': sorted(milestones)}
            else:
                elapsed = None
            self.log('dual_sample', {'elapsed': elapsed, 'rows': rows})
            if self.seconds in milestones:
                self.log('continuous_trial_complete', self.summary)
                return
            time.sleep(2)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--expected-crc', required=True, type=lambda value: int(value, 0))
    p.add_argument('--seconds', type=int, default=1800)
    p.add_argument('--execute', action='store_true')
    a = p.parse_args()
    if not a.execute:
        p.error('This is a control experiment; --execute is required')
    if not 900 <= a.seconds <= 2400:
        p.error('Duration must be900..2400 seconds')
    out = ROOT/'effect-learning'/('capture-native6kw-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    t = CaptureDual(out, a.expected_crc, a.seconds)
    def interrupt(*_):
        raise KeyboardInterrupt('operator/signal')
    signal.signal(signal.SIGINT, interrupt)
    signal.signal(signal.SIGTERM, interrupt)
    try:
        t.s.start()
        t.preflight()
        t.run_dual()
        (out/'outcome.json').write_text(json.dumps({'completed': True, 'target_w_each': 6000,
            'firmware_crc': hex(a.expected_crc), **t.summary}, indent=2))
    except BaseException as e:
        (out/'failure.json').write_text(json.dumps({'error': repr(e), 'summary': t.summary}, indent=2))
        raise
    finally:
        t.finish()
        print('Evidence', out, flush=True)


if __name__ == '__main__':
    main()
