"""Operator-ended brine work: read pump state, stop owned transport helper only."""
from trial import *
from shelly_ota import CORE
out=ROOT/'effect-learning'/('brine-close-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
t=Trial(out)
scripts=t.s.rpc('Script.List')['scripts']
running=any(x['id']==8 and x['running'] for x in scripts)
if running:
 t.s.identity(True)
 if t.s.code()!=CORE:raise GateError('Helper changed; do not touch')
 t.s.changed=True
else:t.s.start()
try:
 rows=[t.capture(s,False) for s in (1,2)]
 (out/'pump-state.json').write_text(json.dumps(rows,indent=2))
 if any(r['control']['state']!=0 or r['control']['saved'] for r in rows):
  raise GateError('Unexpected active control; inspect before actuator changes')
 print('Both control sessions IDLE; native settings',[(r['sid'],r['native']) for r in rows])
finally:
 t.s.stop();print('Transport stopped and cleanup verified',out)
