"""Authorized bounded down-step and larger up-step; no firmware modifications."""
from manual_step import *

class SequenceTrial(ManualTrial):
 observe_native_pause=True
 def stage(self,name,target,seconds):
  self.renew2()
  if 1 in self.owned:
   self.log('transition_restore_start',{'next':name})
   self.restore(1)
   self.renew2()
  self.target=target
  self.log('stage_plan',{'name':name,'target_cC':target,'hold_s':seconds})
  deadline=time.monotonic()+90
  while not self.command(1,'fixed-flow'):
   self.renew2()
   if time.monotonic()>deadline:raise GateError('Stage entry busy')
  while True:
   r=self.sample(name+'_entry');c=r['control'];n=r['native']
   if c['state'] in (0,5,6):raise GateError('Stage entry aborted')
   if c['state']==4 and c['accepted']==c['applied'] and n['mode']==1 and n['flow']==target:break
   if time.monotonic()>deadline:raise GateError('Stage entry timeout')
  start=time.monotonic();self.log('stage_active',{'name':name,'target_cC':target})
  while time.monotonic()-start<seconds:
   r=self.sample(name);c=r['control'];n=r['native']
   if c['state']!=4 or c['mode']!=2 or c['accepted']!=c['applied'] or not c['saved'] or c['error'] not in (0,2):raise GateError('Stage ownership lost')
   if n['mode']!=1 or n['flow']!=target:raise GateError('Stage target changed')
   if time.monotonic()-self.renewed.get(1,0)>60:
    if not self.command(1,'fixed-flow'):raise GateError('Stage renewal busy')
  self.log('stage_complete',{'name':name,'elapsed_s':time.monotonic()-start})
  return r
 def run_sequence(self):
  self.off2()
  r=self.stage('stabilize',3250,900)
  actual=r['snapshot']['samples']['flow_cC']['value']
  down=min(3200,max(3000,((actual+100)//50)*50))
  self.log('down_choice',{'actual_cC':actual,'target_cC':down,'note':'+1C over measured flow where possible; capped below3250. Native stops observed without forced restart.'})
  self.stage('down',down,1200)
  self.stage('up',3800,1200)

def main():
 p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');a=p.parse_args()
 out=ROOT/'effect-learning'/('down-up-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'));t=SequenceTrial(out)
 def stop(*_):raise KeyboardInterrupt('operator/signal')
 signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
 try:
  t.s.start();t.preflight()
  if a.execute:t.run_sequence()
  (out/'outcome.json').write_text(json.dumps({'completed':True,'execute':a.execute}))
 except BaseException as e:
  (out/'failure.json').write_text(json.dumps({'error':repr(e)}));raise
 finally:t.finish();print('Evidence',out,flush=True)
if __name__=='__main__':main()
