# P0080 dual6kW trial — 2026-10-10

Both units installed and verified at prefixCRC9da1db61. BL2 unchanged. D1 initial seq24 reply was truncated (25/44bytes); resume arrived after120s inactivity timeout. Full-set recovery through intact BL2 succeeded, followed by ordinary three-slot update ofD2. All identities, manifests, advancing native replies and helper cleanup verified. Uploader local wrapper now retries identical CRC-invalid/truncated reply frames; firmware duplicate handling was already tested. Physical cause of the one truncated reply is unknown.

Operator-authorized native EFFECT6000W each, maximum requested38C, supervised180s leases renewed during the run. Both applied confirmed; duration1800.87s.49 complete paired host observations, plus command/control logs. Both remained active throughout, no native stop/start during the trial, no hard-feedback abort; pending/ready alternated without aborting. Both ended at36Hz. All commands and responses retained in local rpc.jsonl/events.jsonl.

|Last10min|VP1|VP2|
|---|---:|---:|
|Mean qualified rolling heat power|4.123kW|3.629kW|
|Range|4.005–4.297kW|3.344–3.931kW|
|Standard deviation|0.084kW|0.238kW|
|Samples with ready feedback|14|14|
|Maximum actual supply over trial|34.5C|34.5C|

Six-kW tracking failed: both reached latched EFFECT_CUMULATIVE_CAP (reason6), after five1C increases from30.5C to35.5C. Actual temperatures were well below40C. After this latch no further up-regulation occurred, despite target6000W. No clear alternating control oscillation: target only increased, then held; frequency rose and largely held. This does not establish stability of an unrestricted regulator. Thermal power is derived from quantized temperature/flow, not calibrated electrical measurement. Approximate integration of sampled rolling heat power is1.84+1.59=3.43kWh, versus6kWh for continuous6kW each over30min. This is an estimate, not a validated energy counter; sampling and moving averaging affect it.

Both restored and read back: power1, curve mode2, flow target3050, DHW5200, boost0; controlIDLE/saved0/error0, one verified restore each. Native operating mode0 immediately after restoration is consistent with removing the elevated heating demand. Helper stopped/disabled, serial runtime reset to115200, relays remain off. No live process left running.

Operator clarified future control: actual supply ceiling40C is separate from demand setpoint up to55C. Fast high initial demand must be reduced as power approaches target, with trend/lag braking and temperature protection. Remove/replace the cumulative+5C latch. Future house optimizer2kWh heat per15min means8kW mean total, requiring integration of delivered energy and remaining-energy/remaining-time allocation. These changes and softer stale-data fallback are documented requirements, NOT implemented or installed by this trial.

No Git commit/push. Existing tracked package report/changelog updated, no tracked path additions. General knowhow promotion considered: retain the transfer incident as package evidence until repeated/root cause known; no unsupported Shelly defect claim.
