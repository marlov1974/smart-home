"""Finish authorized restoration after transport helper stopped."""
from trial import *
source=ROOT/'effect-learning/down-up-20261009T204755Z'
out=ROOT/'effect-learning'/('down-up-restore-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
t=Trial(out)
t.original={int(k):v for k,v in json.loads((source/'original-settings.json').read_text()).items()}
t.owned={1,2}
try:t.s.start()
finally:t.finish();print('Evidence',out,flush=True)
