# Hydraulic baseline 2026-10-10
Read-only Procon FC04; Shelly helper cleanup verified. Three complete captures per VP. Both native power1/curve2, compressor26Hz, water pump status1. No shutdown or hydraulic isolation test performed. Brine pump feedback unavailable in this installed image.
|VP|flow L/min|supply C|return C|brine in/out C|
|---|---|---|---|---|
|1|15.0|31.5|29.0|4.0/3.0|
|2|16.0|32.0|29.0, 29.5|4.0/3.0|
