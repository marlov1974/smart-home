# Hydraulic qualification: VP2 off, VP1 heating

P0080 firmware pump A3 extension installed on both devices; prefix CRC3f41636b.
VP2 was temporarily OFF for approximately8minutes. After a transient A3 status6 interval, repeated fresh RPM0, water-pump state0 and compressor0 qualified reported pump stop. Operator subsequently reported using the service display during this interval: possible competing requests, not proven root cause or firmware defect. From elapsed290 through477s, six observations retained stopped feedback with advancing source generations. No independent motor measurement.

During that qualified187s window, VP2 water flow was consistently0L/min. Supply cooled31.5->31C; return28.5->27.5C. No measured heating-side bypass in this direction. Reverse-flow response and minimum detection threshold of the built-in meter are unvalidated; zero cannot exclude all bypass.

VP2 brine inlet/outlet remained2/3C with fresh samples and reported0rpm. There is no brine flow measurement. Reversed temperature difference alone cannot distinguish externally driven reverse circulation from thermal transients; brine bypass remains unresolved.

Only VP2-off/VP1-running direction tested. Reciprocal direction not tested. Restoration and helper cleanup are recorded separately in restoration.json/cleanup.json.
