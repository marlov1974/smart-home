# Reverse hydraulic test — 2026-10-10

Completed: VP1 temporarily OFF, VP2 in native space heating. No forced heating target was needed: VP2 completed DHW (target52C, observed final53C), paused and restarted itself. A read-only wait was restarted to add tank-temperature observation; previous helper cleanup verified.

VP1 stop qualification required two fresh, advancing RPM and water-pump generations plus native power0 and compressor0. Qualified at elapsed112s; observed through295s (183s, six samples). All qualified samples: RPM0, water pump state0, water flow0L/min. VP2 continued heating with19–20L/min. No independent motor-speed instrument or reverse-flow calibration.

First post-OFF sample to final: VP1 supply32->31.5C, return28.5->27.5C, brine inlet4->2C, brine outlet2->3C. Qualified window supply31.5->31.5C, return28->27.5C, brine3/3->2/3C. Thus temperature changes were measured as well as water flow. No water flow was measured through the stopped VP1 branch. The built-in sensor's reverse-flow response/minimum detection threshold is unvalidated; zero does not exclude all bypass. Brine temperature changes and reversed temperature difference cannot alone distinguish hydraulic circulation from post-stop thermal effects. Brine flow remains unmeasured.

Restoration verified: VP1 power1, heating-control mode2, controlIDLE/saved0, DHWtarget52C, boost0. It selected native DHW operating mode1 after restoration; no forced DHW command. VP2 untouched. Helper cleanup verified, test process exited0. See restoration.json, cleanup.json, measurement.json, events.jsonl and rpc.jsonl.

Together with hydraulic-off2-20261010T052949Z, both directions were tested. Neither off branch showed measured water flow after pump-stop qualification. Brine bypass remains unresolved. Display interaction during the first direction is a possible cause of transient A3status6, not a proven root cause.
