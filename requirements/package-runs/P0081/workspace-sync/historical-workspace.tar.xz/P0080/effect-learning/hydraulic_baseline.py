"""Read both pumps' full telemetry; no Procon register writes."""
import json
from datetime import datetime, timezone
from trial import Trial, ROOT

out = ROOT / 'effect-learning' / ('hydraulic-baseline-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
t = Trial(out)
try:
    t.s.start()
    for cycle in range(3):
        for sid in (1, 2):
            row = t.capture(sid)
            print(json.dumps({'cycle': cycle, 'sid': sid, 'native': row['native'],
                              'control': row['control'], 'snapshot': row['snapshot']}), flush=True)
finally:
    t.s.stop()
    print('Evidence:', out, flush=True)
