"""P0080 bounded OFF qualification and hydraulic observation, one pump per run."""
from trial import *

class Hydraulic(Trial):
 def command(self,sid,mode):
  if sid in self.unsafe:raise GateError('Identity unsafe')
  assert mode in ('off','auto') and sid==self.target
  self.identity(sid);c=self.control(sid)
  seq=c['accepted']%65535+1
  packet=encode(seq,mode,lease=180 if mode=='off' else 0,slave=sid)
  b=bytes.fromhex(packet['rtu_hex']);self.log('command_intent',packet)
  if mode=='off':self.owned.add(sid)
  r=self.s.exchange(b)
  if r==b[:6]+crc16(b[:6]):self.renewed[sid]=time.monotonic();return True
  if r==bytes([sid,0x90,6])+crc16(bytes([sid,0x90,6])):return False
  raise GateError('Ambiguous OFF/AUTO ACK '+r.hex())
 def sample(self,sid):
  row=self.capture(sid);row['pump_raw87_98']=self.read(sid,87,12)
  self.log('hydraulic_sample',row);return row
 def run_hydraulic(self):
  self.preflight()
  for sid in (1,2):
   r=self.sample(sid)
   if r['base'][2]==0 or r['native']['operating_mode']!=2:raise GateError('Both pumps must initially heat')
   p=r['pump_raw87_98'];v=r['snapshot']['samples']
   if p[7]!=1 or p[8]>30 or not 0<p[6]<=9999:raise GateError('Fresh running RPM baseline missing')
   if v['water_pump_running']['value']!=1:raise GateError('Water pump running baseline missing')
  deadline=time.monotonic()+90
  while not self.command(self.target,'off'):
   if time.monotonic()>deadline:raise GateError('OFF busy')
   time.sleep(2)
  start=time.monotonic();qualified=None;last_generation=None;consecutive=0;measure=[]
  while time.monotonic()-start<540:
   c=self.control(self.target)
   if c['state']==4 and time.monotonic()-self.renewed[self.target]>60:
    if not self.command(self.target,'off'):raise GateError('OFF renewal busy')
   a=self.sample(self.target);b=self.sample(3-self.target)
   if a['control']['state'] in (0,5,6):raise GateError('OFF session ended')
   if b['native']['power']!=1 or b['native']['operating_mode']!=2 or b['base'][3]!=1 or b['base'][2]==0:raise GateError('Driving pump no longer heating')
   v=a['snapshot']['samples'];p=a['pump_raw87_98'];rpm=p[6]
   water=v['water_pump_running'];flow=v['flow_cL_min']
   fresh=p[7]==1 and p[8]<=30 and p[11]==1 and rpm<=9999 and water['status']==1 and water['age_ms']<=20000
   stopped=fresh and rpm==0 and water['value']==0 and a['native']['power']==0 and a['base'][3]==1 and a['base'][2]==0
   gen=(p[10],water['generation'])
   if stopped and (last_generation is None or all(x!=y for x,y in zip(gen,last_generation))):consecutive+=1;last_generation=gen
   if not stopped:consecutive=0
   elapsed=round(time.monotonic()-start)
   row={'elapsed':elapsed,'off_sid':self.target,'rpm':rpm,'step':p[0],'water_pump':water,'water_flow':flow,'stopped_feedback':stopped,'consecutive':consecutive,'off_snapshot':a['snapshot'],'driving_snapshot':b['snapshot']}
   self.log('hydraulic_result_sample',row);measure.append(row)
   print('HYDRAULIC',elapsed,'OFF',self.target,'rpm',rpm,'step',p[0],'waterpump',water['value'],'flow_cL/min',flow['value'],'stopped',stopped,flush=True)
   if qualified is None and consecutive>=2:qualified=time.monotonic();print('STOP FEEDBACK QUALIFIED',self.target,flush=True)
   if qualified is not None:
    if not stopped:raise GateError('Stopped feedback lost; hydraulic inference invalid')
    if time.monotonic()-qualified>=180:break
   elif time.monotonic()-start>=300:raise GateError('Pump stop not qualified in5min; no isolation inference')
   time.sleep(3)
  if qualified is None:raise GateError('No stop qualification')
  (self.out/'measurement.json').write_text(json.dumps(measure,indent=2))
  (self.out/'outcome.json').write_text(json.dumps({'off_sid':self.target,'completed':True,'qualification':'reported RPM0 and water pump bit0 repeated with advancing generations','physical_motor_or_flow_direction_validation':False},indent=2))

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--off',type=int,choices=(1,2),required=True);a=ap.parse_args()
 out=ROOT/'effect-learning'/('hydraulic-off'+str(a.off)+'-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
 t=Hydraulic(out);t.target=a.off
 def interrupt(*_):raise KeyboardInterrupt()
 signal.signal(signal.SIGINT,interrupt);signal.signal(signal.SIGTERM,interrupt)
 try:t.s.start();t.run_hydraulic()
 except BaseException as e:(out/'failure.json').write_text(json.dumps({'error':repr(e)}));raise
 finally:t.finish();print('Evidence',out,flush=True)
if __name__=='__main__':main()
