"""Read-only wait for native space heating, then bounded reverse hydraulic test."""
from hydraulic_test import Hydraulic
from trial import *

def main():
 out=ROOT/'effect-learning'/('hydraulic-reverse-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
 t=Hydraulic(out);t.target=1
 def interrupt(*_):raise KeyboardInterrupt()
 signal.signal(signal.SIGINT,interrupt);signal.signal(signal.SIGTERM,interrupt)
 try:
  t.s.start();deadline=time.monotonic()+900;stable=0
  while time.monotonic()<deadline:
   rows=[t.capture(s,s==2) for s in (1,2)]
   tank=rows[1]["snapshot"]["samples"]["dhw_cC"]
   print("VP2 DHW",tank,"target_cC",rows[1]["native"]["dhw"],flush=True)
   good=all(r['native']['power']==1 and r['native']['mode']==2 and r['native']['operating_mode']==2 and r['base'][3]==1 and r['base'][2]>0 and r['control']['state']==0 and not r['control']['saved'] for r in rows)
   stable=stable+1 if good else 0
   print('WAIT HEATING',[(r['sid'],r['native']['operating_mode'],r['base'][2]) for r in rows],'stable',stable,flush=True)
   if stable>=2:break
   time.sleep(20)
  else:raise GateError('Native heating not ready within remaining15min; no pump-control writes')
  t.run_hydraulic()
 except BaseException as e:(out/'failure.json').write_text(json.dumps({'error':repr(e)}));raise
 finally:t.finish();print('Evidence',out,flush=True)
if __name__=='__main__':main()
