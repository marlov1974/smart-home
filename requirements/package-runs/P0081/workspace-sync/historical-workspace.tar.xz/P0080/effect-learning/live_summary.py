"""Read saved trial JSONL only; no device, network or control-script imports."""
import argparse
import json
from datetime import datetime, timezone
from pathlib import Path


def summarize(path):
    path = Path(path)
    if path.is_dir():
        path = path/'events.jsonl'
    records = []
    ignored = 0
    with path.open() as stream:
        for line in stream:
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                # A writer may be midway through the last JSONL record.
                ignored += 1
                continue
            if isinstance(record, dict):
                records.append(record)
    mission = next((r['data'] for r in records if r.get('kind') == 'both_applied'), {})
    start = mission.get('mission_start_monotonic')
    captures = {1: [], 2: []}
    for event in records:
        if event.get('kind') != 'capture':
            continue
        row = event.get('data', {})
        sid = row.get('sid')
        if sid not in captures or 'snapshot' not in row:
            continue
        samples = row['snapshot'].get('samples', {})
        native, feedback = row.get('native', {}), row.get('feedback', {})
        control, effect = row.get('control', {}), row.get('effect', {})
        def value(key):
            sample = samples.get(key, {})
            return sample.get('value') if sample.get('status') == 1 else None
        measurement_t = row.get('snapshot_capture', {}).get('midpoint_t', row.get('t'))
        elapsed = measurement_t - start if start is not None and measurement_t is not None else row.get('measurement_elapsed')
        hz = value('compressor_Hz')
        if hz is None and len(row.get('base', [])) >= 3:
            hz = row['base'][2]
        flow, ret = value('flow_cC'), value('return_cC')
        target = native.get('flow')
        captures[sid].append({
            'time': event.get('time'), 'measurement_elapsed_s': elapsed,
            'hz': hz, 'short_w': feedback.get('short_w'), 'instant_w': feedback.get('instant_w'),
            'supply_C': None if flow is None else flow/100,
            'return_C': None if ret is None else ret/100,
            'target_C': None if target is None else target/100,
            'quality': feedback.get('quality_name', feedback.get('quality')),
            'state': control.get('state'), 'phase': effect.get('phase'),
            'native_operating_mode': native.get('operating_mode'),
            'feedback_age_s': feedback.get('last_age_s'),
            'snapshot_sequence': row['snapshot'].get('sequence')})
    by_sid = {}
    for sid, rows in captures.items():
        after = [r for r in rows if r['measurement_elapsed_s'] is not None and r['measurement_elapsed_s'] >= 0]
        before = [r for r in rows if r['measurement_elapsed_s'] is not None and r['measurement_elapsed_s'] < 0]
        def first(field, threshold):
            return next((r['measurement_elapsed_s'] for r in after
                         if r.get(field) is not None and r[field] >= threshold), None)
        by_sid[str(sid)] = {'full_captures': len(rows), 'latest': rows[-2:],
            'last_prestart_hz': before[-1]['hz'] if before else None,
            'first_observed_positive_hz_s': first('hz', 1),
            'first_observed_45hz_s': first('hz', 45),
            'first_observed_target45C_s': first('target_C', 45),
            'first_observed_5700W_short_s': first('short_w', 5700)}
    return {'file': str(path), 'mission': mission, 'devices': by_sid,
            'ignored_incomplete_or_invalid_records': ignored,
            'note': 'First observed thresholds use post-start frozen snapshot time; sampling interval limits transition precision.'}


def text_output(result):
    print(result['file'])
    mission = result['mission']
    print('Mission:', mission.get('mission_start_utc', 'not yet applied / start time unavailable'),
          'duration:', mission.get('duration_s', '?'), 's')
    print('SID  UTC capture-end       elapsed   Hz   shortW   flow   return  target  quality      state phase native age')
    def fmt(value, precision=1):
        if value is None:
            return '-'
        return f'{value:.{precision}f}' if isinstance(value, float) else str(value)
    for sid, data in result['devices'].items():
        for row in data['latest']:
            stamp = row['time'] or '?'
            try:
                stamp = datetime.fromisoformat(stamp).astimezone(timezone.utc).strftime('%H:%M:%S')
            except ValueError:
                pass
            print(f"{sid:>3}  {stamp:<20} {fmt(row['measurement_elapsed_s']):>7} "
                  f"{fmt(row['hz']):>4} {fmt(row['short_w']):>8} {fmt(row['supply_C']):>6} "
                  f"{fmt(row['return_C']):>7} {fmt(row['target_C']):>7} {fmt(row['quality']):<12} "
                  f"{fmt(row['state']):>5} {fmt(row['phase']):>5} {fmt(row['native_operating_mode']):>6} "
                  f"{fmt(row['feedback_age_s']):>3}")
        print(f"  VP{sid}: prestart Hz={fmt(data['last_prestart_hz'])}; first Hz>0 "
              f"{fmt(data['first_observed_positive_hz_s'])}s, >=45Hz {fmt(data['first_observed_45hz_s'])}s, "
              f">=5.7kW {fmt(data['first_observed_5700W_short_s'])}s, "
              f"target>=45C {fmt(data['first_observed_target45C_s'])}s; {data['full_captures']} captures")
    if result['ignored_incomplete_or_invalid_records']:
        print('Incomplete/invalid JSONL rows skipped:', result['ignored_incomplete_or_invalid_records'])


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('path', nargs='?', type=Path, help='Trial directory or events.jsonl; defaults to latest capture-native6kw directory')
    p.add_argument('--json', action='store_true')
    a = p.parse_args()
    path = a.path
    if path is None:
        candidates = [x/'events.jsonl' for x in Path(__file__).resolve().parent.glob('capture-native6kw-*')
                      if (x/'events.jsonl').is_file()]
        if not candidates:
            p.error('No capture-native6kw events.jsonl found yet')
        path = max(candidates, key=lambda x: x.stat().st_mtime_ns)
    result = summarize(path)
    if a.json:
        print(json.dumps(result, indent=2))
    else:
        text_output(result)


if __name__ == '__main__':
    main()
