"""One supervised fixed-temperature step; restore both units on every exit."""
from trial import *

class ManualTrial(Trial):
 # User authorized VP2 shutdown. Ordinary DHW may be stopped on VP2 only;
 # VP1 must be heating and isolation is proved before the step. No DHW writes.
 allowed_native_modes={1:(0,2,7),2:(0,1,2,6,7)}
 def command(self,sid,mode):
  if mode!='fixed-flow':return super().command(sid,mode)
  if sid!=1 or sid in self.unsafe:raise GateError('Wrong/unsafe fixed-flow recipient')
  if not 3000<=self.target<=3800:raise GateError('Target outside manual scope')
  self.identity(sid);c=self.control(sid);seq=1 if c['accepted']==65535 else c['accepted']+1
  packet=encode(seq,mode,flow=self.target/100,lease=180,slave=sid)
  b=bytes.fromhex(packet['rtu_hex']);self.log('command_intent',packet);self.owned.add(sid)
  r=self.s.exchange(b)
  if r==b[:6]+crc16(b[:6]):self.renewed[sid]=time.monotonic();return True
  if r==bytes([sid,0x90,6])+crc16(bytes([sid,0x90,6])):return False
  raise GateError('Ambiguous fixed-flow ACK '+r.hex())
 def sample(self,phase):
  self.renew2();r2=self.capture(2,False)
  if r2['native']['power']!=0 or r2['base'][3]!=1 or r2['base'][2]!=0:raise GateError('VP2 isolation lost')
  r=self.capture(1);s=r['snapshot']['samples'];n=r['native']
  if n['power']!=1 or n['operating_mode'] not in (0,2,7) or n['boost'] or any(n['flags28'][i] for i in (4,5,6,10)):raise GateError('Native heating boundary changed')
  # Derived heat can be unavailable between successive temperature/flow replies.
  # Preserve that gap; safety is gated on the actual fresh primary sources.
  for k in ('flow_cC','return_cC','flow_cL_min','compressor_Hz','flow_target_cC'):
   if s[k]['status']!=1 or s[k]['age_ms']>20000 or s[k]['value'] is None:raise GateError('Primary source invalid: '+k)
  if s['flow_cC']['value']>4000:raise GateError('Actual flow above40C')
  if s['compressor_Hz']['value']<=0 and not getattr(self,'observe_native_pause',False):raise GateError('Native compressor stop: no forced restart')
  self.log('manual_'+phase,r)
  print(phase,'Hz',s['compressor_Hz']['value'],'flow',s['flow_cC']['value']/100,'return',s['return_cC']['value']/100,'W',s['heat_W']['value'],'target',n['flow']/100,flush=True)
  return r
 def run(self,seconds):
  self.off2();end=time.monotonic()+120;baseline=[]
  while time.monotonic()<end:baseline.append(self.sample('baseline'))
  last=baseline[-1];self.target=max(self.original[1]['flow'],last['snapshot']['samples']['flow_cC']['value'])+200
  if not 3000<=self.target<=3800:raise GateError('Step exceeds target range')
  self.log('step_plan',{'target_cC':self.target,'hold_s':seconds,'baseline_s':120,'note':'single exploratory step; baseline not proof of steady state'})
  deadline=time.monotonic()+90
  while not self.command(1,'fixed-flow'):
   if time.monotonic()>deadline:raise GateError('Fixed-flow busy')
   self.renew2();time.sleep(2)
  deadline=time.monotonic()+90
  while True:
   r=self.sample('entry');c=r['control'];n=r['native']
   if c['state'] in (0,5,6):raise GateError('Fixed-flow entry aborted')
   if c['state']==4 and c['accepted']==c['applied'] and n['mode']==1 and n['flow']==self.target:break
   if time.monotonic()>deadline:raise GateError('Fixed-flow entry readback timeout')
  start=time.monotonic()
  while time.monotonic()-start<seconds:
   r=self.sample('hold');c=r['control'];n=r['native']
   if c['state']!=4 or c['mode']!=2 or c['accepted']!=c['applied'] or not c['saved'] or c['error'] not in (0,2):raise GateError('Manual control ownership lost')
   if n['mode']!=1 or n['flow']!=self.target:raise GateError('Manual target readback changed')
   if time.monotonic()-self.renewed.get(1,0)>60:
    if not self.command(1,'fixed-flow'):raise GateError('Manual renewal busy')
  self.log('hold_complete',{'seconds':time.monotonic()-start})

def main():
 p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');p.add_argument('--seconds',type=int,default=900);a=p.parse_args()
 if not 60<=a.seconds<=900:raise ValueError('Invalid duration')
 out=ROOT/'effect-learning'/('manual-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'));t=ManualTrial(out)
 def stop(*_):raise KeyboardInterrupt('operator/signal')
 signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
 try:
  t.s.start();t.preflight()
  if a.execute:t.run(a.seconds)
  (out/'outcome.json').write_text(json.dumps({'completed':True,'execute':a.execute}))
 except BaseException as e:
  (out/'failure.json').write_text(json.dumps({'error':repr(e)}));raise
 finally:t.finish();print('Evidence',out,flush=True)
if __name__=='__main__':main()
