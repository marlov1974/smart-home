# Offline identification from five historical runs

2026-10-10. No device I/O. Data read from `manual-20261009T201601Z`, `down-up-20261009T204755Z`, `dual6kw-20261010T103106Z`, `fast-dual6kw-20261010T114328Z`, and `smooth-dual6kw-20261010T130226Z`.

## Findings that matter for control

1. **Compressor Hz leads the rolling heat-power estimate by about 30–45 seconds.** Nearest-snapshot regression is necessarily coarse because observations are typically 25–40 seconds apart. Pooling conditions, D1's best lagged fit was Pshort=132*Hz(previous30s)-653 W (RMSE591W), versus690W error without lag. D2:117*Hz(previous30s)-567 W (RMSE297W), versus499W without lag. These are empirical local estimates, not calibration constants.
2. **Braking on lagged power alone was visibly late.** Smooth D1 at elapsed672s:56Hz,5.878kW,demand46.71C,actual35.5C. At709s:54Hz,6.25kW,demand44.71C. At746s:52Hz,5.902kW,demand40.71C. At783s:46Hz,5.546kW,demand38.81C. Hz was falling while rolling thermal power was still rising. Continued rapid taper guaranteed an undershoot. D2 held56Hz longer, then similarly declined while demand kept falling.
3. **Absolute temperature delta is insufficient.** D1 Hz was already decreasing with positive9–11C delta. Setpoint history and temperature slope matter. A next-minute Hz-acceleration fit using delta and presentHz gives in-sampleR2=.386; adding past-minute actual-temperature slope gives .450; adding setpoint slope gives .470. Held-out-run errors are poor (including11.7Hz/min for the fast trial with the richer model). A fitted universal law should not be inverted into a controller. Coefficients and folds in fits.json.
4. **Static Hz target is insufficient across loads.** Earlier single-pump32.5C run maintained44Hz and~5.956kW; recent both-pump smooth run reached~6kW at54–56Hz. Pooled fit hides return-temperature/flow/load dependence. For the recent fast and smooth trials, lag-aligned slopes were102–113W/Hz (D1) and105–112W/Hz (D2). Use around110W/Hz as a bounded local leading correction; continuously retain direct thermal feedback.
5. **Useful tested leading estimate:** Plead=Pshort+110*(Hz_now-Hz_about35s_ago). Against shortW about30s later, RMSE improved591→451W(fast) and529→460W(smooth). Against60s-later shortW:1022→725W and942→744W. This offers warning of impending power decline/overshoot; it does not establish achieved heat delivery. Report actual measured heat separately.
6. Native startup/restart is a distinct state: smooth experiment includes a compressor-off interval followed by roughly26Hz plateau before acceleration. Do not tune PI gains from this state or interpret it as command failure. Strong prior down/up commands were confounded by AUTO/curve transitions and compressor stops. Those are not clean impulse experiments.
7. Sensors have0.5C quantization; at16L/min one temperature step corresponds~0.56kW water-side heat. A perfect6.00kW instantaneous curve cannot be verified from these signals. Use60–120s averages and assess sustained±0.5kW plus lack of sustained oscillation. Do not declare stability from a single crossing.

## Recommended next live trial

Use a host controller first for rapid iteration, preserving native pause and temperature-limit behavior. A continuous setpoint law must stop its taper when the physical response already decelerates.

- Start while running, or explicitly report unavoidable native-off/startup time separately. The requested reference curve approximates6*(1-exp(-t/2min));90% at4.6min. Native lockout can make this impossible from a stopped starting state.
- Initial demand45C is enough for a substantial temperature delta and avoids an enormous55→35C brake. Holding45C is a test choice, not a proven optimum. Respect the existing allowed55C request maximum and40C actual supply constraint.
- Calculate Plead with the lagged Hz correction above. DesiredHz=Hz_now+(6000-Plead)/110, bounded locally. UseHz and its trend as leading signals; use measuredthermal power for steady correction and reporting.
- While approaching goal, do not lower request merely because prior power acceleration was positive. Lower only when leading prediction forecasts overshoot or actual supply is approaching its ceiling.
- Near capture, try0.25–0.5C request changes per30s rather than the observed4–6C/min taper. Freeze further downward moves whenHz is declining and Plead<=target+300W; hold for60–90s to expose the native response. If leading power falls below target, make small upward corrections rather than another full45/55C jump.
- Learn the holding demand from the observed low-slope state. Retain that demand as feed-forward; let a slow thermal-power integral update it. Anti-windup freezes the integral when limited by actual-temperature ceiling/nativepause/invalidfeedback. Do not reset learnedholding demand on each ordinary sample.
- The temperature-limit loop is separate and must override acceleration request. Reduce early enough to settle at~39.5–40C and keep reporting achievable measured power, without abandoning an otherwisevalidmission.

This recommendation is an empirical next experiment, not a validated regulator. A brief30s prediction improves the observed power forecast but does not prove closed-loop stability.

## Reproduction

`python3 fit.py` produces normalized.json and fits.json. `python3 lag.py` produces lag.json. `python3 lead.py` prints direct predictive comparison. Only offline files are accessed. Source samples retain raw sensor ages in original events; this quick analysis aligns frozen host snapshot times, so inferred lag is approximate, not an exact transport-delay estimate. Train/test rows overlap in time; run-level validation is more honest than random row folds.

## Later hypothesis from constant-target holds: a native PI-like law

The live45C identification hold added a useful constraint: both compressors briefly reducedHz even while the request stayed45C and actual supply was35–35.5C. Thus our negative request slope alone does not explain native deceleration. Later, they held roughly50–54Hz while water temperatures climbed. This resembles a proportional-plus-slow-integral native law with slew/startup limits:

    f ≈ I + Kp * e,  dI/dt ≈ Ki * e,  e = demand − actual supply.
    Therefore Δf ≈ Kp * Δe + Ki * integral(e dt).

This is a candidate effective model, not a decoded Mitsubishi implementation. Initial ramps are limited to roughly10Hz/min in these runs, and startup/warmup plateaus must be treated separately.

A rough Kp≈2Hz/K is consistent with the initial45C step from30.5C producing a later~30Hz rise, and prior2K steps producing severalHz. It is not independently identifiable from these observations. **Conditional on Kp=2**, fitting endpoint balances over constant-target periods after discarding the first5minutes yields Ki inHz/(K·min):

| Hold | Conditional Ki |
|---|---:|
| Manual32.5C | 0.177 |
| Down/up stabilization32.5C | 0.256 |
| Down32C | 0.155 |
| Up38C | 0.182 |
| Old dual35.5C D1 | 0.104 |
| Old dual35.5C D2 | 0.174 |

The new45C hold, before completion, gives about0.09(D1) and0.14(D2) without trimming because the available constant-target segment is short. These ranges include endpoint quantization, native filtering/history, hydraulic load changes, and imperfect source alignment. They do not prove a uniqueKi; differentKp assumptions will change it. `pi_hypothesis.py` and `pi-hypothesis.json` preserve inputs/results.

If this law is useful locally, a smooth feed-forward inverse is:

    demand_slope = supply_slope + (desired_Hz_slope − Ki * e) / Kp.

For example, at goal with8K temperaturedelta and actual warming0.3K/min, Kp2 andKi0.15 imply a gentle request reduction0.3K/min. That is far less braking than the previous4–6K/min taper. The live firmware candidate instead uses measured acceleration feedback so that an unproven universalKi is not hardcoded; this candidate model explains why such gently varying demand may work and provides future system-identification parameters.

### Native frequency staircase and derivative aliasing

In the new host trial, computingHz slope from35seconds produced alternating0 and~16–20Hz/min as10Hz steps arrived. That caused small45→44.5→45C request dithering before root temporarily held45C for identification. Use a60–90second slope/regression for acceleration, while retaining the shorter~35secondHz lag correction for leading thermal-power prediction. These are different estimation purposes and need not share one window.
