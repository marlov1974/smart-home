"""Offline analysis of capture_native.py evidence; never imports live code.

Run with the development venv Python. All integration uses observed snapshot
header midpoints and adjacent observations, clipped to the requested interval.
Feedback and native readbacks retain their own clocks. No missing tail is filled.
"""
import argparse
import json
import math
import os
import statistics
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/procon-model-mpl")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def read_events(path):
    events = []
    for line in (path / "events.jsonl").read_text().splitlines():
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            pass  # A concurrently appended final line may be incomplete.
    return events


def fresh(sample):
    return sample.get("status") == 1 and sample.get("value") is not None and 0 <= sample.get("age_ms", 60000) < 60000


def load(path):
    events = read_events(path)
    anchor_event = next((e for e in events if e["kind"] == "both_applied"), None)
    if anchor_event is None:
        raise ValueError("No confirmed mission start yet")
    anchor = anchor_event["data"]["mission_start_monotonic"]
    duration = anchor_event["data"]["duration_s"]
    rows = {1: [], 2: []}
    seen = set()
    candidates = [(row, "dual_sample") for event in events if event["kind"] == "dual_sample" for row in event["data"]["rows"]]
    restoring = False
    for event in events:
        if event["kind"] == "command_intent" and event["data"].get("packet", {}).get("words", [0, 0, 0])[2] == 1:
            restoring = True
        if event["kind"] == "capture" and not restoring and "measurement_elapsed" in event["data"] and "snapshot_capture" in event["data"]:
            # guard() can abort after capture() but before dual_sample is logged.
            # Preserve that terminal observation; exclude restoration reads.
            candidates.append((event["data"], "unpaired_pre_restore_capture"))
    for row, source_event in candidates:
            if "snapshot_capture" not in row:
                raise ValueError("This analyzer requires capture_native timestamp brackets")
            sid = row["sid"]
            key = (sid, row["snapshot_capture"]["midpoint_t"])
            if key in seen:
                continue
            seen.add(key)
            samples = row["snapshot"]["samples"]
            value = lambda name: samples[name]["value"] if fresh(samples[name]) else None
            hz, mode, heat = value("compressor_Hz"), value("operating_mode_raw"), value("heat_W")
            if hz == 255:
                hz = None
            native, feedback = row["native"], row["feedback"]
            quality = feedback["quality"]
            short_valid = (quality in (0, 2) and feedback.get("short_w") is not None
                           and feedback.get("last_age_s") is not None and feedback["last_age_s"] < 60
                           and feedback.get("short_count", 0) >= 3 and feedback.get("short_span_s", 0) >= 20
                           and mode in (2, 7) and native["operating_mode"] in (2, 7) and hz not in (None, 0))
            hydraulic = heat if mode in (0, 2, 7) else None
            gated = (0 if hz == 0 else heat) if mode in (0, 2, 7) and hz is not None else None
            return_C = value("return_cC") / 100 if value("return_cC") is not None else None
            flow_l_min = value("flow_cL_min") / 100 if value("flow_cL_min") is not None else None
            capacity_valid = (return_C is not None and flow_l_min is not None and flow_l_min > 0
                              and mode in (0, 2, 7) and abs(samples["return_cC"]["age_ms"] - samples["flow_cL_min"]["age_ms"]) <= 2000)
            capacity = lambda ceiling: max(0, (ceiling - return_C) * flow_l_min * 4180 / 60) if capacity_valid else None
            rows[sid].append({
                "t": row["snapshot_capture"]["midpoint_t"] - anchor,
                "feedback_t": row["feedback_capture"]["midpoint_t"] - anchor,
                "native_t": row["native_captured_t"] - anchor,
                "snapshot_bracket_s": row["snapshot_capture"]["end_t"] - row["snapshot_capture"]["begin_t"],
                "feedback_bracket_s": row["feedback_capture"]["end_t"] - row["feedback_capture"]["begin_t"],
                "source_time_estimate": row["heat_observation"]["source_t_estimate"] - anchor if row["heat_observation"]["source_t_estimate"] is not None else None,
                "heat_age_ms": samples["heat_W"]["age_ms"], "heat_generation": samples["heat_W"]["generation"],
                "hz": hz, "mode": mode, "raw_heat_w": hydraulic, "gated_heat_w": gated,
                "short_w": feedback["short_w"] if short_valid else None,
                "slow_w": feedback.get("slow_w") if short_valid else None,
                "supply_C": value("flow_cC") / 100 if value("flow_cC") is not None else None,
                "return_C": return_C, "flow_L_min": flow_l_min,
                "hydraulic_power_limit40_W": capacity(40), "hydraulic_power_limit39_5_W": capacity(39.5),
                "target_C": native["flow"] / 100, "native_mode": native["mode"],
                "phase": row["effect"]["phase"], "limit_reason": row["effect"]["limit_reason"],
                "pending_flow_cC": row["effect"]["pending_flow_cC"],
                "quality": quality, "control_state": row["control"]["state"],
                "control_error": row["control"]["error"], "lease_s": row["control"]["lease_s"],
                "source_event": source_event,
            })
    for series in rows.values():
        series.sort(key=lambda r: r["t"])
    outcome = json.loads((path / "outcome.json").read_text()) if (path / "outcome.json").exists() else None
    return {"rows": rows, "duration_s": duration, "anchor": anchor_event["data"], "outcome": outcome,
            "failure": json.loads((path / "failure.json").read_text()) if (path / "failure.json").exists() else None}


def segments(points, start, end, max_gap=90):
    """Yield clipped linear pieces; None values and long gaps break coverage."""
    for (ta, va), (tb, vb) in zip(points, points[1:]):
        low, high = max(start, ta), min(end, tb)
        if high <= low or tb <= ta or tb - ta > max_gap or va is None or vb is None:
            continue
        interp = lambda t: va + (vb - va) * (t - ta) / (tb - ta)
        yield low, high, interp(low), interp(high)


def integral(points, start, end):
    pieces = list(segments(points, start, end))
    covered = sum(b - a for a, b, _, _ in pieces)
    watt_seconds = sum((pa + pb) * (b - a) / 2 for a, b, pa, pb in pieces)
    missing, cursor = [], start
    for a, b, _, _ in pieces:
        if a > cursor + 1e-6:
            missing.append([cursor, a])
        cursor = max(cursor, b)
    if cursor < end - 1e-6:
        missing.append([cursor, end])
    boundary = lambda t: next(({"before_s": a, "after_s": b, "before_value": va, "after_value": vb}
                              for (a, va), (b, vb) in zip(points, points[1:])
                              if a <= t <= b and b - a <= 90 and va is not None and vb is not None), None)
    return {"energy_kWh_covered": watt_seconds / 3600000, "coverage_s": covered,
            "coverage_fraction": covered / (end - start), "complete_coverage": abs(covered - (end - start)) < 1e-5,
            "start_boundary": boundary(start), "end_boundary": boundary(end),
            "missing_intervals_s": missing, "time_weighted_mean_W": watt_seconds / covered if covered else None}


def percentile(values, q):
    ordered = sorted(values)
    position = (len(ordered) - 1) * q
    left = int(position)
    return ordered[left] + (ordered[min(left + 1, len(ordered) - 1)] - ordered[left]) * (position - left)


def slope(points):
    if len(points) < 3:
        return None
    tx, py = statistics.mean(p[0] for p in points), statistics.mean(p[1] for p in points)
    denominator = sum((t - tx) ** 2 for t, _ in points)
    return sum((t - tx) * (p - py) for t, p in points) / denominator if denominator else None


def oscillation(points, threshold=250):
    """Descriptive oscillation audit, not a statistical stationarity claim.

    Remove a fitted linear trend and count only >=250W peak/trough reversals.
    Require at least two complete, reasonably consistent cycles before reporting
    a candidate period. Quantization, overlap and sparse sampling still apply.
    """
    b = slope(points)
    if b is None:
        return {"status": "insufficient_samples"}
    if any(b[0] - a[0] > 90 for a, b in zip(points, points[1:])):
        return {"status": "gapped_series_no_period_inference", "candidate_period_s": None}
    detrended = [(t, w - b * (t - points[0][0])) for t, w in points]
    direction, high, low, pivots = 0, detrended[0], detrended[0], []
    for point in detrended[1:]:
        if point[1] > high[1]:
            high = point
        if point[1] < low[1]:
            low = point
        if direction >= 0 and high[1] - point[1] >= threshold:
            pivots.append((high[0], high[1], "peak")); direction = -1; low = point
        elif direction <= 0 and point[1] - low[1] >= threshold:
            pivots.append((low[0], low[1], "trough")); direction = 1; high = point
    periods = [pivots[i][0] - pivots[i - 2][0] for i in range(2, len(pivots))]
    enough = len(pivots) >= 5 and len(periods) >= 3
    cv = statistics.pstdev(periods) / statistics.mean(periods) if periods and statistics.mean(periods) else None
    amplitudes = [abs(b[1] - a[1]) for a, b in zip(pivots, pivots[1:])]
    return {"detrended_p05_p95_width_W": percentile([p for _, p in detrended], .95) - percentile([p for _, p in detrended], .05),
            "hysteresis_W": threshold, "prominent_turns": len(pivots), "pivots": pivots,
            "median_peak_to_trough_W": statistics.median(amplitudes) if amplitudes else None,
            "candidate_period_s": statistics.median(periods) if enough and cv < .4 else None,
            "period_cv": cv if enough else None,
            "status": "repeated_pattern_candidate" if enough and cv < .4 else "no_resolved_repeated_cycle"}


def window_stats(rows, start, end):
    all_points = [(r["feedback_t"], r["short_w"]) for r in rows]
    points = [(t, w) for t, w in all_points if start <= t <= end and w is not None]
    values = [w for _, w in points]
    result = {"start_s": start, "end_s": end, "n": len(values),
              "coverage": integral(all_points, start, end)}
    if not values:
        return result
    b = slope(points)
    result.update({"sample_mean_W": statistics.mean(values), "min_W": min(values), "max_W": max(values),
                   "p05_W": percentile(values, .05), "p95_W": percentile(values, .95),
                   "sample_std_W": statistics.pstdev(values), "trend_W_per_min": b * 60 if b is not None else None,
                   "sample_fraction_5500_6500": sum(5500 <= w <= 6500 for w in values) / len(values),
                   "oscillation": oscillation(points)})
    band_seconds = 0
    for a, b, pa, pb in segments(all_points, start, end):
        if pa == pb:
            band_seconds += b - a if 5500 <= pa <= 6500 else 0
        else:
            crossings = sorted(((5500 - pa) / (pb - pa), (6500 - pa) / (pb - pa)))
            band_seconds += max(0, min(1, crossings[1]) - max(0, crossings[0])) * (b - a)
    covered = result["coverage"]["coverage_s"]
    result["time_fraction_5500_6500_of_covered"] = band_seconds / covered if covered else None
    matching = [r for r in rows if start <= r["t"] <= end]
    result.update({"stopped_samples": sum(r["hz"] == 0 for r in matching),
                   "thermal_limited_samples": sum(r["phase"] == 4 for r in matching),
                   "dhw_samples": sum(r["mode"] in (1, 6) for r in matching)})
    for ceiling in ("40", "39_5"):
        limits = [r[f"hydraulic_power_limit{ceiling}_W"] for r in matching if r[f"hydraulic_power_limit{ceiling}_W"] is not None]
        result[f"hydraulic_limit{ceiling}_W"] = {"mean": statistics.mean(limits), "min": min(limits), "max": max(limits)} if limits else None
    return result


def device_stats(rows, duration, stats_end):
    mission = [r for r in rows if 0 <= r["t"] <= duration]
    # Earlier positive Hz can belong to a preceding heating run that stopped
    # during entry. It must not anchor the subsequent mission's actual restart.
    hz_first = next((r["t"] for r in mission if r["hz"] not in (None, 0) and r["mode"] in (2, 7)), None)
    before_positive = [r for r in rows if hz_first is not None and r["t"] < hz_first and r["hz"] == 0]
    restart = {"earliest_s": before_positive[-1]["t"], "latest_s": hz_first} if before_positive else None
    target_first = next((r["native_t"] for r in rows if r["native_mode"] == 1 and r["target_C"] >= 45), None)
    demand_epochs, epoch = [], None
    for row in rows:
        if row["native_t"] > duration:
            break
        if row["native_mode"] == 1 and row["target_C"] >= 45:
            if epoch is None:
                epoch = {"first_observation_s": row["native_t"], "last_observation_s": row["native_t"], "samples": 0}
            epoch["last_observation_s"] = row["native_t"]
            epoch["samples"] += 1
        elif epoch is not None:
            epoch["below45_observed_s"] = row["native_t"]
            demand_epochs.append(epoch)
            epoch = None
    if epoch is not None:
        demand_epochs.append(epoch)
    sustained = next((e["first_observation_s"] for e in demand_epochs
                      if e["samples"] >= 2 and e["last_observation_s"] - e["first_observation_s"] >= 30
                      and hz_first is not None and e["last_observation_s"] >= hz_first), None)
    thresholds = {}
    for name, watts in (("90", 5400), ("95", 5700)):
        first = next((r["feedback_t"] for r in rows if 0 <= r["feedback_t"] <= duration and r["short_w"] is not None and r["short_w"] >= watts), None)
        thresholds[name] = {"threshold_W": watts, "from_mission_s": first,
                            "from_first_observed_positive_Hz_s": first - hz_first if first is not None and hz_first is not None else None,
                            "from_first_observed_45C_target_s": first - target_first if first is not None and target_first is not None else None,
                            "from_first_sustained_45C_target_s": first - sustained if first is not None and sustained is not None else None}
    raw = [(r["t"], r["raw_heat_w"]) for r in rows]
    gated = [(r["t"], r["gated_heat_w"]) for r in rows]
    short = [r["short_w"] for r in rows if 0 <= r["feedback_t"] <= duration and r["short_w"] is not None]
    valid_short_rows = [r for r in rows if 0 <= r["feedback_t"] <= duration and r["short_w"] is not None]
    valid_flow = [r["supply_C"] for r in mission if r["supply_C"] is not None and r["mode"] in (0, 2, 7)]
    post_start_stops, stopped = [], None
    running_seen = False
    last_running = None
    for row in mission:
        if row["hz"] not in (None, 0) and row["mode"] in (2, 7):
            if stopped is not None:
                stopped["first_resumed_s"] = row["t"]
                post_start_stops.append(stopped)
                stopped = None
            running_seen = True
            last_running = row["t"]
        elif running_seen and row["hz"] == 0:
            if stopped is None:
                stopped = {"last_running_s": last_running, "first_zero_s": row["t"], "last_zero_s": row["t"], "zero_samples": 0, "observed_modes": []}
            stopped["last_zero_s"] = row["t"]
            stopped["zero_samples"] += 1
            if row["mode"] not in stopped["observed_modes"]:
                stopped["observed_modes"].append(row["mode"])
    if stopped is not None:
        post_start_stops.append(stopped)
    prior_running = any(r["t"] < 0 and r["hz"] not in (None, 0) for r in rows)
    entry_stop = prior_running and any(r["hz"] == 0 and (hz_first is None or r["t"] < hz_first) for r in mission)
    demand_changes = []
    for before, after in zip(rows, rows[1:]):
        if after["native_t"] > duration or before["native_mode"] != 1 or after["native_mode"] != 1:
            continue
        delta = after["target_C"] - before["target_C"]
        if abs(delta) < .001:
            continue
        demand_changes.append({"previous_readback_s": before["native_t"], "readback_s": after["native_t"],
                               "from_C": before["target_C"], "to_C": after["target_C"], "delta_C": round(delta, 2),
                               "previous_snapshot_Hz": before["hz"], "snapshot_Hz": after["hz"],
                               "snapshot_s": after["t"], "short_W": after["short_w"], "feedback_s": after["feedback_t"],
                               "supply_C": after["supply_C"], "observed_phase": after["phase"], "observed_limit_reason": after["limit_reason"]})
    first_brake = next((change for change in demand_changes if sustained is not None and change["readback_s"] > sustained
                        and change["delta_C"] < 0 and change["snapshot_Hz"] not in (None, 0)), None)
    return {"snapshot_samples_in_mission": len(mission), "last_snapshot_s": rows[-1]["t"],
            "first_observed_positive_Hz_s": hz_first, "first_positive_Hz_transition_bracket": restart,
            "positive_Hz_start_left_censored": hz_first is not None and not before_positive,
            "entry_stop_observed_after_prior_positive_Hz": entry_stop,
            "post_start_stop_episodes": post_start_stops,
            "first_observed_45C_target_s": target_first, "first_sustained_45C_target_s": sustained,
            "observed_45C_target_epochs": demand_epochs, "thresholds": thresholds,
            "first_observed_target_decrease_after_sustained45": first_brake,
            "verified_target_changes": demand_changes,
            "first900_raw_hydraulic_estimate": integral(raw, 0, 900),
            "first900_compressor_gated_estimate": integral(gated, 0, 900),
            "full_raw_hydraulic_estimate": integral(raw, 0, duration),
            "last5min": window_stats(rows, max(0, stats_end - 300), stats_end),
            "last10min": window_stats(rows, max(0, stats_end - 600), stats_end),
            "final_observed_short_W": valid_short_rows[-1]["short_w"] if valid_short_rows else None,
            "final_observed_short_s": valid_short_rows[-1]["feedback_t"] if valid_short_rows else None,
            "short_power_peak_W": max(short) if short else None,
            "supply_max_heating_C": max(valid_flow) if valid_flow else None,
            "thermal_limited_samples": sum(r["phase"] == 4 for r in mission),
            "control_errors": sorted(set(r["control_error"] for r in mission)),
            "minimum_lease_s": min((r["lease_s"] for r in mission), default=None),
            "max_snapshot_read_bracket_s": max(r["snapshot_bracket_s"] for r in rows),
            "max_feedback_read_bracket_s": max(r["feedback_bracket_s"] for r in rows),
            "unpaired_pre_restore_observations": [{"snapshot_s": r["t"], "supply_C": r["supply_C"], "hz": r["hz"]} for r in rows if r["source_event"] != "dual_sample"]}


def report(data):
    duration = data["duration_s"]
    observed_end = max((r["t"] for rows in data["rows"].values() for r in rows), default=0)
    stats_end = duration if data["outcome"] is not None else min(duration, max(0, observed_end))
    return {"requested_duration_s": duration, "completed": data["outcome"] is not None,
            "observed_snapshot_end_s": observed_end, "statistics_window_end_s": stats_end,
            "statistics_window_basis": "requested_completed_mission" if data["outcome"] is not None else "partial_observed_mission",
            "failure": data["failure"], "anchor": data["anchor"], "outcome": data["outcome"],
            "devices": {sid: device_stats(rows, duration, stats_end) for sid, rows in data["rows"].items() if rows},
            "reference_energy_first900_kWh_each": 6 * (900 - 120 * (1 - math.exp(-900 / 120))) / 3600,
            "flat6kW_energy_first900_kWh_each": 1.5,
            "notes": ["Offline analysis; dual_sample rows and unpaired full captures before restore. An unpaired observation may be the terminal guard sample, or the latest incomplete pair while running. Restoration captures excluded.",
                      "Mission origin is confirmed both_applied monotonic time, not first compressor start.",
                      "Raw heat and Hz use accepted snapshot-header midpoint. Short-average power uses its separate feedback-read midpoint. Target uses native-read completion.",
                      "First-observed thresholds are sampling-limited. Positive-Hz timing uses the first heating run observed within the mission, not a pre-entry run. A left-censored observation does not establish the actual start time.",
                      "A sustained45C target requires at least two verified native observations spanning30s and overlapping the first observed mission heating run; short earlier demand pulses are separate epochs.",
                      "Target-change times are observed native-readback brackets, not exact actuation instants. Associated Hz/power/phase fields were captured separately, so they do not prove an atomic decision state.",
                      "Energy is an uncalibrated water-temperature/flow estimate, not a calibrated heat-meter reading. Temperature quantization and shared hydraulics apply.",
                      "Hydraulic power limits use4180J/(kgK), measured return/flow and a hypothetical40 or39.5C supply. They are conditional capacity estimates, not compressor ratings or a guarantee of achievable output.",
                      "Raw hydraulic energy retains valid signed heat even when compressor is stopped. The separate compressor-gated estimate assumes zero production atHz0.",
                      "Integration interpolates only adjacent supported observations within90s; no extrapolated tail or forced coverage. Bracket status is explicit.",
                      "Feedback averages overlap. Std/trend/oscillation are descriptive, not independent-sample confidence intervals or proof of long-term stability.",
                      "For completed trials last5/10minute windows end at requested duration. For partial/aborted trials they end at the latest observed snapshot, with explicit coverage and no extrapolation."]}


def plot(data, result, out):
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.spines.top": False,
                         "axes.spines.right": False, "axes.grid": True, "grid.alpha": .18})
    duration = data["duration_s"]
    fig, axs = plt.subplots(3, 2, figsize=(15, 11), sharex="col", sharey="row", constrained_layout=True)
    all_rows = [row for rows in data["rows"].values() for row in rows]
    power_top = max(7, max((r["short_w"] / 1000 for r in all_rows if r["short_w"] is not None), default=6) + .5)
    hz_top = max(70, max((r["hz"] for r in all_rows if r["hz"] is not None), default=0) + 5)
    state = "avbrutet" if data["failure"] else "avslutat" if data["outcome"] else "pågående"
    fig.suptitle(f"Sammanhängande effektprov: 2 × 6 kW · {duration // 60} min · {state}", fontsize=18, fontweight="bold")
    for col, sid in enumerate((1, 2)):
        rows = data["rows"][sid]
        if not rows:
            continue
        valid = lambda key: [r[key] if r[key] is not None else math.nan for r in rows]
        t = [r["t"] / 60 for r in rows]
        ft = [r["feedback_t"] / 60 for r in rows]
        nt = [r["native_t"] / 60 for r in rows]
        ax = axs[0, col]
        ax.axhspan(5.5, 6.5, color="#58a979", alpha=.11, label="Målintervall 5,5–6,5 kW")
        ref = [i / 10 for i in range(int(duration / 6) + 1)]
        ax.plot(ref, [6 * (1 - math.exp(-x / 2)) for x in ref], color="#555", ls="--", lw=1.2, label="Önskad referens från 0 (ej mätning)")
        ax.scatter(t, [v / 1000 for v in valid("raw_heat_w")], color="#9daab5", s=12, alpha=.6, label="Rå uppskattad vatteneffekt")
        ax.plot(ft, [v / 1000 for v in valid("short_w")], "o-", color="#0869ac", ms=2.5, lw=2, label="Uppskattad effekt, kort medel")
        ax.set(title=f"VP{sid}", ylabel="Värmeeffekt (kW)", ylim=(-.5, power_top))
        ax.legend(loc="lower right", fontsize=8)
        ax = axs[1, col]
        ax.step(t, valid("hz"), where="post", lw=2, color="#824594")
        ax.set(ylabel="Kompressor (Hz)", ylim=(0, hz_top))
        restart = result["devices"][sid]["first_positive_Hz_transition_bracket"]
        if restart:
            for axis in axs[:, col]:
                axis.axvspan(restart["earliest_s"] / 60, restart["latest_s"] / 60, color="#824594", alpha=.08)
            ax.text(.02, .94, "Lila band: observerat intervall för kompressorstart", transform=ax.transAxes, va="top", fontsize=8)
        elif result["devices"][sid]["positive_Hz_start_left_censored"]:
            ax.text(.02, .94, "Kompressorn gick redan vid första observationen", transform=ax.transAxes, va="top", fontsize=8)
        ax = axs[2, col]
        ax.step(nt, valid("target_C"), where="post", color="#d88622", lw=1.8, label="Verifierat börvärde")
        ax.plot(t, valid("supply_C"), color="#b43c42", lw=2, label="Faktisk framledning")
        ax.plot(t, valid("return_C"), color="#387957", lw=1.5, label="Retur")
        ax.axhline(40, color="#b43c42", ls="--", alpha=.65, label="Gräns faktisk framledning")
        limited = [r for r in rows if r["phase"] == 4 and r["supply_C"] is not None]
        if limited:
            ax.scatter([r["t"] / 60 for r in limited], [r["supply_C"] for r in limited], s=24, marker="x", color="#222", label="Begränsningsläge registrerat")
        ax.set(ylabel="Temperatur (°C)", xlabel="Tid från bekräftad missionstart (min)")
        ax.legend(loc="lower right", fontsize=7.5, ncol=2)
        for axis in axs[:, col]:
            axis.axvline(15, color="#666", lw=.8, ls=":", alpha=.7)
            if data["failure"]:
                axis.axvline(result["observed_snapshot_end_s"] / 60, color="#b43c42", lw=1.1, ls="--", alpha=.75)
            axis.set_xlim(min(-.5, min(t)), duration / 60 + .4)
    out.mkdir(parents=True, exist_ok=True)
    fig.savefig(out / "capture-full.png", dpi=150)
    fig.savefig(out / "capture-full.svg")
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("evidence", type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    data = load(args.evidence)
    result = report(data)
    out = args.out or args.evidence
    plot(data, result, out)
    (out / "capture-analysis.json").write_text(json.dumps(result, indent=2, allow_nan=False))
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
