"""Offline audit of equal-intent native EFFECT renewal and subsequent readbacks."""
import json,sys,datetime
from pathlib import Path
p=Path(sys.argv[1]);es=[]
for l in(p/'events.jsonl').read_text().splitlines():
 try:es.append(json.loads(l))
 except json.JSONDecodeError:pass
last_intent={};rows=[]
for i,e in enumerate(es):
 if e['kind']!='command_intent':continue
 d=e['data'];w=d['packet'].get('words',[]);sid=d['sid']
 if len(w)!=8 or w[2]!=5:continue
 seq=w[1];before=d['before'];old=last_intent.get(sid);equal=old is not None and w[2:]==old[2:];last_intent[sid]=w
 ack=next((x for x in es[i+1:]if x['kind']=='command_ack'and x['data']['sid']==sid and x['data']['seq']==seq and x['data']['mode']=='effect'),None)
 later=next((x for x in es[i+1:]if x['kind']in('capture','effect_vp2')and x['data']['sid']==sid and x['data']['control']['accepted']==seq),None)
 r={'time':e['time'],'sid':sid,'sequence':seq,'equal_intent':equal,'before_state':before['state'],'before_accepted':before['accepted'],'before_applied':before['applied'],'before_phase':before['phase'],'before_lease_s':before['lease_s'],'ack':ack['time']if ack else None,'inflight_equal_applied_renewal':equal and before['state']==3 and before['accepted']==before['applied'],'later_control':later['data']['control']if later else None}
 rows.append(r)
result={'equal_intent_acked':sum(r['equal_intent']and bool(r['ack'])for r in rows),'inflight_equal_applied_acked':[r for r in rows if r['inflight_equal_applied_renewal']and r['ack']],'active_equal_applied_acked':sum(r['equal_intent']and r['before_state']==4 and r['before_accepted']==r['before_applied']and bool(r['ack'])for r in rows),'all_effect_commands':rows,'note':'Before-state is the immediate pre-command diagnostic read, not an atomic claim about firmware state at exact RTU reception; subsequent accepted/applied readback is logged separately.'}
(p/'renewal-audit.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items()if k!='all_effect_commands'},indent=2))
