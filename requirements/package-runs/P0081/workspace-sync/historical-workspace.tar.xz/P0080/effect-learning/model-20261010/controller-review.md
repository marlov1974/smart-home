# Offline controller review, 2026-10-10

## Established implementation defect

The smooth law's `flow > landing + 50` branch continues decreasing the requested supply even after measured acceleration fades or becomes negative. `landing = measured_supply + 1.5 C + positive_power_error / 1000` is a guessed temperature, not an identified FTC equilibrium. The branch applies a minimum0.5 C decrease per decision regardless of negative derivative; the subsequent trim branch then has at most0.5 C recovery per decision. This embeds asymmetric braking and is not acceleration regulation.

Physical repeat `smooth-dual6kw-20261010T130226Z`:

| Pump / elapsed | short power | requested supply | actual supply | filtered derivative |
|---|---:|---:|---:|---:|
|VP1 709s|6.250kW|44.71C|35.5C|+1.211kW/min|
|VP1 746s|5.902kW|40.71C|36.5C|+0.293kW/min|
|VP1 783s|5.546kW|38.81C|36.5C|-0.313kW/min|
|VP1 895s|3.737kW|39.79C|36C|-0.985kW/min|

This shows continued braking after acceleration faded, followed by a delayed recovery. It does not identify a permanent equilibrium temperature delta: historical fixed32.5C late snapshots achieved about6kW at31.5C actual supply and19l/min. A large delta during rapid startup is not necessarily required at steady state.

## Recommended control structure

1. Retain explicit native-pause/startup states; freeze controller integral/learning during off, DHW, invalid pairing or settling. No temperature controller can eliminate native mandatory off-time.
2. Start with bounded55C demand while running, then enter a continuously adjustable capture controller when genuine fresh observations show acceleration. Do not use a fixed guessed landing-temperature branch.
3. Define desired acceleration as a bounded function of remaining power error, approaching zero smoothly near target, e.g. `a_ref = clamp((P_target-P_hat)/tau, -a_down, a_up)` with units explicit. Initial tau90–150s is a hypothesis requiring live tuning, not an identified plant parameter.
4. Update the temperature delta from acceleration error; when actual acceleration already falls below desired acceleration, stop reducing delta and begin modest recovery. Keep a learned steady demand component rather than driving delta towards zero. Changes must be rate-limited and integrate actual elapsed time, not count nominal15s decisions.
5. Use measured-temperature rise and margin to40C as a separate predictive constraint. When constrained, inhibit positive integrator accumulation, report actual delivered power and retain the mission. Do not claim that constant39.5C demand alone guarantees no thermal overshoot.
6. Account for measurement limitations: one0.5C water-delta step is approximately0.49–0.66kW at observed flows; a60s mean and further derivative smoothing delay detection. Deduplicate generations and estimate slope over real sample timestamps. Use Hz trend as an early consistency cue, not calibrated thermal power.
7. Existing aged-data branch still drops requested temperature to supply+0.5C after only15s even though data younger than60s is qualified. Ordinary short gaps should hold command/history. A bounded reduction can be based on age and predicted thermal margin; hard stale/link losses must not cause a fresh increase. Preserve explicit thermal protection.

Do not assess this controller with an independent target trace only. A meaningful offline model must make power/temperature respond to requested delta with startup delay, saturation, return-temperature variation, quantized sensors and lag. A unit test that merely limits output step sizes cannot establish stability. Essential behavioral regression: when under target and already decelerating, the controller must not continue its earlier taper.

## Lease defect fixed in working tree

`ctl_submit` now accepts equal-intent next-sequence EFFECT renewal in APPLY only for a saved, already-applied mission (`applied==accepted`). It preserves actions, transaction phase, pending regulator demand and original snapshot. Initial/unapplied and changed-intent requests remain BUSY. Same-sequence retry does not extend lease. AUTO behavior unchanged.

New `renewal_test` covers pre-SET guard and post-SET/readback renewal, no duplicate SET/no premature readback completion, unchanged restoration snapshot, suspended adjustment and expiry restoration. Complete native ASan/UBSan host suite and Python tests passed; `git diff --check` passed. No network or physical device access by this review agent. Host must attempt renewals in APPLY as well as ACTIVE to benefit from the fix. New firmware has not been built or installed by this agent.

Package-specific control hypotheses remain unvalidated; no general knowhow promotion yet.
