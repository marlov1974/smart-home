/* P0076: conservative staircase with derivative anticipation, no integrator. */
#include "effect.h"
#include "effect_feedback.h"
static uint16_t phase,reason,target,cap,initial,verified,decisions,adjustments;
static uint16_t up_total,down_total,unresponsive,pending,boot_unknown,limit_latched;
static int16_t last_delta;
static int32_t previous_w,last_up_w,derivative;
static uint32_t last_decision,last_adjustment,previous_at;
static uint8_t have_previous,assess_up,pending_demand;
/* P0080 candidate only: no new public fields or ABI. */
typedef struct { uint32_t at; int16_t supply; uint16_t hz; } lead_point;
static lead_point lead_history[16];
static uint8_t lead_head,lead_count,lead_started;
static uint32_t lead_sample_at;
static uint8_t temperature_limited;
static int32_t absolute(int32_t v){return v<0?-v:v;}
void effect_init(void){
    phase=EFFECT_OFF;reason=target=cap=initial=verified=decisions=adjustments=0;
    up_total=down_total=unresponsive=pending=limit_latched=0;boot_unknown=1;last_delta=0;
    previous_w=last_up_w=derivative=0;last_decision=last_adjustment=previous_at=0;
    have_previous=assess_up=pending_demand=0;temperature_limited=0;
    lead_head=lead_count=lead_started=0;lead_sample_at=0;
}
void effect_begin(uint16_t target_w,uint16_t cap_cC,uint32_t t){
    effect_init();target=target_w;cap=cap_cC;phase=EFFECT_START;
    last_decision=last_adjustment=t;
}
void effect_capture(uint16_t flow,uint32_t t){initial=verified=flow;last_adjustment=t;last_decision=cap>4000?t-30000u:t;}
void effect_stop(unsigned why,int restoring){
    reason=(uint16_t)why;phase=restoring?EFFECT_RESTORING:EFFECT_INVALID_FEEDBACK;pending=0;
}
void effect_restored(void){phase=EFFECT_OFF;pending=0;}
/* P0080 fast demand: setpoint is the actuator, actual supply has a separate ceiling. */
static uint16_t effect_fast(const effect_measurement *m,uint16_t flow,uint32_t t){
    int32_t supply=m->supply_cC;
    if(supply<0 || supply>10000 || m->short_w<0 || m->hz==0 || m->hz==255)return 0;
    /* No generation field is exported to this module. Record no faster than5s,
       require fresh paired feedback and abandon a history spanning a long gap. */
    if(lead_count && t-lead_sample_at>=60000u)lead_count=lead_head=0;
    if(m->age_ms<15000u && (!lead_count || t-lead_sample_at>=5000u)){
        lead_history[lead_head]=(lead_point){t,(int16_t)supply,m->hz};
        lead_head=(uint8_t)((lead_head+1u)%16u);if(lead_count<16)++lead_count;
        lead_sample_at=t;
    }
    lead_point past={t,(int16_t)supply,m->hz},accel=past;
    uint32_t distance=UINT32_MAX,accel_distance=UINT32_MAX;
    for(unsigned i=0;i<lead_count;++i){
        uint32_t age=t-lead_history[i].at;
        if(age>=90000u)continue;
        uint32_t d=age>35000u?age-35000u:35000u-age;
        if(d<distance){distance=d;past=lead_history[i];}
        d=age>60000u?age-60000u:60000u-age;
        if(d<accel_distance){accel_distance=d;accel=lead_history[i];}
    }
    uint32_t span=t-past.at,accel_span=t-accel.at,dt=t-last_decision;
    int32_t rate=0,temp_rate=0;
    if(span>=20000u){
        if(accel_span>=40000u)rate=(int32_t)(((int64_t)((int32_t)m->hz-accel.hz)*60000000)/accel_span); /*mHz/min*/
        temp_rate=(int32_t)(((int64_t)(supply-past.supply)*60000)/span); /*cC/min*/
    }
    int32_t temp_projected=supply+(temp_rate>0?temp_rate/2:0);
    temperature_limited=(uint8_t)(supply>=3850 || temp_projected>=3950);
    if(dt<30000u && !(temperature_limited && flow>3950))return 0;
    last_decision=t;++decisions;
    if(have_previous && t-previous_at>=1000u)
        derivative=(int32_t)(((int64_t)(m->short_w-previous_w)*60000)/(t-previous_at));
    previous_w=m->short_w;previous_at=t;have_previous=1;
    int32_t next=flow;phase=EFFECT_HOLD;reason=EFFECT_OK;
    /* Ordinary15..59s old data holds the actuator. Thermal prediction is still
       evaluated; hard-stale handling belongs to the existing control layer. */
    if(m->age_ms<15000u){
        if(!lead_started){
            lead_started=1;phase=EFFECT_START;
            /* Match the current host identification trial's45C initial demand.
               Do not add startup gas if output is already at/above its goal. */
            if(m->short_w<(int32_t)target-300)next=cap<4500?cap:4500;
        }else if(span>=20000u && accel_span>=40000u){
            int32_t predicted=m->short_w+110*((int32_t)m->hz-past.hz);
            int32_t desired=((int32_t)target-predicted)*1000/165; /*mHz/min*/
            if(desired>12000)desired=12000;
            if(desired< -12000)desired=-12000;
            int32_t step=(int32_t)(((int64_t)(desired-rate)*(dt>45000u?45000u:dt))/3600000);
            int32_t bound=predicted>(int32_t)target+1200?100:50;
            if(step>bound)step=bound;
            if(step< -bound)step=-bound;
            /* Quantized10Hz native steps must not brake far below the goal. */
            if(predicted<(int32_t)target-1500 && step<0)step=0;
            /* Already falling near/below goal: NEVER continue earlier braking. */
            if(rate<0 && predicted<=(int32_t)target+300 && step<0)step=0;
            if(absolute(predicted-(int32_t)target)<=300 && absolute(rate)<3000)step=0;
            if(absolute(step)<10)step=0;
            next=(int32_t)flow+step;if(step)phase=EFFECT_CAPTURE;
        }
    }
    if(temperature_limited){
        if(next>3950)next=3950;
        phase=EFFECT_LIMITED;reason=EFFECT_TEMPERATURE_CAP;
    }
    if(next>cap)next=cap;
    if(next<3000)next=3000;
    if(next==flow)return 0;
    pending=(uint16_t)next;last_up_w=m->short_w;return pending;
}
uint16_t effect_decide(const effect_measurement *m,uint16_t flow,uint32_t t){
    if(!m->ready){if(m->quality!=EF_PENDING && m->quality!=EF_WARMUP)effect_stop(EFFECT_BAD_FEEDBACK,0);return 0;}
    if(phase==EFFECT_OFF || phase==EFFECT_RESTORING || phase==EFFECT_INVALID_FEEDBACK || pending)return 0;
    if(cap>4000)return effect_fast(m,flow,t);
    if(t-last_decision<60000u)return 0;
    last_decision=t;++decisions;
    int32_t measured=m->short_w,error_w=(int32_t)target-measured;
    derivative=0;
    if(have_previous && t-previous_at>=1000u)
        derivative=(int32_t)(((int64_t)(measured-previous_w)*60000)/(t-previous_at));
    previous_w=measured;previous_at=t;have_previous=1;
    if(assess_up){
        if(measured-last_up_w<250){if(unresponsive<3)++unresponsive;}else unresponsive=0;
        assess_up=0;
    }
    /* LIMITED is latched against further increases, but overshoot may reduce. */
    if(limit_latched && error_w>=-700){phase=EFFECT_LIMITED;reason=limit_latched;return 0;}
    int32_t abs_error=absolute(error_w);
    if(abs_error<=500 || (phase==EFFECT_HOLD && abs_error<700)){
        phase=EFFECT_HOLD;reason=EFFECT_OK;return 0;
    }
    if(error_w>0 && unresponsive>=3){phase=EFFECT_LIMITED;reason=limit_latched=EFFECT_UNKNOWN_UNREACHABLE;return 0;}
    if(error_w>0 && up_total>=500){phase=EFFECT_LIMITED;reason=limit_latched=EFFECT_CUMULATIVE_CAP;return 0;}
    int32_t projected=measured+derivative/2;
    if(error_w>0 && derivative>0 && projected>=(int32_t)target-500){phase=EFFECT_CAPTURE;return 0;}
    int32_t step;
    if(error_w>2000){phase=EFFECT_START;step=100;}
    else if(error_w>1000){phase=EFFECT_CAPTURE;step=50;}
    else if(error_w>0){phase=EFFECT_CAPTURE;step=25;}
    else {phase=EFFECT_CAPTURE;step=error_w< -2000?-100:error_w< -1000?-50:-25;}
    if(step>0 && step>500-(int32_t)up_total)step=500-(int32_t)up_total;
    int32_t next=(int32_t)flow+step;
    if(next>cap)next=cap;
    if(next<2000)next=2000;
    if(next==(int32_t)flow){phase=EFFECT_LIMITED;reason=step>0?EFFECT_TEMPERATURE_CAP:EFFECT_TEMPERATURE_FLOOR;if(step>0)limit_latched=reason;return 0;}
    reason=EFFECT_OK;pending=(uint16_t)next;last_up_w=measured;
    return pending;
}
int effect_pending_demand(void){return pending && pending_demand;}
uint16_t effect_pause_demand(const effect_measurement *m,uint16_t flow,uint32_t t){
    /* Drop a boost promptly if the native compressor stops. */
    if(cap>4000 && m->quality==EF_WAIT_NATIVE && m->hz==0 && flow>4000 &&
       !pending && m->supply_cC>=0 && m->supply_cC<4000){
        int32_t mild=m->supply_cC+50;if(mild>3800)mild=3800;
        pending=(uint16_t)(mild<2000?2000:mild);pending_demand=1;return pending;
    }
    /* Native start demand is not a power-error correction. Never force Hz/on. */
    if(m->quality!=EF_WAIT_NATIVE || m->hz!=0 || pending || limit_latched ||
       phase==EFFECT_OFF || phase==EFFECT_RESTORING || phase==EFFECT_INVALID_FEEDBACK ||
       m->supply_cC<0 || m->supply_cC>10000 || t-last_adjustment<60000u)return 0;
    int32_t desired=m->supply_cC+50; /*0.5C above fresh measured supply*/
    if(desired<=flow){reason=EFFECT_OK;return 0;}
    if(flow>=cap){reason=limit_latched=EFFECT_TEMPERATURE_CAP;return 0;}
    if(cap<=4000 && up_total>=500){reason=limit_latched=EFFECT_CUMULATIVE_CAP;return 0;}
    int32_t next=(int32_t)flow+100;
    if(next>desired)next=desired;
    if(next>cap)next=cap;
    if(cap<=4000 && next>(int32_t)flow+500-up_total)next=(int32_t)flow+500-up_total;
    pending=(uint16_t)next;pending_demand=1;reason=EFFECT_OK;return pending;
}
void effect_discard_pending(void){pending=0;pending_demand=0;}
void effect_wait(unsigned quality,uint32_t t){
    if(phase==EFFECT_OFF || phase==EFFECT_RESTORING || phase==EFFECT_INVALID_FEEDBACK)return;
    phase=quality==EF_WAIT_NATIVE?EFFECT_WAIT_NATIVE:EFFECT_SETTLING;
    /* A native pause is not evidence that a running pump failed to respond. */
    assess_up=0;
    if(cap<=4000 || quality==EF_WAIT_NATIVE){have_previous=0;derivative=0;lead_count=lead_head=lead_started=0;}
    last_decision=t;
}
void effect_verified(uint16_t flow,uint32_t t){
    if(pending && flow==pending){
        last_delta=(int16_t)((int32_t)flow-verified);
        if(last_delta>0){up_total=(uint16_t)(up_total+last_delta);assess_up=(uint8_t)!pending_demand;}
        else down_total=(uint16_t)(down_total-last_delta);
        ++adjustments;last_adjustment=t;
        /* Measured minimum interval starts at completed readback. */
        last_decision=t;pending=pending_demand=0;
    }
    verified=flow;
}
uint16_t effect_read(unsigned a,const effect_measurement *m,uint16_t flow,uint32_t t){
    int32_t value=0;
    if(a>=325 && a<=332){
        value=a<327?m->instant_w:a<329?m->short_w:a<331?m->slow_w:
            m->short_w==INT32_MIN?INT32_MIN:(int32_t)target-m->short_w;
        return a%2?(uint16_t)((uint32_t)value>>16):(uint16_t)value;
    }
    switch(a){
    case 320:return 1;case 321:return phase;case 322:return reason;
    case 323:return target;case 324:return cap;
    case 333:return m->quality;case 334:return m->ready;case 335:return m->pairs;
    case 336:return m->age_ms/1000u>65535u?65535:(uint16_t)(m->age_ms/1000u);case 337:return (uint16_t)(m->span_ms/1000u);
    case 338:return flow;case 339:return (uint16_t)last_delta;
    case 340:return (t-last_adjustment)/1000u>65535u?65535:(uint16_t)((t-last_adjustment)/1000u);
    case 341:return m->hz;case 342:return decisions;case 343:return adjustments;
    case 344:return up_total;case 345:return down_total;case 346:return unresponsive;
    case 347:return pending;case 348:return (uint16_t)(int16_t)(derivative>32767?32767:derivative< -32768?-32768:derivative);
    case 349:return initial;case 350:return boot_unknown;case 351:return 0;
    default:return 0;
    }
}
