import json,math,statistics,datetime,bisect
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
NAMES=['manual-20261009T201601Z','down-up-20261009T204755Z','dual6kw-20261010T103106Z','fast-dual6kw-20261010T114328Z','smooth-dual6kw-20261010T130226Z']
def stamp(s):return datetime.datetime.fromisoformat(s).timestamp()
def solve(X,y):
 n=len(X[0]);a=[[sum(r[i]*r[j] for r in X)+(0.001 if i==j else 0) for j in range(n)]+[sum(r[i]*v for r,v in zip(X,y))] for i in range(n)]
 for i in range(n):
  k=max(range(i,n),key=lambda k:abs(a[k][i]));a[i],a[k]=a[k],a[i];d=a[i][i]
  if abs(d)<1e-12:return [0]*n
  a[i]=[v/d for v in a[i]]
  for k in range(n):
   if i!=k:
    f=a[k][i];a[k]=[a[k][j]-f*a[i][j] for j in range(n+1)]
 return [r[-1] for r in a]
def recursive(o,rows):
 if isinstance(o,dict):
  if 'sid'in o and 'snapshot'in o and 'native'in o: rows[(o['sid'],o['snapshot']['captured_at_host'])]=o;return
  for v in o.values():recursive(v,rows)
 elif isinstance(o,list):
  for v in o:recursive(v,rows)
series=[]
for name in NAMES:
 rows={}
 for l in (ROOT/name/'events.jsonl').read_text().splitlines():recursive(json.loads(l)['data'],rows)
 for sid in (1,2):
  rr=[]
  for (s,ts),r in rows.items():
   if s!=sid:continue
   ss=r['snapshot']['samples'];v=lambda k:ss[k]['value'];hz=v('compressor_Hz');supply=v('flow_cC');ret=v('return_cC');flow=v('flow_cL_min')
   if None in [hz,supply,ret,flow]:continue
   fb=r.get('feedback',{});w=fb.get('short_w');raw=v('heat_W');raw=(supply-ret)*flow*0.0069666667 if raw is None else raw
   rr.append(dict(t=stamp(ts),hz=hz,supply=supply/100,ret=ret/100,flow=flow/100,set=r['native']['flow']/100,mode=r['native']['mode'],op=r['native']['operating_mode'],w=w,raw=raw,run=name,sid=sid))
  rr.sort(key=lambda r:r['t'])
  if rr:series.append(rr)
(ROOT/'model-20261010'/'normalized.json').write_text(json.dumps(series,indent=2))
print('series counts',[(r[0]['run'],r[0]['sid'],len(r)) for r in series])
def near(rr,t):return min(rr,key=lambda r:abs(r['t']-t))
obs=[]
for rr in series:
 for r in rr:
  p=near(rr,r['t']-60);f=near(rr,r['t']+60)
  dt=r['t']-p['t'];ft=f['t']-r['t']
  if not (35<dt<85 and 35<ft<85):continue
  seg=[a for a in rr if p['t']<=a['t']<=f['t']]
  if any(a['hz']<=0 or a['mode']!=1 or a['op'] not in (2,7) for a in seg):continue
  # Reject native startup plateaus: conservative at least4minutes since restart when visible.
  stopped=[a['t'] for a in rr if a['t']<r['t'] and a['hz']==0]
  if stopped and r['t']-max(stopped)<240:continue
  out=dict(r);out.update(delta=r['set']-r['supply'],slopeT=(r['supply']-p['supply'])*60/dt,slopeSet=(r['set']-p['set'])*60/dt,slopeHz=(r['hz']-p['hz'])*60/dt,Y=(f['hz']-r['hz'])*60/ft)
  for delay in (0,30,60,90,120):
   a=near(rr,r['t']-delay);out['delta'+str(delay)]=a['set']-a['supply']
  obs.append(out)
results=[]
for fs in [['delta','hz'],['delta','hz','slopeT'],['delta','hz','slopeT','slopeSet'],['delta','hz','slopeHz'],['delta60','hz','slopeT','slopeSet'],['delta120','hz','slopeT','slopeSet']]:
 x=lambda o:[1]+[o[f] for f in fs];X=[x(o)for o in obs];y=[o['Y']for o in obs];b=solve(X,y);pred=lambda o:sum(a*c for a,c in zip(x(o),b));m=statistics.mean(y);sse=sum((pred(o)-o['Y'])**2 for o in obs);sst=sum((o['Y']-m)**2 for o in obs);cvs=[]
 for name in NAMES:
  train=[o for o in obs if o['run']!=name];test=[o for o in obs if o['run']==name]
  if not test:continue
  bb=solve([x(o)for o in train],[o['Y']for o in train]);err=[sum(a*c for a,c in zip(x(o),bb))-o['Y'] for o in test];cvs.append(dict(holdout=name,n=len(test),rmse=math.sqrt(statistics.mean(e*e for e in err))))
 results.append(dict(features=['intercept']+fs,beta=b,n=len(obs),R2=1-sse/sst,rmse=math.sqrt(sse/len(y)),holdouts=cvs))
print(json.dumps(results,indent=2))
(ROOT/'model-20261010'/'fits.json').write_text(json.dumps(results,indent=2))
