import json,statistics,math
from pathlib import Path
P=Path(__file__).resolve().parent
S=json.loads((P/'normalized.json').read_text())
results=[]
for sid in (1,2):
 for lag in (0,15,30,45,60,75,90,120):
  a=[]
  for rr in S:
   if rr[0]['sid']!=sid:continue
   for r in rr:
    if r['w'] is None or r['hz']==0 or r['mode']!=1 or r['op']not in(2,7):continue
    prev=min(rr,key=lambda p:abs(p['t']-(r['t']-lag)))
    if abs(prev['t']-(r['t']-lag))>25 or prev['hz']==0:continue
    if any(q['hz']==0 or q['mode']!=1 or q['op']not in(2,7) for q in rr if prev['t']<=q['t']<=r['t']):continue
    a.append((prev['hz'],r['w'],r['run']))
  X=[x for x,y,z in a];Y=[y for x,y,z in a];mx=statistics.mean(X);my=statistics.mean(Y);b=sum((x-mx)*(y-my)for x,y in zip(X,Y))/sum((x-mx)**2 for x in X);inter=my-b*mx;rmse=math.sqrt(statistics.mean((inter+b*x-y)**2 for x,y in zip(X,Y)));results.append(dict(sid=sid,lag_s=lag,n=len(a),W_per_Hz=b,intercept_W=inter,rmse_W=rmse))
print(json.dumps(results,indent=2));(P/'lag.json').write_text(json.dumps(results,indent=2))
for rr in S:
 if rr[0]['run'].startswith('smooth'):
  print('SMOOTH',rr[0]['sid'])
  for r in rr:
   if r['hz']>=46: print(round(r['t']-rr[0]['t']), r['hz'],r['w'],r['raw'],r['set'],r['supply'])
