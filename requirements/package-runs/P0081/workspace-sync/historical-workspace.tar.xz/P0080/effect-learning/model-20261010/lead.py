import json,statistics,math
from pathlib import Path
P=Path(__file__).resolve().parent
S=json.loads((P/'normalized.json').read_text())
for horizon in (0,30,60):
 for run in ('fast','smooth'):
  pairs=[]
  for rr in S:
   if not rr[0]['run'].startswith(run):continue
   for r in rr:
    past=min(rr,key=lambda q:abs(q['t']-(r['t']-35)));future=min(rr,key=lambda q:abs(q['t']-(r['t']+horizon)))
    if abs(past['t']-r['t']+35)>25 or abs(future['t']-r['t']-horizon)>25:continue
    if r['hz']<26 or past['hz']<26 or future['hz']<26 or r['w']is None or future['w']is None:continue
    if any(q['op']not in(2,7) or q['mode']!=1 for q in[past,r,future]):continue
    pred=r['w']+110*(r['hz']-past['hz']);pairs.append((future['w'],r['w'],pred))
  if pairs:
   rms=lambda k:math.sqrt(statistics.mean((r[0]-r[k])**2 for r in pairs));print(horizon,run,len(pairs),round(rms(1)),round(rms(2)))
