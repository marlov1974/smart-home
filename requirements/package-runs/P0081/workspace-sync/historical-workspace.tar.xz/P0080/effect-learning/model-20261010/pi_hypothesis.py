import json,statistics
from pathlib import Path
P=Path(__file__).resolve().parent;S=json.loads((P/'normalized.json').read_text());ev=P.parent/'rocket-lead-20261010T141602Z/events.jsonl'
if ev.exists():
 current={1:[],2:[]}
 for line in ev.read_text().splitlines():
  e=json.loads(line)
  if e['kind']!='rocket_trial_sample':continue
  r=e['data'];s=r['snapshot']['samples'];current[r['sid']].append({'t':r['elapsed'],'hz':s['compressor_Hz']['value'],'supply':s['flow_cC']['value']/100,'set':r['native']['flow']/100,'mode':r['native']['mode'],'op':r['native']['operating_mode'],'run':'rocket-lead-20261010T141602Z','sid':r['sid']})
 S.extend(current.values())
segments=[]
for rr in S:
 block=[]
 for r in rr+[None]:
  okay=r is not None and r['mode']==1 and r['op']in(2,7) and r['hz']>0
  if block and (not okay or r['set']!=block[-1]['set'] or r['t']-block[-1]['t']>80):
   if block[-1]['t']-block[0]['t']>300:segments.append(block)
   block=[]
  if okay:block.append(r)
results=[]
for block in segments:
 for trim in (0,180,300):
  a=[r for r in block if r['t']>=block[0]['t']+trim]
  if len(a)<5 or a[-1]['t']-a[0]['t']<240:continue
  integral=sum(((x['set']-x['supply'])+(y['set']-y['supply']))/2*(y['t']-x['t'])/60 for x,y in zip(a,a[1:]));dh=a[-1]['hz']-a[0]['hz'];de=(a[-1]['set']-a[-1]['supply'])-(a[0]['set']-a[0]['supply']);ki=(dh-2*de)/integral if integral else None
  results.append({'run':a[0]['run'],'sid':a[0]['sid'],'target_C':a[0]['set'],'trim_first_s':trim,'span_min':(a[-1]['t']-a[0]['t'])/60,'Hz_first_last':[a[0]['hz'],a[-1]['hz']],'supply_first_last':[a[0]['supply'],a[-1]['supply']],'integral_K_min':integral,'Ki_given_Kp_2_Hz_K':ki})
print(json.dumps(results,indent=2));(P/'pi-hypothesis.json').write_text(json.dumps(results,indent=2))
