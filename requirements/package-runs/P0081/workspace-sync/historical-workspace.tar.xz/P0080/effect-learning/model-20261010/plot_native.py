"""Offline plotting and bounded 0..900s energy analysis for native dual EFFECT.
Usage: /tmp/procon-dev-venv/bin/python plot_native.py NATIVE_DIR [--pilot PILOT_DIR] [--out OUT_DIR]
Never imports the live transport or modifies device/controller configuration.
"""
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/procon-model-mpl')
import argparse,datetime,json,math,statistics
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def timestamp(t):return datetime.datetime.fromisoformat(t).timestamp()
def load(path):
 es=[]
 for s in(path/'events.jsonl').read_text().splitlines():
  try:es.append(json.loads(s))
  except json.JSONDecodeError:pass
 native=any(e['kind']=='dual_sample'for e in es)
 if native:
  anchor=next((timestamp(e['time'])for e in es if e['kind']=='both_applied'),None)
  if anchor is None:return None
 else:
  anchors=[timestamp(e['time'])-e['data']['elapsed']for e in es if e['kind']=='rocket_trial_sample']
  if not anchors:return None
  anchor=statistics.median(anchors)
 rows={1:[],2:[]};seen=set()
 for e in es:
  if e['kind']=='rocket_trial_sample'and not native:rr=[e['data']]
  elif e['kind']=='dual_sample'and native:rr=e['data']['rows']
  else:continue
  for r in rr:
   ts=timestamp(r['snapshot']['captured_at_host'])if native else timestamp(e['time'])
   t=ts-anchor if native else r['elapsed'];sid=r['sid'];key=(sid,r['snapshot']['sequence'])
   if key in seen:continue
   seen.add(key);samples=r['snapshot']['samples'];v=lambda k:samples[k]['value'];fb=r['feedback']
   rows[sid].append(dict(t=t,hz=v('compressor_Hz'),raw_W=v('heat_W'),short_W=fb.get('short_w'),quality=fb['quality'],supply_C=v('flow_cC')/100 if v('flow_cC')is not None else None,return_C=v('return_cC')/100 if v('return_cC')is not None else None,target_C=r['native']['flow']/100,op=r['native']['operating_mode'],phase=r.get('effect',{}).get('phase'),control_state=r['control']['state'],control_error=r['control']['error'],lease_s=r['control']['lease_s']))
 for rr in rows.values():rr.sort(key=lambda r:r['t'])
 return dict(rows=rows,anchor_utc=anchor,native=native,complete=(path/'outcome.json').exists(),failure=(path/'failure.json').exists(),path=str(path))
def stats(values):return {'n':len(values),'mean':statistics.mean(values),'min':min(values),'max':max(values),'stdev':statistics.pstdev(values)}if values else None
def measure(rr,end=900,complete=False):
 valid=[r for r in rr if 0<=r['t']<=end];last=end if complete else min(end,rr[-1]['t']);late=[r for r in valid if r['t']>=last-300];w=lambda r:r['short_W']if r['quality']in(0,2)and r['op']in(2,7)else None
 powers=[w(r)for r in late if w(r)is not None];last3=[w(r)for r in valid if r['t']>=last-180 and w(r)is not None];reach=lambda threshold:next((r['t']for r in valid if w(r)is not None and w(r)>=threshold),None)
 coverage=energy=0
 for a,b in zip(rr,rr[1:]):
  low=max(0,a['t']);high=min(end,b['t'])
  if high<=low or b['t']-a['t']>90:continue
  def power(r):
   if r['hz']==0:return 0
   return r['raw_W']if r['op']in(2,7)else None
  pa,pb=power(a),power(b)
  if pa is None or pb is None:continue
  interp=lambda x:pa+(pb-pa)*(x-a['t'])/(b['t']-a['t']);energy+=(interp(low)+interp(high))/2*(high-low)/3600000;coverage+=high-low
 starts=[{'earliest_s':a['t'],'latest_s':b['t']}for a,b in zip(rr,rr[1:])if a['hz']==0 and b['hz']is not None and b['hz']>0]
 initial=next((r for r in rr if r['t']>=0),rr[0]);first_positive=next((r['t']for r in valid if r['hz']is not None and r['hz']>0),None)
 first45=next((r['t']for r in valid if r['target_C']>=45),None)
 after45=lambda threshold:next((r['t']-first45 for r in valid if first45 is not None and r['t']>=first45 and w(r)is not None and w(r)>=threshold),None)
 return {'first_45C_verified_target_s':first45,'first90_after_first45_s':after45(5400),'first95_after_first45_s':after45(5700),'last3min_W':stats(last3),'short_power_max_W':max((w(r)for r in valid if w(r)is not None),default=None),'raw_power_max_W':max((r['raw_W']for r in valid if r['op']in(2,7)and r['raw_W']is not None),default=None),'samples_in_quarter':len(valid),'elapsed_last_s':rr[-1]['t'],'first90_s':reach(5400),'first95_s':reach(5700),'first_in_5500_6500_s':next((r['t']for r in valid if w(r)is not None and 5500<=w(r)<=6500),None),'last5min_stopped_samples':sum(r['hz']==0 for r in late),'last5min_unavailable_power_samples':sum(w(r)is None for r in late),'last5min_W':stats(powers),'last5min_band_fraction':sum(5500<=x<=6500 for x in powers)/len(powers)if powers else None,'final_short_W':valid[-1]['short_W']if valid else None,'final_short_sample_s':valid[-1]['t']if valid else None,'last_logged_short_W_including_after900':rr[-1]['short_W'],'supply_max_C':max((r['supply_C']for r in valid if r['supply_C']is not None and r['op']in(2,7)),default=None),'energy_kWh_covered_intervals':energy,'energy_coverage_s':coverage,'running_at_first_mission_sample':initial['hz']is not None and initial['hz']>0,'first_observed_running_s':first_positive,'restart_intervals':starts,'thermal_limited_samples':sum(r['phase']==4 for r in valid),'minimum_observed_lease_s':min((r['lease_s']for r in valid),default=None),'observed_control_errors':sorted(set(r['control_error']for r in valid))}
def plot(data,out,pilot=None):
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.alpha':.2})
 fig,axs=plt.subplots(3,2,figsize=(14,10),sharex='col',constrained_layout=True)
 title='Ny firmware: 2 × 6 kW' if data['complete'] else 'Ny firmware: pågående prov med 2 × 6 kW'
 if data['failure']:title='Ny firmware: avbrutet prov med 2 × 6 kW'
 fig.suptitle(title,fontsize=18,fontweight='bold');summary={}
 for col,sid in enumerate((1,2)):
  rr=data['rows'][sid]
  if not rr:continue
  draw=[r for r in rr if r['t']<=900];t=[r['t']/60 for r in draw];vals=lambda name:[r[name]if r[name]is not None else math.nan for r in draw];short=[r['short_W']/1000 if r['short_W']is not None and r['op']in(2,7)else math.nan for r in draw];raw=[r['raw_W']/1000 if r['raw_W']is not None and r['op']in(2,7)else math.nan for r in draw];ref_t=[i/12 for i in range(181)]
  ax=axs[0,col];ax.axhspan(5.5,6.5,color='#58a979',alpha=.1,label='Målintervall 5,5–6,5 kW');ax.plot(ref_t,[6*(1-math.exp(-x/2))for x in ref_t],color='#555',ls='--',lw=1.3,label='Referens från 0 kW (ej mätning)');ax.scatter(t,raw,s=12,color='#8a9eac',alpha=.5,label='Rå vattenbaserad effekt');ax.plot(t,short,'o-',ms=3,lw=2,color='#0869ac',label='Ny firmware: kort medeleffekt')
  if pilot and pilot['rows'][sid]:
   p=[r for r in pilot['rows'][sid]if r['t']<=900];ax.plot([r['t']/60 for r in p],[r['short_W']/1000 if r['short_W']is not None else math.nan for r in p],color='#b08652',alpha=.85,lw=1.3,label='Tidigare värddatorprov (annan start)')
  ax.set(title=f'VP{sid}',ylabel='Värmeeffekt (kW)',ylim=(-.5,max(7,max((x for x in short if math.isfinite(x)),default=6)+.5)));ax.legend(loc='lower right',fontsize=7.7)
  ax=axs[1,col];ax.step(t,vals('hz'),where='post',lw=2,color='#8b47a0');ax.set(ylabel='Kompressor (Hz)',ylim=(0,max(70,max(vals('hz'))+5)))
  ax=axs[2,col];ax.step(t,vals('target_C'),where='post',lw=2,color='#db8b24',label='Verifierat börvärde');ax.plot(t,vals('supply_C'),lw=2,color='#b43c42',label='Faktisk framledning');ax.plot(t,vals('return_C'),lw=1.5,color='#387957',label='Retur');ax.axhline(40,color='#b43c42',ls='--',alpha=.65,label='Gräns faktisk framledning');ax.set(ylabel='Temperatur (°C)',xlabel='Tid från bekräftad missionstart (min)');ax.legend(loc='lower right',fontsize=8,ncol=2)
  summary[sid]=m=measure(rr,complete=data['complete'])
  initial='Kompressorn gick vid provstart' if m['running_at_first_mission_sample']else 'Kompressorn var stoppad vid provstart';axs[1,col].text(.02,.94,initial,transform=axs[1,col].transAxes,va='top',fontsize=8)
  for start in m['restart_intervals']:
   for a in axs[:,col]:a.axvspan(start['earliest_s']/60,start['latest_s']/60,color='#8b47a0',alpha=.08)
  if m['restart_intervals']:axs[1,col].text(.02,.83,'Lila band: observerat intervall för återstart',transform=axs[1,col].transAxes,va='top',fontsize=8)
  for a in axs[:,col]:a.set_xlim(min(-.7,min(t)),max(15,max(t)))
 out.mkdir(parents=True,exist_ok=True);fig.savefig(out/'native-comparison.png',dpi=150);fig.savefig(out/'native-comparison.svg');plt.close(fig)
 result={'complete':data['complete'],'failed':data['failure'],'devices':summary,'reference_curve_energy_kWh_each_900s':6*(900-120*(1-math.exp(-900/120)))/3600,'flat6kW_energy_kWh_each_900s':1.5,'pilot':{sid:measure(rr,complete=pilot['complete'])for sid,rr in pilot['rows'].items()if rr}if pilot else None,'notes':['Mission0 is native both_applied; rows use actual snapshot UTC time (not paired completion time).','Raw heat integration is clipped to0..900s and reports coverage explicitly; missing intervals are not filled.','Comparison has different initial temperatures/compressor states; it is descriptive, not a controlled A/B estimate.','Reference is6*(1-exp(-t/120s)), not fabricated measurement.','Thermal output is uncalibrated and temperature-quantized; rolling feedback lags compressor.']}
 (out/'native-analysis.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('evidence',type=Path);p.add_argument('--pilot',type=Path);p.add_argument('--out',type=Path);a=p.parse_args();d=load(a.evidence)
 if d is None:raise SystemExit('Mission not confirmed yet; no plot created')
 plot(d,a.out or a.evidence,load(a.pilot)if a.pilot else None)
