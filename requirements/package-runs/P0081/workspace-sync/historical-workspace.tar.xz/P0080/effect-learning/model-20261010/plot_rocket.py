"""Offline only: render real rocket_trial_sample logs and distinguish reference.
Run with /tmp/procon-dev-venv/bin/python plot_rocket.py EVIDENCE_DIR.
"""
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/procon-model-mpl')
import json,sys,math,statistics,datetime
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(sys.argv[1]); events=[]
for line in (P/'events.jsonl').read_text().splitlines():
 try:events.append(json.loads(line))
 except json.JSONDecodeError:pass # Last log write may be incomplete during live trial.
rows={sid:[]for sid in (1,2)};decisions={sid:[]for sid in(1,2)}
for e in events:
 d=e['data']
 if e['kind']=='rocket_trial_sample':rows[d['sid']].append(d)
 elif e['kind']=='lead_decision':decisions[d['sid']].append((e['time'],d))
if not any(rows.values()):raise SystemExit('No samples yet')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.alpha':.2})
fig,axs=plt.subplots(3,2,figsize=(14,10),sharex='col',constrained_layout=True)
summary={};complete=(P/'outcome.json').exists();title='Raketteori: uppmätt effekt och reglering' if complete else 'Raketteori: pågående prov — endast hittills uppmätt'
fig.suptitle(title,fontsize=18,fontweight='bold')
allmax=max(r['elapsed']for rr in rows.values()for r in rr)
start_utc=statistics.median(datetime.datetime.fromisoformat(e['time']).timestamp()-e['data']['elapsed']for e in events if e['kind']=='rocket_trial_sample')
for col,sid in enumerate((1,2)):
 rr=rows[sid]
 if not rr:continue
 t=[r['elapsed']/60 for r in rr];v=lambda r,k:r['snapshot']['samples'][k]['value'];hz=[v(r,'compressor_Hz')for r in rr];short=[r['feedback'].get('short_w')for r in rr];raw=[v(r,'heat_W')for r in rr];actual=[v(r,'flow_cC')/100 for r in rr];ret=[v(r,'return_cC')/100 for r in rr];target=[r['native']['flow']/100 for r in rr]
 ref_t=[i/12 for i in range(int(max(15,max(t))*12)+2)];ref=[6*(1-math.exp(-x/2))for x in ref_t]
 ax=axs[0,col];ax.plot(ref_t,ref,color='#777777',ls='--',lw=1.6,label='Referens från 0 kW, τ=2 min (ej mätning)');ax.axhline(6,color='#144a80',lw=1,alpha=.5);ax.axhspan(5.5,6.5,color='#58a979',alpha=.11,label='Målintervall 5,5–6,5 kW');ax.scatter(t,[x/1000 if x is not None else math.nan for x in raw],s=13,color='#9aa5b1',alpha=.65,label='Vattensidans råa effekt');ax.plot(t,[x/1000 if x is not None else math.nan for x in short],marker='o',ms=3,color='#1367aa',lw=2,label='Effekt, kort medelvärde');
 if decisions[sid]:
  td=[(datetime.datetime.fromisoformat(ts).timestamp()-start_utc)/60 for ts,d in decisions[sid]];pd=[d['predicted_w']/1000 for ts,d in decisions[sid]];ax.plot(td,pd,color='#ca7426',ls=':',lw=1.2,label='Ledande prognos (ej uppmätt effekt)')
 ax.set(ylabel='Värmeeffekt (kW)',title=f'VP{sid}');ax.set_ylim(bottom=-.5);ax.legend(loc='lower right',fontsize=8)
 ax=axs[1,col];ax.step(t,hz,where='post',color='#8944a3',lw=2,label='Kompressor');ax.set(ylabel='Frekvens (Hz)',ylim=(0,max(70,max(hz)+5)))
 ax=axs[2,col];ax.step(t,target,where='post',color='#e39230',lw=2,label='Verifierat börvärde');ax.plot(t,actual,color='#ba3f44',lw=2,label='Faktisk framledning');ax.plot(t,ret,color='#397a56',lw=1.5,label='Retur');ax.axhline(40,color='#ba3f44',ls='--',alpha=.6,label='Gräns faktisk framledning');ax.set(ylabel='Temperatur (°C)',xlabel='Tid från mätprovets start (min)');ax.legend(loc='lower right',fontsize=8,ncol=2)
 starts=[]
 for i in range(1,len(rr)):
  if hz[i-1]==0 and hz[i]>0:starts.append({'between_s':[rr[i-1]['elapsed'],rr[i]['elapsed']]});[a.axvline(t[i],color='#555',ls=':',alpha=.5)for a in axs[:,col]]
 initial='Kompressorn gick redan vid första mätningen' if hz[0]>0 else 'Kompressorn var stoppad vid första mätningen'
 axs[1,col].text(.02,.93,initial,transform=axs[1,col].transAxes,va='top',fontsize=8,bbox=dict(facecolor='white',alpha=.8,edgecolor='none'))
 if starts:axs[1,col].text(.02,.82,'Prickad linje: första observerade återstart',transform=axs[1,col].transAxes,va='top',fontsize=8)
 for a in axs[:,col]:a.set_xlim(0,max(15,allmax/60))
 def stats(vv):return dict(n=len(vv),mean=statistics.mean(vv),min=min(vv),max=max(vv),stdev=statistics.pstdev(vv))if vv else None
 late=[r for r in rr if r['elapsed']>=rr[-1]['elapsed']-300];latew=[r['feedback']['short_w']for r in late if r['feedback'].get('short_w')is not None and r['feedback']['quality']in(0,2)];band=[r['elapsed']for r in rr if r['feedback'].get('short_w')is not None and 5500<=r['feedback']['short_w']<=6500]
 covered=energy=0
 for a,b in zip(rr,rr[1:]):
  dt=b['elapsed']-a['elapsed']
  def heat(r):
   if v(r,'compressor_Hz')==0:return 0
   if r['native']['operating_mode']not in(2,7):return None
   return v(r,'heat_W')
  aa,bb=heat(a),heat(b)
  if aa is not None and bb is not None and dt<=60:energy+=(aa+bb)/2*dt/3600000;covered+=dt
 reach=lambda threshold:next((r['elapsed'] for r in rr if r['feedback'].get('short_w') is not None and r['feedback']['short_w']>=threshold),None)
 summary[sid]=dict(first_90_percent_s=reach(5400),first_95_percent_s=reach(5700),final_short_W=short[-1],samples=len(rr),elapsed_first=rr[0]['elapsed'],elapsed_last=rr[-1]['elapsed'],first_in_5_5_to_6_5_kW_s=min(band)if band else None,last_5min_W=stats(latew),last_5min_in_band_fraction=sum(5500<=w<=6500 for w in latew)/len(latew)if latew else None,actual_supply_max_C=max(actual),raw_heat_kWh_measured_intervals=energy,energy_interval_coverage_s=covered,compressor_restarts=starts,compressor_running_at_first_sample=hz[0]>0)

fig.savefig(P/'rocket-analysis.png',dpi=150);fig.savefig(P/'rocket-analysis.svg');plt.close(fig)
(P/'rocket-analysis.json').write_text(json.dumps({'complete':complete,'devices':summary,'notes':['Read-only log analysis','No zero-power initial measurement invented','First observed compressor restart has sample-interval uncertainty','Heat estimate uncalibrated; sensor quantization and rolling average lag apply']},indent=2))
print(json.dumps(summary,indent=2))
