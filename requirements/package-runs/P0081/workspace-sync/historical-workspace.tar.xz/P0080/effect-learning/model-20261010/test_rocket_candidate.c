#include "effect.h"
#include "effect_feedback.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 effect_measurement m={.instant_w=4000,.short_w=4000,.supply_cC=3300,.hz=40,.ready=1,.quality=EF_READY};
 effect_begin(6000,5500,0);effect_capture(3050,0);
 unsigned flow=effect_decide(&m,3050,0);assert(flow==4500);effect_verified(flow,0);
 unsigned n=0;
 /* Native10Hz steps should not cause braking while lead power remains<4.5kW. */
 for(unsigned t=5000;t<=60000;t+=5000){
  m.hz=t<30000?40:50;m.short_w=2800;m.supply_cC=3300+(int)(t/30000)*50;
  n=effect_decide(&m,flow,t);if(n){assert(n>=flow);flow=n;effect_verified(n,t);}
 }
 /* Near the goal the same positive Hz trend is allowed to brake. */
 unsigned before=flow;
 for(unsigned t=65000;t<=120000;t+=5000){
  m.hz=60;m.short_w=5600;
  n=effect_decide(&m,flow,t);if(n){flow=n;effect_verified(n,t);}
 }
 assert(flow<before);
 /* A persistent Hz decrease below goal cannot continue the taper. */
 for(unsigned t=125000;t<=240000;t+=5000){
  m.hz=58;m.short_w=5500;before=flow;
  n=effect_decide(&m,flow,t);if(n){if(t>=180000)assert(n>=before);flow=n;effect_verified(n,t);}
 }
 m.age_ms=15000;m.short_w=3000;assert(!effect_decide(&m,flow,270000));
 m.age_ms=59000;assert(!effect_decide(&m,flow,300000));
 m.supply_cC=3900;n=effect_decide(&m,flow,330000);assert(n==3950);effect_verified(n,330000);
 assert(effect_read(321,&m,n,330000)==EFFECT_LIMITED);
 effect_begin(6000,5500,0);effect_capture(3800,0);m.age_ms=0;m.supply_cC=3300;m.short_w=7000;
 assert(!effect_decide(&m,3800,0)); /* already above power goal: no startup gas */
 effect_begin(6000,5500,0);effect_capture(3800,0);m.short_w=3000;m.supply_cC=3900;
 assert(effect_decide(&m,3800,0)==3950); /* temperature guard before initial boost */
 puts("PASS candidate:45C initial, Hz-leading brake/recovery, falling-Hz freeze,15..59s hold, thermal priority, no over-target startup boost");
}
