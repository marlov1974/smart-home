"""P0080 recover invalid D1 module set, then update D2; known identities only."""
from update_effect import *
class Recovery(UpdateSender):
 def ready(self,sid):
  st=Sender.ready(self,sid)
  if st['uid']!=UID[sid] or st['mode']!=0:raise GateError('Unexpected identity/mode')
  if sid==1 and not st['valid']:
   if st['manifest_crc']!=0:raise GateError('Unexpected invalid manifest')
   self.log({'repair_base':st});return st
  if not st['valid'] or st['manifest_crc']!=self.expected[sid]:raise GateError('Unexpected valid image')
  q=Trial.__new__(Trial);q.s=self;c=q.control(sid);n=q.native(sid)
  if c['state'] or c['saved'] or n['mode']!=2:raise GateError('Not native curve/idle')
  self.log({'pre_ota_sid':sid,'control':c,'native':n});return st

def main():
 out=ROOT/'effect-learning'/('recover-install-effect-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'));out.mkdir()
 logs=sorted((ROOT/'effect-learning').glob('update-effect-*/device1/rpc.jsonl'))[-1]
 records=[json.loads(x) for x in logs.read_text().splitlines()];w=next(x for x in records if x.get('wait_sid')==2)
 deadline=datetime.fromisoformat(w['time']).timestamp()+w['seconds']+4
 while time.time()<deadline:
  print('WAIT existing D2',round(deadline-time.time()),flush=True);time.sleep(min(20,deadline-time.time()))
 p=plan(MOD/'build-brine-pump',MOD/'build-effect-refresh');expected={1:OLD,2:OLD}
 for sid in (1,2):
  s=Recovery(out/('device'+str(sid)),expected.copy())
  try:
   s.transfer(p,sid,[3-sid],repair=sid==1)
   expected[sid]=NEW;verify(s,sid,NEW)
  finally:s.stop()
  while time.monotonic()<s.wait_until:
   remaining=s.wait_until-time.monotonic();print('WAIT peer',3-sid,round(remaining),flush=True);time.sleep(min(25,remaining))
  v=Recovery(out/('after'+str(sid)),expected.copy())
  try:
   v.start()
   for unit in (1,2):verify(v,unit,expected[unit])
  finally:v.stop()
 (out/'outcome.json').write_text(json.dumps({'verified_both':True,'manifest_crc':hex(NEW)},indent=2))
 print('BOTH UPDATED',out,flush=True)
if __name__=='__main__':main()
