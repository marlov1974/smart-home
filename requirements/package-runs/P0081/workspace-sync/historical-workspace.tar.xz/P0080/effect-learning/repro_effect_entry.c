#include "cn105.h"
#include "control.h"
#include "effect_feedback.h"
#include "telemetry.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static void seal(unsigned char *b,unsigned n){unsigned s=0;for(unsigned i=0;i<n-1;i++)s+=b[i];b[n-1]=(unsigned char)(252-s);}
int main(int argc,char **argv){
 unsigned delay=argc>1?atoi(argv[1]):220,attempts=argc>2?atoi(argv[2]):6;
 unsigned char tx[22],rx[22];unsigned len=0,due=0,svc=0,mode=2,target=3050,submitted=0,done=0,oldstate=99,oldq=99;
 cn_init();
 for(unsigned t=0;t<100000;t++){
  cn_tick(t);
  if(len && t>=due){for(unsigned i=0;i<len;i++)cn_feed(rx[i],t,0);len=0;}
  const effect_feedback_state *f=effect_feedback_get();
  if(!submitted && t>35000 && f->ready){unsigned short w[8]={0xc076,1,5,4000,3800,300,1,3};if(!cn_command(w)){submitted=t;printf("SUBMIT t=%u\n",t);}}
  unsigned st=ctl_read(256);
  if(submitted && (st!=oldstate || (f->quality!=oldq && f->quality!=0 && f->quality!=2))){tele_sample h;tele_snapshot(8,&h);printf("t=%u state=%u q=%u hzage=%u pairs=%u error=%u reason=%u\n",t,st,f->quality,h.age_ms,f->short_count,ctl_read(260),ctl_read(322));}
  oldstate=st;oldq=f->quality;
  unsigned n=0;while(cn_tx_byte(tx+n)){cn_tx_sent();n++;}
  if(n){
   memset(rx,0,22);rx[0]=252;rx[1]=0x62;rx[2]=2;rx[3]=0x7a;rx[4]=16;rx[5]=tx[5];len=22;
   if(tx[1]==0x5a){rx[1]=0x7a;rx[4]=1;rx[5]=0;len=7;}
   else if(tx[1]==0x41){if(tx[6]&8)mode=tx[11];if(tx[6]&0x80)target=tx[15]*256+tx[16];rx[1]=0x61;rx[4]=1;rx[5]=0;len=7;printf("SET t=%u mode=%u target=%u\n",t,mode,target);}
   else switch(tx[5]){
    case 4:rx[6]=28;break;
    case 0x0c:rx[6]=0x0b;rx[7]=0x86;rx[9]=0x0a;rx[10]=0x8c;rx[12]=0x14;rx[13]=0x50;break;
    case 0x14:rx[17]=19;break;
    case 0x26:rx[8]=1;rx[9]=2;rx[11]=mode;rx[13]=0x14;rx[14]=0x50;break;
    case 9:rx[10]=target>>8;rx[11]=target;break;
    case 0xa3:rx[7]=tx[7];rx[8]=++svc%attempts?0:1;rx[9]=4;break;
   }
   seal(rx,len);due=t+delay;
  }
  if(submitted && st==0){done=1;break;}
 }
 printf("FINAL state=%u applied=%u error=%u reason=%u mode=%u restored=%u\n",ctl_read(256),ctl_read(258),ctl_read(260),ctl_read(322),mode,ctl_read(267));return done?1:0;
}
