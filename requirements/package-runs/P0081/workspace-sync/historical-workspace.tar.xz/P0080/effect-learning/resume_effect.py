"""P0080 resume exact acknowledged OTA session after truncated reply; no new erase."""
from update_effect import *
from ota import frame,decode,transactions
out=ROOT/'effect-learning'/('resume-effect-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
s=Sender('DEVICE_HOST','shellypro2-80f3dac8bfec',out)
p=plan(MOD/'build-brine-pump',MOD/'build-effect-refresh')
log=sorted((ROOT/'effect-learning').glob('update-effect-*/device1/rpc.jsonl'))[-1]
records=[json.loads(x) for x in log.read_text().splitlines()]
wait=next(x for x in records if x.get('wait_sid')==2)
expires=datetime.fromisoformat(wait['time']).timestamp()+wait['seconds']
try:
 s.start();s.ev('baud(115200)')
 h=decode(s.exchange(frame(5,0)),5,0);print('RESUME STATUS',h,flush=True)
 assert [h['uid0'],h['uid1'],h['uid2']]==UID[1] and h['active']==1 and h['next_seq'] in (24,25)
 for b in transactions(p,UID[1]):
  seq=struct.unpack('<H',b[4:6])[0];cmd=b[2]
  if seq<h['next_seq']:continue
  if time.time()>expires-35:raise GateError('WAIT margin')
  for attempt in range(3):
   r=s.exchange(b,2 if cmd in (4,6) else .5)
   try:a=decode(r,cmd,seq)
   except ValueError:
    s.log({'retry_exact_frame':seq,'attempt':attempt});continue
   if a['status'] or a['next_seq']!=seq+1 or [a['uid0'],a['uid1'],a['uid2']]!=UID[1]:raise GateError(str(a))
   break
  else:raise GateError('Repeated incomplete replies')
  if seq%10==0:print('RESUMED',seq,flush=True)
 s.ev('baud(9600)');time.sleep(3);verify(s,1,NEW)
 (out/'outcome.json').write_text(json.dumps({'verified':True,'crc':hex(NEW)}))
finally:s.stop()
print('D1 COMPLETE',out,flush=True)
