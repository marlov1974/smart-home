"""P0080 empirical Hz-leading host controller. Physical trials explicitly authorized."""
from rocket_trial import *

class LeadController:
 def __init__(self,trial):self.t=trial;self.h={};self.last={}
 def __call__(self,sid,r,cfg):
  now=r['t'];s=r['snapshot']['samples'];hz=s['compressor_Hz']['value'];flow=s['flow_cC']['value'];f=r['feedback'];c=r['control'];n=r['native'];target=self.t.targets.get(sid)
  hist=self.h.setdefault(sid,[]);hist.append((now,hz,flow));self.h[sid]=hist=[x for x in hist if now-x[0]<180]
  if sid in self.t.pending:return target
  if n['operating_mode'] not in (2,7) or hz==0:
   return min(3800,max(target or n['flow'],flow+50)) if n['operating_mode'] in (0,2,7) else target
  if f['quality'] not in (0,2) or f['short_w'] is None or f['last_age_s']>=60:return target
  if target is None:return min(3950,cfg.get('initial_cC',4500)) if flow>=3800 else cfg.get('initial_cC',4500)
  dt=now-self.last.get(sid,now-30)
  if dt<cfg.get('interval_s',30):return target
  past=min(hist,key=lambda x:abs(now-x[0]-35));span=now-past[0]
  if span<20:return target
  rate=(hz-past[1])*60/span;temp_rate=(flow-past[2])*60/span
  predicted=f['short_w']+cfg.get('watts_per_hz',110)*(hz-past[1])
  goal=cfg.get('target_w',6000);desired=max(-12,min(12,(goal-predicted)/165))
  step=(desired-rate)*min(dt,45)/60*100/6
  bound=100 if predicted>goal+1200 else 50
  step=max(-bound,min(bound,step))
  if rate<0 and predicted<=goal+300:step=max(0,step)
  if abs(predicted-goal)<=300 and abs(rate)<3:step=0
  if abs(step)<10:step=0
  next_t=target+round(step)
  thermal=flow>=3850 or flow+max(0,temp_rate)/2>=3950
  if thermal:next_t=min(next_t,3950)
  next_t=max(3000,min(4500,next_t))
  self.last[sid]=now
  self.t.log('lead_decision',{'sid':sid,'short_w':f['short_w'],'hz':hz,'hz_rate_min':rate,'predicted_w':predicted,'desired_hz_rate_min':desired,'target_before':target,'target_after':next_t,'supply_cC':flow,'thermal':thermal,'config':cfg})
  return next_t

def main():
 a=argparse.ArgumentParser();a.add_argument('--seconds',type=int,default=900);a.add_argument('--config',type=Path,required=True);v=a.parse_args()
 if not 60<=v.seconds<=1200:raise ValueError('bounded duration')
 out=ROOT/'effect-learning'/('rocket-lead-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'));t=RocketTrial(out,True);t.controller=LeadController(t)
 def stop(*_):raise KeyboardInterrupt('operator/signal')
 signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
 try:
  t.s.start();t.preflight();t.run(v.seconds,'delta',v.config)
  (out/'outcome.json').write_text(json.dumps({'completed':True,'seconds':v.seconds,'target_w_each':6000}))
 except BaseException as e:
  (out/'failure.json').write_text(json.dumps({'error':repr(e)}));raise
 finally:t.finish();print('Evidence',out,flush=True)
if __name__=='__main__':main()
