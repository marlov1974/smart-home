"""P0080 authorized dual native EFFECT 6000W/900s with bounded mission lease and restoration."""
from trial import *
EXPECTED=0x982e160b
class Dual(Trial):
 def identity(self,sid):
  st=self.s.status(sid)
  if st['uid']!=UID[sid] or st['valid']!=1 or st['mode']!=0 or st['manifest_crc']!=EXPECTED:
   self.unsafe.add(sid);raise GateError('Identity/image mismatch')
  base=self.read(sid,0,16);now=time.monotonic()
  if sid in self.previous:
   old,at=self.previous[sid]
   if ((base[9]-old)&65535)>now-at+15:self.unsafe.add(sid);raise GateError('Reset/clock discontinuity')
  self.previous[sid]=(base[9],now)
  if base[:2]!=[888,76] or base[11]!=1:raise GateError('CN105 not linked')
  return base
 def native(self,sid):
  le=lambda w:bytes(b for x in w for b in (x&255,x>>8))
  p9=le(self.read(sid,232,8));p26=le(self.read(sid,248,8));diag=self.read(sid,283,13);p28=le(diag[5:])
  age=self.read(sid,176,4);status=self.read(sid,156,4)
  if p9[0]!=9 or p26[0]!=38 or p28[0]!=40 or not diag[0] or diag[1]>=60 or any(age[i]>=60 or status[i]!=1 for i in (0,2)):raise GateError('Native data unavailable for60s')
  return {'power':p26[3],'mode':p26[6],'flow':int.from_bytes(p9[5:7],'big'),'dhw':int.from_bytes(p26[8:10],'big'),'boost':p28[3],'operating_mode':p26[4],'flags28':list(p28)}
 def capture(self,sid,full=True):
  r=super().capture(sid,full)
  if full and sid==2:
   r['effect']=decode_effect(self.read(sid,320,32));r['feedback']=decode_feedback(self.read(sid,352,20))
   self.log('effect_vp2',r)
  return r
 def command(self,sid,mode):
  if sid in self.unsafe:raise GateError('Unsafe identity/reset')
  assert sid in (1,2) and mode in ('effect','auto')
  self.identity(sid);c=self.control(sid);seq=c['accepted']%65535+1
  kwargs={'target_w':6000,'max_flow':55,'boundary_verified':True} if mode=='effect' else {}
  packet=encode(seq,mode,lease=0 if mode=='auto' else 180,slave=sid,**kwargs)
  self.log('command_intent',{'sid':sid,'before':c,'packet':packet})
  b=bytes.fromhex(packet['rtu_hex'])
  if mode!='auto':self.owned.add(sid)
  r=self.s.exchange(b)
  if r==b[:6]+crc16(b[:6]):
   self.renewed[sid]=time.monotonic();self.log('command_ack',{'sid':sid,'mode':mode,'seq':seq});return True
  if r==bytes([sid,0x90,6])+crc16(bytes([sid,0x90,6])):return False
  raise GateError('Ambiguous command ACK '+r.hex())
 def wait_ready(self):
  deadline=time.monotonic()+1200
  while time.monotonic()<deadline:
   rows=[self.capture(sid) for sid in (1,2)]
   print('WAIT HEATING',[(r['sid'],r['native']['operating_mode'],r['base'][2],r['feedback']['quality_name']) for r in rows],flush=True)
   if all(r['native']['power']==1 and r['native']['operating_mode'] in (0,2,7) and r['feedback']['quality'] in (0,8,9) for r in rows):return
   time.sleep(3)
  raise GateError('Both pumps not available for heating within20min; no forcing DHW')
 def run_dual(self):
  self.wait_ready();accepted=set();began=time.monotonic();start=None
  while True:
   rows=[]
   for sid in (1,2):
    if sid not in accepted:
     if self.command(sid,'effect'):accepted.add(sid)
    r=self.capture(sid);rows.append(r);c=r['control'];n=r['native'];f=r['feedback'];samples=r['snapshot']['samples']
    if sid in accepted:
     if c['state'] in (0,5,6) or c['error'] not in (0,2):raise GateError('Native EFFECT aborted '+str((sid,c,f)))
     if n['power']!=1 or n['operating_mode'] not in (0,1,2,6,7):raise GateError('Native heat priority changed '+str(sid))
     if n['mode']==1 and n['flow']>5500:raise GateError('Target above55C')
     if n['operating_mode'] in (2,7) and samples['flow_cC']['status']==1 and samples['flow_cC']['value']>4000:raise GateError('Flow exceeded40C')
     if f['quality'] not in range(10):raise GateError('Feedback hard invalid '+str((sid,f)))
     if c['state'] in (3,4) and c['applied']==c['accepted'] and time.monotonic()-self.renewed.get(sid,0)>60:
      if not self.command(sid,'effect'):self.log('renew_busy',{'sid':sid})
    print('SAMPLE',sid,'elapsed',round(time.monotonic()-start) if start else 'starting','Hz',r['base'][2],'W',f['short_w'],'target',n['flow']/100,'phase',r['effect']['phase'],'quality',f['quality_name'],'state',c['state'],flush=True)
   active=all(r['control']['state']==4 and r['control']['mode']==5 and r['control']['applied']==r['control']['accepted'] and r['native']['mode']==1 for r in rows)
   if start is None and active:
    start=time.monotonic();self.log('both_applied',{'duration_s':900,'target_w_each':6000});print('BOTH APPLIED: 15 MIN TIMER START',flush=True)
   if start is None and time.monotonic()-began>300:raise GateError('EFFECT entry not confirmed in5min')
   self.log('dual_sample',{'elapsed':None if start is None else time.monotonic()-start,'rows':rows})
   if start is not None and time.monotonic()-start>=900:return
   time.sleep(2)

def main():
 out=ROOT/'effect-learning'/('rocket-native6kw-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'));t=Dual(out)
 def interrupt(*_):raise KeyboardInterrupt('operator/signal')
 signal.signal(signal.SIGINT,interrupt);signal.signal(signal.SIGTERM,interrupt)
 t.allowed_native_modes={1:(0,1,2,6,7),2:(0,1,2,6,7)}
 try:
  t.s.start();t.preflight();t.run_dual()
  (out/'outcome.json').write_text(json.dumps({'completed':True,'duration_s':900,'target_w_each':6000,'firmware_crc':hex(EXPECTED)},indent=2))
 except BaseException as e:
  (out/'failure.json').write_text(json.dumps({'error':repr(e)},indent=2));raise
 finally:t.finish();print('Evidence',out,flush=True)
if __name__=='__main__':main()
