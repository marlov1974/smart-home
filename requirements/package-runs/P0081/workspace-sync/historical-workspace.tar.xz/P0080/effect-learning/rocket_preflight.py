from trial import *
out=ROOT/'effect-learning'/('rocket-baseline-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'));t=Trial(out)
t.allowed_native_modes={1:(0,1,2,6,7),2:(0,1,2,6,7)}
try:
 t.s.start();t.preflight()
 for sid in (1,2):
  r=t.capture(sid);print('LIVE',sid,r['base'][2],r['native'],r['snapshot'],flush=True)
finally:t.finish()
print('Evidence',out,flush=True)
