"""Supervised two-pump manual experiment; imports and construction are offline.

CLI defaults to read-only baseline. Delta strategy is deliberately supplied by
a separately reviewed JSON file, rather than assuming a control law here.
Direct targets: {"targets_cC": {"1": 3700, "2": 3700}}. The file is reloaded
each cycle. Library users can implement a law with sample()/set_target().
Only documented fixed-flow 20..45 C, 180 s leases and AUTO are written.
"""
from trial import *
from read_mvp import signed32

EXPECTED = 0x67ff1a3e
SUBSET = ('flow_cC', 'return_cC', 'water_delta_cC', 'flow_cL_min',
          'heat_W', 'compressor_Hz')


def subset_snapshot(read):
    """Freeze once, read six contiguous records, verify no competing capturer."""
    h = read(400, 8)
    if h[:2] != [0x5380, 1] or h[4] not in (0, 1) or h[5:] != [20, 0, 0]:
        raise GateError('Snapshot header mismatch')
    w = read(426, 36)
    if read(402, 2) != h[2:4]:
        raise GateError('Snapshot replaced by another reader')
    samples = {}
    for i, name in enumerate(SUBSET):
        x = w[6*i:6*i+6]
        value = signed32(x[0], x[1])
        if x[2] > 4 or ((value == -(1 << 31)) != (x[2] != 1)):
            raise GateError('Inconsistent snapshot record')
        samples[name] = {'value': value if x[2] == 1 else None,
                         'status': x[2], 'age_ms': x[3] << 16 | x[4],
                         'generation': x[5]}
    return {'sequence': h[2] << 16 | h[3], 'link_lost': bool(h[4]),
            'samples': samples, 'subset': True}


class RocketTrial(Trial):
    allowed_native_modes = {1: (0, 1, 2, 6, 7), 2: (0, 1, 2, 6, 7)}

    def __init__(self, out, execute=False):
        super().__init__(out)
        self.execute = execute
        self.cache = {}
        self.pending = {}
        self.targets = {}
        self.identity_at = {}
        self.controller = None  # Optional callable(sid, row, complete_config)->cC.

    def identity(self, sid):
        # Trial pins the same current smooth image, UID and reset/clock check.
        base = super().identity(sid)
        self.identity_at[sid] = time.monotonic()
        return base

    def native(self, sid):
        # Same fields as Trial; retain the established strict 20 s freshness.
        return super().native(sid)

    def preflight(self):
        super().preflight()
        for sid in (1, 2):
            if self.original[sid]['power'] != 1:
                raise GateError('Both pumps must initially be powered')
        self.log('experiment_limits', {'execute': self.execute,
            'target_range_cC': [2000, 4500], 'actual_heating_max_cC': 4000,
            'lease_s': 180, 'expected_crc': hex(EXPECTED)})

    def sample(self, sid):
        began = time.monotonic()
        if began - self.identity_at.get(sid, 0) >= 120:
            base = self.identity(sid)
        else:
            base = self.read(sid, 0, 16)
            old, at = self.previous[sid]
            if ((base[9] - old) & 65535) > began - at + 15:
                self.unsafe.add(sid)
                raise GateError('Reset/clock discontinuity')
            self.previous[sid] = (base[9], began)
            if base[:2] != [888, 76] or base[11] != 1:
                raise GateError('CN105 not linked')
        cache = self.cache.get(sid)
        # Refresh before 30 s, allowing transport time for the five reads.
        if not cache or began - cache['at'] >= 20 or sid in self.pending:
            c = self.control(sid)
            n = self.native(sid)
            cache = {'control': c, 'native': n, 'at': time.monotonic()}
            self.cache[sid] = cache
        snap = subset_snapshot(lambda a, n: self.read(sid, a, n))
        feedback = decode_feedback(self.read(sid, 352, 20))
        c, n = cache['control'], cache['native']
        row = {'sid': sid, 't': time.monotonic(), 'base': base,
               'control': c, 'native': n, 'snapshot': snap,
               'feedback': feedback,
               'native_control_cache_age_s': time.monotonic() - cache['at'],
               'sample_duration_s': time.monotonic() - began}
        self.log('rocket_sample', row)
        s = snap['samples']
        if n['power'] != 1 or n['boost'] or any(n['flags28'][i] for i in (4, 5, 6, 10)):
            raise GateError('Native power/boost/inhibit boundary changed')
        if n['operating_mode'] not in (0, 1, 2, 6, 7):
            raise GateError('Native operating mode unsupported')
        for key in ('flow_cC', 'return_cC', 'compressor_Hz'):
            if s[key]['status'] != 1 or s[key]['age_ms'] >= 60000:
                raise GateError('Primary source unavailable for60s: ' + key)
        if n['operating_mode'] in (0, 2, 7) and s['flow_cC']['value'] > 4000:
            raise GateError('Actual heating supply exceeded40C')
        if sid in self.owned:
            if c['state'] in (0, 5, 6) or c['error'] not in (0, 2):
                raise GateError('Manual ownership/control fault')
            p = self.pending.get(sid)
            if p and c['state'] == 4 and c['accepted'] == c['applied'] == p['sequence']:
                if n['mode'] != 1 or n['flow'] != p['target']:
                    raise GateError('Direct target readback mismatch')
                self.log('target_verified', {'sid': sid, **p})
                self.pending.pop(sid)
            elif p and time.monotonic() - p['at'] > 90:
                raise GateError('Manual target application timeout')
            elif not p and c['state'] == 4:
                if c['mode'] != 2 or n['mode'] != 1 or n['flow'] != self.targets[sid]:
                    raise GateError('External/manual target change')
        return row

    def set_target(self, sid, target_cC):
        if not self.execute:
            raise GateError('Writes require explicit execute=True / --execute')
        if sid not in (1, 2) or sid in self.unsafe or type(target_cC) is not int or not 2000 <= target_cC <= 4500:
            raise GateError('Unsafe recipient or fixed target range')
        if sid in self.pending:
            return False
        self.identity(sid)
        c, n = self.control(sid), self.native(sid)
        self.cache[sid] = {'control': c, 'native': n, 'at': time.monotonic()}
        if n['operating_mode'] not in (0, 2, 7) or n['power'] != 1 or n['boost'] or any(n['flags28'][i] for i in (4, 5, 6, 10)):
            self.log('target_wait_native', {'sid': sid, 'native': n})
            return False
        if sid in self.owned and (c['state'] != 4 or c['accepted'] != c['applied'] or c['mode'] != 2):
            return False
        seq = c['accepted'] % 65535 + 1
        packet = encode(seq, 'fixed-flow', flow=target_cC/100, lease=180, slave=sid)
        self.log('command_intent', {'sid': sid, 'before': {'control': c, 'native': n}, 'packet': packet})
        b = bytes.fromhex(packet['rtu_hex'])
        already_owned = sid in self.owned
        self.owned.add(sid)  # Lost ACK must still restore the original session.
        r = self.s.exchange(b)
        if r == bytes([sid, 0x90, 6]) + crc16(bytes([sid, 0x90, 6])):
            if not already_owned:
                self.owned.remove(sid)
            return False
        if r != b[:6] + crc16(b[:6]):
            raise GateError('Ambiguous manual command ACK')
        now = time.monotonic()
        self.targets[sid] = target_cC
        self.renewed[sid] = now
        self.pending[sid] = {'sequence': seq, 'target': target_cC, 'at': now}
        return True

    def command(self, sid, mode):
        if mode != 'auto':
            raise GateError('Use set_target for manual control')
        return super().command(sid, mode)

    def run(self, seconds, strategy='baseline', config=None):
        start = time.monotonic()
        while time.monotonic() - start < seconds:
            for sid in (1, 2):
                row = self.sample(sid)
                row['elapsed'] = time.monotonic() - start
                self.log('rocket_trial_sample', row)
                s = row['snapshot']['samples']
                print('ROCKET', sid, round(row['elapsed']), 'Hz', s['compressor_Hz']['value'],
                      'W', s['heat_W']['value'], 'supply', s['flow_cC']['value'],
                      'target', row['native']['flow'], flush=True)
                if strategy == 'delta':
                    settings = json.loads(Path(config).read_text())
                    target = settings.get('targets_cC', {}).get(str(sid))
                    if target is None:
                        if self.controller is None:
                            raise GateError('Law config requires a reviewed controller callback')
                        target = self.controller(sid, row, settings)
                    if target is None:
                        target = self.targets.get(sid)
                    if target is None:
                        continue
                    if target != self.targets.get(sid) or time.monotonic() - self.renewed.get(sid, 0) >= 60:
                        self.set_target(sid, target)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--execute', action='store_true')
    p.add_argument('--seconds', type=int, default=300)
    p.add_argument('--strategy', choices=('baseline', 'delta'), default='baseline')
    p.add_argument('--config', type=Path)
    a = p.parse_args()
    if not 10 <= a.seconds <= 1200:
        p.error('Duration must be10..1200 seconds')
    if a.strategy == 'delta' and (not a.execute or not a.config):
        p.error('Delta needs --execute and a reviewed --config')
    out = ROOT/'effect-learning'/('rocket-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    t = RocketTrial(out, execute=a.execute)
    def stop(*_):
        raise KeyboardInterrupt('operator/signal')
    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGTERM, stop)
    try:
        t.s.start()
        t.preflight()
        t.run(a.seconds, a.strategy, a.config)
        (out/'outcome.json').write_text(json.dumps({'completed': True, 'seconds': a.seconds, 'strategy': a.strategy, 'execute': a.execute}, indent=2))
    except BaseException as e:
        (out/'failure.json').write_text(json.dumps({'error': repr(e)}))
        raise
    finally:
        t.finish()
        print('Evidence', out, flush=True)


if __name__ == '__main__':
    main()
