"""Offline guards around actual command encoder and restoration supervisor."""
import tempfile,json
from pathlib import Path
from trial import Trial,GateError
from control_command import encode
class Bus:
 def __init__(self):self.sent=[]
 def exchange(self,b):
  from shelly_ota import crc16
  self.sent.append(b);return b[:6]+crc16(b[:6])
with tempfile.TemporaryDirectory() as td:
 t=Trial.__new__(Trial);t.s=Bus();t.out=Path(td);t.owned=set();t.unsafe=set();t.renewed={};t.identity=lambda sid:None;t.control=lambda sid:{'accepted':65535};t.log=lambda *args:None
 assert t.command(1,'effect') and 1 in t.owned
 b=t.s.sent[-1];assert b==bytes.fromhex(encode(1,'effect',lease=180,slave=1,target_w=4000,max_flow=38,boundary_verified=True)['rtu_hex'])
 assert t.command(2,'off');assert t.s.sent[-1][0]==2
 for sid,mode in [(1,'off'),(2,'effect'),(3,'auto')]:
  try:t.command(sid,mode)
  except AssertionError:pass
  else:raise AssertionError('scope escape')
 t.unsafe.add(1)
 try:t.command(1,'auto')
 except GateError:pass
 else:raise AssertionError('restore after reset allowed')
 t.original={2:{'power':1,'mode':2,'flow':3050,'dhw':5200,'boost':0}}
 t.capture=lambda sid,full:{'native':{'power':1,'mode':2,'flow':3100,'dhw':5200,'boost':0},'control':{'state':0,'saved':0}}
 assert t.restore(2)['verified'] # native curve may move its target
 t.capture=lambda sid,full:{'native':{'power':0,'mode':2,'flow':3050,'dhw':5200,'boost':0},'control':{'state':0,'saved':0}}
 try:t.restore(2)
 except GateError:pass
 else:raise AssertionError('false restoration accepted')
print('PASS trial guards: exact addressed intent/lease/cap, sequence rollover, wrong-pump rejection, no reset restore, native restoration evidence')
