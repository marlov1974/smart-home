"""P0080 bounded two-pump physical learning trial. Default read-only preflight."""
import sys,json,time,struct,signal,argparse
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];MOD=ROOT/'implementation-smart-home/procon/modular'
sys.path.insert(0,str(MOD/'tools'))
from shelly_ota import Sender,crc16
from read_snapshot import read_snapshot
from read_mvp import decode_effect,decode_feedback
from control_command import encode
UID={1:[5898296,909201410,540096578],2:[5373989,909201412,540096578]}
KEYS=('state','accepted','applied','rejected','error','saved','touched','mode','lease_s','acks','readbacks','restores','original_power','original_mode','original_flow','original_dhw','original_boost','current_power','current_mode','current_flow','current_dhw','current_boost','action','actions','phase','retries','persistent_recovery')
class GateError(RuntimeError):pass
class Trial:
 def __init__(self,out):
  self.out=out;self.s=Sender('DEVICE_HOST','shellypro2-80f3dac8bfec',out);self.original={};self.owned=set();self.unsafe=set();self.previous={};self.renewed={};self.rows=[]
 def log(self,kind,data):
  with (self.out/'events.jsonl').open('a') as f:f.write(json.dumps({'time':datetime.now(timezone.utc).isoformat(),'kind':kind,'data':data})+'\n')
 def read(self,sid,a,n):
  if n>16:return sum((self.read(sid,a+i,min(16,n-i)) for i in range(0,n,16)),[])
  b=struct.pack('>BBHH',sid,4,a,n);r=self.s.exchange(b+crc16(b))
  if len(r)!=5+2*n or r[:3]!=bytes([sid,4,2*n]) or r[-2:]!=crc16(r[:-2]):raise GateError('Bad FC04 '+str((sid,a,r.hex())))
  return list(struct.unpack('>'+str(n)+'H',r[3:-2]))
 def identity(self,sid):
  st=self.s.status(sid)
  if st['uid']!=UID[sid] or st['valid']!=1 or st['mode']!=0 or st['manifest_crc']!={1:0x71b30837,2:0x7adaecf1}[sid]:
   self.unsafe.add(sid);raise GateError('Identity/image changed')
  base=self.read(sid,0,16);now=time.monotonic()
  if sid in self.previous:
   old,at=self.previous[sid]
   if ((base[9]-old)&65535)>now-at+15:self.unsafe.add(sid);raise GateError('Reset/clock discontinuity')
  self.previous[sid]=(base[9],now)
  if base[:2]!=[888,76] or base[11]!=1:raise GateError('CN105 not linked')
  return base
 def control(self,sid):return dict(zip(KEYS,self.read(sid,256,27)))
 def native(self,sid):
  le=lambda w:bytes(b for x in w for b in (x&255,x>>8))
  p9=le(self.read(sid,232,8));p26=le(self.read(sid,248,8));diag=self.read(sid,283,13);p28=le(diag[5:])
  age=self.read(sid,176,4);status=self.read(sid,156,4)
  if p9[0]!=9 or p26[0]!=38 or p28[0]!=40 or not diag[0] or diag[1]>20 or any(age[i]>20 or status[i]!=1 for i in (0,2)):raise GateError('Native data stale')
  return {'power':p26[3],'mode':p26[6],'flow':int.from_bytes(p9[5:7],'big'),'dhw':int.from_bytes(p26[8:10],'big'),'boost':p28[3],'operating_mode':p26[4],'flags28':list(p28)}
 def capture(self,sid,full=True):
  base=self.identity(sid);c=self.control(sid);n=self.native(sid)
  row={'sid':sid,'t':time.monotonic(),'base':base,'control':c,'native':n}
  if full:
   row['snapshot']=read_snapshot(lambda a,n:self.read(sid,a,n))
   if sid==1:row['effect']=decode_effect(self.read(sid,320,32));row['feedback']=decode_feedback(self.read(sid,352,20))
  self.log('capture',row);return row
 def preflight(self):
  for sid in (1,2):
   r=self.capture(sid);n=r['native'];c=r['control']
   if c['state']!=0 or c['saved']:raise GateError('Existing control session')
   if n['mode']!=2 or n['boost'] or any(n['flags28'][i] for i in (4,5,6,10)):raise GateError('Not ordinary native curve/DHW')
   if not 2000<=n['flow']<=3800 or not 4000<=n['dhw']<=6000 or n['operating_mode'] not in getattr(self,'allowed_native_modes',{}).get(sid,(0,2,7)):raise GateError('Native settings outside trial')
   if sid==1 and n['power']!=1:raise GateError('VP1 not powered')
   self.original[sid]={k:n[k] for k in ('power','mode','flow','dhw','boost')}
   print('BASELINE',sid,self.original[sid], 'Hz',r['base'][2],flush=True)
  (self.out/'original-settings.json').write_text(json.dumps(self.original,indent=2))
 def command(self,sid,mode):
  if sid in self.unsafe:raise GateError('Unsafe identity/reset restore blocked')
  assert (sid,mode) in ((1,'effect'),(1,'auto'),(2,'off'),(2,'auto'))
  self.identity(sid);c=self.control(sid);seq=1 if c['accepted']==65535 else c['accepted']+1
  kwargs={'target_w':4000,'max_flow':38,'boundary_verified':True} if mode=='effect' else {}
  packet=encode(seq,mode,lease=0 if mode=='auto' else 180,slave=sid,**kwargs);b=bytes.fromhex(packet['rtu_hex']);self.log('command_intent',packet)
  # Mark possible acceptance before TX: a lost ACK still requires restoration.
  if mode!='auto':self.owned.add(sid)
  r=self.s.exchange(b)
  if r==b[:6]+crc16(b[:6]):self.renewed[sid]=time.monotonic();return True
  if r==bytes([sid,0x90,6])+crc16(bytes([sid,0x90,6])):return False
  raise GateError('Ambiguous command ACK '+r.hex())
 def renew2(self):
  if 2 in self.owned and time.monotonic()-self.renewed.get(2,0)>60:
   c=self.control(2)
   if c['state']!=4 or c['mode']!=0:raise GateError('VP2 OFF lease ended')
   self.command(2,'off')
 def off2(self):
  if self.original[2]['power']==0:return
  deadline=time.monotonic()+180
  while not self.command(2,'off'):
   if time.monotonic()>deadline:raise GateError('VP2 OFF busy')
   time.sleep(2)
  stopped=0
  while time.monotonic()<deadline:
   r=self.capture(2,False);c=r['control']
   if c['state'] in (5,6) or (c['state']==0 and not c['saved']):raise GateError('VP2 OFF failed')
   if c['state']==4 and r['native']['power']==0 and r['base'][3]==1 and r['base'][2]==0:stopped+=1
   else:stopped=0
   if stopped>=2:print('VP2 OFF confirmed',flush=True);return
   if c['state']==4:self.renew2()
   time.sleep(3)
  raise GateError('VP2 failed to stop')
 def run(self,seconds):
  self.off2();until=time.monotonic()+60
  while time.monotonic()<until:
   self.renew2();r=self.capture(1);print('ISOLATED BASELINE',r['base'][2],r['snapshot']['samples']['heat_W'],flush=True)
  deadline=time.monotonic()+90
  while not self.command(1,'effect'):
   self.renew2()
   if time.monotonic()>deadline:raise GateError('EFFECT busy')
   time.sleep(2)
  start=time.monotonic();active=False
  while time.monotonic()-start<seconds:
   self.renew2();r2=self.capture(2,False)
   if r2['native']['power']!=0 or not r2['base'][3] or r2['base'][2]!=0:raise GateError('VP2 no longer isolated')
   r=self.capture(1);r['elapsed']=time.monotonic()-start;self.rows.append(r);c=r['control'];f=r['feedback'];n=r['native'];tele=r['snapshot']['samples']
   if c['state'] in (0,5,6):raise GateError('VP1 ownership/restoration state '+str(c))
   if c['error'] not in (0,2) or n['power']!=1 or n['operating_mode'] not in (0,2,7):raise GateError('Control/native heating guard')
   if n['mode']==1 and n['flow']>3800:raise GateError('Target exceeds38C')
   for key in ('flow_cC','return_cC','compressor_Hz'):
    if tele[key]['status']!=1 or tele[key]['age_ms']>20000:raise GateError('Primary telemetry lost')
   if tele['flow_cC']['value']>4000:raise GateError('Actual flow exceeds40C')
   if f['quality'] not in (0,1,2,8,9):raise GateError('Feedback invalid '+str(f['quality']))
   if c['state']==4:
    active=True
    if c['mode']!=5 or c['applied']!=c['accepted'] or n['mode']!=1:raise GateError('EFFECT not applied')
    if time.monotonic()-self.renewed.get(1,0)>60:self.command(1,'effect')
   elif not active and time.monotonic()-start>120:raise GateError('Initial EFFECT timeout')
   self.log('trial_sample',r)
   print('TRIAL',round(r['elapsed']), 'Hz',r['base'][2],'W',f['short_w'],'targetC',n['flow']/100,'phase',r['effect']['phase'],'quality',f['quality_name'],flush=True)
   time.sleep(2)
 def restore(self,sid):
  if sid not in self.owned:return {'untouched':True}
  end=time.monotonic()+230
  while time.monotonic()<end:
   r=self.capture(sid,False);c=r['control'];n=r['native']
   if c['state']==0 and not c['saved']:
    keys=('power','mode','dhw','boost')
    if any(n[k]!=self.original[sid][k] for k in keys):raise GateError('Restored settings mismatch '+str(sid))
    self.log('restored',r);return {'verified':True,'native':n,'control':c}
   if c['state'] in (4,6) and c['saved']:self.command(sid,'auto')
   time.sleep(2)
  raise GateError('Restoration timeout '+str(sid))
 def finish(self):
  results={}
  for sid in (1,2):
   try:results[sid]=self.restore(sid)
   except BaseException as e:results[sid]={'error':repr(e)}
  (self.out/'restoration.json').write_text(json.dumps(results,indent=2));self.s.stop();print('RESTORATION',results,flush=True)
  if any('error' in x for x in results.values()):raise GateError('Restoration not fully verified')
def main():
 a=argparse.ArgumentParser();a.add_argument('--execute',action='store_true');a.add_argument('--seconds',type=int,default=900);v=a.parse_args()
 if not 60<=v.seconds<=900:raise ValueError('Trial bound')
 out=ROOT/'effect-learning'/('run-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'));t=Trial(out)
 def interrupt(*_):raise KeyboardInterrupt('operator/signal')
 signal.signal(signal.SIGINT,interrupt);signal.signal(signal.SIGTERM,interrupt)
 try:
  t.s.start();t.preflight()
  if v.execute:t.run(v.seconds)
  (out/'outcome.json').write_text(json.dumps({'completed':True,'execute':v.execute,'duration':v.seconds},indent=2))
 except BaseException as e:
  (out/'failure.json').write_text(json.dumps({'error':repr(e)}));raise
 finally:t.finish();print('Evidence',out,flush=True)
if __name__=='__main__':main()
