"""P0080 EFFECT refresh OTA explicitly authorized before dual6kW trial, known D1/D2 identities, no heating-control writes."""
from trial import *
from shelly_ota import system
from ota import plan,crc,decode

NEW=0x784a48ae;OLD=0x982e160b
class UpdateSender(Sender):
 def __init__(self,out,expected):
  super().__init__('DEVICE_HOST','shellypro2-80f3dac8bfec',out);self.expected=expected;self.wait_until=0
 def ready(self,sid):
  st=super().ready(sid)
  if st['uid']!=UID[sid] or st['mode']!=0 or not st['valid'] or st['manifest_crc']!=self.expected[sid]:raise GateError('Known identity/base mismatch')
  # Preserve a reviewable native snapshot before any system command.
  q=Trial.__new__(Trial);q.s=self
  control=q.control(sid);native=q.native(sid)
  if control['state'] or control['saved'] or native['mode']!=2:raise GateError('Not idle native curve')
  self.log({'pre_ota_sid':sid,'control':control,'native':native})
  return st
 def enter(self,sid,cmd):
  seconds=120 if cmd==254 else 900;b=system(sid,cmd,0x80,seconds)
  for _ in range(20):
   r=self.exchange(b)
   if r==b[:6]+crc16(b[:6]):
    if cmd==254:self.wait_until=time.monotonic()+seconds+3;self.log({'wait_sid':sid,'seconds':seconds})
    return
   if r==bytes([sid,0x90,6])+crc16(bytes([sid,0x90,6])):time.sleep(.3);continue
   raise GateError('Ambiguous handoff '+r.hex())
  raise GateError('Handoff remained busy')
 def exchange(self,b,wait=.5):
  if b[:2]==b'P8' and self.wait_until and self.wait_until-time.monotonic()<35:raise GateError('Peer WAIT margin exhausted; stop OTA')
  for attempt in range(3):
   r=super().exchange(b,wait)
   if b[:2]!=b'P8':return r
   try:decode(r,b[2],struct.unpack('<H',b[4:6])[0])
   except ValueError:
    self.log({'retry_exact_frame':b[2:8].hex(),'attempt':attempt});continue
   return r
  raise GateError('Repeated incomplete OTA replies')

def verify(s,sid,expected):
 q=Trial.__new__(Trial);q.s=s
 rows=[]
 deadline=time.monotonic()+65
 while True:
  st=s.status(sid)
  if st['uid']!=UID[sid] or st['manifest_crc']!=expected or st['valid']!=1 or st['mode']!=0:raise GateError('Post-OTA identity/image')
  base=q.read(sid,0,16)
  if base[11]==1 and base[3]==1:break
  if time.monotonic()>deadline:raise GateError('CN105 warmup timeout')
  time.sleep(3)
 for _ in range(2):
  base=q.read(sid,0,16);c=q.control(sid);n=q.native(sid);snap=read_snapshot(lambda a,num:q.read(sid,a,num))
  if base[11]!=1 or base[3]!=1 or c['state'] or c['saved'] or n['mode']!=2:raise GateError('Post-OTA normal operation')
  pump_raw=q.read(sid,87,12);s.log({'pump_diagnostics_sid':sid,'raw87_98':pump_raw});print('PUMP',sid,pump_raw,flush=True)
  row={'sid':sid,'status':st,'base':base,'control':c,'native':n,'snapshot':snap};rows.append(row);s.log({'verified_normal':row})
  print('VERIFIED',sid,'CRC',hex(expected),'Hz',base[2],'snapshot',snap['sequence'],flush=True);time.sleep(8)
 if rows[-1]['base'][5]==rows[0]['base'][5]:raise GateError('CN105 reply counter not advancing')
 return rows

def main():
 out=ROOT/'effect-learning'/('update-startup-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'));out.mkdir()
 p=plan(MOD/'build-effect-rocket',MOD/'build-effect-startup')
 if p['slots']!=[2] or p['expected_manifest_crc']!=OLD or crc(bytes.fromhex(p['manifest'])[:56])!=NEW:raise GateError('Unexpected artifact plan')
 expected={1:OLD,2:OLD};result={}
 for sid in (1,2):
  s=UpdateSender(out/('device'+str(sid)),expected.copy())
  try:
   s.transfer(p,sid,[3-sid])
   outcome=s.out/'outcome.json';info=json.loads(outcome.read_text());info['peers_wait_seconds']=120;outcome.write_text(json.dumps(info,indent=2))
   expected[sid]=NEW;result[sid]=verify(s,sid,NEW)
  finally:s.stop()
  while time.monotonic()<s.wait_until:
   remaining=s.wait_until-time.monotonic();print('WAIT return',3-sid,round(remaining),'seconds',flush=True);time.sleep(min(30,remaining))
  # Verify both units have returned before touching the bus for the next OTA.
  v=UpdateSender(out/('after'+str(sid)),expected.copy())
  try:
   v.start()
   for unit in (1,2):verify(v,unit,expected[unit])
  finally:v.stop()
 (out/'outcome.json').write_text(json.dumps({'verified_both':True,'manifest_crc':hex(NEW),'updated_slots':['mode'],'results':result},indent=2))
 print('BOTH UPDATED',out,flush=True)
if __name__=='__main__':main()
