import sys,json,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'implementation-smart-home/procon/modular/tools'))
from shelly_ota import Sender
from ota import frame,decode,crc
s=Sender('DEVICE_HOST','shellypro2-80f3dac8bfec',ROOT/'snapshot-ota-finish-20261009b')
try:
 s.start();s.ev('baud(115200)')
 def exchange(cmd,seq):
  a=decode(s.exchange(frame(cmd,seq),1.5),cmd,seq)
  assert [a['uid0'],a['uid1'],a['uid2']]==[5898296,909201410,540096578],a
  print(a,flush=True);return a
 st=exchange(5,0);assert (st['next_seq'],st['active']) in ((38,1),(39,0)),st
 a=exchange(4,38);assert a['status']==0 and a['next_seq']==39,a
 a=exchange(6,39);assert a['status']==0 and a['next_seq']==40,a
 s.ev('baud(9600)');time.sleep(3);v=s.status(1)
 assert v['valid']==1 and v['manifest_crc']==crc((ROOT/'implementation-smart-home/procon/modular/release-snapshot/manifest.bin').read_bytes()),v
 (s.out/'outcome.json').write_text(json.dumps({'verified':True,'final':v},indent=2));print(v,flush=True)
finally:s.stop()
