/* P0075 supervised fixed57 + up to16 immediate00 bytes; GPL-3.0-only.
 * Local prefix supplies P75_SESSION and P75_TOKEN. No autostart TX.
 */
let iUart=UART.get(0),iState='idle',iRaw='',iRx=0,iTx=0,iZero=0,iPos=0;
let iStart=0,iLast=0,iTrace=[],iTimer=null;
let iHeader='\x57\x10\x00\x00\x80\x00\x08\xef';
if(!iUart)throw new Error('UART');
function iStop(state){iState=state;if(iTimer!==null){Timer.clear(iTimer);iTimer=null;}}
iUart.recv(function(data){
 if(!data.length)return;
 iRx+=data.length;iRaw+=data.slice(0,128-iRaw.length);
 iStop(iRx>128?'overflow':'response');
});
function iSend(data,kind){
 let n=iUart.send(data);
 iTrace.push({ms:Shelly.getUptimeMs()-iStart,kind:kind,n:n});
 if(typeof n!=='number' || n%1!==0 || n<1 || n>data.length){iStop('send_error');return 0;}
 iTx+=n;iLast=Shelly.getUptimeMs();return n;
}
function iTick(){
 if(iState!=='running')return;
 if(Shelly.getUptimeMs()-iStart>1000){iStop('deadline');return;}
 if(iPos<iHeader.length){iPos+=iSend(iHeader.slice(iPos),'header');return;}
 if(iZero<16){if(iSend('\x00','zero')===1)iZero++;return;}
 if(Shelly.getUptimeMs()-iLast>=250)iStop('no_response');
}
HTTPServer.registerEndpoint('readback',function(req,res){
 res.headers=[['Content-Type','application/json'],['Cache-Control','no-store']];
 res.code=400;res.body='{"error":"REQUEST"}';
 try{
  if(req.method==='POST' && typeof req.body==='string' && req.body.length<=512){
   let q=JSON.parse(req.body);
   if(q.session!==P75_SESSION || q.token!==P75_TOKEN){res.code=403;res.body='{"error":"AUTH"}';}
   else if(q.op==='status' || q.op==='start' || q.op==='stop'){
    if(q.op==='stop')iStop('stopped');
    if(q.op==='start' && q.seq===1 && iState==='idle'){
     iState='running';iStart=Shelly.getUptimeMs();
     iTimer=Timer.set(10,true,iTick);iTick();
    }
    res.code=200;res.body=JSON.stringify({state:iState,sent:iTx,zeros:iZero,received:iRx,base64:btoa(iRaw),trace:iTrace});
   }
  }
 }catch(e){iStop('exception');}
 res.send();
});
