/* P0075 experimental read hypothesis, NOT a validated flash protocol. GPL-3.0-only. */
function makeProbeCore(io,session,token){
  if(!session || typeof token!=='string' || token.length<32)throw new Error('AUTH_CONFIG');
  let frame='\x57\x10\x00\x00\x80\x00\x08\xef';
  let variant=io.variant || 'sum8';
  if(variant==='crc32-sum8')frame='\x57\x10\x00\x00\x80\x00\x08\x6e\x99\x26\x97\xb3';
  else if(variant!=='sum8')throw new Error('VARIANT');
  let state='idle',raw='',count=0,tx=0,start=0,created=io.now(),error='';
  function result(){return {state:state,raw:raw,received:count,sent:tx,error:error,hypothesis:'length16-absolute08008000-'+variant};}
  function fail(e){state='silent';error=e;}
  function tick(){
    if(state==='idle' && io.now()-created>=900000)fail('EXPIRED');
    if(state!=='waiting')return;
    if(io.now()-start>=3000){state=count?'captured_unvalidated':'no_response';return;}
    if(tx<frame.length){
      let n=io.send(frame.slice(tx));
      if(typeof n!=='number' || n%1!==0 || n<0 || n>frame.length-tx){fail('SEND_ERROR');return;}
      tx+=n;
    }
  }
  function receive(data){
    if(typeof data!=='string'){fail('NON_BINARY');return;}
    if(data.length===0)return;
    if(state!=='waiting' || tx!==frame.length){fail('UNSOLICITED_OR_EARLY');return;}
    for(let i=0;i<data.length;i++)if(data.charCodeAt(i)>255){fail('NON_BINARY');return;}
    count+=data.length;let remaining=128-raw.length;
    raw+=data.slice(0,remaining);
    if(data.length>remaining)fail('RX_OVERFLOW');
  }
  function request(s,t,n,op){
    if(s!==session || t!==token)throw new Error('AUTH');
    if(n!==1 || (op!=='probe' && op!=='status' && op!=='stop'))throw new Error('REQUEST');
    tick();
    if(op==='stop'){fail('STOPPED');return result();}
    if(op==='probe' && state==='idle'){state='waiting';start=io.now();tick();}
    return result();
  }
  return {request:request,receive:receive,tick:tick};
}
