/* P0075 discovery adapter GPL-3.0-only.
 * Prepend local P75_SESSION/P75_TOKEN constants; never commit generated secrets.
 * Requires hardware-qualified Serial100 js_uart -> UART0, 1152008N1.
 * No autostart, configuration writes, device reboot or automatic discovery.
 */
let p75uart=UART.get(0);
if (!p75uart) throw new Error('UART_UNAVAILABLE');
let p75core=makeReadbackCore({now:function(){return Shelly.getUptimeMs();},
  send:function(s){return p75uart.send(s);}},P75_SESSION,P75_TOKEN);
p75uart.recv(function(data){p75core.receive(data);});
Timer.set(100,true,function(){p75core.tick();});
HTTPServer.registerEndpoint('readback',function(req,res){
  res.headers=[['Content-Type','application/json'],['Cache-Control','no-store']];
  if(req.method!=='POST' || typeof req.body!=='string' || req.body.length>512){
    res.code=400;res.body='{"error":"REQUEST"}';res.send();return;
  }
  try {
    let q=JSON.parse(req.body);
    if(!q || q.session!==P75_SESSION || q.token!==P75_TOKEN){
      res.code=403;res.body='{"error":"AUTH"}';res.send();return;
    }
    let r=p75core.request(q.session,q.token,q.seq,q.op);
    r.base64=btoa(r.raw);r.raw='';
    res.code=200;res.body=JSON.stringify(r);
  } catch(e) {res.code=400;res.body='{"error":"REJECTED"}';}
  res.send();
});
