/* P0075 discovery-only core, GPL-3.0-only. No endpoint, UART mapping or autostart.
 * Inject clock(ms)/send(binary string) only after separate hardware qualification.
 * No arbitrary frame endpoint. Read 0x57 remains BLOCKED_READ_PROTOCOL.
 */
function makeReadbackCore(io, session, token) {
  if (!session || typeof token !== 'string' || token.length < 32) throw new Error('auth config');
  let seq=0, state='idle', rx='', pending=false, sentAt=0, last=io.now(), high=0, reason='';
  function stop(why) { state='silent'; pending=false; rx=''; reason=why; }
  function result() { return {seq:seq,state:state,raw:rx,high_water:high,error:reason}; }
  function tick() {
    let now=io.now();
    if (state==='silent') return;
    if (now-last>=(seq===0?900000:60000) || now<last) {stop('SESSION_EXPIRED');return;}
    if (state==='waiting' && now-sentAt>=3000) {stop('TIMEOUT');return;}
    if (pending) {
      let n=io.send('\x5a');
      if (n===1) pending=false;
      else if (n!==0) stop('SEND_ERROR');
    }
  }
  function receive(data) {
    if (state==='silent' || data==='') return;
    if (state!=='waiting' || pending) {stop('UNSOLICITED_OR_ECHO');return;}
    if (typeof data!=='string' || data.length>12-rx.length) {stop('RX_OVERFLOW');return;}
    for(let i=0;i<data.length;i++) if(data.charCodeAt(i)>255) {stop('NON_BINARY');return;}
    rx+=data;if(rx.length>high)high=rx.length;
    if (rx.length && rx.charCodeAt(0)!==0x7a) {stop('HEADER_OR_ECHO');return;}
    if(rx.length===12) {
      let sum=0;for(let i=0;i<11;i++)sum+=rx.charCodeAt(i);
      if((sum&255)!==rx.charCodeAt(11)){stop('CHECKSUM');return;}
      state='ready';
    }
  }
  function request(s,t,n,op) {
    if (s!==session || t!==token) throw new Error('UNAUTHORIZED');
    tick();
    if (typeof n!=='number' || n%1!==0 || n<0 || n>65535 || (n===0 && op!=='status')) throw new Error('SEQUENCE');
    if (op!=='discover' && op!=='status' && op!=='ack' && op!=='stop') throw new Error('BLOCKED_READ_PROTOCOL');
    if(op==='stop'){stop('STOPPED');return result();}
    if(state==='silent')return result();
    if(n===seq) {
      if(op==='ack' && state==='ready'){rx='';state='acked';}
      last=io.now();return result(); /* lost network reply never repeats UART send */
    }
    if(op!=='discover' || n!==seq+1 || (state!=='idle' && state!=='acked')) throw new Error('BUSY_OR_SEQUENCE');
    if (n>20) {stop('ATTEMPT_LIMIT');return result();}
    seq=n;state='waiting';rx='';pending=true;sentAt=last=io.now();tick();return result();
  }
  return {request:request,receive:receive,tick:tick};
}
