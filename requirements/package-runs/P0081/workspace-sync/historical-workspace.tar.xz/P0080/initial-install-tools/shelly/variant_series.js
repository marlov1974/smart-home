/* P0075 bounded hypothesis series GPL-3.0-only. Prefix supplies fixed P75_FRAMES,
 * P75_SESSION/P75_TOKEN. Only listed57 frames and5A; no arbitrary payload API. */
let vUart=UART.get(0),vSeq=0,vState='idle',vKind='',vRaw='',vRx=0,vTx=0,vFrame='';
let vAt=0,vSeen=0,vDiscoveries=0,vGate=false,vHalt=false,vFirstRx=-1,vCallbacks=0;
if(!vUart)throw new Error('UART');
function vFail(s){vState=s;vHalt=true;vGate=false;}
function vTick(){
 if(vState!=='waiting')return;
 if(Shelly.getUptimeMs()-vAt>=3000){
  if(vKind==='discovery')vFail('discovery_timeout');
  else if(vTx!==vFrame.length)vFail('partial_send');
  else if(vRx && typeof P75_DISCOVERY_PROBES!=='undefined' && P75_DISCOVERY_PROBES){
   if(vRx%12){vFail('control_framing');return;}
   for(let o=0;o<vRx;o+=12){let sum=0;for(let j=0;j<11;j++)sum+=vRaw.charCodeAt(o+j);
    if(vRaw.charCodeAt(o)!==0x7a || (sum&255)!==vRaw.charCodeAt(o+11)){vFail('control_checksum');return;}}
   vState='captured_discovery';
  } else vState='no_response';
  return;
 }
 // A delayed tail is a separate UART burst, not the reviewed fixed frame.
 // Earlier captured trials reported full send lengths; their interpretation is unchanged.
 if(vTx<vFrame.length){let remaining=vFrame.length-vTx,n=vUart.send(vFrame.slice(vTx));
  if(typeof n!=='number'||n%1!==0||n<0||n>remaining){vFail('send_error');return;}
  vTx+=n;
  if(n!==remaining){vFail('partial_send');return;}
 }
}
vUart.recv(function(data){
 if(!data.length)return;
 if(vFirstRx<0)vFirstRx=Shelly.getUptimeMs()-vAt;vCallbacks++;
 vRx+=data.length;vRaw+=data.slice(0,128-vRaw.length);
 if(vRx>128){vFail('overflow');return;}
 if(vState!=='waiting'||vTx!==vFrame.length){vFail('unexpected_rx');return;}
 if(vKind!=='discovery'){if(typeof P75_DISCOVERY_PROBES==='undefined'||!P75_DISCOVERY_PROBES)vFail('probe_response');return;}
 if(vRaw.charCodeAt(0)!==0x7a||vRaw.length>12){vFail('discovery_framing');return;}
 if(vRaw.length===12){let sum=0;for(let j=0;j<11;j++)sum+=vRaw.charCodeAt(j);
  if((sum&255)!==vRaw.charCodeAt(11)){vFail('discovery_checksum');return;}
  vState='ready';vGate=true;
 }
});
Timer.set(100,true,vTick);
HTTPServer.registerEndpoint('readback',function(req,res){
 res.headers=[['Content-Type','application/json'],['Cache-Control','no-store']];
 res.code=400;res.body='{"error":"REQUEST"}';
 try{
  if(req.method==='POST'&&typeof req.body==='string'&&req.body.length<=512){
   let q=JSON.parse(req.body);
   if(!q||q.session!==P75_SESSION||q.token!==P75_TOKEN){res.code=403;res.body='{"error":"AUTH"}';}
   else if(q.op==='status'||q.op==='send'||q.op==='stop'){
    vTick();
    if(q.op==='stop')vFail('stopped');
    if(q.op==='send'&&!vHalt&&q.seq===vSeq+1&&vState!=='waiting'){
     let frame='',allowed=false;
     if(q.variant==='discovery'&&vDiscoveries<17){frame='\x5a';vDiscoveries++;allowed=true;}
     else if(typeof q.variant==='number'&&q.variant%1===0&&q.variant>=0&&q.variant<P75_FRAMES.length&&q.variant<16&&vGate&&!(vSeen&(1<<q.variant))){
      frame=P75_FRAMES[q.variant];vSeen|=1<<q.variant;allowed=true;
     }
     if(allowed){vSeq=q.seq;vKind=q.variant;vFrame=frame;vRaw='';vRx=0;vTx=0;vFirstRx=-1;vCallbacks=0;vAt=Shelly.getUptimeMs();vGate=false;vState='waiting';vTick();}
    }
    res.code=200;res.body=JSON.stringify({seq:vSeq,state:vState,variant:vKind,sent:vTx,received:vRx,base64:btoa(vRaw),halt:vHalt,first_rx_ms:vFirstRx,callbacks:vCallbacks});
   }
  }
 }catch(e){vFail('exception');}
 res.send();
});
