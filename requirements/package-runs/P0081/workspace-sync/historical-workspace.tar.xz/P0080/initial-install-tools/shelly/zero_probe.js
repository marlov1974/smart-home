/* P0075 operator-authorized parser-completion probe. GPL-3.0-only.
 * Local prefix supplies P75_SESSION/P75_TOKEN. Only byte00, at most16 sends.
 */
let zUart=UART.get(0), zSeq=0,zSent=0,zRaw='',zTotal=0,zState='idle',zLast=-1000;
if(!zUart)throw new Error('UART');
zUart.recv(function(data){
  zTotal+=data.length;
  if(data.length){zRaw+=data.slice(0,128-zRaw.length);zState=zTotal>128?'overflow':'response';}
});
HTTPServer.registerEndpoint('readback',function(req,res){
 res.headers=[['Content-Type','application/json'],['Cache-Control','no-store']];
 res.code=400;res.body='{"error":"REQUEST"}';
 try{
  if(req.method==='POST' && typeof req.body==='string' && req.body.length<=512){
   let q=JSON.parse(req.body);
   if(q.session!==P75_SESSION || q.token!==P75_TOKEN){res.code=403;res.body='{"error":"AUTH"}';}
   else if(q.op==='status' || q.op==='zero'){
    if(q.op==='zero' && zState==='idle'){
     if(q.seq===zSeq+1 && zSeq<16 && Shelly.getUptimeMs()-zLast>=500){
      zSeq=q.seq;zLast=Shelly.getUptimeMs();
      let n=zUart.send('\x00');
      if(n===1)zSent++;else zState='send_error';
      if(zSeq===16 && zState==='idle')zState='limit';
     }
    }
    res.code=200;res.body=JSON.stringify({seq:zSeq,sent:zSent,state:zState,received:zTotal,base64:btoa(zRaw)});
   }
  }
 }catch(e){}
 res.send();
});
