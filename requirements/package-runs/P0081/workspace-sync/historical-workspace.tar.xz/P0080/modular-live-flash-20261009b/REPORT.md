# P0080 modular EFFECT initial installation — 2026-10-09

Operator confirmed DIP00000000 and authorized update. Bootloader discovery succeeded. The reviewed P0076 uploader was copied into ../initial-install-tools; only linked-image validation limit/message changed from20480 to53312 bytes for the verified modular image. Application erase envelope remains98304 bytes, original bootloader excluded. Frame payload240 bytes, maximum wire252 bytes.

Full application erase received direct71 ACK. All223 program packets received direct73 ACK, total53312 bytes. No retries or option-byte writes. Completed17:18:27 UTC. Image SHA256:7e6193edad6aaeb92c3a03468a1e28fb04764dd48a16f9da3f7bdc4b9c03fc24.

Cleanup verified: maintenance script stopped/disabled, all scripts stopped/disabled, relays off, persisted serial remains js_uart1152008N1. No normal boot or flash readback yet. This proves transfer acknowledgement only, not physical chunk OTA operation. The previous MVP3 flash-test application and test cell in the application erase envelope have been replaced/erased by this authorized installation.

Next operator step: power off Procon, restore DIP10000110, power on. Then read resident FC04 raw384/count16 to check B180/protocol1/full-set-valid/layout/manifestCRC/UID and read normal telemetry without issuing a control lease.
