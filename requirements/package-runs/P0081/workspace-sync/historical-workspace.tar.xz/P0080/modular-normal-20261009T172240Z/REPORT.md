# P0080 physical normal-boot verification — 2026-10-09

Operator restored normal DIP and restarted. Read-only FC04 via temporary Shelly UART helper at9600. All three resident status reads: B180/protocol1, valid1, normal mode0, layout3833993797, manifest CRC3241876207 matching complete release manifest. UID5898296/909201410/540096578. P76 revision2/API1/features15 identity and DIP address1 valid.

CN105 linked1, error0/UART error0, handshake count1. Uptime92→105→119 seconds, replies13→15→16, bytes3879→4363→4913. Telemetry generations advance (standard13→15→17, brine6→7→8). No resets observed in this interval.

Observed compressor20Hz; brine5/5C; flow32C; return30.5C; water flow13L/min; DHW51.5C; outdoor7C; target30.5C. These are device-reported readings, not independent sensor calibration. Calculated water-side thermal power approximately1358W in valid samples. One non-atomic snapshot caught invalid power sentinel before status/generation read later changed; do not interpret that sentinel as actual power. Brine pump status/step unavailable as before.

Control state0/lease0 and EFFECT phase0: no commanded effect target, no control writes. This verifies modular startup and telemetry, not closed-loop control or a physical per-chunk OTA transaction. Initial check script compared whole-manifest CRC with stored payload CRC; corrected the verifier only and successful rerun matched whole-manifest CRC.

Cleanup verified: runtime UART restored115200, helper stopped/disabled, all scripts stopped/disabled and relays off. Raw reads and timestamps in rpc.jsonl/samples.json/result.json.
