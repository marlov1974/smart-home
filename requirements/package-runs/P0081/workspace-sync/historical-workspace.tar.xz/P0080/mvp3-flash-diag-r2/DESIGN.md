# P0080 MVP3 flash test addendum

Direct operator request authorizes build of two diagnostic features. No live flash, device request or control in this step. MVP3 r3 source is copied, not replaced in G2/P79/P80 feasibility work.

Reserve page63 at0x0801F800..0x0801FFFF within exercised96KiB application envelope and outside linked16KiB code. Linker assertions forbid overlap. A candidate installer must erase full app envelope; test page contents are disposable. Not an unused location in vendor firmware! Only valid after this candidate is installed.

FC16 addr400 qty4: magic0xF180, sequence1..8, value high16/low16. Fresh write erases the fixed2KiB page and programs value/inverse in one8-byte doubleword, then verifies. Never accepts a caller address. Exact duplicate sequence/value returns cached outcome; mismatch/out-of-order rejected. Up to8 attempts per boot. Active control or CN105 transaction returns busy before mutation. No AUTO or other heat-control commands added.

FC04 addr400 qty16 reads hardware and value directly. Gate CPU family0x435, density128/256, RDP0, WRP/PCROP nonoverlap, idle flash controller; never change protections. Writer, busy loops and literals execute from copied RAM section. TIM2 elapsed timeout, watchdog feed, interrupts saved/masked, cache flush, lock on safe completion. If controller stays busy, request MCU reset from RAM; never return to flash. Fault handler preserves DE-off/default reset behavior; torn-cell ECC recovery is NOT claimed. No flash read/write automatically at boot.

Functions: ft_command validates envelope/dedup/rate/idle then invokes writer; ft_snapshot samples fixed record and status; ft_program_ram erases/programs fixed page; ft_wait_ram services watchdog/timer; protocol integration handles only exact new ranges. Tests: host protocol cases and actual ARM ELF with flash-register mock; baseline tests; image/RAM closure checks; deterministic build. Hardware procedure remains separate.
