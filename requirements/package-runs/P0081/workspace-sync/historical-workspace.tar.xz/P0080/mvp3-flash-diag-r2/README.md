# MVP3 flash diagnostics r2

Adds read-only FC04 raw416, exactly16 words. Existing400 block reports revision2.
All previous flash protection gates and fixed-page writer remain unchanged.
No option bytes are changed and no test write occurs on boot.

Pairs416/417 through430/431 are uint32 high-word first:
IDCODE, flash size KiB, FLASH_OPTR, WRP1AR, WRP1BR, PCROP1SR,
PCROP1ER, diagnostic reason mask.
Mask bits: 0 RDP not AA; 1 WRP1A covers page; 2 WRP1B covers page;
3 PCROP overlaps; 4 family mismatch; 5 density mismatch; 6 controller busy.
This exposes the current gate interpretation without relaxing it.

Based on MVP3 flash-test r1. This is not the P76 effect controller.
