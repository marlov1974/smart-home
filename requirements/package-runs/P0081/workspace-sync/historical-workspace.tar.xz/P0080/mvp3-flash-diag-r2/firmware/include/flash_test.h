/* P0080 directly requested MVP3 fixed-page diagnostic. */
#ifndef FLASH_TEST_H
#define FLASH_TEST_H
#include <stdint.h>
#define FT_ADDRESS 0x0801f800u
#define FT_PAGE 63u
enum { FT_NONE,FT_OK,FT_ID,FT_DENSITY,FT_PROTECTED,FT_BUSY,FT_UNLOCK,FT_ERASE,FT_PROGRAM,FT_VERIFY,FT_LIMIT };
uint8_t ft_command(const uint16_t words[4]);
void ft_diagnostics(uint16_t words[16]);
void ft_snapshot(uint16_t words[16]);
uint32_t ft_gate(void);
uint32_t ft_program_ram(uint32_t value);
#endif
