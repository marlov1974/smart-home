/* P0080. No arbitrary addresses, options, boot writes or automatic boot test. */
#include "flash_test.h"
#include "cn105.h"
#include "platform.h"
#define REG(a) (*(volatile uint32_t *)(uintptr_t)(a))
#define F 0x40022000u
#define SR REG(F+0x10u)
#define CR REG(F+0x14u)
#define ACR REG(F)
#define ERR 0xc3fau
#define BUSY (1u<<16)
#define LOCK (1u<<31)
#define RAMFN __attribute__((section(".ramfunc"),noinline))
static uint32_t last_value,elapsed,last_sr;
static uint16_t sequence,attempts,status;
static uint8_t outcome;
#ifndef FLASH_TEST_HOST
static int protected_page(uint32_t r) {
    unsigned start=r&127u,end=(r>>16)&127u;
    return start<=end && FT_PAGE>=start && FT_PAGE<=end;
}
uint32_t ft_gate(void) {
    if((REG(0xe0042000u)&0xfffu)!=0x435u)return FT_ID;
    uint16_t kb=*(volatile uint16_t *)(uintptr_t)0x1fff75e0u;
    if(kb!=128 && kb!=256)return FT_DENSITY;
    if((REG(F+0x20)&255u)!=0xaau)return FT_PROTECTED;
    if(protected_page(REG(F+0x2c)) || protected_page(REG(F+0x30)))return FT_PROTECTED;
    uint32_t start=(REG(F+0x24)&32767u)*8u;
    uint32_t end=(REG(F+0x28)&32767u)*8u+7u;
    if(start<=end && start<0x20000u && end>=0x1f800u)return FT_PROTECTED;
    if((SR&BUSY) || (CR&0x40007u))return FT_BUSY;
    return 0;
}
static RAMFN void reset_busy(void) {
    /* Do not return into flash if BSY never clears. No retry after reset. */
    REG(0xe000ed0cu)=0x05fa0004u;
    __asm volatile("dsb\nisb" ::: "memory");
    for(;;)__asm volatile("nop");
}
static RAMFN void wait_flash(void) {
    uint32_t t=REG(0x40000024u);
    while(SR&BUSY){
        REG(0x40003000u)=0xaaaau;
        if(REG(0x40000024u)-t>2000000u)reset_busy();
    }
}
uint32_t RAMFN ft_program_ram(uint32_t value) {
    uint32_t primask,acr=ACR,result=FT_OK;
    __asm volatile("mrs %0,primask\ncpsid i":"=r"(primask)::"memory");
    ACR=acr&~0x600u;
    __asm volatile("dsb\nisb" ::: "memory");
    if(CR&LOCK){REG(F+8)=0x45670123u;REG(F+8)=0xcdef89abu;}
    if(CR&LOCK){result=FT_UNLOCK;goto finish;}
    SR=ERR|1u;
    CR=(CR&~0x3fbu)|2u|(FT_PAGE<<3);
    CR|=1u<<16;
    wait_flash();
    CR&=~0x3fau;
    if(SR&ERR){result=FT_ERASE;goto finish;}
    SR=ERR|1u;
    CR|=1u;
    REG(FT_ADDRESS)=value;
    __asm volatile("isb" ::: "memory");
    REG(FT_ADDRESS+4)=~value;
    wait_flash();
    CR&=~1u;
    if(SR&ERR)result=FT_PROGRAM;
finish:
    CR|=LOCK;
    /* Cache reset while both caches disabled, then restore prior configuration. */
    ACR=(acr&~0x600u)|0x1800u;
    ACR=acr&~0x600u;
    ACR=acr;
    __asm volatile("dsb\nisb\nmsr primask,%0"::"r"(primask):"memory");
    return result;
}
static uint32_t read_word(unsigned n){return REG(FT_ADDRESS+4*n);}
static uint32_t read_sr(void){return SR;}
#else
extern uint32_t ft_host_read(unsigned);
extern uint32_t ft_host_sr(void);
#define read_word ft_host_read
#define read_sr ft_host_sr
#endif
uint8_t ft_command(const uint16_t w[4]) {
    uint32_t value=((uint32_t)w[2]<<16)|w[3];
    if(w[0]!=0xf180 || !w[1])return 3;
    if(w[1]==sequence)return value==last_value?outcome:3;
    if(w[1]!=(unsigned)sequence+1)return 3;
    if(attempts>=8){status=FT_LIMIT;return 4;}
    if(cn_read(71)!=0 || cn_read(39)!=0)return 6;
    uint32_t gate=ft_gate();if(gate){status=(uint16_t)gate;return 4;}
    sequence=w[1];last_value=value;++attempts;
    uint32_t t=micros();status=(uint16_t)ft_program_ram(value);elapsed=micros()-t;last_sr=read_sr();
    if(status==FT_OK && (read_word(0)!=value || read_word(1)!=~value))status=FT_VERIFY;
    outcome=status==FT_OK?0:4;
    return outcome;
}
void ft_snapshot(uint16_t w[16]) {
    uint32_t gate=ft_gate(),v=0,inv=0,valid=3;
    if(!gate){v=read_word(0);inv=read_word(1);valid=(v==0xffffffffu && inv==0xffffffffu)?0:inv==~v?1:2;}
    w[0]=0xf180;w[1]=2;w[2]=FT_ADDRESS>>16;w[3]=FT_ADDRESS&65535u;
    w[4]=gate?(uint16_t)gate:status;w[5]=attempts;w[6]=sequence;
    w[7]=v>>16;w[8]=v;w[9]=inv>>16;w[10]=inv;w[11]=valid;
    w[12]=elapsed>>16;w[13]=elapsed;w[14]=last_sr>>16;w[15]=last_sr;
}

/* Read-only raw diagnostics, even when the test-page access gate is closed.
 * uint32 pairs, high word first: IDCODE, flash KiB, OPTR, WRP1AR,
 * WRP1BR, PCROP1SR, PCROP1ER, reasons. Never reads the test cell here. */
/* Explicit branches also keep the diagnostic path straightforward to audit. */
#ifndef FLASH_TEST_HOST
__attribute__((optimize("no-if-conversion,no-if-conversion2")))
#endif
void ft_diagnostics(uint16_t w[16]) {
    uint32_t v[8];
    v[7]=0;
#ifndef FLASH_TEST_HOST
    v[0]=REG(0xe0042000u);
    v[1]=*(volatile uint16_t *)(uintptr_t)0x1fff75e0u;
    v[2]=REG(F+0x20);v[3]=REG(F+0x2c);v[4]=REG(F+0x30);
    v[5]=REG(F+0x24);v[6]=REG(F+0x28);
    if((v[2]&255u)!=0xaau)v[7]|=1u;
    if(protected_page(v[3]))v[7]|=2u;
    if(protected_page(v[4]))v[7]|=4u;
    uint32_t start=(v[5]&32767u)*8u,end=(v[6]&32767u)*8u+7u;
    if(start<=end && start<0x20000u && end>=0x1f800u)v[7]|=8u;
    if((v[0]&0xfffu)!=0x435u)v[7]|=16u;
    if(v[1]!=128 && v[1]!=256)v[7]|=32u;
    if((SR&BUSY)||(CR&0x40007u))v[7]|=64u;
#else
    for(unsigned i=0;i<8;++i)v[i]=0;
#endif
    for(unsigned i=0;i<8;++i){w[i*2]=v[i]>>16;w[i*2+1]=v[i];}
}
