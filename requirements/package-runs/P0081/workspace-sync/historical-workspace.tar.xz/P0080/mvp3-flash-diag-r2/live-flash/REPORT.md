# MVP3 flash diagnostics r2 — 2026-10-09

User authorized build and flash and moved Procon to all-off update mode. Discovery and all preflight gates passed. Full98304-byte application erase received71; compact12672-byte image received53/53 direct73 ACKs. Original bootloader range excluded. Transfer finished15:20:44 UTC. Scripts stopped/disabled and cleanup verified.

SHA256: 2e1aca01e2708f51ec82f2a6a71c94af1b95b03470c2fd42748a824037fb5c41

Adds FC04 raw416/16 read-only protection diagnostics; raw400/16 revision now2. No protection changes and no automatic test-page writes. Build and simulated tests documented in ../build/VERIFICATION.json. No flash readback or normal boot verified yet.

Next: operator power off, DIP10000110, power on; verify candidate revision2 and read416/16 before considering any test write.
