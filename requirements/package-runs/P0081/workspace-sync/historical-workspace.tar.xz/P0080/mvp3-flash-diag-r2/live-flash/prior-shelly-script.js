let frames=["AQQAAAAQ8cY=", "AQQARAAEsdw=", "AQQBkAAQ8Bc=", "AQQAtAAQseA=", "ARABkAAECPGAAAESNFZ4fs4=", "ARABkAAECPGAAAKlWg/wRpE="];

let u=UART.get(0),raw='',waiting=false,count=0;
if(!u)throw new Error('NO_UART');
u.recv(function(d){if(waiting){raw+=d;if(raw.length>64)raw=raw.slice(0,65);}});
function begin(){u.configure({baud:9600,format:'8N1'});return true;}
function send(i){if(waiting||i<0||i>=frames.length||count>=50)throw new Error('GATE');raw='';waiting=true;count++;return u.send(atob(frames[i]));}
function result(){waiting=false;return btoa(raw);}
function restore(){waiting=false;u.configure({baud:115200,format:'8N1'});return true;}
Timer.set(120000,false,function(){restore();Shelly.call('Script.Stop',{id:8});});
