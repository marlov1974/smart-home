# R2 normal boot and protection diagnosis — 2026-10-09

Normal boot verified: flash-test revision2, baseline888/72, CN105 linked, compressor24Hz with1-second age, errors0. Only four FC04 requests sent; no FC16 or flash programming. Shelly runtime UART restored115200; all scripts stopped/disabled, relays off.

Raw diagnostics:
- IDCODE 0x10016435
- FLASH_KIB 128
- OPTR 0xFBFFF8BB; RDP byte0xBB (level1)
- WRP1AR 0xFF00FFFF
- WRP1BR 0xFF00FFFF
- PCROP1SR 0xFFFFFFFF
- PCROP1ER 0xFFFF0000
- reason mask0x00000001: exclusively RDP!=AA

The current gate is stopping at its RDP0 requirement. Neither WRP interval nor PCROP overlaps the test page according to the implemented decoder. Attempts/sequence remain0, cell read remains blocked; placeholder zeros do not describe physical flash contents.

ST RM0394/AN5156 distinguish user execution booted from flash from debug/RAM/system-loader boot restrictions. RDP1 alone is not proof that user application self-programming is unavailable. Next implementation should account for permitted execution context while retaining WRP/PCROP gates and never changing option bytes. Physical erase/program/readback and persistence remain unproven.

Reference: https://www.st.com/resource/en/reference_manual/rm0394-stm32l41xxx42xxx43xxx44xxx45xxx46xxx-advanced-armbased-32bit-mcus-stmicroelectronics.pdf
