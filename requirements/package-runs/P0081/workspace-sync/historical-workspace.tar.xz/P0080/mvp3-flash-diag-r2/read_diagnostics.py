"""Read-only r2 protection diagnostics; only FC04 requests."""
import sys,json,time,struct,base64
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parents[1]/'P0076/procon-melcobems-mini-a1m/tools'))
from flash_shelly import FlashSession
sys.path.insert(0,str(ROOT/'tools'))
from flash_test_frame import crc
out=ROOT/('live-test-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
s=FlashSession(host='DEVICE_HOST',device_id='shellypro2-80f3dac8bfec',image=ROOT/'build/procon-mvp.bin',manifest=ROOT/'build/procon-mvp.json',out=out)
out.mkdir()
def frame(b):return b+crc(b)
reads=[(0,16),(68,4),(400,16),(416,16)]
frames=[frame(struct.pack('>BBHH',1,4,a,n)) for a,n in reads]
source='let frames='+json.dumps([base64.b64encode(x).decode() for x in frames])+';\n'+'''
let u=UART.get(0),raw='',waiting=false,count=0;
if(!u)throw new Error('NO_UART');
u.recv(function(d){if(waiting){raw+=d;if(raw.length>64)raw=raw.slice(0,65);}});
function begin(){u.configure({baud:9600,format:'8N1'});return true;}
function send(i){if(waiting||i<0||i>=frames.length||count>=50)throw new Error('GATE');raw='';waiting=true;count++;return u.send(atob(frames[i]));}
function result(){waiting=false;return btoa(raw);}
function restore(){waiting=false;u.configure({baud:115200,format:'8N1'});return true;}
Timer.set(120000,false,function(){restore();Shelly.call('Script.Stop',{id:8});});
'''
changed=False
samples=[]
def ev(code):
 s.record({'eval_code':code})
 v=s.evaluate(code)
 if code.startswith(('send(', 'begin(', 'restore(')) and isinstance(v,str):return json.loads(v)
 return v
def tx(i):
 s.record({'tx_hex':frames[i].hex(),'frame_index':i})
 if ev('send(%d)'%i)!=len(frames[i]):raise RuntimeError('SHORT_SEND')
 time.sleep(.6)
 raw=base64.b64decode(ev('result()'),validate=True)
 s.record({'rx_hex':raw.hex()})
 if len(raw)<5 or raw[-2:]!=crc(raw[:-2]) or raw[0]!=1:raise RuntimeError('BAD_REPLY '+raw.hex())
 if raw[1]&128:return {'exception':raw[2]}
 if i<4:
  n=reads[i][1]
  if len(raw)!=5+2*n or raw[:3]!=bytes([1,4,2*n]):raise RuntimeError('READ_SHAPE')
  v=list(struct.unpack('>'+str(n)+'H',raw[3:-2]))
 else:
  if raw!=frame(frames[i][:6]):raise RuntimeError('WRITE_ACK')
  v='ACK'
 samples.append({'frame':i,'value':v});s.save('samples.json',samples);print(i,v,flush=True);return v
def read(i):
 v=tx(i)
 if isinstance(v,dict):raise RuntimeError(str(v))
 return v
try:
 s.save('preflight.json',s.identity(False))
 (out/'prior.js').write_text(s.read_code());(out/'deployed.js').write_text(source)
 changed=True
 for offset in range(0,len(source),1024):s.rpc('Script.PutCode',{'id':8,'code':source[offset:offset+1024],'append':offset!=0})
 assert s.read_code()==source
 s.rpc('Script.Start',{'id':8});time.sleep(.3)
 s.identity(True);assert ev('begin()') is True
 before=read(0);assert before[:2]==[888,72]
 assert read(1)==[3,1,3,0]
 initial=read(2);assert initial[:4]==[0xf180,2,0x0801,0xf800],initial
 words=read(3)
 names=['IDCODE','FLASH_KIB','OPTR','WRP1AR','WRP1BR','PCROP1SR','PCROP1ER','REASONS']
 decoded={name:(words[2*i]<<16)|words[2*i+1] for i,name in enumerate(names)}
 s.save('result.json',{'success':True,'normal_boot_verified':True,'baseline':before,'flash_status':initial,'diagnostics':decoded,'read_only':True})
 print(json.dumps({k:hex(v) for k,v in decoded.items()}),flush=True)

except BaseException as e:
 s.save('failure.json',{'error':repr(e)});raise
finally:
 if changed:
  try:ev('restore()')
  finally:s.stop()
 print('Evidence:',out,flush=True)
