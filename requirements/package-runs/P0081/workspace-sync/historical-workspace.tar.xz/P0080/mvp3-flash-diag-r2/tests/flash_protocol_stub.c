/* Legacy protocol regression: no hardware backend. */
#include "flash_test.h"
uint8_t ft_command(const uint16_t w[4]){(void)w;return 4;}
void ft_snapshot(uint16_t w[16]){for(unsigned i=0;i<16;i++)w[i]=0;}

void ft_diagnostics(uint16_t w[16]){for(unsigned i=0;i<16;i++)w[i]=0;}
