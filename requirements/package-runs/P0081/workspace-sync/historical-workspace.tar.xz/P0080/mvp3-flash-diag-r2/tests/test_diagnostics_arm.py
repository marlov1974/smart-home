import sys,struct
from pathlib import Path
from test_flash_arm import Board,crc,F
from unicorn import UC_HOOK_MEM_INVALID
from unicorn.arm_const import UC_ARM_REG_PC
p=Path(sys.argv[1])
for scenario,mask in [('ok',0),('rdp',1),('wrp',2),('pcrop',8),('cpu',16),('density',32),('busy',64)]:
 b=Board(p,scenario)
 b.u.hook_add(UC_HOOK_MEM_INVALID,lambda u,access,a,n,v,d: print("INVALID",hex(a),hex(u.reg_read(UC_ARM_REG_PC)),flush=True) or False)
 req=bytes.fromhex('010401a00010');out=b.call(req+crc(req))
 assert out[:3]==bytes([1,4,32])
 w=struct.unpack('>16H',out[3:-2]);v=[w[i]<<16|w[i+1] for i in range(0,16,2)]
 expected=[struct.unpack('<I',b.u.mem_read(a,4))[0] for a in [0xe0042000,F+0x20,F+0x2c,F+0x30,F+0x24,F+0x28]]
 assert [v[0]]+v[2:7]==expected
 assert v[1]==(64 if scenario=='density' else 128) and v[7]==mask,(scenario,v)
 assert not b.erases and not b.stores and not b.keys
 for a,n in [(416,15),(417,16),(415,16)]:
  req=struct.pack('>BBHH',1,4,a,n);out=b.call(req+crc(req));assert out[1:3]==bytes([0x84,2])
 print('PASS read-only diagnostics',scenario,hex(mask))
