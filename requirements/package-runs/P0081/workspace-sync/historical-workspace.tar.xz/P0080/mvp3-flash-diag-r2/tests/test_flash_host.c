#include "flash_test.h"
#include "modbus.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static uint32_t value=0xffffffffu,inverse=0xffffffffu,gate,programs,time_us;
static int active,owner,bad_verify;
uint32_t ft_gate(void){return gate;}
uint32_t ft_host_read(unsigned n){return n?inverse:value;}
uint32_t ft_host_sr(void){return 1;}
uint32_t ft_program_ram(uint32_t v){++programs;value=v;inverse=bad_verify?0:~v;return FT_OK;}
uint16_t cn_read(unsigned a){return a==71?active:a==39?owner:0;}
uint8_t cn_command(const uint16_t w[8]){(void)w;assert(0);return 4;}
uint32_t micros(void){return ++time_us;}
static size_t request(uint16_t seq,uint32_t v,uint8_t *out,size_t cap){
 uint8_t r[]={1,16,1,144,0,4,8,0xf1,0x80,seq>>8,seq,v>>24,v>>16,v>>8,v,0,0};
 uint16_t c=crc16(r,15);r[15]=c;r[16]=c>>8;return modbus_reply(r,sizeof r,out,cap);
}
int main(void){
 uint8_t out[64];uint16_t w[16];
 ft_snapshot(w);assert(w[11]==0&&programs==0);
 assert(request(1,0x12345678,out,7)==0&&programs==0);
 gate=FT_PROTECTED;assert(request(1,1,out,64)==5&&out[2]==4&&programs==0);gate=0;
 active=1;assert(request(1,1,out,64)==5&&out[2]==6&&programs==0);active=0;
 owner=1;assert(request(1,1,out,64)==5&&out[2]==6&&programs==0);owner=0;
 assert(request(2,1,out,64)==5&&out[2]==3&&programs==0);
 assert(request(1,0x12345678,out,64)==8&&programs==1&&crc16(out,8)==0);
 assert(request(1,0x12345678,out,64)==8&&programs==1);
 assert(request(1,123,out,64)==5&&out[2]==3&&programs==1);
 ft_snapshot(w);assert(w[11]==1&&w[7]==0x1234&&w[8]==0x5678&&w[9]==0xedcb&&w[10]==0xa987);
 uint8_t read[]={1,4,1,144,0,16,0,0};uint16_t c=crc16(read,6);read[6]=c;read[7]=c>>8;
 assert(modbus_reply(read,8,out,64)==37&&crc16(out,37)==0&&out[3]==0xf1&&out[4]==0x80);
 read[0]=0; c=crc16(read,6);read[6]=c;read[7]=c>>8;assert(!modbus_reply(read,8,out,64));
 read[0]=1;read[7]^=1;assert(!modbus_reply(read,8,out,64));
 bad_verify=1;assert(request(2,123,out,64)==5&&out[2]==4);ft_snapshot(w);assert(w[4]==FT_VERIFY);
 assert(request(2,123,out,64)==5&&programs==2);bad_verify=0;
 for(unsigned seq=3;seq<=8;seq++)assert(request(seq,seq,out,64)==8);
 assert(programs==8&&request(9,1,out,64)==5&&programs==8);
 puts("PASS flash feature: fixed range, readback, CRC, guards, duplicate, verify error, eight-attempt cap");
}
