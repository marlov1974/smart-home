"""P0080 offline request encoder / response decoder. Never sends anything."""
import argparse,json,struct
def crc(b):
 c=65535
 for v in b:
  c^=v
  for _ in range(8):c=(c>>1)^(0xa001 if c&1 else 0)
 return struct.pack('<H',c)
def main():
 p=argparse.ArgumentParser();s=p.add_subparsers(dest='action',required=True)
 s.add_parser('read');w=s.add_parser('write');w.add_argument('sequence',type=lambda v:int(v,0));w.add_argument('value',type=lambda v:int(v,0));d=s.add_parser('decode');d.add_argument('hex')
 a=p.parse_args()
 if a.action=='decode':
  b=bytes.fromhex(a.hex)
  if len(b)!=37 or b[:3]!=bytes([1,4,32]) or b[-2:]!=crc(b[:-2]):p.error('Expected valid slave1 FC04 sixteen-word response')
  w=struct.unpack('>16H',b[3:-2]);print(json.dumps({'magic':hex(w[0]),'revision':w[1],'address':hex((w[2]<<16)|w[3]),'status':w[4],'attempts':w[5],'sequence':w[6],'value':hex((w[7]<<16)|w[8]),'inverse':hex((w[9]<<16)|w[10]),'valid':w[11],'elapsed_us':(w[12]<<16)|w[13],'flash_sr':hex((w[14]<<16)|w[15])},indent=2));return
 if a.action=='read':b=bytes.fromhex('01 04 01 90 00 10')
 else:
  if not 1<=a.sequence<=8 or not 0<=a.value<=0xffffffff:p.error('sequence1..8; value0..0xffffffff')
  b=bytes.fromhex('01 10 01 90 00 04 08 f1 80')+struct.pack('>HI',a.sequence,a.value)
 print((b+crc(b)).hex(' '))
if __name__=='__main__':main()
