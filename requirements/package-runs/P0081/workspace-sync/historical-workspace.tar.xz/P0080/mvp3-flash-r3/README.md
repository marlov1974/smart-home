# MVP3 flash test r3

Adds read-only FC04 raw416, exactly16 words. Existing400 block reports revision3.
The gate now accepts RDP AA and observed BB. Other RDP bytes, including CC, are rejected.
Debug enabled (DHCSR bit0) or a VTOR different from08008000 rejects access.
These are consistency checks, not independent proof of the hardware boot mode;
normal power-on through the existing flash bootloader remains required.
WRP/PCROP checks and the fixed-page writer remain unchanged.
No option bytes are changed and no test write occurs on boot.

Pairs416/417 through430/431 are uint32 high-word first:
IDCODE, flash size KiB, FLASH_OPTR, WRP1AR, WRP1BR, PCROP1SR,
PCROP1ER, diagnostic reason mask.
Mask bits: 0 RDP neither AA nor BB; 1 WRP1A covers page; 2 WRP1B covers page;
3 PCROP overlaps; 4 family mismatch; 5 density mismatch; 6 controller busy; 7 debug enabled or unexpected VTOR.
RDP protection remains enabled. No option-byte writes are added.
Reference: ST RM0394 and AN5156 permit user flash access after boot from flash at RDP1.
The writer executes its busy loop from RAM after normal flash boot; this is not boot-from-RAM.

Based on MVP3 flash-test r1. This is not the P76 effect controller.
