# Physical flash self-programming verified — MVP3 flash-test r3

2026-10-09, following user-confirmed normal-mode reboot.

- Candidate F180 revision3 verified, control state0, protection reasons0.
- Initial fixed page0x0801F800 record read as FFFFFFFF/FFFFFFFF (erased).
- Sequence1 wrote12345678 and inverseEDCBA987; direct flash readback matched, status1, attempt1.
- Exact duplicate sequence1/value acknowledged; attempts stayed1 and stored record/duration stayed identical. No additional erase according to firmware accounting.
- Sequence2 wroteA55A0FF0 and inverse5AA5F00F; direct flash readback matched, status1, attempt2. Changed bits prove erase/rewrite path is exercised.
- Both reported erase/program durations22123 microseconds (22.123 ms); FLASH_SR0.
- RDP remainsBB, OPTR FBFFF8BB; complete protection diagnostics identical before/after.
- CN105 linked before/after; compressor22 Hz; replies49→52; protocol and UART errors0→0; uptime359→382 seconds. Flow, return and compressor telemetry generations advanced.
- Sole transmitted write type: fixed-page FC16 address400/4. No pump control or option-byte writes.
- Runtime UART restored115200; all Shelly scripts stopped/disabled, relays off.

Result: real-device erase/program/direct-readback and duplicate handling verified. Persistence across a subsequent power cycle is NOT yet verified. Leave DIP10000110 and power-cycle only Procon, then read the record before any further write. Expected A55A0FF0 / 5AA5F00F with counters reset0.

Raw timestamped commands/responses: rpc.jsonl; decoded evidence: result.json and samples.json; final transport state: final-state.json.
