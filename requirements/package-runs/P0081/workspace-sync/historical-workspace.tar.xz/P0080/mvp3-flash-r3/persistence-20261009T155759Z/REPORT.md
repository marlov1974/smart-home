# Power-cycle persistence verified — 2026-10-09

Operator confirmed power cycle of Procon with DIP10000110 unchanged. Four CRC-valid FC04 reads only; no writes.

MVP3 flash-test revision3 confirmed. Fixed address0x0801F800 retains value0xA55A0FF0 and inverse0x5AA5F00F, validity1. Volatile status/attempt/sequence/duration reset to0. Uptime115 seconds, consistent with reboot. This verifies persistence of the previous physical test write across the operator-confirmed power cycle.

CN105 linked, compressor20Hz with0-second sample age, protocol/UART errors0. OPTR remains0xFBFFF8BB (RDP BB), diagnostic reasons0. Scripts stopped/disabled after runtime UART restoration115200; both relays off.

Combined with ../live-test-20261009T155232Z/REPORT.md, fixed-page erase, write, direct readback, rewrite, duplicate accounting and power-cycle persistence are now physically verified. This does not validate a complete OTA bootloader or power-loss recovery during programming.
