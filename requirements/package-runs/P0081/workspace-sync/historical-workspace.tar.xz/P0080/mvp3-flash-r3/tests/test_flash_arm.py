"""P0080 executes actual candidate ELF with mocked FLASH controller, no hardware."""
import struct,sys,json
from pathlib import Path
from elftools.elf.elffile import ELFFile
from unicorn import *
from unicorn.arm_const import *
F=0x40022000;TEST=0x0801f800
def crc(b):
 c=65535
 for v in b:
  c^=v
  for _ in range(8):c=(c>>1)^(0xa001 if c&1 else 0)
 return struct.pack('<H',c)
def frame(seq,v):
 b=bytes.fromhex('01 10 01 90 00 04 08 f1 80')+struct.pack('>HI',seq,v)
 return b+crc(b)
class Board:
 def __init__(self,path,scenario='ok'):
  self.u=u=Uc(UC_ARCH_ARM,UC_MODE_THUMB|UC_MODE_MCLASS)
  for a,n in [(0x08000000,0x40000),(0x20000000,0x10000),(0x40000000,0x30000),(0xe000e000,0x2000),(0xe0042000,0x1000),(0x1fff7000,0x1000)]:u.mem_map(a,n)
  u.mem_write(0x08000000,b'\xff'*0x40000)
  with path.open('rb') as f:
   elf=ELFFile(f)
   for seg in elf.iter_segments():
    if seg['p_type']=='PT_LOAD' and seg['p_filesz']:
     u.mem_write(seg['p_paddr'],seg.data());u.mem_write(seg['p_vaddr'],seg.data())
   self.sym={s.name:s['st_value'] for s in elf.get_section_by_name('.symtab').iter_symbols()}
  self.scenario=scenario;self.cr=0xc0000000;self.sr=0;self.acr=0x600;self.keys=[];self.erases=0;self.stores=[];self.busy=0;self.t=0;self.reset=False
  self.put(0xe0042000,0x435);u.mem_write(0x1fff75e0,struct.pack('<H',128))
  self.put(0xe000ed08,0x08008000);self.put(0xe000edf0,0);self.put(F+0x20,0xaa);self.put(F+0x24,0x7fff);self.put(F+0x28,0);self.put(F+0x2c,0x7f);self.put(F+0x30,0x7f)
  if scenario=='wrp':self.put(F+0x2c,(63<<16)|63)
  if scenario=='pcrop':self.put(F+0x24,0x3f00);self.put(F+0x28,0x3fff)
  if scenario=='rdp1':self.put(F+0x20,0xfbfff8bb)
  if scenario=='rdp2':self.put(F+0x20,0xcc)
  if scenario=='debug':self.put(0xe000edf0,1)
  if scenario=='vtor':self.put(0xe000ed08,0x20000000)
  if scenario=='rdp':self.put(F+0x20,0)
  if scenario=='cpu':self.put(0xe0042000,0)
  if scenario=='density':u.mem_write(0x1fff75e0,struct.pack('<H',64))
  if scenario=='busy':self.sr=1<<16;self.busy=100000
  u.hook_add(UC_HOOK_CODE,self.code);u.hook_add(UC_HOOK_MEM_READ,self.read);u.hook_add(UC_HOOK_MEM_WRITE,self.write)
 def put(self,a,v):self.u.mem_write(a,struct.pack('<I',v))
 def code(self,u,a,n,d):
  if a==0x20003f00:u.emu_stop();return
  if self.busy and self.erases:assert 0x20000000<=a<self.sym['_ramfunc_end'],f'flash execution while busy {a:x}'
 def read(self,u,access,a,n,v,d):
  if self.busy and self.erases and 0x08000000<=a<0x08040000:raise AssertionError('flash data dependency while busy')
  if a==F+0x14:self.put(a,self.cr)
  if a==F:self.put(a,self.acr)
  if a==F+0x10:
   if self.busy:
    if self.scenario!='timeout':self.busy-=1
    if not self.busy:self.sr=(16 if self.scenario=='erase-error' else 8 if self.scenario=='program-error' and self.stores else 1)
   self.put(a,self.sr)
  if a==0x40000024:self.t+=10000;self.put(a,self.t)
 def write(self,u,access,a,n,v,d):
  pc=u.reg_read(UC_ARM_REG_PC)
  if 0x20000000<=a<0x20010000:return
  if a==F+8:
   assert 0x20000000<=pc<self.sym['_ramfunc_end'];self.keys.append(v)
   if len(self.keys)%2==0:
    assert self.keys[-2:]==[0x45670123,0xcdef89ab]
    if self.scenario!='unlock':self.cr&=~(1<<31)
  elif a==F+0x10:self.sr&=~v
  elif a==F:
   if v&0x1800:assert not v&0x600
   self.acr=v
  elif a==F+0x14:
   assert not self.busy
   assert not v&((1<<17)|(1<<18)|(1<<27)|4),'option/fast/mass operation'
   self.cr=v&~(1<<16)
   if v&(1<<16):
    assert (v>>3)&127==63 and v&2 and not v&1
    assert 0x20000000<=pc<self.sym['_ramfunc_end']
    self.erases+=1
    if self.scenario!='erase-error':u.mem_write(TEST,b'\xff'*2048)
    self.busy=4;self.sr=1<<16
  elif TEST<=a<TEST+8:
   assert n==4 and self.cr&1 and not self.cr&(1<<31)
   assert 0x20000000<=pc<self.sym['_ramfunc_end']
   self.stores.append((a,v))
   if len(self.stores)%2==0:
    assert self.stores[-2][0]==TEST and a==TEST+4
    self.busy=4;self.sr=1<<16
  elif a==0x40003000:assert v==0xaaaa
  elif a==0xe000ed0c:self.reset=True;u.emu_stop()
  else:raise AssertionError(f'unexpected write {a:x}')
 def call(self,request):
  u=self.u;u.mem_write(0x20002000,request)
  u.reg_write(UC_ARM_REG_SP,0x20003000);u.reg_write(UC_ARM_REG_LR,0x20003f01)
  for r,v in [(UC_ARM_REG_R0,0x20002000),(UC_ARM_REG_R1,len(request)),(UC_ARM_REG_R2,0x20002200),(UC_ARM_REG_R3,64)]:u.reg_write(r,v)
  u.emu_start(self.sym['modbus_reply'],0,count=300000)
  if self.reset:return b''
  assert u.reg_read(UC_ARM_REG_PC)==0x20003f00
  n=u.reg_read(UC_ARM_REG_R0);assert n<=64
  data=bytes(u.mem_read(0x20002200,n));assert data[-2:]==crc(data[:-2]);return data
def main():
 p=Path(sys.argv[1]);tests=[]
 for scenario in ('ok','rdp1','rdp2','debug','vtor','wrp','pcrop','rdp','cpu','density','busy','unlock','erase-error','program-error','timeout'):
  b=Board(p,scenario);before=bytes(b.u.mem_read(0x08000000,0x1f800));out=b.call(frame(1,0x12345678))
  assert bytes(b.u.mem_read(0x08000000,0x1f800))==before,'non-test flash changed'
  if scenario in ('ok','rdp1'):
   assert out[1]==16 and b.erases==1 and len(b.stores)==2 and b.acr==0x600 and b.cr&(1<<31)
   assert b.call(frame(1,0x12345678))==out and b.erases==1
   r=bytes.fromhex('01 04 01 90 00 10');data=b.call(r+crc(r));w=struct.unpack('>16H',data[3:-2]);assert w[7:12]==(0x1234,0x5678,0xedcb,0xa987,1)
   assert b.call(frame(2,0xabcdef01))[1]==16 and b.erases==2
   # Simulated reset of volatile RAM, retained physical flash record, no boot write.
   fresh=Board(p);fresh.u.mem_write(TEST,bytes(b.u.mem_read(TEST,2048)));data=fresh.call(r+crc(r));w=struct.unpack('>16H',data[3:-2]);assert w[5:9]==(0,0,0xabcd,0xef01) and fresh.erases==0
  elif scenario=='timeout':assert b.reset and b.erases==1 and not b.stores
  else:
   assert out[1:3]==bytes([0x90,4]),(scenario,out.hex())
   if scenario in ('rdp2','debug','vtor','wrp','pcrop','rdp','cpu','density','busy'):assert not b.keys and not b.erases
  tests.append(scenario);print('PASS ARM flash',scenario)
 Path('build/flash-arm-results.json').write_text(json.dumps({'scenarios':tests,'pass':True,'hardware':False},indent=2)+'\n')
if __name__=='__main__':main()
