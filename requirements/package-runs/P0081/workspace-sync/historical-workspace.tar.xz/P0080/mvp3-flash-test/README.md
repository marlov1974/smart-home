# MVP3 flash-test r1 — P0080 experimental addendum

Built from P0072 MVP r3 as explicitly requested. This is **not P0076 EFFECT** and
does not include that later regulator or DIP addressing. Slave1,9600 8N1; ordinary
MVP3 telemetry/control retained. Legacy revision register68 remains3; new exact
FC04 block400/16 identifies this candidate as magicF180, flash-test revision1.

No live action was performed in this build. Physical installation and testing
remain a separate operator handoff. Firmware writes no flash automatically at
startup. P79 and the earlier P80 feasibility package remain unchanged.

## Two features

1. FC16 at raw address400, quantity4: `[0xF180, sequence, value_high16, value_low16]`.
   Sequence starts1 after boot and increases through8. Erases **one fixed2-KiB
   page** at0x0801F800..0x0801FFFF, then programs value and its bitwise inverse as
   a single8-byte double-word. No address parameter, mass erase or option writes.
2. FC04 at raw address400, quantity16: directly reads the fixed flash record plus
   diagnostics. This is a real volatile flash load, not a copy of the command.
   Both value and inverse remain available after restart; counters reset.

Exact repeated latest sequence/value returns its previous result without another
erase. Conflicting/stale/out-of-order sequences fail. Each boot permits at most8
attempts; an erase/program failure consumes the attempt. BUSY/preflight rejection
does not. When control is active or CN105 owns a transaction, Modbus exception6
is returned before writing; retry the unchanged request later. Exception4 means
inspect the read block, not keep blindly retrying. Boot/power loss clears retry
memory, so read current state before issuing a new write after restart.

| Register | Meaning |
|---|---|
|400/401|Magic0xF180 / revision1|
|402/403|Fixed address high/low|
|404|Status:0 untouched,1 verified,2 wrong family,3 density,4 protection,5 flash busy,6 unlock failed,7 erase error,8 program error,9 mismatch,10 limit|
|405/406|Attempt count / last accepted sequence|
|407/408|Value high/low16|
|409/410|Inverse high/low16|
|411|0 erased,1 value/inverse match,2 mismatch,3 read blocked|
|412/413|Last operation duration in microseconds, high/low|
|414/415|Last FLASH_SR high/low|

Example value0x12345678 gives inverse0xEDCBA987. All sixteen words must be read in
one request; other new ranges are rejected. `tools/flash_test_frame.py` encodes
requests/decodes replies offline and has no device/network access.

## Memory and implementation

Application starts0x08008000; linked load12392 B, upper bound0x0800C000.
Test page is outside that bound and inside the historically exercised96-KiB
application envelope. It is **not claimed unused in vendor firmware**. The test
is valid only on this candidate; never send it to another firmware as a guessed
register write. Reflashing erases the test record.

Guard: L43x/44x family ID0x435 and density128/256KiB; this project targets L433.
Family ID alone does not distinguish every device variant. RDP must be0, WRP and
PCROP must not cover the page, controller must be idle. No protection changes.
Writer/busy loops/literals are in308 bytes of SRAM, copied by existing startup.
Timer2 supplies a2-second timeout; watchdog is fed. Persistent BSY requests MCU
reset from RAM instead of returning to flash. Cache state is restored and flash
locked after a completed operation. Interrupt state is preserved. CN105 servicing
is paused during the brief operation; physical latency has not been measured.

No automatic recovery from a torn-cell ECC fault is claimed. A fault may cause
the existing fault/watchdog reset path and a missing reply; boot does not read
the test cell automatically. Do not use this build for power-cut testing. Native
FTC safeties are unchanged; existing MVP3 session restoration limitations remain.

## Verification and physical next step

Passed11 actual-ELF flash mock scenarios: success/read/restart persistence and
duplicate; WRP/PCROP/RDP/family/density gates; busy; failed unlock; erase/program
error; timeout/reset. Mock asserts fixed page only, no flash execution/data reads
while our operation is busy, and no option/mass writes. No real device is modeled
perfectly. Passed host feature tests,4 baseline C suites with ASan/UBSan,
9 baseline Python tests and15 baseline ARM scenarios including AUTO/control.
ELF verifies bounds/vectors; RAM-call/literal closure checked; deterministic
rebuild verified before release. See build/closure.json and flash-arm-results.json.

The release BIN is the full98304-byte envelope for the established vendor updater;
do not substitute a short file unless using the separately controlled full erase
path. Initial install through original bootloader/DIP procedure remains separate.
After install: confirm heartbeat, input0=888, ordinary communication and the new
400/16 marker; record its initial page value. Ensure no active control lease.
Then explicitly write a chosen value, read back value/inverse/status, restart
without reflashing and read again. A second value proves erase+rewrite. Check
ordinary telemetry before/after. Stop on unexpected error. None of these physical
steps has been performed by this build.

References: [ST flash HAL](https://github.com/STMicroelectronics/stm32l4xx-hal-driver/blob/master/Src/stm32l4xx_hal_flash.c),
[L433 device header](https://github.com/STMicroelectronics/cmsis-device-l4/blob/master/Include/stm32l433xx.h),
[L433 datasheet](https://www.st.com/resource/en/datasheet/stm32l433cb.pdf).

Build: `make all TOOLCHAIN=/path/toolchain PYTHON=/path/python-with-pyelftools`.
Tests: baseline binaries and Python tools as in Makefile; flash feature native
test uses `-DFLASH_TEST_HOST` with flash_test.c/modbus.c; ARM tests require Unicorn.
No commit/push or physical deployment in this delivery.
